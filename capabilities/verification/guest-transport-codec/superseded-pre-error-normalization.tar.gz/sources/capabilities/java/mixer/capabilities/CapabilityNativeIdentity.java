// Generated native bridge identity, not an execution grant.
package mixer.capabilities;
public final class CapabilityNativeIdentity {
    private CapabilityNativeIdentity() {}
    public static final String SHA256 = "187a070871e2835c1dd13a49a9c162eea423f53e6ef639003bbe5d76a6e21818";
}
