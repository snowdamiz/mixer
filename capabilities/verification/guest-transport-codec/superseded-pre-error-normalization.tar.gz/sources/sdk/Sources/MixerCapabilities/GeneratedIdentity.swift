// Generated; include this plus toolchain/platform/configuration/dependencies in the installed native runtime fingerprint.
public enum CapabilityNativeIdentity {
    public static let sha256 = "187a070871e2835c1dd13a49a9c162eea423f53e6ef639003bbe5d76a6e21818"
}
