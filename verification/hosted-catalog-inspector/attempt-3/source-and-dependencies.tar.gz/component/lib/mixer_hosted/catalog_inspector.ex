defmodule MixerHosted.CatalogInspector do
  @moduledoc """
  Private point-in-time inspection of the selected authority-only contract.

  Caller supplies its trusted dedicated runtime Repo, before serving protected
  traffic, and owns connection freshness and migration/publication coordination.
  Observed settings cannot establish that a pooled connection has never been
  used. Success is diagnostic metadata, never an authorization capability.
  """
  alias MixerHosted.CatalogInspector.Raw

  @priv Path.expand("../../priv", __DIR__)
  @manifest_path Path.join(@priv, "selected-expected.json")
  @catalog_path Path.join(@priv, "catalog.sql")
  @enforcement_path Path.join(@priv, "enforcement.sql")
  @external_resource @manifest_path
  @external_resource @catalog_path
  @external_resource @enforcement_path
  @manifest_bytes File.read!(@manifest_path)
  @manifest_sha256 "78c0c8a56c6d358eda1e8a183176d5fe7b7e67e9427bdeb4aa1bb308dfaa8e6e"
  if Base.encode16(:crypto.hash(:sha256, @manifest_bytes), case: :lower) != @manifest_sha256,
    do: raise("selected catalog manifest bytes changed")
  @expected Jason.decode!(@manifest_bytes)
  @catalog File.read!(@catalog_path)
  @enforcement File.read!(@enforcement_path)
  @session "SELECT jsonb_build_object('session_user',session_user,'current_user',current_user,'role',current_setting('role'),'database',current_database(),'session_replication_role',current_setting('session_replication_role'),'row_security',current_setting('row_security'),'default_transaction_isolation',current_setting('default_transaction_isolation'),'transaction_isolation',current_setting('transaction_isolation'),'transaction_read_only',current_setting('transaction_read_only'))"
  @budget_ms 5000
  @payload_bytes 4_194_304
  # These are resource ceilings, not a claim that all catalog allocation or
  # server work is bounded. Count only LIMIT+1 rows; never aggregate them here.
  @counts [{"pg_roles", 4096}, {"pg_auth_members", 4096}, {"pg_namespace", 4096},
           {"pg_class", 32768}, {"pg_attribute", 262144}, {"pg_proc", 32768},
           {"pg_constraint", 32768}, {"pg_trigger", 32768}, {"pg_default_acl", 4096},
           {"pg_database", 4096}, {"pg_settings", 4096}, {"pg_parameter_acl", 4096}]
  @preflight "SELECT " <> Enum.map_join(@counts, ",", fn {table, limit} ->
    "(SELECT count(*) FROM (SELECT 1 FROM pg_catalog.#{table} LIMIT #{limit + 1}) AS bounded) <= #{limit}"
  end)
  @state "SELECT pg_backend_pid(), session_user::text, current_user::text, current_setting('role'), current_setting('transaction_isolation'), current_setting('transaction_read_only'), current_setting('row_security'), current_setting('session_replication_role')"

  @type result :: {:ok, %{manifest_sha256: String.t(), snapshot_scope: :point_in_time}} |
                  {:error, :catalog_unavailable | :catalog_mismatch | :malformed_catalog}
  @spec verify(module()) :: result()
  def verify(repo) when is_atom(repo) do
    deadline = System.monotonic_time(:millisecond) + @budget_ms
    owner = self()
    dynamic = repo.get_dynamic_repo()
    if repo.__adapter__() != Ecto.Adapters.Postgres or repo.checked_out?() or repo.in_transaction?(),
      do: unavailable!()
    context = %{repo: repo, dynamic: dynamic, owner: owner, deadline: deadline}
    repo.checkout(fn ->
      # The exact original session comparison is deliberately outside BEGIN:
      # the read-only snapshot's isolation/read-only fields are different.
      fresh = capture!(context, @session, false)
      if fresh !== @expected["fresh_session"], do: throw(:catalog_mismatch)
      [[backend]] = query!(context, "SELECT pg_backend_pid()")
      result = repo.transaction(fn ->
        query!(context, "SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
        budget!(context)
        # Fixed settings revert on success and rollback. No session SET, role,
        # advisory lock, DDL, temp object, or application-data access is used.
        query!(context, "SET LOCAL search_path = pg_catalog")
        query!(context, "SET LOCAL lock_timeout = '250ms'")
        query!(context, "SET LOCAL idle_in_transaction_session_timeout = '5s'")
        assert_state!(context, backend)
        rows = timed_query!(context, @preflight)
        case rows do
          [counts] when length(counts) == length(@counts) ->
            if not Enum.all?(counts, &(&1 === true)), do: unavailable!()
          _ -> unavailable!()
        end
        raw = %{"legacy" => capture!(context, @catalog, true),
                "enforcement" => capture!(context, @enforcement, true),
                "fresh_session" => fresh}
        normalized = Raw.normalize!(raw)
        if normalized !== @expected, do: throw(:catalog_mismatch)
        assert_state!(context, backend)
        budget!(context)
        %{manifest_sha256: @manifest_sha256, snapshot_scope: :point_in_time}
      end, queue: false, timeout: remaining!(context), log: false)
      case result do
        {:ok, metadata} -> budget!(context); {:ok, metadata}
        _ -> unavailable!()
      end
    end, queue: false, timeout: remaining!(context))
  rescue
    _ -> {:error, :catalog_unavailable}
  catch
    kind when kind in [:catalog_unavailable, :catalog_mismatch, :malformed_catalog] -> {:error, kind}
    _, _ -> {:error, :catalog_unavailable}
  end
  def verify(_), do: {:error, :catalog_unavailable}

  defp capture!(context, sql, transaction?) do
    # The accepted SELECT bytes are preserved in resources. The separately
    # tested envelope suppresses oversized payloads before Postgrex/Jason decode.
    body = sql |> String.trim() |> String.trim_trailing(";")
    envelope = "WITH mixer_catalog_capture(value) AS MATERIALIZED (" <> body <>
      ") SELECT CASE WHEN pg_catalog.octet_length(value::text) <= #{@payload_bytes} THEN value::text ELSE NULL END FROM mixer_catalog_capture"
    rows = if transaction?, do: timed_query!(context, envelope), else: query!(context, envelope)
    case rows do
      [[bytes]] when is_binary(bytes) and byte_size(bytes) <= @payload_bytes -> Raw.decode!(bytes)
      _ -> unavailable!()
    end
  end

  defp assert_state!(context, backend) do
    case timed_query!(context, @state) do
      [[^backend, "mixer_hosted_runtime", "mixer_hosted_runtime", "none", "repeatable read", "on", "on", "origin"]] -> :ok
      _ -> unavailable!()
    end
  end
  defp timed_query!(context, sql) do
    ms = remaining!(context)
    query!(context, "SELECT pg_catalog.set_config('statement_timeout', $1, true)", [Integer.to_string(ms) <> "ms"])
    query!(context, sql)
  end
  defp query!(context, sql, params \\ []) do
    remaining = remaining!(context)
    case Ecto.Adapters.SQL.query(context.dynamic, sql, params, queue: false, timeout: remaining,
                               log: false, telemetry_options: [mixer_catalog_inspector: true]) do
      {:ok, %Postgrex.Result{rows: rows}} -> budget!(context); rows
      _ -> unavailable!()
    end
  end
  defp remaining!(context) do
    if self() != context.owner or context.repo.get_dynamic_repo() !== context.dynamic, do: unavailable!()
    ms = context.deadline - System.monotonic_time(:millisecond)
    if ms <= 0, do: unavailable!()
    ms
  end
  defp budget!(context), do: remaining!(context)
  defp unavailable!, do: throw(:catalog_unavailable)
end
