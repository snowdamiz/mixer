#!/usr/bin/env python3
"""Private native interruption fixture, rebuilt public XCTest runner, unchanged owned-instance controller."""
import argparse,hashlib,importlib,json,os,pathlib,signal,subprocess,sys
BASE=pathlib.Path(__file__).resolve().parent;ROOT=BASE.parents[1]
PARENT=ROOT/'verification/apple-toggle-pan-origin-correction'
sys.path.insert(0,str(PARENT))
import harness as inherited
import apps as artifact
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
require=artifact.require
original_manifest=artifact.expected_manifest

def expected_manifest(key):
 return read(BASE/'built-app-manifest.json') if key=='diagnostic' else original_manifest(key)
artifact.expected_manifest=expected_manifest

class CandidateApps:
 CONFIGS=artifact.CONFIGS
 @staticmethod
 def restore(destination,key):
  config=artifact.CONFIGS[key];manifest=expected_manifest(key)
  folder=BASE if key=='diagnostic' else artifact.ORIGINAL/config['folder']
  payload,modes=artifact.archive_payload(folder/'built-app.tar.gz',manifest,config)
  require(not destination.exists() and not destination.is_symlink() and destination.resolve()==destination,'Fresh canonical restore destination required')
  destination.mkdir(parents=True);app=destination/config['app']
  for directory in [app,app/'Frameworks',app/'_CodeSignature']:directory.mkdir(exist_ok=True);directory.chmod(0o755)
  for name,value in payload.items():
   target=app/artifact.relative_name(name);target.write_bytes(value);target.chmod(modes[name])
  return artifact.verify_restored(app,key)
 verify_installed=staticmethod(artifact.verify_installed)

def verify():
 seal=read(BASE/'packet-seal.json')
 require(seal['schema']=='mixer.apple-toggle.native-interruption.1','Wrong native interruption packet')
 for name,digest in seal['files'].items():
  p=ROOT/artifact.relative_name(name);require(p.is_file() and not p.is_symlink() and sha(p)==digest,'Sealed source changed: '+name)
 # A separate process checks the entire unchanged parent source, runner archive,
 # compiled Products, frozen comparator, historical evidence, compiler and tools.
 cmd=[sys.executable,'-B',str(PARENT/'harness.py'),'verify']
 p=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,timeout=60)
 require(p.returncode==0,'Parent verifier failed: '+p.stderr)
 parent=json.loads(p.stdout);require(parent['sealSHA256']=='a12746e44aa43cd1176747a9afc637c102f736a6201ee9b8cb2580f8fefb84ba','Parent identity changed')
 selection=read(BASE/'selection.json');source=BASE/'source'
 actual={str(p.relative_to(source)):sha(p) for p in sorted(source.rglob('*')) if p.is_file() and not p.is_symlink()}
 lock=read(BASE/'source-lock.json');require(actual==lock['sha256'],'Candidate source lock mismatch')
 digest=hashlib.sha256(json.dumps(actual,sort_keys=True,separators=(',',':')).encode()).hexdigest();require(digest==lock['sourceClosureSHA256'],'Candidate closure mismatch')
 changed=sorted(k for k in set(actual)|set(selection['sourceBefore']) if actual.get(k)!=selection['sourceBefore'].get(k))
 require(changed==['Prototype/NativeInterruptionChecks.swift','Prototype/main.swift'],'Candidate escaped fixture-only changes')
 receipt=read(BASE/'receipt.json');manifest=expected_manifest('diagnostic');commands=read(BASE/receipt['buildCommands'])
 require(receipt['sourceClosureSHA256']==digest and receipt['archiveSHA256']==manifest['archiveSHA256'],'Build receipt mismatch')
 require(all(x['exitCode']==0 for x in commands),'Candidate build failed')
 compiled={v.split('/source/',1)[1] for command in commands for v in command['argv'] if '/source/' in v and v.endswith('.swift')}
 require(compiled=={n for n in actual if n.endswith('.swift')},'Exact compile source set mismatch')
 require(all(sha(pathlib.Path(n))==d for n,d in receipt['toolFiles'].items()),'Candidate compiler/tools changed')
 payload,_=artifact.archive_payload(BASE/'built-app.tar.gz',manifest,artifact.CONFIGS['diagnostic'])
 binaries={n:artifact.frozen.macho(payload[n]) for n in [artifact.CONFIGS['diagnostic']['executable'],'Frameworks/libMixerCore.dylib','Frameworks/libMixerUI.dylib']}
 manifest=read(BASE/'build-products-manifest.json')
 require(inherited.tree(inherited.PRODUCTS)==manifest['products'],'Rebuilt runner tree changed')
 inherited.product_archive_payload(manifest)
 require(all(sha(ROOT/n)==d for n,d in manifest['sourceFiles'].items()),'Runner build sources changed')
 require(all(sha(pathlib.Path(n))==d for n,d in manifest['toolFiles'].items()),'Runner tools changed')
 previous=ROOT/'verification/apple-toggle-semantic-activation'
 require(sha(previous/'packet-seal.json')==selection['baselinePacketSealSHA256'],'Baseline semantic seal changed')
 for n,d in read(previous/'packet-seal.json')['files'].items(): require(sha(ROOT/n)==d,'Baseline semantic source changed')
 require(sha(BASE/'source/Prototype/AuthoredToggleCarrier.swift')==sha(previous/'source/Prototype/AuthoredToggleCarrier.swift'),'Carrier changed in fixture slice')
 return {'testRunnerProductTreeSHA256':manifest['productTreeSHA256'],'sealSHA256':sha(BASE/'packet-seal.json'),'candidateSourceClosureSHA256':digest,'candidateArchiveSHA256':manifest['archiveSHA256'],'binaryBuildVersions':binaries,'parent':parent,'changedDiagnosticFiles':changed,'harnessScope':'Sixteen new real public XCTest pan cases; fixture interrupts native pan through closed public app operations','nativeExecution':False}

# Configure copies loaded only in this dedicated process. Parent files remain immutable.
import importlib.util
spec=importlib.util.spec_from_file_location('native_interruption_oracle',BASE/'interruption_oracle.py')
oracle=importlib.util.module_from_spec(spec);spec.loader.exec_module(oracle)
import bridge as inherited_bridge
for name in ['ACTIONS','CASES','CASE_ACTION','CASE_COMMAND_SEQUENCE','COMMANDS','geometry_valid','verdict']:
 setattr(inherited_bridge,name,getattr(oracle,name))
inherited.BASE=BASE
inherited.PRODUCTS=BASE/'build/Build/Products'
inherited.PRODUCT_ARCHIVE=BASE/'test-runner-products.tar.gz'
inherited.packet=CandidateApps
inherited.verify=verify
inherited.SCOPES={'interaction':{'cases':oracle.CASES,'methods':[x['method'] for x in oracle.SPECS.values()]}}
original_summary=inherited.runtime_summary
def summary(*args,**kwargs):
 value=original_summary(*args,**kwargs)
 value['schema']='mixer.apple-toggle.native-interruption-runtime.1'
 value['qualification']='Sixteen private native pan cases only; direct accessibility during real held pan is not physical VoiceOver.'
 return value
inherited.runtime_summary=summary

def main():
 parser=argparse.ArgumentParser();parser.add_argument('action',choices=['verify','run','cleanup']);parser.add_argument('--reviewed-seal');parser.add_argument('--scope',choices=['interaction'],default='interaction');a=parser.parse_args()
 if a.action=='verify':print(json.dumps(verify(),sort_keys=True))
 elif a.action=='run':inherited.run(a.reviewed_seal,a.scope)
 else:
  inherited.RUN_DIR=inherited.select_runtime_directory(a.scope);life=read(inherited.RUN_DIR/'lifecycle.json');require(life['verifiedHandoff']['sealSHA256']==verify()['sealSHA256'],'Recovery identity changed');commands=inherited.Commands(inherited.RUN_DIR/'recovery-commands.json')
  results=inherited.cleanup_independently([('owned-simulator-and-baseline-reconciliation',lambda:inherited.cleanup(life,commands)),('ephemeral-capability-workspace-removal',lambda:inherited.remove_ephemeral(life))]);life.update(cleanedUp=all(v['passed'] for v in results),recoveryCleanupResults=results);inherited.write(inherited.RUN_DIR/'lifecycle.json',life);require(life['cleanedUp'],'Recovery incomplete')
if __name__=='__main__':
 def stop(signum,frame):raise KeyboardInterrupt('Root native interruption harness interruption')
 signal.signal(signal.SIGINT,stop);signal.signal(signal.SIGTERM,stop);main()
