# Private ordinary Android staged C bridge

The checklist engine now exports the existing registry's prepare, commit and
abort decisions through `mixer_android_v2.h`. These functions share its original
create/destroy registry. They forward to the accepted SPI without a second state
machine, output cache or token allocator. The older exchange ABI is unchanged.

Prepare returns caller-owned packet bytes and a nonzero token while retaining
the candidate engine. Modifying or releasing those packet bytes does not modify
the engine. Failure to retain or deliver the packet downstream must abort the
token. A matching commit is allowed only after gated native attachment and final
validation; ambiguous commit outcome requires session/presentation retirement.
One pending token blocks legacy exchange as well as another prepare. Destroy
invalidates the token. The header documents bounds, valid nonoverlapping foreign
pointers, statuses, retry behavior and the engine's value-semantics requirement.

This slice adds private exports to the ordinary checklist library only. JNI,
generated application entry points, Activity coordination and actual native
attachment are separate follow-on work. It does not enable V2 opt-in, change the
signed path, or provide general-purpose rollback for reference state or external
effects. Final hardware and launch qualification remain open.

Verification is pending in `verification/android-engine-v2-c-bridge/`.
