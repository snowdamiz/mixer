//! Isolated draft: literal shared control helpers on the original phase.
//! The future caller owns fetch, cursor, fuel, outer work, pc advance and finish.
#![allow(dead_code, clippy::result_large_err)]
use super::*;
use crate::experimental::cache::ControlKind;

macro_rules! swift_control_leaf {
    (pop $s:ident) => {
        $s.control_pop_value()
    };
    (push $s:ident, $v:expr) => {
        $s.phase.push_value($v)
    };
    (invariant $s:ident) => {
        $s.invariant("swift_control_invariant")
    };
    (values $s:ident) => {
        $s.phase.parts.values
    };
    (controls $s:ident) => {
        $s.phase.parts.controls
    };
    (frame $s:ident, $f:ident) => {
        let $f = $s.control_frame_scalars()?;
    };
    (floor $f:ident) => {
        $f.controls
    };
    (result $c:ident) => {
        $c.result()
    };
    (height $c:ident) => {
        $c.height()
    };
    (loop $c:ident) => {
        $c.is_loop()
    };
    (function $c:ident) => {
        $c.is_function()
    };
    (clear $c:ident) => {
        $c.clear_result()
    };
    (start $c:ident) => {
        $c.start()
    };
    (after_end $s:ident, $c:ident) => {
        $c.end()
            .checked_add(1)
            .ok_or_else(|| $s.invariant("swift_control_after_end"))?
    };
    (depth_offset $s:ident, $d:ident) => {
        usize::try_from($d)
            .ok()
            .and_then(|n| n.checked_add(1))
            .ok_or_else(|| $s.invariant("swift_control_depth_offset"))?
    };
    (truncate_values $s:ident, $h:expr) => {
        $s.control_truncate_values($h)?
    };
    (truncate_controls $s:ident, $h:expr) => {
        $s.control_truncate_controls($h)?
    };
    (observe $s:ident) => {
        $s.agreement()?
    };
    (set_pc $s:ident, $pc:expr) => {
        $s.control_set_pc($pc)?;
    };
    (copy_control $s:ident, $index:ident) => {
        $s.control_branch_copy($index)?
    };
    (selected $s:ident, $target:ident) => {
        $target.expect("prevalidated selected target")
    };
    (room $s:ident) => {
        $s.control_room()
    };
    (depth_limit $s:ident) => {
        $s.phase.parts.cache.proof().decode_policy().control_depth()
    };
    (depth_error $s:ident, $f:ident) => {
        $s.limit(
            SwiftRunFailureKind::ControlLimit,
            SwiftRunResource::Controls,
            "swift_control_depth_exceeded",
            $s.phase.parts.controls.len() - $f.controls + 1,
            $s.phase.parts.cache.proof().decode_policy().control_depth(),
        )
    };
    (publish $s:ident, $kind:ident, $f:ident, $end:ident, $result:ident) => {
        $s.control_publish(
            $kind,
            $f.pc,
            $end,
            $s.phase.parts.values.len(),
            $result.is_some(),
        )?;
    };
    (false_pc $s:ident, $alternative:ident, $end:ident) => {
        let pc = match $alternative {
            Some(alternative) => alternative
                .checked_add(1)
                .ok_or_else(|| $s.invariant("swift_control_alternative_pc"))?,
            None => $end,
        };
        $s.control_set_pc(pc)?;
    };
    (else_pc $s:ident, $end:ident) => {
        $s.control_else($end)?
    };
    (pop_control $s:ident) => {
        $s.control_pop()
    };
    (block_guard $s:ident, $kind:ident, $end:ident, $alternative:ident) => {
        $s.control_block_guard($kind, $end, $alternative)?;
    };
}
impl FrameOperationPhase<'_> {
    crate::experimental::execution::borrowed::shared_control_methods!(
        self,
        SwiftRunFailure,
        swift_control_leaf,
        control,
        {
            self.control_close_guard(control)?;
        }
    );

    /// Preserve the accepted value primitive and its original first failure.
    /// An error after an actual pop is its rejected live removal; retain that debt.
    fn control_pop_value(&mut self) -> Result<Value, SwiftRunFailure> {
        let previous_length = self.phase.parts.values.len();
        let result = self.phase.pop_value();
        if result.is_err() && self.phase.parts.values.len() != previous_length {
            self.cleanup.live_unreconciled = true;
        }
        result
    }

    /// No borrowed frame/pin survives any mutable leaf or accounted operation.
    fn control_frame_scalars(&mut self) -> Result<FrameScalars, SwiftRunFailure> {
        let frame = match self.phase.parts.frames.last() {
            Some(frame) => FrameScalars {
                function: frame.function,
                pc: frame.pc,
                base: frame.base,
                operands: frame.operands,
                controls: frame.controls,
                result: frame.result,
            },
            None => return Err(self.invariant("swift_control_frame_missing")),
        };
        if frame.base > frame.operands
            || frame.operands > self.phase.parts.values.len()
            || frame.controls > self.phase.parts.controls.len()
        {
            return Err(self.invariant("swift_control_frame_floor"));
        }
        Ok(frame)
    }
    fn control_function_bound(&mut self) -> Result<usize, SwiftRunFailure> {
        let frame = self.control_frame_scalars()?;
        let sentinel = match self.phase.parts.controls.get(frame.controls).copied() {
            Some(control) => control,
            None => return Err(self.invariant("swift_control_function_missing")),
        };
        if !sentinel.is_function() || sentinel.height() != frame.operands {
            return Err(self.invariant("swift_control_function_sentinel"));
        }
        let after_end = match sentinel.end().checked_add(1) {
            Some(pc) => pc,
            None => return Err(self.invariant("swift_control_function_bound")),
        };
        if frame.pc > after_end {
            return Err(self.invariant("swift_control_function_pc"));
        }
        Ok(sentinel.end())
    }
    fn control_block_guard(
        &mut self,
        kind: ControlKind,
        end: usize,
        alternative: Option<usize>,
    ) -> Result<(), SwiftRunFailure> {
        let frame = self.control_frame_scalars()?;
        let bound = self.control_function_bound()?;
        if end < frame.pc || end > bound || (kind != ControlKind::If && alternative.is_some()) {
            return Err(self.invariant("swift_control_block_bound"));
        }
        if let Some(alternative) = alternative {
            if alternative < frame.pc || alternative >= end || alternative.checked_add(1).is_none()
            {
                return Err(self.invariant("swift_control_alternative_bound"));
            }
        }
        self.phase
            .parts
            .controls
            .len()
            .checked_sub(frame.controls)
            .and_then(|depth| depth.checked_add(1))
            .ok_or_else(|| self.invariant("swift_control_block_depth"))?;
        Ok(())
    }
    fn control_branch_copy(&mut self, index: usize) -> Result<Control, SwiftRunFailure> {
        let frame = self.control_frame_scalars()?;
        let bound = self.control_function_bound()?;
        let control = match self.phase.parts.controls.get(index).copied() {
            Some(control) if index >= frame.controls => control,
            _ => return Err(self.invariant("swift_control_branch_floor")),
        };
        if control.end() > bound || control.start() > control.end() {
            return Err(self.invariant("swift_control_branch_bound"));
        }
        Ok(control)
    }
    fn control_close_guard(&mut self, control: Control) -> Result<(), SwiftRunFailure> {
        let frame = self.control_frame_scalars()?;
        let height = control.height();
        if height < frame.operands
            || height > self.phase.parts.values.len()
            || (control.result() && height == self.phase.parts.values.len())
        {
            return Err(self.invariant("swift_control_close_floor"));
        }
        Ok(())
    }
    fn control_room(&mut self) -> Result<(), SwiftRunFailure> {
        let length = self.phase.parts.controls.len();
        let capacity = self.phase.parts.controls.capacity();
        if length >= capacity {
            return Err(self.limit(
                SwiftRunFailureKind::ControlLimit,
                SwiftRunResource::ExactCapacity,
                "swift_control_capacity",
                length.saturating_add(1),
                capacity,
            ));
        }
        Ok(())
    }
    fn control_publish(
        &mut self,
        kind: ControlKind,
        start: usize,
        end: usize,
        height: usize,
        result: bool,
    ) -> Result<(), SwiftRunFailure> {
        let control = Control::decoded(kind, start, end, height, result);
        // control_room and checked inclusive-depth admission established room.
        // This is the last fallible admission; publish immediately afterwards.
        self.add_live(Live::Controls)?;
        self.phase.parts.controls.push(control);
        Ok(())
    }
    fn control_remove(&mut self, resource: Live, amount: usize) -> Result<(), SwiftRunFailure> {
        let result = self.phase.operation.control.remove_live_at_with_wasi(
            resource,
            amount,
            self.phase.operation.cursor,
            Some(self.phase.operation.wasi.usage()),
        );
        if result.is_err() {
            self.cleanup.live_unreconciled = true;
        }
        result
    }
    fn control_truncate_values(&mut self, height: usize) -> Result<(), SwiftRunFailure> {
        let removed = self
            .phase
            .parts
            .values
            .len()
            .checked_sub(height)
            .ok_or_else(|| self.invariant("swift_control_values_height"))?;
        self.phase.parts.values.truncate(height);
        self.control_remove(Live::Values, removed)
    }
    fn control_truncate_controls(&mut self, height: usize) -> Result<(), SwiftRunFailure> {
        let removed = self
            .phase
            .parts
            .controls
            .len()
            .checked_sub(height)
            .ok_or_else(|| self.invariant("swift_control_controls_height"))?;
        self.phase.parts.controls.truncate(height);
        self.control_remove(Live::Controls, removed)
    }
    fn control_pop(&mut self) -> Result<Control, SwiftRunFailure> {
        let frame = self.control_frame_scalars()?;
        if self.phase.parts.controls.len() <= frame.controls {
            return Err(self.invariant("swift_control_end_floor"));
        }
        let control = self
            .phase
            .parts
            .controls
            .pop()
            .expect("checked current frame control");
        self.control_remove(Live::Controls, 1)?;
        Ok(control)
    }
    fn control_set_pc(&mut self, pc: usize) -> Result<(), SwiftRunFailure> {
        match self.phase.parts.frames.last_mut() {
            Some(frame) => {
                frame.pc = pc;
                Ok(())
            }
            None => Err(self.invariant("swift_control_pc_frame")),
        }
    }
    fn control_else(&mut self, end: usize) -> Result<(), SwiftRunFailure> {
        let frame = self.control_frame_scalars()?;
        let bound = self.control_function_bound()?;
        let control = match self.phase.parts.controls.last().copied() {
            Some(control) if self.phase.parts.controls.len() > frame.controls => control,
            _ => return Err(self.invariant("swift_control_else_floor")),
        };
        if !control.is_if() || control.end() != end || end < frame.pc || end > bound {
            return Err(self.invariant("swift_control_else_match"));
        }
        self.control_set_pc(end)
    }
    pub(crate) fn control_operation(
        &mut self,
        operation: Operation,
        selected_target: Option<u32>,
    ) -> Result<bool, SwiftRunFailure> {
        let result = self.control_operation_inner(operation, selected_target);
        if result.is_err() {
            self.terminal();
        }
        result
    }
    fn control_operation_inner(
        &mut self,
        operation: Operation,
        selected_target: Option<u32>,
    ) -> Result<bool, SwiftRunFailure> {
        self.active()?;
        self.control_function_bound()?;
        let mut finished = false;
        match operation {
            Operation::Block {
                kind,
                result,
                end,
                alternative,
            } => {
                crate::experimental::execution::borrowed::shared_control_arm!(
                    Block,
                    self,
                    swift_control_leaf,
                    finished,
                    kind,
                    result,
                    end,
                    alternative
                );
            }
            Operation::Else { end } => {
                crate::experimental::execution::borrowed::shared_control_arm!(
                    Else,
                    self,
                    swift_control_leaf,
                    finished,
                    end
                );
            }
            Operation::End => {
                crate::experimental::execution::borrowed::shared_control_arm!(
                    End,
                    self,
                    swift_control_leaf,
                    finished
                );
            }
            Operation::Br(depth) => {
                crate::experimental::execution::borrowed::shared_control_arm!(
                    Br,
                    self,
                    swift_control_leaf,
                    finished,
                    depth
                );
            }
            Operation::BrIf(depth) => {
                crate::experimental::execution::borrowed::shared_control_arm!(
                    BrIf,
                    self,
                    swift_control_leaf,
                    finished,
                    depth
                );
            }
            Operation::BrTable { .. } => {
                let target = selected_target;
                // Validate before consuming selector: selection belongs to caller.
                if target.is_none() {
                    return Err(self.invariant("swift_control_target_missing"));
                }
                crate::experimental::execution::borrowed::shared_control_arm!(
                    BrTable,
                    self,
                    swift_control_leaf,
                    finished,
                    target
                );
            }
            Operation::Return => {
                crate::experimental::execution::borrowed::shared_control_arm!(
                    Return,
                    self,
                    swift_control_leaf,
                    finished
                );
            }
            _ => {
                return Err(self.phase.operation.control.fail(
                    self.phase.operation.cursor,
                    Fault::new(
                        SwiftRunFailureKind::UnsupportedEnvironment,
                        "swift_control_unsupported_operation",
                    ),
                    Some(self.phase.operation.wasi.usage()),
                ))
            }
        }
        Ok(finished)
    }
}
// ACCOUNTING_START
struct PermanentPositions {
    completion_production_18_source: &'static std::option::Option<
        std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    >,
    completion_production_18_argument: &'static std::option::Option<
        std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    >,
    completion_production_18_returned: &'static std::option::Option<
        std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    >,
    completion_production_18_caller: &'static std::option::Option<
        std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    >,
    completion_production_17_source: bool,
    completion_production_17_argument: bool,
    completion_production_17_returned: bool,
    completion_production_17_caller: bool,
    #[cfg(test)]
    completion_unit_18_source: &'static std::option::Option<
        std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    >,
    #[cfg(test)]
    completion_unit_18_argument: &'static std::option::Option<
        std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    >,
    #[cfg(test)]
    completion_unit_18_returned: &'static std::option::Option<
        std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    >,
    #[cfg(test)]
    completion_unit_18_caller: &'static std::option::Option<
        std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    >,
    #[cfg(test)]
    completion_unit_17_source: bool,
    #[cfg(test)]
    completion_unit_17_argument: bool,
    #[cfg(test)]
    completion_unit_17_returned: bool,
    #[cfg(test)]
    completion_unit_17_caller: bool,
    fixed_fixed_caller_slot_source: Option<Result<bool, SwiftRunFailure>>,
    fixed_fixed_caller_slot_argument: Option<Result<bool, SwiftRunFailure>>,
    fixed_fixed_caller_slot_returned: Option<Result<bool, SwiftRunFailure>>,
    fixed_fixed_caller_slot_caller: Option<Result<bool, SwiftRunFailure>>,
    fixed_fixed_caller_result_source: Result<bool, SwiftRunFailure>,
    fixed_fixed_caller_result_argument: Result<bool, SwiftRunFailure>,
    fixed_fixed_caller_result_returned: Result<bool, SwiftRunFailure>,
    fixed_fixed_caller_result_caller: Result<bool, SwiftRunFailure>,
    fixed_fixed_caller_bool_source: bool,
    fixed_fixed_caller_bool_argument: bool,
    fixed_fixed_caller_bool_returned: bool,
    fixed_fixed_caller_bool_caller: bool,
    fixed_fixed_caller_failure_source: SwiftRunFailure,
    fixed_fixed_caller_failure_argument: SwiftRunFailure,
    fixed_fixed_caller_failure_returned: SwiftRunFailure,
    fixed_fixed_caller_failure_caller: SwiftRunFailure,
    fixed_fixed_caller_retained_failure_source: Option<SwiftRunFailure>,
    fixed_fixed_caller_retained_failure_argument: Option<SwiftRunFailure>,
    fixed_fixed_caller_retained_failure_returned: Option<SwiftRunFailure>,
    fixed_fixed_caller_retained_failure_caller: Option<SwiftRunFailure>,
    fixed_prepare_storage_slot_source: Option<Result<bool, SwiftRunFailure>>,
    fixed_prepare_storage_slot_argument: Option<Result<bool, SwiftRunFailure>>,
    fixed_prepare_storage_slot_returned: Option<Result<bool, SwiftRunFailure>>,
    fixed_prepare_storage_slot_caller: Option<Result<bool, SwiftRunFailure>>,
    fixed_prepare_storage_result_source: Result<bool, SwiftRunFailure>,
    fixed_prepare_storage_result_argument: Result<bool, SwiftRunFailure>,
    fixed_prepare_storage_result_returned: Result<bool, SwiftRunFailure>,
    fixed_prepare_storage_result_caller: Result<bool, SwiftRunFailure>,
    fixed_prepare_storage_bool_source: bool,
    fixed_prepare_storage_bool_argument: bool,
    fixed_prepare_storage_bool_returned: bool,
    fixed_prepare_storage_bool_caller: bool,
    fixed_prepare_storage_failure_source: SwiftRunFailure,
    fixed_prepare_storage_failure_argument: SwiftRunFailure,
    fixed_prepare_storage_failure_returned: SwiftRunFailure,
    fixed_prepare_storage_failure_caller: SwiftRunFailure,
    fixed_prepare_storage_retained_failure_source: Option<SwiftRunFailure>,
    fixed_prepare_storage_retained_failure_argument: Option<SwiftRunFailure>,
    fixed_prepare_storage_retained_failure_returned: Option<SwiftRunFailure>,
    fixed_prepare_storage_retained_failure_caller: Option<SwiftRunFailure>,
    fixed_complete_storage_slot_source: Option<Result<bool, SwiftRunFailure>>,
    fixed_complete_storage_slot_argument: Option<Result<bool, SwiftRunFailure>>,
    fixed_complete_storage_slot_returned: Option<Result<bool, SwiftRunFailure>>,
    fixed_complete_storage_slot_caller: Option<Result<bool, SwiftRunFailure>>,
    fixed_complete_storage_result_source: Result<bool, SwiftRunFailure>,
    fixed_complete_storage_result_argument: Result<bool, SwiftRunFailure>,
    fixed_complete_storage_result_returned: Result<bool, SwiftRunFailure>,
    fixed_complete_storage_result_caller: Result<bool, SwiftRunFailure>,
    fixed_complete_storage_bool_source: bool,
    fixed_complete_storage_bool_argument: bool,
    fixed_complete_storage_bool_returned: bool,
    fixed_complete_storage_bool_caller: bool,
    fixed_complete_storage_failure_source: SwiftRunFailure,
    fixed_complete_storage_failure_argument: SwiftRunFailure,
    fixed_complete_storage_failure_returned: SwiftRunFailure,
    fixed_complete_storage_failure_caller: SwiftRunFailure,
    fixed_complete_storage_retained_failure_source: Option<SwiftRunFailure>,
    fixed_complete_storage_retained_failure_argument: Option<SwiftRunFailure>,
    fixed_complete_storage_retained_failure_returned: Option<SwiftRunFailure>,
    fixed_complete_storage_retained_failure_caller: Option<SwiftRunFailure>,
    fixed_complete_drop_tuple_slot_source: Option<Result<bool, SwiftRunFailure>>,
    fixed_complete_drop_tuple_slot_argument: Option<Result<bool, SwiftRunFailure>>,
    fixed_complete_drop_tuple_slot_returned: Option<Result<bool, SwiftRunFailure>>,
    fixed_complete_drop_tuple_slot_caller: Option<Result<bool, SwiftRunFailure>>,
    fixed_complete_drop_tuple_result_source: Result<bool, SwiftRunFailure>,
    fixed_complete_drop_tuple_result_argument: Result<bool, SwiftRunFailure>,
    fixed_complete_drop_tuple_result_returned: Result<bool, SwiftRunFailure>,
    fixed_complete_drop_tuple_result_caller: Result<bool, SwiftRunFailure>,
    fixed_complete_drop_tuple_bool_source: bool,
    fixed_complete_drop_tuple_bool_argument: bool,
    fixed_complete_drop_tuple_bool_returned: bool,
    fixed_complete_drop_tuple_bool_caller: bool,
    fixed_complete_drop_tuple_failure_source: SwiftRunFailure,
    fixed_complete_drop_tuple_failure_argument: SwiftRunFailure,
    fixed_complete_drop_tuple_failure_returned: SwiftRunFailure,
    fixed_complete_drop_tuple_failure_caller: SwiftRunFailure,
    fixed_complete_drop_tuple_retained_failure_source: Option<SwiftRunFailure>,
    fixed_complete_drop_tuple_retained_failure_argument: Option<SwiftRunFailure>,
    fixed_complete_drop_tuple_retained_failure_returned: Option<SwiftRunFailure>,
    fixed_complete_drop_tuple_retained_failure_caller: Option<SwiftRunFailure>,
    fixed_return_wrapper_slot_source: Option<Result<bool, SwiftRunFailure>>,
    fixed_return_wrapper_slot_argument: Option<Result<bool, SwiftRunFailure>>,
    fixed_return_wrapper_slot_returned: Option<Result<bool, SwiftRunFailure>>,
    fixed_return_wrapper_slot_caller: Option<Result<bool, SwiftRunFailure>>,
    fixed_return_wrapper_result_source: Result<bool, SwiftRunFailure>,
    fixed_return_wrapper_result_argument: Result<bool, SwiftRunFailure>,
    fixed_return_wrapper_result_returned: Result<bool, SwiftRunFailure>,
    fixed_return_wrapper_result_caller: Result<bool, SwiftRunFailure>,
    fixed_return_wrapper_bool_source: bool,
    fixed_return_wrapper_bool_argument: bool,
    fixed_return_wrapper_bool_returned: bool,
    fixed_return_wrapper_bool_caller: bool,
    fixed_return_wrapper_failure_source: SwiftRunFailure,
    fixed_return_wrapper_failure_argument: SwiftRunFailure,
    fixed_return_wrapper_failure_returned: SwiftRunFailure,
    fixed_return_wrapper_failure_caller: SwiftRunFailure,
    fixed_return_wrapper_retained_failure_source: Option<SwiftRunFailure>,
    fixed_return_wrapper_retained_failure_argument: Option<SwiftRunFailure>,
    fixed_return_wrapper_retained_failure_returned: Option<SwiftRunFailure>,
    fixed_return_wrapper_retained_failure_caller: Option<SwiftRunFailure>,
    fixed_retained_report_slot_source: Option<Result<bool, SwiftRunFailure>>,
    fixed_retained_report_slot_argument: Option<Result<bool, SwiftRunFailure>>,
    fixed_retained_report_slot_returned: Option<Result<bool, SwiftRunFailure>>,
    fixed_retained_report_slot_caller: Option<Result<bool, SwiftRunFailure>>,
    fixed_retained_report_result_source: Result<bool, SwiftRunFailure>,
    fixed_retained_report_result_argument: Result<bool, SwiftRunFailure>,
    fixed_retained_report_result_returned: Result<bool, SwiftRunFailure>,
    fixed_retained_report_result_caller: Result<bool, SwiftRunFailure>,
    fixed_retained_report_bool_source: bool,
    fixed_retained_report_bool_argument: bool,
    fixed_retained_report_bool_returned: bool,
    fixed_retained_report_bool_caller: bool,
    fixed_retained_report_failure_source: SwiftRunFailure,
    fixed_retained_report_failure_argument: SwiftRunFailure,
    fixed_retained_report_failure_returned: SwiftRunFailure,
    fixed_retained_report_failure_caller: SwiftRunFailure,
    fixed_retained_report_retained_failure_source: Option<SwiftRunFailure>,
    fixed_retained_report_retained_failure_argument: Option<SwiftRunFailure>,
    fixed_retained_report_retained_failure_returned: Option<SwiftRunFailure>,
    fixed_retained_report_retained_failure_caller: Option<SwiftRunFailure>,
}
struct ActivePositions {
    private_scalar_transfers: crate::experimental::execution::SwiftControlPrivatePositions,
    mir_production_0_0_source: bool,
    mir_production_0_0_argument: bool,
    mir_production_0_0_returned: bool,
    mir_production_0_0_caller: bool,
    mir_production_0_1_source: crate::experimental::execution::Control,
    mir_production_0_1_argument: crate::experimental::execution::Control,
    mir_production_0_1_returned: crate::experimental::execution::Control,
    mir_production_0_1_caller: crate::experimental::execution::Control,
    alias_production_0_1_0_self_source: crate::experimental::execution::Control,
    alias_production_0_1_0_self_argument: crate::experimental::execution::Control,
    alias_production_0_1_0_self_returned: crate::experimental::execution::Control,
    alias_production_0_1_0_self_caller: crate::experimental::execution::Control,
    mir_production_1_0_source: usize,
    mir_production_1_0_argument: usize,
    mir_production_1_0_returned: usize,
    mir_production_1_0_caller: usize,
    mir_production_1_1_source: crate::experimental::execution::Control,
    mir_production_1_1_argument: crate::experimental::execution::Control,
    mir_production_1_1_returned: crate::experimental::execution::Control,
    mir_production_1_1_caller: crate::experimental::execution::Control,
    alias_production_1_1_0_self_source: crate::experimental::execution::Control,
    alias_production_1_1_0_self_argument: crate::experimental::execution::Control,
    alias_production_1_1_0_self_returned: crate::experimental::execution::Control,
    alias_production_1_1_0_self_caller: crate::experimental::execution::Control,
    mir_production_2_0_source: usize,
    mir_production_2_0_argument: usize,
    mir_production_2_0_returned: usize,
    mir_production_2_0_caller: usize,
    mir_production_2_1_source: crate::experimental::execution::Control,
    mir_production_2_1_argument: crate::experimental::execution::Control,
    mir_production_2_1_returned: crate::experimental::execution::Control,
    mir_production_2_1_caller: crate::experimental::execution::Control,
    alias_production_2_1_0_self_source: crate::experimental::execution::Control,
    alias_production_2_1_0_self_argument: crate::experimental::execution::Control,
    alias_production_2_1_0_self_returned: crate::experimental::execution::Control,
    alias_production_2_1_0_self_caller: crate::experimental::execution::Control,
    mir_production_3_0_source: usize,
    mir_production_3_0_argument: usize,
    mir_production_3_0_returned: usize,
    mir_production_3_0_caller: usize,
    mir_production_3_1_source: crate::experimental::execution::Control,
    mir_production_3_1_argument: crate::experimental::execution::Control,
    mir_production_3_1_returned: crate::experimental::execution::Control,
    mir_production_3_1_caller: crate::experimental::execution::Control,
    alias_production_3_1_0_self_source: crate::experimental::execution::Control,
    alias_production_3_1_0_self_argument: crate::experimental::execution::Control,
    alias_production_3_1_0_self_returned: crate::experimental::execution::Control,
    alias_production_3_1_0_self_caller: crate::experimental::execution::Control,
    mir_production_4_0_source: bool,
    mir_production_4_0_argument: bool,
    mir_production_4_0_returned: bool,
    mir_production_4_0_caller: bool,
    mir_production_4_1_source: crate::experimental::execution::Control,
    mir_production_4_1_argument: crate::experimental::execution::Control,
    mir_production_4_1_returned: crate::experimental::execution::Control,
    mir_production_4_1_caller: crate::experimental::execution::Control,
    alias_production_4_1_0_self_source: crate::experimental::execution::Control,
    alias_production_4_1_0_self_argument: crate::experimental::execution::Control,
    alias_production_4_1_0_self_returned: crate::experimental::execution::Control,
    alias_production_4_1_0_self_caller: crate::experimental::execution::Control,
    mir_production_5_0_source: bool,
    mir_production_5_0_argument: bool,
    mir_production_5_0_returned: bool,
    mir_production_5_0_caller: bool,
    mir_production_5_1_source: crate::experimental::execution::Control,
    mir_production_5_1_argument: crate::experimental::execution::Control,
    mir_production_5_1_returned: crate::experimental::execution::Control,
    mir_production_5_1_caller: crate::experimental::execution::Control,
    alias_production_5_1_0_self_source: crate::experimental::execution::Control,
    alias_production_5_1_0_self_argument: crate::experimental::execution::Control,
    alias_production_5_1_0_self_returned: crate::experimental::execution::Control,
    alias_production_5_1_0_self_caller: crate::experimental::execution::Control,
    mir_production_6_0_source: bool,
    mir_production_6_0_argument: bool,
    mir_production_6_0_returned: bool,
    mir_production_6_0_caller: bool,
    mir_production_6_1_source: crate::experimental::execution::Control,
    mir_production_6_1_argument: crate::experimental::execution::Control,
    mir_production_6_1_returned: crate::experimental::execution::Control,
    mir_production_6_1_caller: crate::experimental::execution::Control,
    alias_production_6_1_0_self_source: crate::experimental::execution::Control,
    alias_production_6_1_0_self_argument: crate::experimental::execution::Control,
    alias_production_6_1_0_self_returned: crate::experimental::execution::Control,
    alias_production_6_1_0_self_caller: crate::experimental::execution::Control,
    mir_production_7_0_source: (),
    mir_production_7_0_argument: (),
    mir_production_7_0_returned: (),
    mir_production_7_0_caller: (),
    mir_production_7_1_source: &'static mut crate::experimental::execution::Control,
    mir_production_7_1_argument: &'static mut crate::experimental::execution::Control,
    mir_production_7_1_returned: &'static mut crate::experimental::execution::Control,
    mir_production_7_1_caller: &'static mut crate::experimental::execution::Control,
    alias_production_7_1_0_self_source: &'static mut crate::experimental::execution::Control,
    alias_production_7_1_0_self_argument: &'static mut crate::experimental::execution::Control,
    alias_production_7_1_0_self_returned: &'static mut crate::experimental::execution::Control,
    alias_production_7_1_0_self_caller: &'static mut crate::experimental::execution::Control,
    literal_production_7_0_source: bool,
    literal_production_7_0_argument: bool,
    literal_production_7_0_returned: bool,
    literal_production_7_0_caller: bool,
    mir_production_8_0_source: crate::experimental::execution::Control,
    mir_production_8_0_argument: crate::experimental::execution::Control,
    mir_production_8_0_returned: crate::experimental::execution::Control,
    mir_production_8_0_caller: crate::experimental::execution::Control,
    mir_production_8_7_source: isize,
    mir_production_8_7_argument: isize,
    mir_production_8_7_returned: isize,
    mir_production_8_7_caller: isize,
    mir_production_8_1_source: crate::experimental::cache::ControlKind,
    mir_production_8_1_argument: crate::experimental::cache::ControlKind,
    mir_production_8_1_returned: crate::experimental::cache::ControlKind,
    mir_production_8_1_caller: crate::experimental::cache::ControlKind,
    alias_production_8_1_0_kind_source: crate::experimental::cache::ControlKind,
    alias_production_8_1_0_kind_argument: crate::experimental::cache::ControlKind,
    alias_production_8_1_0_kind_returned: crate::experimental::cache::ControlKind,
    alias_production_8_1_0_kind_caller: crate::experimental::cache::ControlKind,
    mir_production_8_2_source: usize,
    mir_production_8_2_argument: usize,
    mir_production_8_2_returned: usize,
    mir_production_8_2_caller: usize,
    alias_production_8_2_0_start_source: usize,
    alias_production_8_2_0_start_argument: usize,
    alias_production_8_2_0_start_returned: usize,
    alias_production_8_2_0_start_caller: usize,
    mir_production_8_3_source: usize,
    mir_production_8_3_argument: usize,
    mir_production_8_3_returned: usize,
    mir_production_8_3_caller: usize,
    alias_production_8_3_0_end_source: usize,
    alias_production_8_3_0_end_argument: usize,
    alias_production_8_3_0_end_returned: usize,
    alias_production_8_3_0_end_caller: usize,
    mir_production_8_4_source: usize,
    mir_production_8_4_argument: usize,
    mir_production_8_4_returned: usize,
    mir_production_8_4_caller: usize,
    alias_production_8_4_0_height_source: usize,
    alias_production_8_4_0_height_argument: usize,
    alias_production_8_4_0_height_returned: usize,
    alias_production_8_4_0_height_caller: usize,
    mir_production_8_5_source: bool,
    mir_production_8_5_argument: bool,
    mir_production_8_5_returned: bool,
    mir_production_8_5_caller: bool,
    alias_production_8_5_0_result_source: bool,
    alias_production_8_5_0_result_argument: bool,
    alias_production_8_5_0_result_returned: bool,
    alias_production_8_5_0_result_caller: bool,
    mir_production_9_0_source: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_9_0_argument: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_9_0_returned: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_9_0_caller: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_9_2_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, Value>,
    mir_production_9_2_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, Value>,
    mir_production_9_2_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, Value>,
    mir_production_9_2_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, Value>,
    mir_production_9_3_source: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_9_3_argument: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_9_3_returned: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_9_3_caller: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_9_4_source: isize,
    mir_production_9_4_argument: isize,
    mir_production_9_4_returned: isize,
    mir_production_9_4_caller: isize,
    mir_production_9_5_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_9_5_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_9_5_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_9_5_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_9_5_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_9_5_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_9_5_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_9_5_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_9_6_source: Value,
    mir_production_9_6_argument: Value,
    mir_production_9_6_returned: Value,
    mir_production_9_6_caller: Value,
    alias_production_9_6_0_val_source: Value,
    alias_production_9_6_0_val_argument: Value,
    alias_production_9_6_0_val_returned: Value,
    alias_production_9_6_0_val_caller: Value,
    mir_production_9_7_source: isize,
    mir_production_9_7_argument: isize,
    mir_production_9_7_returned: isize,
    mir_production_9_7_caller: isize,
    mir_production_9_8_source: i32,
    mir_production_9_8_argument: i32,
    mir_production_9_8_returned: i32,
    mir_production_9_8_caller: i32,
    alias_production_9_8_0_value_source: i32,
    alias_production_9_8_0_value_argument: i32,
    alias_production_9_8_0_value_returned: i32,
    alias_production_9_8_0_value_caller: i32,
    mir_production_9_9_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_9_9_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_9_9_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_9_9_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_9_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_9_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_9_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_9_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_9_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_9_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_9_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_9_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    literal_production_9_0_source: &'static str,
    literal_production_9_0_argument: &'static str,
    literal_production_9_0_returned: &'static str,
    literal_production_9_0_caller: &'static str,
    mir_production_10_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_3_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_3_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_3_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_3_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_4_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_4_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_4_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_4_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_5_source: isize,
    mir_production_10_5_argument: isize,
    mir_production_10_5_returned: isize,
    mir_production_10_5_caller: isize,
    mir_production_10_6_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_6_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_6_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_6_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_6_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_6_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_6_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_6_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_7_source: std::option::Option<Value>,
    mir_production_10_7_argument: std::option::Option<Value>,
    mir_production_10_7_returned: std::option::Option<Value>,
    mir_production_10_7_caller: std::option::Option<Value>,
    alias_production_10_7_0_value_source: std::option::Option<Value>,
    alias_production_10_7_0_value_argument: std::option::Option<Value>,
    alias_production_10_7_0_value_returned: std::option::Option<Value>,
    alias_production_10_7_0_value_caller: std::option::Option<Value>,
    mir_production_10_8_source: bool,
    mir_production_10_8_argument: bool,
    mir_production_10_8_returned: bool,
    mir_production_10_8_caller: bool,
    mir_production_10_9_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, Value>,
    mir_production_10_9_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, Value>,
    mir_production_10_9_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, Value>,
    mir_production_10_9_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, Value>,
    mir_production_10_10_source: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_10_argument: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_10_returned: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_10_caller: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_11_source: isize,
    mir_production_10_11_argument: isize,
    mir_production_10_11_returned: isize,
    mir_production_10_11_caller: isize,
    mir_production_10_12_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_12_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_12_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_12_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_12_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_12_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_12_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_12_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_13_source: Value,
    mir_production_10_13_argument: Value,
    mir_production_10_13_returned: Value,
    mir_production_10_13_caller: Value,
    alias_production_10_13_0_val_source: Value,
    alias_production_10_13_0_val_argument: Value,
    alias_production_10_13_0_val_returned: Value,
    alias_production_10_13_0_val_caller: Value,
    mir_production_10_14_source: bool,
    mir_production_10_14_argument: bool,
    mir_production_10_14_returned: bool,
    mir_production_10_14_caller: bool,
    mir_production_10_15_source: usize,
    mir_production_10_15_argument: usize,
    mir_production_10_15_returned: usize,
    mir_production_10_15_caller: usize,
    mir_production_10_16_source: usize,
    mir_production_10_16_argument: usize,
    mir_production_10_16_returned: usize,
    mir_production_10_16_caller: usize,
    mir_production_10_17_source: &'static std::vec::Vec<Value>,
    mir_production_10_17_argument: &'static std::vec::Vec<Value>,
    mir_production_10_17_returned: &'static std::vec::Vec<Value>,
    mir_production_10_17_caller: &'static std::vec::Vec<Value>,
    mir_production_10_18_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_10_18_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_10_18_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_10_18_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_10_19_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_19_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_19_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_19_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_20_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_20_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_20_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_20_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_21_source: usize,
    mir_production_10_21_argument: usize,
    mir_production_10_21_returned: usize,
    mir_production_10_21_caller: usize,
    mir_production_10_22_source: usize,
    mir_production_10_22_argument: usize,
    mir_production_10_22_returned: usize,
    mir_production_10_22_caller: usize,
    mir_production_10_23_source: usize,
    mir_production_10_23_argument: usize,
    mir_production_10_23_returned: usize,
    mir_production_10_23_caller: usize,
    mir_production_10_24_source: &'static std::vec::Vec<Value>,
    mir_production_10_24_argument: &'static std::vec::Vec<Value>,
    mir_production_10_24_returned: &'static std::vec::Vec<Value>,
    mir_production_10_24_caller: &'static std::vec::Vec<Value>,
    mir_production_10_25_source: usize,
    mir_production_10_25_argument: usize,
    mir_production_10_25_returned: usize,
    mir_production_10_25_caller: usize,
    mir_production_10_26_source: (usize, bool),
    mir_production_10_26_argument: (usize, bool),
    mir_production_10_26_returned: (usize, bool),
    mir_production_10_26_caller: (usize, bool),
    mir_production_10_27_source: (usize, bool),
    mir_production_10_27_argument: (usize, bool),
    mir_production_10_27_returned: (usize, bool),
    mir_production_10_27_caller: (usize, bool),
    mir_production_10_28_source: isize,
    mir_production_10_28_argument: isize,
    mir_production_10_28_returned: isize,
    mir_production_10_28_caller: isize,
    mir_production_10_30_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_30_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_30_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_30_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_31_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_31_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_31_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_31_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_32_source: usize,
    mir_production_10_32_argument: usize,
    mir_production_10_32_returned: usize,
    mir_production_10_32_caller: usize,
    mir_production_10_33_source: isize,
    mir_production_10_33_argument: isize,
    mir_production_10_33_returned: isize,
    mir_production_10_33_caller: isize,
    mir_production_10_35_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_35_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_35_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_35_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_36_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_36_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_36_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_36_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_37_source: isize,
    mir_production_10_37_argument: isize,
    mir_production_10_37_returned: isize,
    mir_production_10_37_caller: isize,
    mir_production_10_39_source: isize,
    mir_production_10_39_argument: isize,
    mir_production_10_39_returned: isize,
    mir_production_10_39_caller: isize,
    mir_production_10_41_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_41_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_41_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_41_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_10_42_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_42_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_42_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_42_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_43_source: &'static mut crate::experimental_swift_reactor::execution::ExecutionOperationPhase<'static>,
    mir_production_10_43_argument: &'static mut crate::experimental_swift_reactor::execution::ExecutionOperationPhase<'static>,
    mir_production_10_43_returned: &'static mut crate::experimental_swift_reactor::execution::ExecutionOperationPhase<'static>,
    mir_production_10_43_caller: &'static mut crate::experimental_swift_reactor::execution::ExecutionOperationPhase<'static>,
    mir_production_10_44_source: isize,
    mir_production_10_44_argument: isize,
    mir_production_10_44_returned: isize,
    mir_production_10_44_caller: isize,
    mir_production_10_46_source: &'static mut std::vec::Vec<Value>,
    mir_production_10_46_argument: &'static mut std::vec::Vec<Value>,
    mir_production_10_46_returned: &'static mut std::vec::Vec<Value>,
    mir_production_10_46_caller: &'static mut std::vec::Vec<Value>,
    mir_production_10_47_source: &'static mut std::vec::Vec<Value>,
    mir_production_10_47_argument: &'static mut std::vec::Vec<Value>,
    mir_production_10_47_returned: &'static mut std::vec::Vec<Value>,
    mir_production_10_47_caller: &'static mut std::vec::Vec<Value>,
    mir_production_10_29_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_29_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_29_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_29_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_29_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_29_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_29_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_29_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_34_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_34_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_34_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_34_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_34_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_34_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_34_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_34_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_38_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_38_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_38_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_38_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_38_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_38_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_38_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_38_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_40_source: Value,
    mir_production_10_40_argument: Value,
    mir_production_10_40_returned: Value,
    mir_production_10_40_caller: Value,
    alias_production_10_40_0_value_source: Value,
    alias_production_10_40_0_value_argument: Value,
    alias_production_10_40_0_value_returned: Value,
    alias_production_10_40_0_value_caller: Value,
    mir_production_10_45_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_45_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_45_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_45_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_45_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_45_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_45_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_10_45_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_10_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_10_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_10_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_10_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_10_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_10_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_10_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_10_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_10_2_source: crate::experimental::execution::Control,
    mir_production_10_2_argument: crate::experimental::execution::Control,
    mir_production_10_2_returned: crate::experimental::execution::Control,
    mir_production_10_2_caller: crate::experimental::execution::Control,
    alias_production_10_2_0_control_source: crate::experimental::execution::Control,
    alias_production_10_2_0_control_argument: crate::experimental::execution::Control,
    alias_production_10_2_0_control_returned: crate::experimental::execution::Control,
    alias_production_10_2_0_control_caller: crate::experimental::execution::Control,
    literal_production_10_0_source: &'static str,
    literal_production_10_0_argument: &'static str,
    literal_production_10_0_returned: &'static str,
    literal_production_10_0_caller: &'static str,
    literal_production_10_1_source: usize,
    literal_production_10_1_argument: usize,
    literal_production_10_1_returned: usize,
    literal_production_10_1_caller: usize,
    literal_production_10_2_source: usize,
    literal_production_10_2_argument: usize,
    literal_production_10_2_returned: usize,
    literal_production_10_2_caller: usize,
    mir_production_11_0_source: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_0_argument: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_0_returned: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_0_caller: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_3_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_11_3_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_11_3_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_11_3_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_11_3_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_11_3_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_11_3_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_11_3_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_11_4_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_11_4_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_11_4_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_11_4_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_11_5_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_5_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_5_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_5_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_6_source: isize,
    mir_production_11_6_argument: isize,
    mir_production_11_6_returned: isize,
    mir_production_11_6_caller: isize,
    mir_production_11_7_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_7_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_7_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_7_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_7_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_7_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_7_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_7_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_8_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_11_8_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_11_8_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_11_8_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_11_8_0_val_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_11_8_0_val_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_11_8_0_val_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_11_8_0_val_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_11_9_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_11_9_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_11_9_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_11_9_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_11_10_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_10_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_10_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_10_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_11_source: std::option::Option<usize>,
    mir_production_11_11_argument: std::option::Option<usize>,
    mir_production_11_11_returned: std::option::Option<usize>,
    mir_production_11_11_caller: std::option::Option<usize>,
    mir_production_11_12_source: std::option::Option<usize>,
    mir_production_11_12_argument: std::option::Option<usize>,
    mir_production_11_12_returned: std::option::Option<usize>,
    mir_production_11_12_caller: std::option::Option<usize>,
    mir_production_11_13_source: usize,
    mir_production_11_13_argument: usize,
    mir_production_11_13_returned: usize,
    mir_production_11_13_caller: usize,
    mir_production_11_14_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_11_14_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_11_14_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_11_14_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_11_15_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_11_15_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_11_15_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_11_15_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_11_16_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_16_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_16_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_16_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_17_source: std::option::Option<usize>,
    mir_production_11_17_argument: std::option::Option<usize>,
    mir_production_11_17_returned: std::option::Option<usize>,
    mir_production_11_17_caller: std::option::Option<usize>,
    mir_production_11_18_source: std::option::Option<usize>,
    mir_production_11_18_argument: std::option::Option<usize>,
    mir_production_11_18_returned: std::option::Option<usize>,
    mir_production_11_18_caller: std::option::Option<usize>,
    mir_production_11_19_source: std::result::Result<usize, std::num::TryFromIntError>,
    mir_production_11_19_argument: std::result::Result<usize, std::num::TryFromIntError>,
    mir_production_11_19_returned: std::result::Result<usize, std::num::TryFromIntError>,
    mir_production_11_19_caller: std::result::Result<usize, std::num::TryFromIntError>,
    mir_production_11_20_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_11_20_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_11_20_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_11_20_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_11_21_source: isize,
    mir_production_11_21_argument: isize,
    mir_production_11_21_returned: isize,
    mir_production_11_21_caller: isize,
    mir_production_11_24_source: (&'static usize,),
    mir_production_11_24_argument: (&'static usize,),
    mir_production_11_24_returned: (&'static usize,),
    mir_production_11_24_caller: (&'static usize,),
    mir_production_11_25_source: &'static usize,
    mir_production_11_25_argument: &'static usize,
    mir_production_11_25_returned: &'static usize,
    mir_production_11_25_caller: &'static usize,
    mir_production_11_26_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_11_26_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_11_26_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_11_26_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_11_27_source: isize,
    mir_production_11_27_argument: isize,
    mir_production_11_27_returned: isize,
    mir_production_11_27_caller: isize,
    mir_production_11_31_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental::execution::Control>,
    mir_production_11_31_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental::execution::Control>,
    mir_production_11_31_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental::execution::Control>,
    mir_production_11_31_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental::execution::Control>,
    mir_production_11_32_source: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_32_argument: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_32_returned: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_32_caller: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_33_source: isize,
    mir_production_11_33_argument: isize,
    mir_production_11_33_returned: isize,
    mir_production_11_33_caller: isize,
    mir_production_11_36_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_36_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_36_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_36_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_37_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_37_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_37_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_37_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_38_source: usize,
    mir_production_11_38_argument: usize,
    mir_production_11_38_returned: usize,
    mir_production_11_38_caller: usize,
    mir_production_11_39_source: usize,
    mir_production_11_39_argument: usize,
    mir_production_11_39_returned: usize,
    mir_production_11_39_caller: usize,
    mir_production_11_40_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_11_40_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_11_40_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_11_40_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_11_41_source: (usize, bool),
    mir_production_11_41_argument: (usize, bool),
    mir_production_11_41_returned: (usize, bool),
    mir_production_11_41_caller: (usize, bool),
    mir_production_11_42_source: isize,
    mir_production_11_42_argument: isize,
    mir_production_11_42_returned: isize,
    mir_production_11_42_caller: isize,
    mir_production_11_44_source: bool,
    mir_production_11_44_argument: bool,
    mir_production_11_44_returned: bool,
    mir_production_11_44_caller: bool,
    mir_production_11_45_source: crate::experimental::execution::Control,
    mir_production_11_45_argument: crate::experimental::execution::Control,
    mir_production_11_45_returned: crate::experimental::execution::Control,
    mir_production_11_45_caller: crate::experimental::execution::Control,
    mir_production_11_46_source: (),
    mir_production_11_46_argument: (),
    mir_production_11_46_returned: (),
    mir_production_11_46_caller: (),
    mir_production_11_47_source: &'static mut crate::experimental::execution::Control,
    mir_production_11_47_argument: &'static mut crate::experimental::execution::Control,
    mir_production_11_47_returned: &'static mut crate::experimental::execution::Control,
    mir_production_11_47_caller: &'static mut crate::experimental::execution::Control,
    mir_production_11_48_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_48_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_48_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_48_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_49_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_49_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_49_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_49_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_50_source: crate::experimental::execution::Control,
    mir_production_11_50_argument: crate::experimental::execution::Control,
    mir_production_11_50_returned: crate::experimental::execution::Control,
    mir_production_11_50_caller: crate::experimental::execution::Control,
    mir_production_11_51_source: isize,
    mir_production_11_51_argument: isize,
    mir_production_11_51_returned: isize,
    mir_production_11_51_caller: isize,
    mir_production_11_53_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_53_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_53_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_53_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_54_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_54_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_54_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_54_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_55_source: usize,
    mir_production_11_55_argument: usize,
    mir_production_11_55_returned: usize,
    mir_production_11_55_caller: usize,
    mir_production_11_56_source: bool,
    mir_production_11_56_argument: bool,
    mir_production_11_56_returned: bool,
    mir_production_11_56_caller: bool,
    mir_production_11_57_source: crate::experimental::execution::Control,
    mir_production_11_57_argument: crate::experimental::execution::Control,
    mir_production_11_57_returned: crate::experimental::execution::Control,
    mir_production_11_57_caller: crate::experimental::execution::Control,
    mir_production_11_58_source: (usize, bool),
    mir_production_11_58_argument: (usize, bool),
    mir_production_11_58_returned: (usize, bool),
    mir_production_11_58_caller: (usize, bool),
    mir_production_11_59_source: isize,
    mir_production_11_59_argument: isize,
    mir_production_11_59_returned: isize,
    mir_production_11_59_caller: isize,
    mir_production_11_62_source: bool,
    mir_production_11_62_argument: bool,
    mir_production_11_62_returned: bool,
    mir_production_11_62_caller: bool,
    mir_production_11_63_source: crate::experimental::execution::Control,
    mir_production_11_63_argument: crate::experimental::execution::Control,
    mir_production_11_63_returned: crate::experimental::execution::Control,
    mir_production_11_63_caller: crate::experimental::execution::Control,
    mir_production_11_64_source: crate::experimental::execution::Control,
    mir_production_11_64_argument: crate::experimental::execution::Control,
    mir_production_11_64_returned: crate::experimental::execution::Control,
    mir_production_11_64_caller: crate::experimental::execution::Control,
    mir_production_11_65_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_11_65_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_11_65_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_11_65_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_11_66_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_66_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_66_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_66_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_67_source: std::option::Option<usize>,
    mir_production_11_67_argument: std::option::Option<usize>,
    mir_production_11_67_returned: std::option::Option<usize>,
    mir_production_11_67_caller: std::option::Option<usize>,
    mir_production_11_68_source: usize,
    mir_production_11_68_argument: usize,
    mir_production_11_68_returned: usize,
    mir_production_11_68_caller: usize,
    mir_production_11_69_source: crate::experimental::execution::Control,
    mir_production_11_69_argument: crate::experimental::execution::Control,
    mir_production_11_69_returned: crate::experimental::execution::Control,
    mir_production_11_69_caller: crate::experimental::execution::Control,
    mir_production_11_70_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_11_70_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_11_70_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_11_70_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_11_71_source: isize,
    mir_production_11_71_argument: isize,
    mir_production_11_71_returned: isize,
    mir_production_11_71_caller: isize,
    mir_production_11_74_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_74_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_74_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_74_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_75_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_75_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_75_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_75_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_76_source: usize,
    mir_production_11_76_argument: usize,
    mir_production_11_76_returned: usize,
    mir_production_11_76_caller: usize,
    mir_production_11_77_source: isize,
    mir_production_11_77_argument: isize,
    mir_production_11_77_returned: isize,
    mir_production_11_77_caller: isize,
    mir_production_11_79_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_79_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_79_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_79_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_11_80_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_80_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_80_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_80_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_81_source: isize,
    mir_production_11_81_argument: isize,
    mir_production_11_81_returned: isize,
    mir_production_11_81_caller: isize,
    mir_production_11_83_source: bool,
    mir_production_11_83_argument: bool,
    mir_production_11_83_returned: bool,
    mir_production_11_83_caller: bool,
    mir_production_11_84_source: crate::experimental::execution::Control,
    mir_production_11_84_argument: crate::experimental::execution::Control,
    mir_production_11_84_returned: crate::experimental::execution::Control,
    mir_production_11_84_caller: crate::experimental::execution::Control,
    mir_production_11_85_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_11_85_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_11_85_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_11_85_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_11_86_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_11_86_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_11_86_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_11_86_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_11_22_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_22_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_22_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_22_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_22_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_22_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_22_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_22_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_23_source: usize,
    mir_production_11_23_argument: usize,
    mir_production_11_23_returned: usize,
    mir_production_11_23_caller: usize,
    alias_production_11_23_0_val_source: usize,
    alias_production_11_23_0_val_argument: usize,
    alias_production_11_23_0_val_returned: usize,
    alias_production_11_23_0_val_caller: usize,
    mir_production_11_28_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_28_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_28_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_28_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_28_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_28_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_28_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_28_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_29_source: usize,
    mir_production_11_29_argument: usize,
    mir_production_11_29_returned: usize,
    mir_production_11_29_caller: usize,
    alias_production_11_29_0_index_source: usize,
    alias_production_11_29_0_index_argument: usize,
    alias_production_11_29_0_index_returned: usize,
    alias_production_11_29_0_index_caller: usize,
    alias_production_11_29_1_val_source: usize,
    alias_production_11_29_1_val_argument: usize,
    alias_production_11_29_1_val_returned: usize,
    alias_production_11_29_1_val_caller: usize,
    mir_production_11_30_source: crate::experimental::execution::Control,
    mir_production_11_30_argument: crate::experimental::execution::Control,
    mir_production_11_30_returned: crate::experimental::execution::Control,
    mir_production_11_30_caller: crate::experimental::execution::Control,
    alias_production_11_30_0_control_source: crate::experimental::execution::Control,
    alias_production_11_30_0_control_argument: crate::experimental::execution::Control,
    alias_production_11_30_0_control_returned: crate::experimental::execution::Control,
    alias_production_11_30_0_control_caller: crate::experimental::execution::Control,
    mir_production_11_34_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_34_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_34_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_34_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_34_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_34_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_34_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_34_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_35_source: crate::experimental::execution::Control,
    mir_production_11_35_argument: crate::experimental::execution::Control,
    mir_production_11_35_returned: crate::experimental::execution::Control,
    mir_production_11_35_caller: crate::experimental::execution::Control,
    alias_production_11_35_0_val_source: crate::experimental::execution::Control,
    alias_production_11_35_0_val_argument: crate::experimental::execution::Control,
    alias_production_11_35_0_val_returned: crate::experimental::execution::Control,
    alias_production_11_35_0_val_caller: crate::experimental::execution::Control,
    mir_production_11_43_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_43_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_43_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_43_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_43_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_43_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_43_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_43_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_52_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_52_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_52_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_52_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_52_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_52_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_52_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_52_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_60_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_60_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_60_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_60_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_60_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_60_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_60_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_60_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_61_source: usize,
    mir_production_11_61_argument: usize,
    mir_production_11_61_returned: usize,
    mir_production_11_61_caller: usize,
    alias_production_11_61_0_pc_source: usize,
    alias_production_11_61_0_pc_argument: usize,
    alias_production_11_61_0_pc_returned: usize,
    alias_production_11_61_0_pc_caller: usize,
    mir_production_11_72_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_72_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_72_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_72_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_72_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_72_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_72_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_72_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_73_source: usize,
    mir_production_11_73_argument: usize,
    mir_production_11_73_returned: usize,
    mir_production_11_73_caller: usize,
    alias_production_11_73_0_val_source: usize,
    alias_production_11_73_0_val_argument: usize,
    alias_production_11_73_0_val_returned: usize,
    alias_production_11_73_0_val_caller: usize,
    mir_production_11_78_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_78_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_78_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_78_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_78_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_78_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_78_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_78_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_82_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_82_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_82_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_82_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_82_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_82_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_82_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_11_82_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_11_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_11_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_11_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_11_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_11_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_11_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_11_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_11_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_11_2_source: u32,
    mir_production_11_2_argument: u32,
    mir_production_11_2_returned: u32,
    mir_production_11_2_caller: u32,
    alias_production_11_2_0_depth_source: u32,
    alias_production_11_2_0_depth_argument: u32,
    alias_production_11_2_0_depth_returned: u32,
    alias_production_11_2_0_depth_caller: u32,
    literal_production_11_0_source: usize,
    literal_production_11_0_argument: usize,
    literal_production_11_0_returned: usize,
    literal_production_11_0_caller: usize,
    literal_production_11_1_source: usize,
    literal_production_11_1_argument: usize,
    literal_production_11_1_returned: usize,
    literal_production_11_1_caller: usize,
    literal_production_11_2_source: usize,
    literal_production_11_2_argument: usize,
    literal_production_11_2_returned: usize,
    literal_production_11_2_caller: usize,
    mir_production_12_0_source: std::option::Option<usize>,
    mir_production_12_0_argument: std::option::Option<usize>,
    mir_production_12_0_returned: std::option::Option<usize>,
    mir_production_12_0_caller: std::option::Option<usize>,
    mir_production_12_1_source: (),
    mir_production_12_1_argument: (),
    mir_production_12_1_returned: (),
    mir_production_12_1_caller: (),
    mir_production_12_2_source: usize,
    mir_production_12_2_argument: usize,
    mir_production_12_2_returned: usize,
    mir_production_12_2_caller: usize,
    alias_production_12_2_0_n_source: usize,
    alias_production_12_2_0_n_argument: usize,
    alias_production_12_2_0_n_returned: usize,
    alias_production_12_2_0_n_caller: usize,
    literal_production_12_0_source: usize,
    literal_production_12_0_argument: usize,
    literal_production_12_0_returned: usize,
    literal_production_12_0_caller: usize,
    mir_production_13_0_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_13_0_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_13_0_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_13_0_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_13_2_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_13_2_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_13_2_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_13_2_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_13_1_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_13_1_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_13_1_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_13_1_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    literal_production_13_0_source: &'static str,
    literal_production_13_0_argument: &'static str,
    literal_production_13_0_returned: &'static str,
    literal_production_13_0_caller: &'static str,
    mir_production_14_0_source: bool,
    mir_production_14_0_argument: bool,
    mir_production_14_0_returned: bool,
    mir_production_14_0_caller: bool,
    mir_production_14_3_source: usize,
    mir_production_14_3_argument: usize,
    mir_production_14_3_returned: usize,
    mir_production_14_3_caller: usize,
    mir_production_14_4_source: usize,
    mir_production_14_4_argument: usize,
    mir_production_14_4_returned: usize,
    mir_production_14_4_caller: usize,
    mir_production_14_5_source: &'static usize,
    mir_production_14_5_argument: &'static usize,
    mir_production_14_5_returned: &'static usize,
    mir_production_14_5_caller: &'static usize,
    mir_production_14_1_source: (&'static usize,),
    mir_production_14_1_argument: (&'static usize,),
    mir_production_14_1_returned: (&'static usize,),
    mir_production_14_1_caller: (&'static usize,),
    mir_production_14_2_source: &'static usize,
    mir_production_14_2_argument: &'static usize,
    mir_production_14_2_returned: &'static usize,
    mir_production_14_2_caller: &'static usize,
    alias_production_14_2_0_i_source: &'static usize,
    alias_production_14_2_0_i_argument: &'static usize,
    alias_production_14_2_0_i_returned: &'static usize,
    alias_production_14_2_0_i_caller: &'static usize,
    mir_production_15_0_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_15_0_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_15_0_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_15_0_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_15_2_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_15_2_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_15_2_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_15_2_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_15_1_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_15_1_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_15_1_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_15_1_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    literal_production_15_0_source: &'static str,
    literal_production_15_0_argument: &'static str,
    literal_production_15_0_returned: &'static str,
    literal_production_15_0_caller: &'static str,
    mir_production_16_0_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_16_0_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_16_0_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_16_0_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_16_2_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_16_2_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_16_2_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_16_2_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_16_1_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_16_1_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_16_1_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_16_1_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    literal_production_16_0_source: &'static str,
    literal_production_16_0_argument: &'static str,
    literal_production_16_0_returned: &'static str,
    literal_production_16_0_caller: &'static str,
    mir_production_17_0_source: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_17_0_argument: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_17_0_returned: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_17_0_caller: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_17_0_0_result_source: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_17_0_0_result_argument: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_17_0_0_result_returned: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_17_0_0_result_caller: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_17_2_source: usize,
    mir_production_17_2_argument: usize,
    mir_production_17_2_returned: usize,
    mir_production_17_2_caller: usize,
    alias_production_17_2_0_previous_length_source: usize,
    alias_production_17_2_0_previous_length_argument: usize,
    alias_production_17_2_0_previous_length_returned: usize,
    alias_production_17_2_0_previous_length_caller: usize,
    mir_production_17_3_source: &'static std::vec::Vec<Value>,
    mir_production_17_3_argument: &'static std::vec::Vec<Value>,
    mir_production_17_3_returned: &'static std::vec::Vec<Value>,
    mir_production_17_3_caller: &'static std::vec::Vec<Value>,
    mir_production_17_4_source: &'static mut crate::experimental_swift_reactor::execution::ExecutionOperationPhase<'static>,
    mir_production_17_4_argument: &'static mut crate::experimental_swift_reactor::execution::ExecutionOperationPhase<'static>,
    mir_production_17_4_returned: &'static mut crate::experimental_swift_reactor::execution::ExecutionOperationPhase<'static>,
    mir_production_17_4_caller: &'static mut crate::experimental_swift_reactor::execution::ExecutionOperationPhase<'static>,
    mir_production_17_5_source: bool,
    mir_production_17_5_argument: bool,
    mir_production_17_5_returned: bool,
    mir_production_17_5_caller: bool,
    mir_production_17_6_source: &'static std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_17_6_argument: &'static std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_17_6_returned: &'static std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_17_6_caller: &'static std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_17_7_source: bool,
    mir_production_17_7_argument: bool,
    mir_production_17_7_returned: bool,
    mir_production_17_7_caller: bool,
    mir_production_17_8_source: usize,
    mir_production_17_8_argument: usize,
    mir_production_17_8_returned: usize,
    mir_production_17_8_caller: usize,
    mir_production_17_9_source: &'static std::vec::Vec<Value>,
    mir_production_17_9_argument: &'static std::vec::Vec<Value>,
    mir_production_17_9_returned: &'static std::vec::Vec<Value>,
    mir_production_17_9_caller: &'static std::vec::Vec<Value>,
    mir_production_17_10_source: &'static mut std::vec::Vec<Value>,
    mir_production_17_10_argument: &'static mut std::vec::Vec<Value>,
    mir_production_17_10_returned: &'static mut std::vec::Vec<Value>,
    mir_production_17_10_caller: &'static mut std::vec::Vec<Value>,
    mir_production_17_11_source: &'static mut std::vec::Vec<Value>,
    mir_production_17_11_argument: &'static mut std::vec::Vec<Value>,
    mir_production_17_11_returned: &'static mut std::vec::Vec<Value>,
    mir_production_17_11_caller: &'static mut std::vec::Vec<Value>,
    mir_production_17_12_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameCleanupState,
    mir_production_17_12_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameCleanupState,
    mir_production_17_12_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameCleanupState,
    mir_production_17_12_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameCleanupState,
    mir_production_17_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_17_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_17_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_17_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_17_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_17_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_17_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_17_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    literal_production_17_0_source: bool,
    literal_production_17_0_argument: bool,
    literal_production_17_0_returned: bool,
    literal_production_17_0_caller: bool,
    mir_production_18_0_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_18_0_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_18_0_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_18_0_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_18_2_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_18_2_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_18_2_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_18_2_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_18_2_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_18_2_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_18_2_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_18_2_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_18_3_source: std::option::Option<&'static crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_18_3_argument: std::option::Option<&'static crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_18_3_returned: std::option::Option<&'static crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_18_3_caller: std::option::Option<&'static crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_18_4_source: &'static [crate::experimental_swift_reactor::execution::SwiftFrame],
    mir_production_18_4_argument: &'static [crate::experimental_swift_reactor::execution::SwiftFrame],
    mir_production_18_4_returned: &'static [crate::experimental_swift_reactor::execution::SwiftFrame],
    mir_production_18_4_caller: &'static [crate::experimental_swift_reactor::execution::SwiftFrame],
    mir_production_18_5_source: &'static std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_18_5_argument: &'static std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_18_5_returned: &'static std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_18_5_caller: &'static std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_18_6_source: isize,
    mir_production_18_6_argument: isize,
    mir_production_18_6_returned: isize,
    mir_production_18_6_caller: isize,
    mir_production_18_7_source: &'static crate::experimental_swift_reactor::execution::SwiftFrame,
    mir_production_18_7_argument: &'static crate::experimental_swift_reactor::execution::SwiftFrame,
    mir_production_18_7_returned: &'static crate::experimental_swift_reactor::execution::SwiftFrame,
    mir_production_18_7_caller: &'static crate::experimental_swift_reactor::execution::SwiftFrame,
    alias_production_18_7_0_frame_source: &'static crate::experimental_swift_reactor::execution::SwiftFrame,
    alias_production_18_7_0_frame_argument: &'static crate::experimental_swift_reactor::execution::SwiftFrame,
    alias_production_18_7_0_frame_returned: &'static crate::experimental_swift_reactor::execution::SwiftFrame,
    alias_production_18_7_0_frame_caller: &'static crate::experimental_swift_reactor::execution::SwiftFrame,
    mir_production_18_8_source: u32,
    mir_production_18_8_argument: u32,
    mir_production_18_8_returned: u32,
    mir_production_18_8_caller: u32,
    mir_production_18_9_source: usize,
    mir_production_18_9_argument: usize,
    mir_production_18_9_returned: usize,
    mir_production_18_9_caller: usize,
    mir_production_18_10_source: usize,
    mir_production_18_10_argument: usize,
    mir_production_18_10_returned: usize,
    mir_production_18_10_caller: usize,
    mir_production_18_11_source: usize,
    mir_production_18_11_argument: usize,
    mir_production_18_11_returned: usize,
    mir_production_18_11_caller: usize,
    mir_production_18_12_source: usize,
    mir_production_18_12_argument: usize,
    mir_production_18_12_returned: usize,
    mir_production_18_12_caller: usize,
    mir_production_18_13_source: bool,
    mir_production_18_13_argument: bool,
    mir_production_18_13_returned: bool,
    mir_production_18_13_caller: bool,
    mir_production_18_14_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_18_14_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_18_14_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_18_14_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_18_15_source: bool,
    mir_production_18_15_argument: bool,
    mir_production_18_15_returned: bool,
    mir_production_18_15_caller: bool,
    mir_production_18_16_source: usize,
    mir_production_18_16_argument: usize,
    mir_production_18_16_returned: usize,
    mir_production_18_16_caller: usize,
    mir_production_18_17_source: usize,
    mir_production_18_17_argument: usize,
    mir_production_18_17_returned: usize,
    mir_production_18_17_caller: usize,
    mir_production_18_18_source: bool,
    mir_production_18_18_argument: bool,
    mir_production_18_18_returned: bool,
    mir_production_18_18_caller: bool,
    mir_production_18_19_source: usize,
    mir_production_18_19_argument: usize,
    mir_production_18_19_returned: usize,
    mir_production_18_19_caller: usize,
    mir_production_18_20_source: usize,
    mir_production_18_20_argument: usize,
    mir_production_18_20_returned: usize,
    mir_production_18_20_caller: usize,
    mir_production_18_21_source: &'static std::vec::Vec<Value>,
    mir_production_18_21_argument: &'static std::vec::Vec<Value>,
    mir_production_18_21_returned: &'static std::vec::Vec<Value>,
    mir_production_18_21_caller: &'static std::vec::Vec<Value>,
    mir_production_18_22_source: bool,
    mir_production_18_22_argument: bool,
    mir_production_18_22_returned: bool,
    mir_production_18_22_caller: bool,
    mir_production_18_23_source: usize,
    mir_production_18_23_argument: usize,
    mir_production_18_23_returned: usize,
    mir_production_18_23_caller: usize,
    mir_production_18_24_source: usize,
    mir_production_18_24_argument: usize,
    mir_production_18_24_returned: usize,
    mir_production_18_24_caller: usize,
    mir_production_18_25_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_18_25_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_18_25_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_18_25_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_18_26_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_18_26_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_18_26_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_18_26_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_18_27_source: &'static mut std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_18_27_argument: &'static mut std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_18_27_returned: &'static mut std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_18_27_caller: &'static mut std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_18_28_source: &'static mut std::vec::Vec<Value>,
    mir_production_18_28_argument: &'static mut std::vec::Vec<Value>,
    mir_production_18_28_returned: &'static mut std::vec::Vec<Value>,
    mir_production_18_28_caller: &'static mut std::vec::Vec<Value>,
    mir_production_18_29_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_18_29_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_18_29_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_18_29_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_18_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_18_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_18_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_18_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_18_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_18_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_18_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_18_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    literal_production_18_0_source: &'static str,
    literal_production_18_0_argument: &'static str,
    literal_production_18_0_returned: &'static str,
    literal_production_18_0_caller: &'static str,
    literal_production_18_1_source: &'static str,
    literal_production_18_1_argument: &'static str,
    literal_production_18_1_returned: &'static str,
    literal_production_18_1_caller: &'static str,
    mir_production_19_0_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_19_0_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_19_0_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_19_0_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_19_2_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_19_2_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_19_2_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_19_2_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_19_3_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_19_3_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_19_3_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_19_3_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_19_4_source: isize,
    mir_production_19_4_argument: isize,
    mir_production_19_4_returned: isize,
    mir_production_19_4_caller: isize,
    mir_production_19_5_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_19_5_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_19_5_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_19_5_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_19_5_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_19_5_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_19_5_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_19_5_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_19_6_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_19_6_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_19_6_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_19_6_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_19_6_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_19_6_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_19_6_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_19_6_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_19_6_1_val_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_19_6_1_val_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_19_6_1_val_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_19_6_1_val_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_19_7_source: std::option::Option<crate::experimental::execution::Control>,
    mir_production_19_7_argument: std::option::Option<crate::experimental::execution::Control>,
    mir_production_19_7_returned: std::option::Option<crate::experimental::execution::Control>,
    mir_production_19_7_caller: std::option::Option<crate::experimental::execution::Control>,
    mir_production_19_8_source: std::option::Option<&'static crate::experimental::execution::Control>,
    mir_production_19_8_argument: std::option::Option<&'static crate::experimental::execution::Control>,
    mir_production_19_8_returned: std::option::Option<&'static crate::experimental::execution::Control>,
    mir_production_19_8_caller: std::option::Option<&'static crate::experimental::execution::Control>,
    mir_production_19_9_source: &'static [crate::experimental::execution::Control],
    mir_production_19_9_argument: &'static [crate::experimental::execution::Control],
    mir_production_19_9_returned: &'static [crate::experimental::execution::Control],
    mir_production_19_9_caller: &'static [crate::experimental::execution::Control],
    mir_production_19_10_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_19_10_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_19_10_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_19_10_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_19_11_source: usize,
    mir_production_19_11_argument: usize,
    mir_production_19_11_returned: usize,
    mir_production_19_11_caller: usize,
    mir_production_19_12_source: isize,
    mir_production_19_12_argument: isize,
    mir_production_19_12_returned: isize,
    mir_production_19_12_caller: isize,
    mir_production_19_14_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_19_14_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_19_14_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_19_14_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_19_15_source: bool,
    mir_production_19_15_argument: bool,
    mir_production_19_15_returned: bool,
    mir_production_19_15_caller: bool,
    mir_production_19_16_source: bool,
    mir_production_19_16_argument: bool,
    mir_production_19_16_returned: bool,
    mir_production_19_16_caller: bool,
    mir_production_19_17_source: usize,
    mir_production_19_17_argument: usize,
    mir_production_19_17_returned: usize,
    mir_production_19_17_caller: usize,
    mir_production_19_18_source: usize,
    mir_production_19_18_argument: usize,
    mir_production_19_18_returned: usize,
    mir_production_19_18_caller: usize,
    mir_production_19_19_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_19_19_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_19_19_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_19_19_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_19_20_source: std::option::Option<usize>,
    mir_production_19_20_argument: std::option::Option<usize>,
    mir_production_19_20_returned: std::option::Option<usize>,
    mir_production_19_20_caller: std::option::Option<usize>,
    mir_production_19_21_source: usize,
    mir_production_19_21_argument: usize,
    mir_production_19_21_returned: usize,
    mir_production_19_21_caller: usize,
    mir_production_19_22_source: isize,
    mir_production_19_22_argument: isize,
    mir_production_19_22_returned: isize,
    mir_production_19_22_caller: isize,
    mir_production_19_24_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_19_24_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_19_24_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_19_24_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_19_25_source: bool,
    mir_production_19_25_argument: bool,
    mir_production_19_25_returned: bool,
    mir_production_19_25_caller: bool,
    mir_production_19_26_source: usize,
    mir_production_19_26_argument: usize,
    mir_production_19_26_returned: usize,
    mir_production_19_26_caller: usize,
    mir_production_19_27_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_19_27_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_19_27_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_19_27_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_19_28_source: usize,
    mir_production_19_28_argument: usize,
    mir_production_19_28_returned: usize,
    mir_production_19_28_caller: usize,
    mir_production_19_29_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_19_29_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_19_29_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_19_29_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_19_13_source: crate::experimental::execution::Control,
    mir_production_19_13_argument: crate::experimental::execution::Control,
    mir_production_19_13_returned: crate::experimental::execution::Control,
    mir_production_19_13_caller: crate::experimental::execution::Control,
    alias_production_19_13_0_sentinel_source: crate::experimental::execution::Control,
    alias_production_19_13_0_sentinel_argument: crate::experimental::execution::Control,
    alias_production_19_13_0_sentinel_returned: crate::experimental::execution::Control,
    alias_production_19_13_0_sentinel_caller: crate::experimental::execution::Control,
    alias_production_19_13_1_control_source: crate::experimental::execution::Control,
    alias_production_19_13_1_control_argument: crate::experimental::execution::Control,
    alias_production_19_13_1_control_returned: crate::experimental::execution::Control,
    alias_production_19_13_1_control_caller: crate::experimental::execution::Control,
    mir_production_19_23_source: usize,
    mir_production_19_23_argument: usize,
    mir_production_19_23_returned: usize,
    mir_production_19_23_caller: usize,
    alias_production_19_23_0_after_end_source: usize,
    alias_production_19_23_0_after_end_argument: usize,
    alias_production_19_23_0_after_end_returned: usize,
    alias_production_19_23_0_after_end_caller: usize,
    alias_production_19_23_1_pc_source: usize,
    alias_production_19_23_1_pc_argument: usize,
    alias_production_19_23_1_pc_returned: usize,
    alias_production_19_23_1_pc_caller: usize,
    mir_production_19_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_19_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_19_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_19_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_19_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_19_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_19_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_19_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    literal_production_19_0_source: &'static str,
    literal_production_19_0_argument: &'static str,
    literal_production_19_0_returned: &'static str,
    literal_production_19_0_caller: &'static str,
    literal_production_19_1_source: &'static str,
    literal_production_19_1_argument: &'static str,
    literal_production_19_1_returned: &'static str,
    literal_production_19_1_caller: &'static str,
    literal_production_19_2_source: usize,
    literal_production_19_2_argument: usize,
    literal_production_19_2_returned: usize,
    literal_production_19_2_caller: usize,
    literal_production_19_3_source: &'static str,
    literal_production_19_3_argument: &'static str,
    literal_production_19_3_returned: &'static str,
    literal_production_19_3_caller: &'static str,
    literal_production_19_4_source: &'static str,
    literal_production_19_4_argument: &'static str,
    literal_production_19_4_returned: &'static str,
    literal_production_19_4_caller: &'static str,
    mir_production_20_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_5_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_20_5_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_20_5_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_20_5_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_20_6_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_6_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_6_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_6_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_7_source: isize,
    mir_production_20_7_argument: isize,
    mir_production_20_7_returned: isize,
    mir_production_20_7_caller: isize,
    mir_production_20_8_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_8_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_8_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_8_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_20_8_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_20_8_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_20_8_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_20_8_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_9_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_20_9_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_20_9_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_20_9_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_20_9_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_20_9_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_20_9_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_20_9_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_20_9_1_val_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_20_9_1_val_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_20_9_1_val_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_20_9_1_val_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_20_10_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_20_10_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_20_10_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_20_10_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_20_11_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_11_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_11_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_11_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_12_source: isize,
    mir_production_20_12_argument: isize,
    mir_production_20_12_returned: isize,
    mir_production_20_12_caller: isize,
    mir_production_20_15_source: bool,
    mir_production_20_15_argument: bool,
    mir_production_20_15_returned: bool,
    mir_production_20_15_caller: bool,
    mir_production_20_16_source: usize,
    mir_production_20_16_argument: usize,
    mir_production_20_16_returned: usize,
    mir_production_20_16_caller: usize,
    mir_production_20_17_source: bool,
    mir_production_20_17_argument: bool,
    mir_production_20_17_returned: bool,
    mir_production_20_17_caller: bool,
    mir_production_20_18_source: bool,
    mir_production_20_18_argument: bool,
    mir_production_20_18_returned: bool,
    mir_production_20_18_caller: bool,
    mir_production_20_19_source: &'static crate::experimental::cache::ControlKind,
    mir_production_20_19_argument: &'static crate::experimental::cache::ControlKind,
    mir_production_20_19_returned: &'static crate::experimental::cache::ControlKind,
    mir_production_20_19_caller: &'static crate::experimental::cache::ControlKind,
    mir_production_20_20_source: &'static crate::experimental::cache::ControlKind,
    mir_production_20_20_argument: &'static crate::experimental::cache::ControlKind,
    mir_production_20_20_returned: &'static crate::experimental::cache::ControlKind,
    mir_production_20_20_caller: &'static crate::experimental::cache::ControlKind,
    mir_production_20_21_source: bool,
    mir_production_20_21_argument: bool,
    mir_production_20_21_returned: bool,
    mir_production_20_21_caller: bool,
    mir_production_20_22_source: &'static std::option::Option<usize>,
    mir_production_20_22_argument: &'static std::option::Option<usize>,
    mir_production_20_22_returned: &'static std::option::Option<usize>,
    mir_production_20_22_caller: &'static std::option::Option<usize>,
    mir_production_20_23_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_20_23_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_20_23_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_20_23_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_20_24_source: isize,
    mir_production_20_24_argument: isize,
    mir_production_20_24_returned: isize,
    mir_production_20_24_caller: isize,
    mir_production_20_26_source: bool,
    mir_production_20_26_argument: bool,
    mir_production_20_26_returned: bool,
    mir_production_20_26_caller: bool,
    mir_production_20_27_source: usize,
    mir_production_20_27_argument: usize,
    mir_production_20_27_returned: usize,
    mir_production_20_27_caller: usize,
    mir_production_20_28_source: bool,
    mir_production_20_28_argument: bool,
    mir_production_20_28_returned: bool,
    mir_production_20_28_caller: bool,
    mir_production_20_29_source: bool,
    mir_production_20_29_argument: bool,
    mir_production_20_29_returned: bool,
    mir_production_20_29_caller: bool,
    mir_production_20_30_source: &'static std::option::Option<usize>,
    mir_production_20_30_argument: &'static std::option::Option<usize>,
    mir_production_20_30_returned: &'static std::option::Option<usize>,
    mir_production_20_30_caller: &'static std::option::Option<usize>,
    mir_production_20_31_source: std::option::Option<usize>,
    mir_production_20_31_argument: std::option::Option<usize>,
    mir_production_20_31_returned: std::option::Option<usize>,
    mir_production_20_31_caller: std::option::Option<usize>,
    mir_production_20_32_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_20_32_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_20_32_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_20_32_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_20_33_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_20_33_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_20_33_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_20_33_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_20_34_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_34_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_34_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_34_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_35_source: std::option::Option<usize>,
    mir_production_20_35_argument: std::option::Option<usize>,
    mir_production_20_35_returned: std::option::Option<usize>,
    mir_production_20_35_caller: std::option::Option<usize>,
    mir_production_20_36_source: std::option::Option<usize>,
    mir_production_20_36_argument: std::option::Option<usize>,
    mir_production_20_36_returned: std::option::Option<usize>,
    mir_production_20_36_caller: std::option::Option<usize>,
    mir_production_20_37_source: usize,
    mir_production_20_37_argument: usize,
    mir_production_20_37_returned: usize,
    mir_production_20_37_caller: usize,
    mir_production_20_38_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_20_38_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_20_38_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_20_38_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_20_39_source: usize,
    mir_production_20_39_argument: usize,
    mir_production_20_39_returned: usize,
    mir_production_20_39_caller: usize,
    mir_production_20_40_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_20_40_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_20_40_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_20_40_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_20_41_source: isize,
    mir_production_20_41_argument: isize,
    mir_production_20_41_returned: isize,
    mir_production_20_41_caller: isize,
    mir_production_20_44_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_20_44_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_20_44_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_20_44_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_20_13_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_13_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_13_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_13_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_20_13_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_20_13_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_20_13_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_20_13_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_14_source: usize,
    mir_production_20_14_argument: usize,
    mir_production_20_14_returned: usize,
    mir_production_20_14_caller: usize,
    alias_production_20_14_0_bound_source: usize,
    alias_production_20_14_0_bound_argument: usize,
    alias_production_20_14_0_bound_returned: usize,
    alias_production_20_14_0_bound_caller: usize,
    alias_production_20_14_1_val_source: usize,
    alias_production_20_14_1_val_argument: usize,
    alias_production_20_14_1_val_returned: usize,
    alias_production_20_14_1_val_caller: usize,
    mir_production_20_42_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_42_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_42_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_42_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_20_42_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_20_42_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_20_42_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_20_42_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_20_43_source: usize,
    mir_production_20_43_argument: usize,
    mir_production_20_43_returned: usize,
    mir_production_20_43_caller: usize,
    alias_production_20_43_0_val_source: usize,
    alias_production_20_43_0_val_argument: usize,
    alias_production_20_43_0_val_returned: usize,
    alias_production_20_43_0_val_caller: usize,
    mir_production_20_25_source: usize,
    mir_production_20_25_argument: usize,
    mir_production_20_25_returned: usize,
    mir_production_20_25_caller: usize,
    alias_production_20_25_0_alternative_source: usize,
    alias_production_20_25_0_alternative_argument: usize,
    alias_production_20_25_0_alternative_returned: usize,
    alias_production_20_25_0_alternative_caller: usize,
    mir_production_20_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_20_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_20_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_20_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_20_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_20_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_20_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_20_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_20_2_source: crate::experimental::cache::ControlKind,
    mir_production_20_2_argument: crate::experimental::cache::ControlKind,
    mir_production_20_2_returned: crate::experimental::cache::ControlKind,
    mir_production_20_2_caller: crate::experimental::cache::ControlKind,
    alias_production_20_2_0_kind_source: crate::experimental::cache::ControlKind,
    alias_production_20_2_0_kind_argument: crate::experimental::cache::ControlKind,
    alias_production_20_2_0_kind_returned: crate::experimental::cache::ControlKind,
    alias_production_20_2_0_kind_caller: crate::experimental::cache::ControlKind,
    mir_production_20_3_source: usize,
    mir_production_20_3_argument: usize,
    mir_production_20_3_returned: usize,
    mir_production_20_3_caller: usize,
    alias_production_20_3_0_end_source: usize,
    alias_production_20_3_0_end_argument: usize,
    alias_production_20_3_0_end_returned: usize,
    alias_production_20_3_0_end_caller: usize,
    mir_production_20_4_source: Option<usize>,
    mir_production_20_4_argument: Option<usize>,
    mir_production_20_4_returned: Option<usize>,
    mir_production_20_4_caller: Option<usize>,
    alias_production_20_4_0_alternative_source: Option<usize>,
    alias_production_20_4_0_alternative_argument: Option<usize>,
    alias_production_20_4_0_alternative_returned: Option<usize>,
    alias_production_20_4_0_alternative_caller: Option<usize>,
    literal_production_20_0_source: &'static str,
    literal_production_20_0_argument: &'static str,
    literal_production_20_0_returned: &'static str,
    literal_production_20_0_caller: &'static str,
    literal_production_20_1_source: usize,
    literal_production_20_1_argument: usize,
    literal_production_20_1_returned: usize,
    literal_production_20_1_caller: usize,
    literal_production_20_2_source: &'static str,
    literal_production_20_2_argument: &'static str,
    literal_production_20_2_returned: &'static str,
    literal_production_20_2_caller: &'static str,
    mir_production_21_0_source: std::option::Option<usize>,
    mir_production_21_0_argument: std::option::Option<usize>,
    mir_production_21_0_returned: std::option::Option<usize>,
    mir_production_21_0_caller: std::option::Option<usize>,
    mir_production_21_1_source: (),
    mir_production_21_1_argument: (),
    mir_production_21_1_returned: (),
    mir_production_21_1_caller: (),
    mir_production_21_2_source: usize,
    mir_production_21_2_argument: usize,
    mir_production_21_2_returned: usize,
    mir_production_21_2_caller: usize,
    alias_production_21_2_0_depth_source: usize,
    alias_production_21_2_0_depth_argument: usize,
    alias_production_21_2_0_depth_returned: usize,
    alias_production_21_2_0_depth_caller: usize,
    literal_production_21_0_source: usize,
    literal_production_21_0_argument: usize,
    literal_production_21_0_returned: usize,
    literal_production_21_0_caller: usize,
    mir_production_22_0_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_22_0_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_22_0_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_22_0_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_22_2_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_22_2_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_22_2_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_22_2_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_22_1_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_22_1_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_22_1_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_22_1_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    literal_production_22_0_source: &'static str,
    literal_production_22_0_argument: &'static str,
    literal_production_22_0_returned: &'static str,
    literal_production_22_0_caller: &'static str,
    mir_production_23_0_source: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_0_argument: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_0_returned: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_0_caller: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_3_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_23_3_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_23_3_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_23_3_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_23_4_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_4_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_4_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_4_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_5_source: isize,
    mir_production_23_5_argument: isize,
    mir_production_23_5_returned: isize,
    mir_production_23_5_caller: isize,
    mir_production_23_6_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_6_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_6_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_6_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_23_6_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_23_6_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_23_6_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_23_6_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_7_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_23_7_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_23_7_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_23_7_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_23_7_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_23_7_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_23_7_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_23_7_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_23_7_1_val_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_23_7_1_val_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_23_7_1_val_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_23_7_1_val_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_23_8_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_23_8_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_23_8_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_23_8_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_23_9_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_9_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_9_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_9_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_10_source: isize,
    mir_production_23_10_argument: isize,
    mir_production_23_10_returned: isize,
    mir_production_23_10_caller: isize,
    mir_production_23_13_source: std::option::Option<crate::experimental::execution::Control>,
    mir_production_23_13_argument: std::option::Option<crate::experimental::execution::Control>,
    mir_production_23_13_returned: std::option::Option<crate::experimental::execution::Control>,
    mir_production_23_13_caller: std::option::Option<crate::experimental::execution::Control>,
    mir_production_23_14_source: std::option::Option<&'static crate::experimental::execution::Control>,
    mir_production_23_14_argument: std::option::Option<&'static crate::experimental::execution::Control>,
    mir_production_23_14_returned: std::option::Option<&'static crate::experimental::execution::Control>,
    mir_production_23_14_caller: std::option::Option<&'static crate::experimental::execution::Control>,
    mir_production_23_15_source: &'static [crate::experimental::execution::Control],
    mir_production_23_15_argument: &'static [crate::experimental::execution::Control],
    mir_production_23_15_returned: &'static [crate::experimental::execution::Control],
    mir_production_23_15_caller: &'static [crate::experimental::execution::Control],
    mir_production_23_16_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_23_16_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_23_16_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_23_16_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_23_17_source: isize,
    mir_production_23_17_argument: isize,
    mir_production_23_17_returned: isize,
    mir_production_23_17_caller: isize,
    mir_production_23_20_source: bool,
    mir_production_23_20_argument: bool,
    mir_production_23_20_returned: bool,
    mir_production_23_20_caller: bool,
    mir_production_23_21_source: usize,
    mir_production_23_21_argument: usize,
    mir_production_23_21_returned: usize,
    mir_production_23_21_caller: usize,
    mir_production_23_22_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_23_22_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_23_22_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_23_22_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_23_23_source: bool,
    mir_production_23_23_argument: bool,
    mir_production_23_23_returned: bool,
    mir_production_23_23_caller: bool,
    mir_production_23_24_source: usize,
    mir_production_23_24_argument: usize,
    mir_production_23_24_returned: usize,
    mir_production_23_24_caller: usize,
    mir_production_23_25_source: bool,
    mir_production_23_25_argument: bool,
    mir_production_23_25_returned: bool,
    mir_production_23_25_caller: bool,
    mir_production_23_26_source: usize,
    mir_production_23_26_argument: usize,
    mir_production_23_26_returned: usize,
    mir_production_23_26_caller: usize,
    mir_production_23_27_source: usize,
    mir_production_23_27_argument: usize,
    mir_production_23_27_returned: usize,
    mir_production_23_27_caller: usize,
    mir_production_23_28_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_23_28_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_23_28_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_23_28_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_23_29_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_23_29_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_23_29_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_23_29_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_23_11_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_11_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_11_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_11_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_23_11_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_23_11_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_23_11_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_23_11_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_23_12_source: usize,
    mir_production_23_12_argument: usize,
    mir_production_23_12_returned: usize,
    mir_production_23_12_caller: usize,
    alias_production_23_12_0_bound_source: usize,
    alias_production_23_12_0_bound_argument: usize,
    alias_production_23_12_0_bound_returned: usize,
    alias_production_23_12_0_bound_caller: usize,
    alias_production_23_12_1_val_source: usize,
    alias_production_23_12_1_val_argument: usize,
    alias_production_23_12_1_val_returned: usize,
    alias_production_23_12_1_val_caller: usize,
    mir_production_23_18_source: crate::experimental::execution::Control,
    mir_production_23_18_argument: crate::experimental::execution::Control,
    mir_production_23_18_returned: crate::experimental::execution::Control,
    mir_production_23_18_caller: crate::experimental::execution::Control,
    alias_production_23_18_0_control_source: crate::experimental::execution::Control,
    alias_production_23_18_0_control_argument: crate::experimental::execution::Control,
    alias_production_23_18_0_control_returned: crate::experimental::execution::Control,
    alias_production_23_18_0_control_caller: crate::experimental::execution::Control,
    alias_production_23_18_1_control_source: crate::experimental::execution::Control,
    alias_production_23_18_1_control_argument: crate::experimental::execution::Control,
    alias_production_23_18_1_control_returned: crate::experimental::execution::Control,
    alias_production_23_18_1_control_caller: crate::experimental::execution::Control,
    mir_production_23_19_source: &'static crate::experimental::execution::Control,
    mir_production_23_19_argument: &'static crate::experimental::execution::Control,
    mir_production_23_19_returned: &'static crate::experimental::execution::Control,
    mir_production_23_19_caller: &'static crate::experimental::execution::Control,
    alias_production_23_19_0_control_source: &'static crate::experimental::execution::Control,
    alias_production_23_19_0_control_argument: &'static crate::experimental::execution::Control,
    alias_production_23_19_0_control_returned: &'static crate::experimental::execution::Control,
    alias_production_23_19_0_control_caller: &'static crate::experimental::execution::Control,
    mir_production_23_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_23_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_23_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_23_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_23_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_23_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_23_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_23_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_23_2_source: usize,
    mir_production_23_2_argument: usize,
    mir_production_23_2_returned: usize,
    mir_production_23_2_caller: usize,
    alias_production_23_2_0_index_source: usize,
    alias_production_23_2_0_index_argument: usize,
    alias_production_23_2_0_index_returned: usize,
    alias_production_23_2_0_index_caller: usize,
    literal_production_23_0_source: &'static str,
    literal_production_23_0_argument: &'static str,
    literal_production_23_0_returned: &'static str,
    literal_production_23_0_caller: &'static str,
    literal_production_23_1_source: &'static str,
    literal_production_23_1_argument: &'static str,
    literal_production_23_1_returned: &'static str,
    literal_production_23_1_caller: &'static str,
    mir_production_24_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_24_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_24_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_24_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_24_3_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_24_3_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_24_3_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_24_3_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_24_4_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_24_4_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_24_4_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_24_4_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_24_5_source: isize,
    mir_production_24_5_argument: isize,
    mir_production_24_5_returned: isize,
    mir_production_24_5_caller: isize,
    mir_production_24_6_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_24_6_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_24_6_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_24_6_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_24_6_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_24_6_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_24_6_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_24_6_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_24_7_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_24_7_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_24_7_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_24_7_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_24_7_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_24_7_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_24_7_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_24_7_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_24_7_1_val_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_24_7_1_val_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_24_7_1_val_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_24_7_1_val_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_24_9_source: bool,
    mir_production_24_9_argument: bool,
    mir_production_24_9_returned: bool,
    mir_production_24_9_caller: bool,
    mir_production_24_10_source: usize,
    mir_production_24_10_argument: usize,
    mir_production_24_10_returned: usize,
    mir_production_24_10_caller: usize,
    mir_production_24_11_source: bool,
    mir_production_24_11_argument: bool,
    mir_production_24_11_returned: bool,
    mir_production_24_11_caller: bool,
    mir_production_24_12_source: usize,
    mir_production_24_12_argument: usize,
    mir_production_24_12_returned: usize,
    mir_production_24_12_caller: usize,
    mir_production_24_13_source: &'static std::vec::Vec<Value>,
    mir_production_24_13_argument: &'static std::vec::Vec<Value>,
    mir_production_24_13_returned: &'static std::vec::Vec<Value>,
    mir_production_24_13_caller: &'static std::vec::Vec<Value>,
    mir_production_24_14_source: bool,
    mir_production_24_14_argument: bool,
    mir_production_24_14_returned: bool,
    mir_production_24_14_caller: bool,
    mir_production_24_15_source: bool,
    mir_production_24_15_argument: bool,
    mir_production_24_15_returned: bool,
    mir_production_24_15_caller: bool,
    mir_production_24_16_source: usize,
    mir_production_24_16_argument: usize,
    mir_production_24_16_returned: usize,
    mir_production_24_16_caller: usize,
    mir_production_24_17_source: &'static std::vec::Vec<Value>,
    mir_production_24_17_argument: &'static std::vec::Vec<Value>,
    mir_production_24_17_returned: &'static std::vec::Vec<Value>,
    mir_production_24_17_caller: &'static std::vec::Vec<Value>,
    mir_production_24_18_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_24_18_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_24_18_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_24_18_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_24_19_source: &'static mut std::vec::Vec<Value>,
    mir_production_24_19_argument: &'static mut std::vec::Vec<Value>,
    mir_production_24_19_returned: &'static mut std::vec::Vec<Value>,
    mir_production_24_19_caller: &'static mut std::vec::Vec<Value>,
    mir_production_24_20_source: &'static mut std::vec::Vec<Value>,
    mir_production_24_20_argument: &'static mut std::vec::Vec<Value>,
    mir_production_24_20_returned: &'static mut std::vec::Vec<Value>,
    mir_production_24_20_caller: &'static mut std::vec::Vec<Value>,
    mir_production_24_8_source: usize,
    mir_production_24_8_argument: usize,
    mir_production_24_8_returned: usize,
    mir_production_24_8_caller: usize,
    alias_production_24_8_0_height_source: usize,
    alias_production_24_8_0_height_argument: usize,
    alias_production_24_8_0_height_returned: usize,
    alias_production_24_8_0_height_caller: usize,
    mir_production_24_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_24_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_24_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_24_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_24_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_24_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_24_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_24_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_24_2_source: crate::experimental::execution::Control,
    mir_production_24_2_argument: crate::experimental::execution::Control,
    mir_production_24_2_returned: crate::experimental::execution::Control,
    mir_production_24_2_caller: crate::experimental::execution::Control,
    alias_production_24_2_0_control_source: crate::experimental::execution::Control,
    alias_production_24_2_0_control_argument: crate::experimental::execution::Control,
    alias_production_24_2_0_control_returned: crate::experimental::execution::Control,
    alias_production_24_2_0_control_caller: crate::experimental::execution::Control,
    literal_production_24_0_source: &'static str,
    literal_production_24_0_argument: &'static str,
    literal_production_24_0_returned: &'static str,
    literal_production_24_0_caller: &'static str,
    mir_production_25_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_25_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_25_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_25_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_25_2_source: usize,
    mir_production_25_2_argument: usize,
    mir_production_25_2_returned: usize,
    mir_production_25_2_caller: usize,
    alias_production_25_2_0_length_source: usize,
    alias_production_25_2_0_length_argument: usize,
    alias_production_25_2_0_length_returned: usize,
    alias_production_25_2_0_length_caller: usize,
    mir_production_25_3_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_25_3_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_25_3_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_25_3_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_25_5_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_25_5_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_25_5_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_25_5_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_25_6_source: bool,
    mir_production_25_6_argument: bool,
    mir_production_25_6_returned: bool,
    mir_production_25_6_caller: bool,
    mir_production_25_7_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_25_7_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_25_7_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_25_7_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_25_8_source: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    mir_production_25_8_argument: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    mir_production_25_8_returned: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    mir_production_25_8_caller: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    mir_production_25_9_source: crate::experimental_swift_reactor::control::SwiftRunResource,
    mir_production_25_9_argument: crate::experimental_swift_reactor::control::SwiftRunResource,
    mir_production_25_9_returned: crate::experimental_swift_reactor::control::SwiftRunResource,
    mir_production_25_9_caller: crate::experimental_swift_reactor::control::SwiftRunResource,
    mir_production_25_10_source: usize,
    mir_production_25_10_argument: usize,
    mir_production_25_10_returned: usize,
    mir_production_25_10_caller: usize,
    mir_production_25_11_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_25_11_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_25_11_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_25_11_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_25_12_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_25_12_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_25_12_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_25_12_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_25_4_source: usize,
    mir_production_25_4_argument: usize,
    mir_production_25_4_returned: usize,
    mir_production_25_4_caller: usize,
    alias_production_25_4_0_capacity_source: usize,
    alias_production_25_4_0_capacity_argument: usize,
    alias_production_25_4_0_capacity_returned: usize,
    alias_production_25_4_0_capacity_caller: usize,
    mir_production_25_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_25_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_25_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_25_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_25_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_25_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_25_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_25_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    literal_production_25_0_source: usize,
    literal_production_25_0_argument: usize,
    literal_production_25_0_returned: usize,
    literal_production_25_0_caller: usize,
    literal_production_25_1_source: &'static str,
    literal_production_25_1_argument: &'static str,
    literal_production_25_1_returned: &'static str,
    literal_production_25_1_caller: &'static str,
    mir_production_26_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_26_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_26_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_26_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_26_7_source: crate::experimental::execution::Control,
    mir_production_26_7_argument: crate::experimental::execution::Control,
    mir_production_26_7_returned: crate::experimental::execution::Control,
    mir_production_26_7_caller: crate::experimental::execution::Control,
    alias_production_26_7_0_control_source: crate::experimental::execution::Control,
    alias_production_26_7_0_control_argument: crate::experimental::execution::Control,
    alias_production_26_7_0_control_returned: crate::experimental::execution::Control,
    alias_production_26_7_0_control_caller: crate::experimental::execution::Control,
    mir_production_26_8_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_26_8_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_26_8_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_26_8_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_26_9_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_26_9_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_26_9_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_26_9_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_26_10_source: crate::experimental_swift_reactor::control::Live,
    mir_production_26_10_argument: crate::experimental_swift_reactor::control::Live,
    mir_production_26_10_returned: crate::experimental_swift_reactor::control::Live,
    mir_production_26_10_caller: crate::experimental_swift_reactor::control::Live,
    mir_production_26_11_source: isize,
    mir_production_26_11_argument: isize,
    mir_production_26_11_returned: isize,
    mir_production_26_11_caller: isize,
    mir_production_26_13_source: (),
    mir_production_26_13_argument: (),
    mir_production_26_13_returned: (),
    mir_production_26_13_caller: (),
    mir_production_26_14_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_26_14_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_26_14_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_26_14_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_26_12_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_26_12_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_26_12_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_26_12_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_26_12_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_26_12_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_26_12_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_26_12_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_26_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_26_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_26_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_26_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_26_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_26_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_26_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_26_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_26_2_source: crate::experimental::cache::ControlKind,
    mir_production_26_2_argument: crate::experimental::cache::ControlKind,
    mir_production_26_2_returned: crate::experimental::cache::ControlKind,
    mir_production_26_2_caller: crate::experimental::cache::ControlKind,
    alias_production_26_2_0_kind_source: crate::experimental::cache::ControlKind,
    alias_production_26_2_0_kind_argument: crate::experimental::cache::ControlKind,
    alias_production_26_2_0_kind_returned: crate::experimental::cache::ControlKind,
    alias_production_26_2_0_kind_caller: crate::experimental::cache::ControlKind,
    mir_production_26_3_source: usize,
    mir_production_26_3_argument: usize,
    mir_production_26_3_returned: usize,
    mir_production_26_3_caller: usize,
    alias_production_26_3_0_start_source: usize,
    alias_production_26_3_0_start_argument: usize,
    alias_production_26_3_0_start_returned: usize,
    alias_production_26_3_0_start_caller: usize,
    mir_production_26_4_source: usize,
    mir_production_26_4_argument: usize,
    mir_production_26_4_returned: usize,
    mir_production_26_4_caller: usize,
    alias_production_26_4_0_end_source: usize,
    alias_production_26_4_0_end_argument: usize,
    alias_production_26_4_0_end_returned: usize,
    alias_production_26_4_0_end_caller: usize,
    mir_production_26_5_source: usize,
    mir_production_26_5_argument: usize,
    mir_production_26_5_returned: usize,
    mir_production_26_5_caller: usize,
    alias_production_26_5_0_height_source: usize,
    alias_production_26_5_0_height_argument: usize,
    alias_production_26_5_0_height_returned: usize,
    alias_production_26_5_0_height_caller: usize,
    mir_production_26_6_source: bool,
    mir_production_26_6_argument: bool,
    mir_production_26_6_returned: bool,
    mir_production_26_6_caller: bool,
    alias_production_26_6_0_result_source: bool,
    alias_production_26_6_0_result_argument: bool,
    alias_production_26_6_0_result_returned: bool,
    alias_production_26_6_0_result_caller: bool,
    mir_production_27_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_27_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_27_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_27_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_27_0_0_result_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_27_0_0_result_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_27_0_0_result_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_27_0_0_result_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_27_4_source: std::option::Option<crate::experimental_wasi::WasiUsage>,
    mir_production_27_4_argument: std::option::Option<crate::experimental_wasi::WasiUsage>,
    mir_production_27_4_returned: std::option::Option<crate::experimental_wasi::WasiUsage>,
    mir_production_27_4_caller: std::option::Option<crate::experimental_wasi::WasiUsage>,
    mir_production_27_5_source: crate::experimental_wasi::WasiUsage,
    mir_production_27_5_argument: crate::experimental_wasi::WasiUsage,
    mir_production_27_5_returned: crate::experimental_wasi::WasiUsage,
    mir_production_27_5_caller: crate::experimental_wasi::WasiUsage,
    mir_production_27_6_source: &'static crate::experimental_wasi::accounted::AccountedWasi,
    mir_production_27_6_argument: &'static crate::experimental_wasi::accounted::AccountedWasi,
    mir_production_27_6_returned: &'static crate::experimental_wasi::accounted::AccountedWasi,
    mir_production_27_6_caller: &'static crate::experimental_wasi::accounted::AccountedWasi,
    mir_production_27_7_source: bool,
    mir_production_27_7_argument: bool,
    mir_production_27_7_returned: bool,
    mir_production_27_7_caller: bool,
    mir_production_27_8_source: &'static std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_27_8_argument: &'static std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_27_8_returned: &'static std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_27_8_caller: &'static std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_27_9_source: &'static mut crate::experimental_swift_reactor::control::RuntimeControl,
    mir_production_27_9_argument: &'static mut crate::experimental_swift_reactor::control::RuntimeControl,
    mir_production_27_9_returned: &'static mut crate::experimental_swift_reactor::control::RuntimeControl,
    mir_production_27_9_caller: &'static mut crate::experimental_swift_reactor::control::RuntimeControl,
    mir_production_27_10_source: &'static mut crate::experimental_wasi::accounted::AccountedWasi,
    mir_production_27_10_argument: &'static mut crate::experimental_wasi::accounted::AccountedWasi,
    mir_production_27_10_returned: &'static mut crate::experimental_wasi::accounted::AccountedWasi,
    mir_production_27_10_caller: &'static mut crate::experimental_wasi::accounted::AccountedWasi,
    mir_production_27_11_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameCleanupState,
    mir_production_27_11_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameCleanupState,
    mir_production_27_11_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameCleanupState,
    mir_production_27_11_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameCleanupState,
    mir_production_27_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_27_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_27_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_27_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_27_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_27_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_27_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_27_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_27_2_source: crate::experimental_swift_reactor::control::Live,
    mir_production_27_2_argument: crate::experimental_swift_reactor::control::Live,
    mir_production_27_2_returned: crate::experimental_swift_reactor::control::Live,
    mir_production_27_2_caller: crate::experimental_swift_reactor::control::Live,
    alias_production_27_2_0_resource_source: crate::experimental_swift_reactor::control::Live,
    alias_production_27_2_0_resource_argument: crate::experimental_swift_reactor::control::Live,
    alias_production_27_2_0_resource_returned: crate::experimental_swift_reactor::control::Live,
    alias_production_27_2_0_resource_caller: crate::experimental_swift_reactor::control::Live,
    mir_production_27_3_source: usize,
    mir_production_27_3_argument: usize,
    mir_production_27_3_returned: usize,
    mir_production_27_3_caller: usize,
    alias_production_27_3_0_amount_source: usize,
    alias_production_27_3_0_amount_argument: usize,
    alias_production_27_3_0_amount_returned: usize,
    alias_production_27_3_0_amount_caller: usize,
    literal_production_27_0_source: bool,
    literal_production_27_0_argument: bool,
    literal_production_27_0_returned: bool,
    literal_production_27_0_caller: bool,
    mir_production_28_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_28_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_28_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_28_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_28_3_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_28_3_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_28_3_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_28_3_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_28_4_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_28_4_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_28_4_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_28_4_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_28_5_source: std::option::Option<usize>,
    mir_production_28_5_argument: std::option::Option<usize>,
    mir_production_28_5_returned: std::option::Option<usize>,
    mir_production_28_5_caller: std::option::Option<usize>,
    mir_production_28_6_source: usize,
    mir_production_28_6_argument: usize,
    mir_production_28_6_returned: usize,
    mir_production_28_6_caller: usize,
    mir_production_28_7_source: &'static std::vec::Vec<Value>,
    mir_production_28_7_argument: &'static std::vec::Vec<Value>,
    mir_production_28_7_returned: &'static std::vec::Vec<Value>,
    mir_production_28_7_caller: &'static std::vec::Vec<Value>,
    mir_production_28_8_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_28_8_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_28_8_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_28_8_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_28_9_source: isize,
    mir_production_28_9_argument: isize,
    mir_production_28_9_returned: isize,
    mir_production_28_9_caller: isize,
    mir_production_28_10_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_28_10_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_28_10_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_28_10_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_28_10_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_28_10_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_28_10_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_28_10_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_28_11_source: usize,
    mir_production_28_11_argument: usize,
    mir_production_28_11_returned: usize,
    mir_production_28_11_caller: usize,
    alias_production_28_11_0_removed_source: usize,
    alias_production_28_11_0_removed_argument: usize,
    alias_production_28_11_0_removed_returned: usize,
    alias_production_28_11_0_removed_caller: usize,
    alias_production_28_11_1_val_source: usize,
    alias_production_28_11_1_val_argument: usize,
    alias_production_28_11_1_val_returned: usize,
    alias_production_28_11_1_val_caller: usize,
    mir_production_28_12_source: (),
    mir_production_28_12_argument: (),
    mir_production_28_12_returned: (),
    mir_production_28_12_caller: (),
    mir_production_28_13_source: crate::experimental_swift_reactor::control::Live,
    mir_production_28_13_argument: crate::experimental_swift_reactor::control::Live,
    mir_production_28_13_returned: crate::experimental_swift_reactor::control::Live,
    mir_production_28_13_caller: crate::experimental_swift_reactor::control::Live,
    mir_production_28_14_source: &'static mut std::vec::Vec<Value>,
    mir_production_28_14_argument: &'static mut std::vec::Vec<Value>,
    mir_production_28_14_returned: &'static mut std::vec::Vec<Value>,
    mir_production_28_14_caller: &'static mut std::vec::Vec<Value>,
    mir_production_28_15_source: &'static mut std::vec::Vec<Value>,
    mir_production_28_15_argument: &'static mut std::vec::Vec<Value>,
    mir_production_28_15_returned: &'static mut std::vec::Vec<Value>,
    mir_production_28_15_caller: &'static mut std::vec::Vec<Value>,
    mir_production_28_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_28_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_28_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_28_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_28_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_28_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_28_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_28_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_28_2_source: usize,
    mir_production_28_2_argument: usize,
    mir_production_28_2_returned: usize,
    mir_production_28_2_caller: usize,
    alias_production_28_2_0_height_source: usize,
    alias_production_28_2_0_height_argument: usize,
    alias_production_28_2_0_height_returned: usize,
    alias_production_28_2_0_height_caller: usize,
    mir_production_29_0_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_29_0_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_29_0_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_29_0_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_29_2_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_29_2_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_29_2_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_29_2_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_29_1_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_29_1_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_29_1_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_29_1_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    literal_production_29_0_source: &'static str,
    literal_production_29_0_argument: &'static str,
    literal_production_29_0_returned: &'static str,
    literal_production_29_0_caller: &'static str,
    mir_production_30_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_30_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_30_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_30_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_30_3_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_30_3_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_30_3_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_30_3_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_30_4_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_30_4_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_30_4_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_30_4_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_30_5_source: std::option::Option<usize>,
    mir_production_30_5_argument: std::option::Option<usize>,
    mir_production_30_5_returned: std::option::Option<usize>,
    mir_production_30_5_caller: std::option::Option<usize>,
    mir_production_30_6_source: usize,
    mir_production_30_6_argument: usize,
    mir_production_30_6_returned: usize,
    mir_production_30_6_caller: usize,
    mir_production_30_7_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_30_7_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_30_7_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_30_7_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_30_8_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_30_8_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_30_8_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_30_8_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_30_9_source: isize,
    mir_production_30_9_argument: isize,
    mir_production_30_9_returned: isize,
    mir_production_30_9_caller: isize,
    mir_production_30_10_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_30_10_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_30_10_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_30_10_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_30_10_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_30_10_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_30_10_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_30_10_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_30_11_source: usize,
    mir_production_30_11_argument: usize,
    mir_production_30_11_returned: usize,
    mir_production_30_11_caller: usize,
    alias_production_30_11_0_removed_source: usize,
    alias_production_30_11_0_removed_argument: usize,
    alias_production_30_11_0_removed_returned: usize,
    alias_production_30_11_0_removed_caller: usize,
    alias_production_30_11_1_val_source: usize,
    alias_production_30_11_1_val_argument: usize,
    alias_production_30_11_1_val_returned: usize,
    alias_production_30_11_1_val_caller: usize,
    mir_production_30_12_source: (),
    mir_production_30_12_argument: (),
    mir_production_30_12_returned: (),
    mir_production_30_12_caller: (),
    mir_production_30_13_source: crate::experimental_swift_reactor::control::Live,
    mir_production_30_13_argument: crate::experimental_swift_reactor::control::Live,
    mir_production_30_13_returned: crate::experimental_swift_reactor::control::Live,
    mir_production_30_13_caller: crate::experimental_swift_reactor::control::Live,
    mir_production_30_14_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_30_14_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_30_14_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_30_14_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_30_15_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_30_15_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_30_15_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_30_15_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_30_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_30_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_30_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_30_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_30_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_30_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_30_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_30_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_30_2_source: usize,
    mir_production_30_2_argument: usize,
    mir_production_30_2_returned: usize,
    mir_production_30_2_caller: usize,
    alias_production_30_2_0_height_source: usize,
    alias_production_30_2_0_height_argument: usize,
    alias_production_30_2_0_height_returned: usize,
    alias_production_30_2_0_height_caller: usize,
    mir_production_31_0_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_31_0_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_31_0_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_31_0_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_31_2_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_31_2_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_31_2_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_31_2_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_31_1_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_31_1_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_31_1_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_31_1_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    literal_production_31_0_source: &'static str,
    literal_production_31_0_argument: &'static str,
    literal_production_31_0_returned: &'static str,
    literal_production_31_0_caller: &'static str,
    mir_production_32_0_source: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_0_argument: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_0_returned: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_0_caller: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_2_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_32_2_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_32_2_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_32_2_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_32_3_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_3_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_3_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_3_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_4_source: isize,
    mir_production_32_4_argument: isize,
    mir_production_32_4_returned: isize,
    mir_production_32_4_caller: isize,
    mir_production_32_5_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_5_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_5_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_5_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_32_5_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_32_5_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_32_5_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_32_5_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_6_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_32_6_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_32_6_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_32_6_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_32_6_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_32_6_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_32_6_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_32_6_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_32_6_1_val_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_32_6_1_val_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_32_6_1_val_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_32_6_1_val_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_32_7_source: bool,
    mir_production_32_7_argument: bool,
    mir_production_32_7_returned: bool,
    mir_production_32_7_caller: bool,
    mir_production_32_8_source: usize,
    mir_production_32_8_argument: usize,
    mir_production_32_8_returned: usize,
    mir_production_32_8_caller: usize,
    mir_production_32_9_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_32_9_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_32_9_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_32_9_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_32_10_source: usize,
    mir_production_32_10_argument: usize,
    mir_production_32_10_returned: usize,
    mir_production_32_10_caller: usize,
    mir_production_32_11_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_32_11_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_32_11_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_32_11_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_32_13_source: std::option::Option<crate::experimental::execution::Control>,
    mir_production_32_13_argument: std::option::Option<crate::experimental::execution::Control>,
    mir_production_32_13_returned: std::option::Option<crate::experimental::execution::Control>,
    mir_production_32_13_caller: std::option::Option<crate::experimental::execution::Control>,
    mir_production_32_14_source: &'static str,
    mir_production_32_14_argument: &'static str,
    mir_production_32_14_returned: &'static str,
    mir_production_32_14_caller: &'static str,
    mir_production_32_15_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_32_15_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_32_15_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_32_15_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_32_16_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_16_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_16_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_16_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_17_source: crate::experimental_swift_reactor::control::Live,
    mir_production_32_17_argument: crate::experimental_swift_reactor::control::Live,
    mir_production_32_17_returned: crate::experimental_swift_reactor::control::Live,
    mir_production_32_17_caller: crate::experimental_swift_reactor::control::Live,
    mir_production_32_18_source: isize,
    mir_production_32_18_argument: isize,
    mir_production_32_18_returned: isize,
    mir_production_32_18_caller: isize,
    mir_production_32_20_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_32_20_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_32_20_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_32_20_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_32_21_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_32_21_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_32_21_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_32_21_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_32_12_source: crate::experimental::execution::Control,
    mir_production_32_12_argument: crate::experimental::execution::Control,
    mir_production_32_12_returned: crate::experimental::execution::Control,
    mir_production_32_12_caller: crate::experimental::execution::Control,
    alias_production_32_12_0_control_source: crate::experimental::execution::Control,
    alias_production_32_12_0_control_argument: crate::experimental::execution::Control,
    alias_production_32_12_0_control_returned: crate::experimental::execution::Control,
    alias_production_32_12_0_control_caller: crate::experimental::execution::Control,
    mir_production_32_19_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_19_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_19_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_19_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_32_19_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_32_19_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_32_19_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_32_19_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_32_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_32_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_32_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_32_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_32_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_32_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_32_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_32_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    literal_production_32_0_source: &'static str,
    literal_production_32_0_argument: &'static str,
    literal_production_32_0_returned: &'static str,
    literal_production_32_0_caller: &'static str,
    literal_production_32_1_source: &'static str,
    literal_production_32_1_argument: &'static str,
    literal_production_32_1_returned: &'static str,
    literal_production_32_1_caller: &'static str,
    literal_production_32_2_source: usize,
    literal_production_32_2_argument: usize,
    literal_production_32_2_returned: usize,
    literal_production_32_2_caller: usize,
    mir_production_33_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_33_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_33_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_33_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_33_3_source: std::option::Option<&'static mut crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_33_3_argument: std::option::Option<&'static mut crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_33_3_returned: std::option::Option<&'static mut crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_33_3_caller: std::option::Option<&'static mut crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_33_4_source: &'static mut [crate::experimental_swift_reactor::execution::SwiftFrame],
    mir_production_33_4_argument: &'static mut [crate::experimental_swift_reactor::execution::SwiftFrame],
    mir_production_33_4_returned: &'static mut [crate::experimental_swift_reactor::execution::SwiftFrame],
    mir_production_33_4_caller: &'static mut [crate::experimental_swift_reactor::execution::SwiftFrame],
    mir_production_33_5_source: isize,
    mir_production_33_5_argument: isize,
    mir_production_33_5_returned: isize,
    mir_production_33_5_caller: isize,
    mir_production_33_6_source: &'static mut crate::experimental_swift_reactor::execution::SwiftFrame,
    mir_production_33_6_argument: &'static mut crate::experimental_swift_reactor::execution::SwiftFrame,
    mir_production_33_6_returned: &'static mut crate::experimental_swift_reactor::execution::SwiftFrame,
    mir_production_33_6_caller: &'static mut crate::experimental_swift_reactor::execution::SwiftFrame,
    alias_production_33_6_0_frame_source: &'static mut crate::experimental_swift_reactor::execution::SwiftFrame,
    alias_production_33_6_0_frame_argument: &'static mut crate::experimental_swift_reactor::execution::SwiftFrame,
    alias_production_33_6_0_frame_returned: &'static mut crate::experimental_swift_reactor::execution::SwiftFrame,
    alias_production_33_6_0_frame_caller: &'static mut crate::experimental_swift_reactor::execution::SwiftFrame,
    mir_production_33_7_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_33_7_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_33_7_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_33_7_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_33_8_source: &'static mut std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_33_8_argument: &'static mut std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_33_8_returned: &'static mut std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_33_8_caller: &'static mut std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    mir_production_33_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_33_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_33_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_33_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_33_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_33_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_33_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_33_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_33_2_source: usize,
    mir_production_33_2_argument: usize,
    mir_production_33_2_returned: usize,
    mir_production_33_2_caller: usize,
    alias_production_33_2_0_pc_source: usize,
    alias_production_33_2_0_pc_argument: usize,
    alias_production_33_2_0_pc_returned: usize,
    alias_production_33_2_0_pc_caller: usize,
    literal_production_33_0_source: &'static str,
    literal_production_33_0_argument: &'static str,
    literal_production_33_0_returned: &'static str,
    literal_production_33_0_caller: &'static str,
    mir_production_34_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_3_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_34_3_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_34_3_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_34_3_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_34_4_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_4_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_4_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_4_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_5_source: isize,
    mir_production_34_5_argument: isize,
    mir_production_34_5_returned: isize,
    mir_production_34_5_caller: isize,
    mir_production_34_6_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_6_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_6_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_6_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_34_6_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_34_6_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_34_6_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_34_6_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_7_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_34_7_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_34_7_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_34_7_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_34_7_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_34_7_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_34_7_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_34_7_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_34_7_1_val_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_34_7_1_val_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_34_7_1_val_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_34_7_1_val_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_34_8_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_34_8_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_34_8_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_34_8_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_34_9_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_9_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_9_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_9_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_10_source: isize,
    mir_production_34_10_argument: isize,
    mir_production_34_10_returned: isize,
    mir_production_34_10_caller: isize,
    mir_production_34_13_source: std::option::Option<crate::experimental::execution::Control>,
    mir_production_34_13_argument: std::option::Option<crate::experimental::execution::Control>,
    mir_production_34_13_returned: std::option::Option<crate::experimental::execution::Control>,
    mir_production_34_13_caller: std::option::Option<crate::experimental::execution::Control>,
    mir_production_34_14_source: std::option::Option<&'static crate::experimental::execution::Control>,
    mir_production_34_14_argument: std::option::Option<&'static crate::experimental::execution::Control>,
    mir_production_34_14_returned: std::option::Option<&'static crate::experimental::execution::Control>,
    mir_production_34_14_caller: std::option::Option<&'static crate::experimental::execution::Control>,
    mir_production_34_15_source: &'static [crate::experimental::execution::Control],
    mir_production_34_15_argument: &'static [crate::experimental::execution::Control],
    mir_production_34_15_returned: &'static [crate::experimental::execution::Control],
    mir_production_34_15_caller: &'static [crate::experimental::execution::Control],
    mir_production_34_16_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_34_16_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_34_16_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_34_16_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_34_17_source: isize,
    mir_production_34_17_argument: isize,
    mir_production_34_17_returned: isize,
    mir_production_34_17_caller: isize,
    mir_production_34_20_source: bool,
    mir_production_34_20_argument: bool,
    mir_production_34_20_returned: bool,
    mir_production_34_20_caller: bool,
    mir_production_34_21_source: usize,
    mir_production_34_21_argument: usize,
    mir_production_34_21_returned: usize,
    mir_production_34_21_caller: usize,
    mir_production_34_22_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_34_22_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_34_22_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_34_22_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_34_23_source: usize,
    mir_production_34_23_argument: usize,
    mir_production_34_23_returned: usize,
    mir_production_34_23_caller: usize,
    mir_production_34_24_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_34_24_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_34_24_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_34_24_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_34_25_source: bool,
    mir_production_34_25_argument: bool,
    mir_production_34_25_returned: bool,
    mir_production_34_25_caller: bool,
    mir_production_34_26_source: bool,
    mir_production_34_26_argument: bool,
    mir_production_34_26_returned: bool,
    mir_production_34_26_caller: bool,
    mir_production_34_27_source: usize,
    mir_production_34_27_argument: usize,
    mir_production_34_27_returned: usize,
    mir_production_34_27_caller: usize,
    mir_production_34_28_source: bool,
    mir_production_34_28_argument: bool,
    mir_production_34_28_returned: bool,
    mir_production_34_28_caller: bool,
    mir_production_34_29_source: usize,
    mir_production_34_29_argument: usize,
    mir_production_34_29_returned: usize,
    mir_production_34_29_caller: usize,
    mir_production_34_30_source: bool,
    mir_production_34_30_argument: bool,
    mir_production_34_30_returned: bool,
    mir_production_34_30_caller: bool,
    mir_production_34_31_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_34_31_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_34_31_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_34_31_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_34_32_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_34_32_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_34_32_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_34_32_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_34_33_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_34_33_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_34_33_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_34_33_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_34_11_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_11_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_11_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_11_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_34_11_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_34_11_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_34_11_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_34_11_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_34_12_source: usize,
    mir_production_34_12_argument: usize,
    mir_production_34_12_returned: usize,
    mir_production_34_12_caller: usize,
    alias_production_34_12_0_bound_source: usize,
    alias_production_34_12_0_bound_argument: usize,
    alias_production_34_12_0_bound_returned: usize,
    alias_production_34_12_0_bound_caller: usize,
    alias_production_34_12_1_val_source: usize,
    alias_production_34_12_1_val_argument: usize,
    alias_production_34_12_1_val_returned: usize,
    alias_production_34_12_1_val_caller: usize,
    mir_production_34_18_source: crate::experimental::execution::Control,
    mir_production_34_18_argument: crate::experimental::execution::Control,
    mir_production_34_18_returned: crate::experimental::execution::Control,
    mir_production_34_18_caller: crate::experimental::execution::Control,
    alias_production_34_18_0_control_source: crate::experimental::execution::Control,
    alias_production_34_18_0_control_argument: crate::experimental::execution::Control,
    alias_production_34_18_0_control_returned: crate::experimental::execution::Control,
    alias_production_34_18_0_control_caller: crate::experimental::execution::Control,
    alias_production_34_18_1_control_source: crate::experimental::execution::Control,
    alias_production_34_18_1_control_argument: crate::experimental::execution::Control,
    alias_production_34_18_1_control_returned: crate::experimental::execution::Control,
    alias_production_34_18_1_control_caller: crate::experimental::execution::Control,
    mir_production_34_19_source: &'static crate::experimental::execution::Control,
    mir_production_34_19_argument: &'static crate::experimental::execution::Control,
    mir_production_34_19_returned: &'static crate::experimental::execution::Control,
    mir_production_34_19_caller: &'static crate::experimental::execution::Control,
    alias_production_34_19_0_control_source: &'static crate::experimental::execution::Control,
    alias_production_34_19_0_control_argument: &'static crate::experimental::execution::Control,
    alias_production_34_19_0_control_returned: &'static crate::experimental::execution::Control,
    alias_production_34_19_0_control_caller: &'static crate::experimental::execution::Control,
    mir_production_34_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_34_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_34_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_34_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_34_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_34_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_34_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_34_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_34_2_source: usize,
    mir_production_34_2_argument: usize,
    mir_production_34_2_returned: usize,
    mir_production_34_2_caller: usize,
    alias_production_34_2_0_end_source: usize,
    alias_production_34_2_0_end_argument: usize,
    alias_production_34_2_0_end_returned: usize,
    alias_production_34_2_0_end_caller: usize,
    literal_production_34_0_source: &'static str,
    literal_production_34_0_argument: &'static str,
    literal_production_34_0_returned: &'static str,
    literal_production_34_0_caller: &'static str,
    literal_production_34_1_source: &'static str,
    literal_production_34_1_argument: &'static str,
    literal_production_34_1_returned: &'static str,
    literal_production_34_1_caller: &'static str,
    mir_production_35_0_source: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_35_0_argument: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_35_0_returned: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_35_0_caller: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_35_0_0_result_source: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_35_0_0_result_argument: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_35_0_0_result_returned: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_35_0_0_result_caller: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_35_4_source: bool,
    mir_production_35_4_argument: bool,
    mir_production_35_4_returned: bool,
    mir_production_35_4_caller: bool,
    mir_production_35_5_source: &'static std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_35_5_argument: &'static std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_35_5_returned: &'static std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_35_5_caller: &'static std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_35_6_source: (),
    mir_production_35_6_argument: (),
    mir_production_35_6_returned: (),
    mir_production_35_6_caller: (),
    mir_production_35_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_35_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_35_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_35_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_35_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_35_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_35_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_35_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_35_2_source: crate::experimental::cache::Operation,
    mir_production_35_2_argument: crate::experimental::cache::Operation,
    mir_production_35_2_returned: crate::experimental::cache::Operation,
    mir_production_35_2_caller: crate::experimental::cache::Operation,
    alias_production_35_2_0_operation_source: crate::experimental::cache::Operation,
    alias_production_35_2_0_operation_argument: crate::experimental::cache::Operation,
    alias_production_35_2_0_operation_returned: crate::experimental::cache::Operation,
    alias_production_35_2_0_operation_caller: crate::experimental::cache::Operation,
    mir_production_35_3_source: Option<u32>,
    mir_production_35_3_argument: Option<u32>,
    mir_production_35_3_returned: Option<u32>,
    mir_production_35_3_caller: Option<u32>,
    alias_production_35_3_0_selected_target_source: Option<u32>,
    alias_production_35_3_0_selected_target_argument: Option<u32>,
    alias_production_35_3_0_selected_target_returned: Option<u32>,
    alias_production_35_3_0_selected_target_caller: Option<u32>,
    mir_production_36_0_source: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_0_argument: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_0_returned: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_0_caller: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_4_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_4_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_4_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_4_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_5_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_5_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_5_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_5_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_6_source: isize,
    mir_production_36_6_argument: isize,
    mir_production_36_6_returned: isize,
    mir_production_36_6_caller: isize,
    mir_production_36_7_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_7_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_7_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_7_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_7_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_7_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_7_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_7_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_8_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_36_8_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_36_8_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_36_8_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_36_9_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_9_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_9_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_9_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_10_source: isize,
    mir_production_36_10_argument: isize,
    mir_production_36_10_returned: isize,
    mir_production_36_10_caller: isize,
    mir_production_36_11_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_11_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_11_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_11_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_11_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_11_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_11_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_11_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_12_source: usize,
    mir_production_36_12_argument: usize,
    mir_production_36_12_returned: usize,
    mir_production_36_12_caller: usize,
    alias_production_36_12_0_val_source: usize,
    alias_production_36_12_0_val_argument: usize,
    alias_production_36_12_0_val_returned: usize,
    alias_production_36_12_0_val_caller: usize,
    mir_production_36_13_source: bool,
    mir_production_36_13_argument: bool,
    mir_production_36_13_returned: bool,
    mir_production_36_13_caller: bool,
    alias_production_36_13_0_finished_source: bool,
    alias_production_36_13_0_finished_argument: bool,
    alias_production_36_13_0_finished_returned: bool,
    alias_production_36_13_0_finished_caller: bool,
    mir_production_36_14_source: isize,
    mir_production_36_14_argument: isize,
    mir_production_36_14_returned: isize,
    mir_production_36_14_caller: isize,
    mir_production_36_20_source: bool,
    mir_production_36_20_argument: bool,
    mir_production_36_20_returned: bool,
    mir_production_36_20_caller: bool,
    mir_production_36_21_source: &'static crate::experimental::cache::ControlKind,
    mir_production_36_21_argument: &'static crate::experimental::cache::ControlKind,
    mir_production_36_21_returned: &'static crate::experimental::cache::ControlKind,
    mir_production_36_21_caller: &'static crate::experimental::cache::ControlKind,
    mir_production_36_22_source: &'static crate::experimental::cache::ControlKind,
    mir_production_36_22_argument: &'static crate::experimental::cache::ControlKind,
    mir_production_36_22_returned: &'static crate::experimental::cache::ControlKind,
    mir_production_36_22_caller: &'static crate::experimental::cache::ControlKind,
    mir_production_36_23_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    mir_production_36_23_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    mir_production_36_23_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    mir_production_36_23_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    mir_production_36_24_source: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_24_argument: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_24_returned: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_24_caller: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_25_source: isize,
    mir_production_36_25_argument: isize,
    mir_production_36_25_returned: isize,
    mir_production_36_25_caller: isize,
    mir_production_36_28_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_28_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_28_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_28_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_29_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_29_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_29_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_29_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_30_source: isize,
    mir_production_36_30_argument: isize,
    mir_production_36_30_returned: isize,
    mir_production_36_30_caller: isize,
    mir_production_36_32_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_32_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_32_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_32_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_33_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_33_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_33_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_33_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_34_source: isize,
    mir_production_36_34_argument: isize,
    mir_production_36_34_returned: isize,
    mir_production_36_34_caller: isize,
    mir_production_36_36_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_36_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_36_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_36_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_37_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_37_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_37_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_37_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_38_source: isize,
    mir_production_36_38_argument: isize,
    mir_production_36_38_returned: isize,
    mir_production_36_38_caller: isize,
    mir_production_36_40_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_36_40_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_36_40_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_36_40_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    mir_production_36_41_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_41_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_41_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_41_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_42_source: isize,
    mir_production_36_42_argument: isize,
    mir_production_36_42_returned: isize,
    mir_production_36_42_caller: isize,
    mir_production_36_45_source: bool,
    mir_production_36_45_argument: bool,
    mir_production_36_45_returned: bool,
    mir_production_36_45_caller: bool,
    mir_production_36_46_source: usize,
    mir_production_36_46_argument: usize,
    mir_production_36_46_returned: usize,
    mir_production_36_46_caller: usize,
    mir_production_36_47_source: usize,
    mir_production_36_47_argument: usize,
    mir_production_36_47_returned: usize,
    mir_production_36_47_caller: usize,
    mir_production_36_48_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_36_48_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_36_48_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_36_48_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_36_49_source: usize,
    mir_production_36_49_argument: usize,
    mir_production_36_49_returned: usize,
    mir_production_36_49_caller: usize,
    mir_production_36_50_source: (usize, bool),
    mir_production_36_50_argument: (usize, bool),
    mir_production_36_50_returned: (usize, bool),
    mir_production_36_50_caller: (usize, bool),
    mir_production_36_51_source: usize,
    mir_production_36_51_argument: usize,
    mir_production_36_51_returned: usize,
    mir_production_36_51_caller: usize,
    mir_production_36_52_source: &'static crate::experimental::policy::Policy<'static>,
    mir_production_36_52_argument: &'static crate::experimental::policy::Policy<'static>,
    mir_production_36_52_returned: &'static crate::experimental::policy::Policy<'static>,
    mir_production_36_52_caller: &'static crate::experimental::policy::Policy<'static>,
    mir_production_36_53_source: &'static crate::experimental::swift::ValidatedSwiftReactor,
    mir_production_36_53_argument: &'static crate::experimental::swift::ValidatedSwiftReactor,
    mir_production_36_53_returned: &'static crate::experimental::swift::ValidatedSwiftReactor,
    mir_production_36_53_caller: &'static crate::experimental::swift::ValidatedSwiftReactor,
    mir_production_36_54_source: &'static crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    mir_production_36_54_argument: &'static crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    mir_production_36_54_returned: &'static crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    mir_production_36_54_caller: &'static crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    mir_production_36_55_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_36_55_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_36_55_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_36_55_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_36_56_source: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    mir_production_36_56_argument: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    mir_production_36_56_returned: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    mir_production_36_56_caller: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    mir_production_36_57_source: crate::experimental_swift_reactor::control::SwiftRunResource,
    mir_production_36_57_argument: crate::experimental_swift_reactor::control::SwiftRunResource,
    mir_production_36_57_returned: crate::experimental_swift_reactor::control::SwiftRunResource,
    mir_production_36_57_caller: crate::experimental_swift_reactor::control::SwiftRunResource,
    mir_production_36_58_source: usize,
    mir_production_36_58_argument: usize,
    mir_production_36_58_returned: usize,
    mir_production_36_58_caller: usize,
    mir_production_36_59_source: usize,
    mir_production_36_59_argument: usize,
    mir_production_36_59_returned: usize,
    mir_production_36_59_caller: usize,
    mir_production_36_60_source: usize,
    mir_production_36_60_argument: usize,
    mir_production_36_60_returned: usize,
    mir_production_36_60_caller: usize,
    mir_production_36_61_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_36_61_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_36_61_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_36_61_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_36_62_source: usize,
    mir_production_36_62_argument: usize,
    mir_production_36_62_returned: usize,
    mir_production_36_62_caller: usize,
    mir_production_36_63_source: (usize, bool),
    mir_production_36_63_argument: (usize, bool),
    mir_production_36_63_returned: (usize, bool),
    mir_production_36_63_caller: (usize, bool),
    mir_production_36_64_source: (usize, bool),
    mir_production_36_64_argument: (usize, bool),
    mir_production_36_64_returned: (usize, bool),
    mir_production_36_64_caller: (usize, bool),
    mir_production_36_65_source: usize,
    mir_production_36_65_argument: usize,
    mir_production_36_65_returned: usize,
    mir_production_36_65_caller: usize,
    mir_production_36_66_source: &'static crate::experimental::policy::Policy<'static>,
    mir_production_36_66_argument: &'static crate::experimental::policy::Policy<'static>,
    mir_production_36_66_returned: &'static crate::experimental::policy::Policy<'static>,
    mir_production_36_66_caller: &'static crate::experimental::policy::Policy<'static>,
    mir_production_36_67_source: &'static crate::experimental::swift::ValidatedSwiftReactor,
    mir_production_36_67_argument: &'static crate::experimental::swift::ValidatedSwiftReactor,
    mir_production_36_67_returned: &'static crate::experimental::swift::ValidatedSwiftReactor,
    mir_production_36_67_caller: &'static crate::experimental::swift::ValidatedSwiftReactor,
    mir_production_36_68_source: &'static crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    mir_production_36_68_argument: &'static crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    mir_production_36_68_returned: &'static crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    mir_production_36_68_caller: &'static crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    mir_production_36_69_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_69_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_69_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_69_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_70_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_70_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_70_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_70_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_71_source: usize,
    mir_production_36_71_argument: usize,
    mir_production_36_71_returned: usize,
    mir_production_36_71_caller: usize,
    mir_production_36_72_source: usize,
    mir_production_36_72_argument: usize,
    mir_production_36_72_returned: usize,
    mir_production_36_72_caller: usize,
    mir_production_36_73_source: &'static std::vec::Vec<Value>,
    mir_production_36_73_argument: &'static std::vec::Vec<Value>,
    mir_production_36_73_returned: &'static std::vec::Vec<Value>,
    mir_production_36_73_caller: &'static std::vec::Vec<Value>,
    mir_production_36_74_source: bool,
    mir_production_36_74_argument: bool,
    mir_production_36_74_returned: bool,
    mir_production_36_74_caller: bool,
    mir_production_36_75_source: &'static std::option::Option<Type>,
    mir_production_36_75_argument: &'static std::option::Option<Type>,
    mir_production_36_75_returned: &'static std::option::Option<Type>,
    mir_production_36_75_caller: &'static std::option::Option<Type>,
    mir_production_36_76_source: isize,
    mir_production_36_76_argument: isize,
    mir_production_36_76_returned: isize,
    mir_production_36_76_caller: isize,
    mir_production_36_78_source: bool,
    mir_production_36_78_argument: bool,
    mir_production_36_78_returned: bool,
    mir_production_36_78_caller: bool,
    mir_production_36_80_source: isize,
    mir_production_36_80_argument: isize,
    mir_production_36_80_returned: isize,
    mir_production_36_80_caller: isize,
    mir_production_36_82_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_36_82_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_36_82_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_36_82_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    mir_production_36_83_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_83_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_83_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_83_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_84_source: std::option::Option<usize>,
    mir_production_36_84_argument: std::option::Option<usize>,
    mir_production_36_84_returned: std::option::Option<usize>,
    mir_production_36_84_caller: std::option::Option<usize>,
    mir_production_36_85_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_36_85_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_36_85_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_36_85_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_36_86_source: isize,
    mir_production_36_86_argument: isize,
    mir_production_36_86_returned: isize,
    mir_production_36_86_caller: isize,
    mir_production_36_89_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_89_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_89_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_89_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_90_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_90_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_90_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_90_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_91_source: usize,
    mir_production_36_91_argument: usize,
    mir_production_36_91_returned: usize,
    mir_production_36_91_caller: usize,
    mir_production_36_92_source: isize,
    mir_production_36_92_argument: isize,
    mir_production_36_92_returned: isize,
    mir_production_36_92_caller: isize,
    mir_production_36_94_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_94_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_94_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_94_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_95_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_95_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_95_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_95_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_96_source: isize,
    mir_production_36_96_argument: isize,
    mir_production_36_96_returned: isize,
    mir_production_36_96_caller: isize,
    mir_production_36_99_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_99_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_99_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_99_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_100_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_100_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_100_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_100_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_101_source: isize,
    mir_production_36_101_argument: isize,
    mir_production_36_101_returned: isize,
    mir_production_36_101_caller: isize,
    mir_production_36_103_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_103_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_103_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_103_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_104_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_104_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_104_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_104_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_105_source: isize,
    mir_production_36_105_argument: isize,
    mir_production_36_105_returned: isize,
    mir_production_36_105_caller: isize,
    mir_production_36_107_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental::execution::Control>,
    mir_production_36_107_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental::execution::Control>,
    mir_production_36_107_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental::execution::Control>,
    mir_production_36_107_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental::execution::Control>,
    mir_production_36_108_source: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_108_argument: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_108_returned: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_108_caller: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_109_source: isize,
    mir_production_36_109_argument: isize,
    mir_production_36_109_returned: isize,
    mir_production_36_109_caller: isize,
    mir_production_36_112_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_112_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_112_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_112_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_113_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_113_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_113_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_113_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_114_source: isize,
    mir_production_36_114_argument: isize,
    mir_production_36_114_returned: isize,
    mir_production_36_114_caller: isize,
    mir_production_36_116_source: bool,
    mir_production_36_116_argument: bool,
    mir_production_36_116_returned: bool,
    mir_production_36_116_caller: bool,
    mir_production_36_117_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_117_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_117_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_117_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    mir_production_36_118_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_118_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_118_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_118_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_119_source: isize,
    mir_production_36_119_argument: isize,
    mir_production_36_119_returned: isize,
    mir_production_36_119_caller: isize,
    mir_production_36_122_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    mir_production_36_122_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    mir_production_36_122_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    mir_production_36_122_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    mir_production_36_123_source: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_123_argument: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_123_returned: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_123_caller: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_124_source: isize,
    mir_production_36_124_argument: isize,
    mir_production_36_124_returned: isize,
    mir_production_36_124_caller: isize,
    mir_production_36_128_source: bool,
    mir_production_36_128_argument: bool,
    mir_production_36_128_returned: bool,
    mir_production_36_128_caller: bool,
    mir_production_36_129_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    mir_production_36_129_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    mir_production_36_129_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    mir_production_36_129_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    mir_production_36_130_source: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_130_argument: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_130_returned: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_130_caller: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_131_source: isize,
    mir_production_36_131_argument: isize,
    mir_production_36_131_returned: isize,
    mir_production_36_131_caller: isize,
    mir_production_36_134_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    mir_production_36_134_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    mir_production_36_134_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    mir_production_36_134_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    mir_production_36_135_source: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_135_argument: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_135_returned: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_135_caller: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_136_source: isize,
    mir_production_36_136_argument: isize,
    mir_production_36_136_returned: isize,
    mir_production_36_136_caller: isize,
    mir_production_36_140_source: bool,
    mir_production_36_140_argument: bool,
    mir_production_36_140_returned: bool,
    mir_production_36_140_caller: bool,
    mir_production_36_141_source: &'static std::option::Option<u32>,
    mir_production_36_141_argument: &'static std::option::Option<u32>,
    mir_production_36_141_returned: &'static std::option::Option<u32>,
    mir_production_36_141_caller: &'static std::option::Option<u32>,
    mir_production_36_142_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_36_142_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_36_142_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_36_142_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_36_143_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    mir_production_36_143_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    mir_production_36_143_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    mir_production_36_143_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    mir_production_36_144_source: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_144_argument: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_144_returned: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_144_caller: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_145_source: isize,
    mir_production_36_145_argument: isize,
    mir_production_36_145_returned: isize,
    mir_production_36_145_caller: isize,
    mir_production_36_148_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    mir_production_36_148_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    mir_production_36_148_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    mir_production_36_148_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    mir_production_36_149_source: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_149_argument: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_149_returned: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_149_caller: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_150_source: u32,
    mir_production_36_150_argument: u32,
    mir_production_36_150_returned: u32,
    mir_production_36_150_caller: u32,
    mir_production_36_151_source: &'static str,
    mir_production_36_151_argument: &'static str,
    mir_production_36_151_returned: &'static str,
    mir_production_36_151_caller: &'static str,
    mir_production_36_152_source: isize,
    mir_production_36_152_argument: isize,
    mir_production_36_152_returned: isize,
    mir_production_36_152_caller: isize,
    mir_production_36_155_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_36_155_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_36_155_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_36_155_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_36_156_source: crate::experimental_swift_reactor::control::Cursor,
    mir_production_36_156_argument: crate::experimental_swift_reactor::control::Cursor,
    mir_production_36_156_returned: crate::experimental_swift_reactor::control::Cursor,
    mir_production_36_156_caller: crate::experimental_swift_reactor::control::Cursor,
    mir_production_36_157_source: crate::experimental_swift_reactor::control::Fault,
    mir_production_36_157_argument: crate::experimental_swift_reactor::control::Fault,
    mir_production_36_157_returned: crate::experimental_swift_reactor::control::Fault,
    mir_production_36_157_caller: crate::experimental_swift_reactor::control::Fault,
    mir_production_36_158_source: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    mir_production_36_158_argument: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    mir_production_36_158_returned: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    mir_production_36_158_caller: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    mir_production_36_159_source: std::option::Option<crate::experimental_wasi::WasiUsage>,
    mir_production_36_159_argument: std::option::Option<crate::experimental_wasi::WasiUsage>,
    mir_production_36_159_returned: std::option::Option<crate::experimental_wasi::WasiUsage>,
    mir_production_36_159_caller: std::option::Option<crate::experimental_wasi::WasiUsage>,
    mir_production_36_160_source: crate::experimental_wasi::WasiUsage,
    mir_production_36_160_argument: crate::experimental_wasi::WasiUsage,
    mir_production_36_160_returned: crate::experimental_wasi::WasiUsage,
    mir_production_36_160_caller: crate::experimental_wasi::WasiUsage,
    mir_production_36_161_source: &'static crate::experimental_wasi::accounted::AccountedWasi,
    mir_production_36_161_argument: &'static crate::experimental_wasi::accounted::AccountedWasi,
    mir_production_36_161_returned: &'static crate::experimental_wasi::accounted::AccountedWasi,
    mir_production_36_161_caller: &'static crate::experimental_wasi::accounted::AccountedWasi,
    mir_production_36_162_source: bool,
    mir_production_36_162_argument: bool,
    mir_production_36_162_returned: bool,
    mir_production_36_162_caller: bool,
    mir_production_36_163_source: &'static mut crate::experimental_swift_reactor::control::RuntimeControl,
    mir_production_36_163_argument: &'static mut crate::experimental_swift_reactor::control::RuntimeControl,
    mir_production_36_163_returned: &'static mut crate::experimental_swift_reactor::control::RuntimeControl,
    mir_production_36_163_caller: &'static mut crate::experimental_swift_reactor::control::RuntimeControl,
    mir_production_36_164_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_36_164_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_36_164_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_36_164_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_36_165_source: &'static mut crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    mir_production_36_165_argument: &'static mut crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    mir_production_36_165_returned: &'static mut crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    mir_production_36_165_caller: &'static mut crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    mir_production_36_166_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_36_166_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_36_166_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_36_166_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    mir_production_36_167_source: &'static mut crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    mir_production_36_167_argument: &'static mut crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    mir_production_36_167_returned: &'static mut crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    mir_production_36_167_caller: &'static mut crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    mir_production_36_168_source: &'static mut std::vec::Vec<Value>,
    mir_production_36_168_argument: &'static mut std::vec::Vec<Value>,
    mir_production_36_168_returned: &'static mut std::vec::Vec<Value>,
    mir_production_36_168_caller: &'static mut std::vec::Vec<Value>,
    mir_production_36_169_source: &'static mut crate::experimental_wasi::accounted::AccountedWasi,
    mir_production_36_169_argument: &'static mut crate::experimental_wasi::accounted::AccountedWasi,
    mir_production_36_169_returned: &'static mut crate::experimental_wasi::accounted::AccountedWasi,
    mir_production_36_169_caller: &'static mut crate::experimental_wasi::accounted::AccountedWasi,
    mir_production_36_15_source: crate::experimental::cache::ControlKind,
    mir_production_36_15_argument: crate::experimental::cache::ControlKind,
    mir_production_36_15_returned: crate::experimental::cache::ControlKind,
    mir_production_36_15_caller: crate::experimental::cache::ControlKind,
    alias_production_36_15_0_kind_source: crate::experimental::cache::ControlKind,
    alias_production_36_15_0_kind_argument: crate::experimental::cache::ControlKind,
    alias_production_36_15_0_kind_returned: crate::experimental::cache::ControlKind,
    alias_production_36_15_0_kind_caller: crate::experimental::cache::ControlKind,
    mir_production_36_16_source: std::option::Option<Type>,
    mir_production_36_16_argument: std::option::Option<Type>,
    mir_production_36_16_returned: std::option::Option<Type>,
    mir_production_36_16_caller: std::option::Option<Type>,
    alias_production_36_16_0_result_source: std::option::Option<Type>,
    alias_production_36_16_0_result_argument: std::option::Option<Type>,
    alias_production_36_16_0_result_returned: std::option::Option<Type>,
    alias_production_36_16_0_result_caller: std::option::Option<Type>,
    mir_production_36_17_source: usize,
    mir_production_36_17_argument: usize,
    mir_production_36_17_returned: usize,
    mir_production_36_17_caller: usize,
    alias_production_36_17_0_end_source: usize,
    alias_production_36_17_0_end_argument: usize,
    alias_production_36_17_0_end_returned: usize,
    alias_production_36_17_0_end_caller: usize,
    mir_production_36_18_source: std::option::Option<usize>,
    mir_production_36_18_argument: std::option::Option<usize>,
    mir_production_36_18_returned: std::option::Option<usize>,
    mir_production_36_18_caller: std::option::Option<usize>,
    alias_production_36_18_0_alternative_source: std::option::Option<usize>,
    alias_production_36_18_0_alternative_argument: std::option::Option<usize>,
    alias_production_36_18_0_alternative_returned: std::option::Option<usize>,
    alias_production_36_18_0_alternative_caller: std::option::Option<usize>,
    mir_production_36_98_source: usize,
    mir_production_36_98_argument: usize,
    mir_production_36_98_returned: usize,
    mir_production_36_98_caller: usize,
    alias_production_36_98_0_end_source: usize,
    alias_production_36_98_0_end_argument: usize,
    alias_production_36_98_0_end_returned: usize,
    alias_production_36_98_0_end_caller: usize,
    mir_production_36_106_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_106_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_106_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_106_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_106_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_106_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_106_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_106_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_110_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_110_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_110_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_110_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_110_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_110_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_110_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_110_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_111_source: crate::experimental::execution::Control,
    mir_production_36_111_argument: crate::experimental::execution::Control,
    mir_production_36_111_returned: crate::experimental::execution::Control,
    mir_production_36_111_caller: crate::experimental::execution::Control,
    alias_production_36_111_0_control_source: crate::experimental::execution::Control,
    alias_production_36_111_0_control_argument: crate::experimental::execution::Control,
    alias_production_36_111_0_control_returned: crate::experimental::execution::Control,
    alias_production_36_111_0_control_caller: crate::experimental::execution::Control,
    alias_production_36_111_1_val_source: crate::experimental::execution::Control,
    alias_production_36_111_1_val_argument: crate::experimental::execution::Control,
    alias_production_36_111_1_val_returned: crate::experimental::execution::Control,
    alias_production_36_111_1_val_caller: crate::experimental::execution::Control,
    mir_production_36_121_source: u32,
    mir_production_36_121_argument: u32,
    mir_production_36_121_returned: u32,
    mir_production_36_121_caller: u32,
    alias_production_36_121_0_depth_source: u32,
    alias_production_36_121_0_depth_argument: u32,
    alias_production_36_121_0_depth_returned: u32,
    alias_production_36_121_0_depth_caller: u32,
    mir_production_36_127_source: u32,
    mir_production_36_127_argument: u32,
    mir_production_36_127_returned: u32,
    mir_production_36_127_caller: u32,
    alias_production_36_127_0_depth_source: u32,
    alias_production_36_127_0_depth_argument: u32,
    alias_production_36_127_0_depth_returned: u32,
    alias_production_36_127_0_depth_caller: u32,
    mir_production_36_139_source: std::option::Option<u32>,
    mir_production_36_139_argument: std::option::Option<u32>,
    mir_production_36_139_returned: std::option::Option<u32>,
    mir_production_36_139_caller: std::option::Option<u32>,
    alias_production_36_139_0_target_source: std::option::Option<u32>,
    alias_production_36_139_0_target_argument: std::option::Option<u32>,
    alias_production_36_139_0_target_returned: std::option::Option<u32>,
    alias_production_36_139_0_target_caller: std::option::Option<u32>,
    mir_production_36_19_source: bool,
    mir_production_36_19_argument: bool,
    mir_production_36_19_returned: bool,
    mir_production_36_19_caller: bool,
    alias_production_36_19_0_cond_source: bool,
    alias_production_36_19_0_cond_argument: bool,
    alias_production_36_19_0_cond_returned: bool,
    alias_production_36_19_0_cond_caller: bool,
    mir_production_36_26_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_26_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_26_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_26_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_26_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_26_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_26_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_26_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_27_source: i32,
    mir_production_36_27_argument: i32,
    mir_production_36_27_returned: i32,
    mir_production_36_27_caller: i32,
    alias_production_36_27_0_val_source: i32,
    alias_production_36_27_0_val_argument: i32,
    alias_production_36_27_0_val_returned: i32,
    alias_production_36_27_0_val_caller: i32,
    mir_production_36_31_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_31_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_31_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_31_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_31_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_31_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_31_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_31_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_35_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_35_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_35_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_35_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_35_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_35_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_35_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_35_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_39_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_39_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_39_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_39_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_39_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_39_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_39_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_39_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_43_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_43_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_43_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_43_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_43_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_43_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_43_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_43_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_44_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_36_44_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_36_44_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_36_44_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_36_44_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_36_44_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_36_44_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_36_44_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_36_44_1_val_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_36_44_1_val_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_36_44_1_val_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    alias_production_36_44_1_val_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    mir_production_36_77_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_77_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_77_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_77_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_77_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_77_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_77_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_77_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_79_source: usize,
    mir_production_36_79_argument: usize,
    mir_production_36_79_returned: usize,
    mir_production_36_79_caller: usize,
    alias_production_36_79_0_pc_source: usize,
    alias_production_36_79_0_pc_argument: usize,
    alias_production_36_79_0_pc_returned: usize,
    alias_production_36_79_0_pc_caller: usize,
    mir_production_36_81_source: usize,
    mir_production_36_81_argument: usize,
    mir_production_36_81_returned: usize,
    mir_production_36_81_caller: usize,
    alias_production_36_81_0_alternative_source: usize,
    alias_production_36_81_0_alternative_argument: usize,
    alias_production_36_81_0_alternative_returned: usize,
    alias_production_36_81_0_alternative_caller: usize,
    mir_production_36_97_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_97_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_97_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_97_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_97_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_97_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_97_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_97_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_93_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_93_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_93_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_93_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_93_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_93_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_93_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_93_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_87_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_87_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_87_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_87_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_87_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_87_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_87_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_87_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_88_source: usize,
    mir_production_36_88_argument: usize,
    mir_production_36_88_returned: usize,
    mir_production_36_88_caller: usize,
    alias_production_36_88_0_val_source: usize,
    alias_production_36_88_0_val_argument: usize,
    alias_production_36_88_0_val_returned: usize,
    alias_production_36_88_0_val_caller: usize,
    mir_production_36_102_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_102_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_102_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_102_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_102_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_102_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_102_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_102_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_115_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_115_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_115_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_115_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_115_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_115_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_115_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_115_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_120_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_120_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_120_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_120_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_120_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_120_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_120_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_120_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_125_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_125_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_125_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_125_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_125_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_125_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_125_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_125_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_126_source: bool,
    mir_production_36_126_argument: bool,
    mir_production_36_126_returned: bool,
    mir_production_36_126_caller: bool,
    alias_production_36_126_0_val_source: bool,
    alias_production_36_126_0_val_argument: bool,
    alias_production_36_126_0_val_returned: bool,
    alias_production_36_126_0_val_caller: bool,
    mir_production_36_132_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_132_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_132_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_132_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_132_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_132_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_132_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_132_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_133_source: i32,
    mir_production_36_133_argument: i32,
    mir_production_36_133_returned: i32,
    mir_production_36_133_caller: i32,
    alias_production_36_133_0_val_source: i32,
    alias_production_36_133_0_val_argument: i32,
    alias_production_36_133_0_val_returned: i32,
    alias_production_36_133_0_val_caller: i32,
    mir_production_36_137_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_137_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_137_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_137_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_137_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_137_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_137_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_137_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_138_source: bool,
    mir_production_36_138_argument: bool,
    mir_production_36_138_returned: bool,
    mir_production_36_138_caller: bool,
    alias_production_36_138_0_val_source: bool,
    alias_production_36_138_0_val_argument: bool,
    alias_production_36_138_0_val_returned: bool,
    alias_production_36_138_0_val_caller: bool,
    mir_production_36_146_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_146_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_146_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_146_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_146_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_146_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_146_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_146_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_147_source: i32,
    mir_production_36_147_argument: i32,
    mir_production_36_147_returned: i32,
    mir_production_36_147_caller: i32,
    alias_production_36_147_0_val_source: i32,
    alias_production_36_147_0_val_argument: i32,
    alias_production_36_147_0_val_returned: i32,
    alias_production_36_147_0_val_caller: i32,
    mir_production_36_153_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_153_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_153_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_153_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_153_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_153_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_153_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    alias_production_36_153_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    mir_production_36_154_source: bool,
    mir_production_36_154_argument: bool,
    mir_production_36_154_returned: bool,
    mir_production_36_154_caller: bool,
    alias_production_36_154_0_val_source: bool,
    alias_production_36_154_0_val_argument: bool,
    alias_production_36_154_0_val_returned: bool,
    alias_production_36_154_0_val_caller: bool,
    mir_production_36_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_36_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_36_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_36_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_36_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_36_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_36_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    alias_production_36_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_36_2_source: crate::experimental::cache::Operation,
    mir_production_36_2_argument: crate::experimental::cache::Operation,
    mir_production_36_2_returned: crate::experimental::cache::Operation,
    mir_production_36_2_caller: crate::experimental::cache::Operation,
    alias_production_36_2_0_operation_source: crate::experimental::cache::Operation,
    alias_production_36_2_0_operation_argument: crate::experimental::cache::Operation,
    alias_production_36_2_0_operation_returned: crate::experimental::cache::Operation,
    alias_production_36_2_0_operation_caller: crate::experimental::cache::Operation,
    mir_production_36_3_source: Option<u32>,
    mir_production_36_3_argument: Option<u32>,
    mir_production_36_3_returned: Option<u32>,
    mir_production_36_3_caller: Option<u32>,
    alias_production_36_3_0_selected_target_source: Option<u32>,
    alias_production_36_3_0_selected_target_argument: Option<u32>,
    alias_production_36_3_0_selected_target_returned: Option<u32>,
    alias_production_36_3_0_selected_target_caller: Option<u32>,
    literal_production_36_0_source: bool,
    literal_production_36_0_argument: bool,
    literal_production_36_0_returned: bool,
    literal_production_36_0_caller: bool,
    literal_production_36_1_source: &'static str,
    literal_production_36_1_argument: &'static str,
    literal_production_36_1_returned: &'static str,
    literal_production_36_1_caller: &'static str,
    literal_production_36_2_source: bool,
    literal_production_36_2_argument: bool,
    literal_production_36_2_returned: bool,
    literal_production_36_2_caller: bool,
    literal_production_36_3_source: usize,
    literal_production_36_3_argument: usize,
    literal_production_36_3_returned: usize,
    literal_production_36_3_caller: usize,
    literal_production_36_4_source: i32,
    literal_production_36_4_argument: i32,
    literal_production_36_4_returned: i32,
    literal_production_36_4_caller: i32,
    literal_production_36_5_source: bool,
    literal_production_36_5_argument: bool,
    literal_production_36_5_returned: bool,
    literal_production_36_5_caller: bool,
    literal_production_36_6_source: usize,
    literal_production_36_6_argument: usize,
    literal_production_36_6_returned: usize,
    literal_production_36_6_caller: usize,
    literal_production_36_7_source: usize,
    literal_production_36_7_argument: usize,
    literal_production_36_7_returned: usize,
    literal_production_36_7_caller: usize,
    literal_production_36_8_source: usize,
    literal_production_36_8_argument: usize,
    literal_production_36_8_returned: usize,
    literal_production_36_8_caller: usize,
    literal_production_36_9_source: &'static str,
    literal_production_36_9_argument: &'static str,
    literal_production_36_9_returned: &'static str,
    literal_production_36_9_caller: &'static str,
    literal_production_36_10_source: usize,
    literal_production_36_10_argument: usize,
    literal_production_36_10_returned: usize,
    literal_production_36_10_caller: usize,
    literal_production_36_11_source: i32,
    literal_production_36_11_argument: i32,
    literal_production_36_11_returned: i32,
    literal_production_36_11_caller: i32,
    literal_production_36_12_source: &'static str,
    literal_production_36_12_argument: &'static str,
    literal_production_36_12_returned: &'static str,
    literal_production_36_12_caller: &'static str,
    literal_production_36_13_source: &'static str,
    literal_production_36_13_argument: &'static str,
    literal_production_36_13_returned: &'static str,
    literal_production_36_13_caller: &'static str,
    mir_production_37_0_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_37_0_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_37_0_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_37_0_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    mir_production_37_2_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_37_2_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_37_2_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_37_2_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    mir_production_37_1_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_37_1_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_37_1_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    mir_production_37_1_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    literal_production_37_0_source: &'static str,
    literal_production_37_0_argument: &'static str,
    literal_production_37_0_returned: &'static str,
    literal_production_37_0_caller: &'static str,
    #[cfg(test)]
    mir_unit_0_0_source: bool,
    #[cfg(test)]
    mir_unit_0_0_argument: bool,
    #[cfg(test)]
    mir_unit_0_0_returned: bool,
    #[cfg(test)]
    mir_unit_0_0_caller: bool,
    #[cfg(test)]
    mir_unit_0_1_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_0_1_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_0_1_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_0_1_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_0_1_0_self_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_0_1_0_self_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_0_1_0_self_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_0_1_0_self_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_1_0_source: usize,
    #[cfg(test)]
    mir_unit_1_0_argument: usize,
    #[cfg(test)]
    mir_unit_1_0_returned: usize,
    #[cfg(test)]
    mir_unit_1_0_caller: usize,
    #[cfg(test)]
    mir_unit_1_1_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_1_1_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_1_1_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_1_1_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_1_1_0_self_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_1_1_0_self_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_1_1_0_self_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_1_1_0_self_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_2_0_source: usize,
    #[cfg(test)]
    mir_unit_2_0_argument: usize,
    #[cfg(test)]
    mir_unit_2_0_returned: usize,
    #[cfg(test)]
    mir_unit_2_0_caller: usize,
    #[cfg(test)]
    mir_unit_2_1_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_2_1_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_2_1_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_2_1_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_2_1_0_self_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_2_1_0_self_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_2_1_0_self_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_2_1_0_self_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_3_0_source: usize,
    #[cfg(test)]
    mir_unit_3_0_argument: usize,
    #[cfg(test)]
    mir_unit_3_0_returned: usize,
    #[cfg(test)]
    mir_unit_3_0_caller: usize,
    #[cfg(test)]
    mir_unit_3_1_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_3_1_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_3_1_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_3_1_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_3_1_0_self_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_3_1_0_self_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_3_1_0_self_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_3_1_0_self_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_4_0_source: bool,
    #[cfg(test)]
    mir_unit_4_0_argument: bool,
    #[cfg(test)]
    mir_unit_4_0_returned: bool,
    #[cfg(test)]
    mir_unit_4_0_caller: bool,
    #[cfg(test)]
    mir_unit_4_1_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_4_1_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_4_1_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_4_1_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_4_1_0_self_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_4_1_0_self_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_4_1_0_self_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_4_1_0_self_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_5_0_source: bool,
    #[cfg(test)]
    mir_unit_5_0_argument: bool,
    #[cfg(test)]
    mir_unit_5_0_returned: bool,
    #[cfg(test)]
    mir_unit_5_0_caller: bool,
    #[cfg(test)]
    mir_unit_5_1_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_5_1_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_5_1_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_5_1_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_5_1_0_self_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_5_1_0_self_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_5_1_0_self_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_5_1_0_self_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_6_0_source: bool,
    #[cfg(test)]
    mir_unit_6_0_argument: bool,
    #[cfg(test)]
    mir_unit_6_0_returned: bool,
    #[cfg(test)]
    mir_unit_6_0_caller: bool,
    #[cfg(test)]
    mir_unit_6_1_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_6_1_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_6_1_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_6_1_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_6_1_0_self_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_6_1_0_self_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_6_1_0_self_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_6_1_0_self_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_7_0_source: (),
    #[cfg(test)]
    mir_unit_7_0_argument: (),
    #[cfg(test)]
    mir_unit_7_0_returned: (),
    #[cfg(test)]
    mir_unit_7_0_caller: (),
    #[cfg(test)]
    mir_unit_7_1_source: &'static mut crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_7_1_argument: &'static mut crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_7_1_returned: &'static mut crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_7_1_caller: &'static mut crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_7_1_0_self_source: &'static mut crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_7_1_0_self_argument: &'static mut crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_7_1_0_self_returned: &'static mut crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_7_1_0_self_caller: &'static mut crate::experimental::execution::Control,
    #[cfg(test)]
    literal_unit_7_0_source: bool,
    #[cfg(test)]
    literal_unit_7_0_argument: bool,
    #[cfg(test)]
    literal_unit_7_0_returned: bool,
    #[cfg(test)]
    literal_unit_7_0_caller: bool,
    #[cfg(test)]
    mir_unit_8_0_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_8_0_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_8_0_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_8_0_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_8_7_source: isize,
    #[cfg(test)]
    mir_unit_8_7_argument: isize,
    #[cfg(test)]
    mir_unit_8_7_returned: isize,
    #[cfg(test)]
    mir_unit_8_7_caller: isize,
    #[cfg(test)]
    mir_unit_8_1_source: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_8_1_argument: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_8_1_returned: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_8_1_caller: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    alias_unit_8_1_0_kind_source: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    alias_unit_8_1_0_kind_argument: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    alias_unit_8_1_0_kind_returned: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    alias_unit_8_1_0_kind_caller: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_8_2_source: usize,
    #[cfg(test)]
    mir_unit_8_2_argument: usize,
    #[cfg(test)]
    mir_unit_8_2_returned: usize,
    #[cfg(test)]
    mir_unit_8_2_caller: usize,
    #[cfg(test)]
    alias_unit_8_2_0_start_source: usize,
    #[cfg(test)]
    alias_unit_8_2_0_start_argument: usize,
    #[cfg(test)]
    alias_unit_8_2_0_start_returned: usize,
    #[cfg(test)]
    alias_unit_8_2_0_start_caller: usize,
    #[cfg(test)]
    mir_unit_8_3_source: usize,
    #[cfg(test)]
    mir_unit_8_3_argument: usize,
    #[cfg(test)]
    mir_unit_8_3_returned: usize,
    #[cfg(test)]
    mir_unit_8_3_caller: usize,
    #[cfg(test)]
    alias_unit_8_3_0_end_source: usize,
    #[cfg(test)]
    alias_unit_8_3_0_end_argument: usize,
    #[cfg(test)]
    alias_unit_8_3_0_end_returned: usize,
    #[cfg(test)]
    alias_unit_8_3_0_end_caller: usize,
    #[cfg(test)]
    mir_unit_8_4_source: usize,
    #[cfg(test)]
    mir_unit_8_4_argument: usize,
    #[cfg(test)]
    mir_unit_8_4_returned: usize,
    #[cfg(test)]
    mir_unit_8_4_caller: usize,
    #[cfg(test)]
    alias_unit_8_4_0_height_source: usize,
    #[cfg(test)]
    alias_unit_8_4_0_height_argument: usize,
    #[cfg(test)]
    alias_unit_8_4_0_height_returned: usize,
    #[cfg(test)]
    alias_unit_8_4_0_height_caller: usize,
    #[cfg(test)]
    mir_unit_8_5_source: bool,
    #[cfg(test)]
    mir_unit_8_5_argument: bool,
    #[cfg(test)]
    mir_unit_8_5_returned: bool,
    #[cfg(test)]
    mir_unit_8_5_caller: bool,
    #[cfg(test)]
    alias_unit_8_5_0_result_source: bool,
    #[cfg(test)]
    alias_unit_8_5_0_result_argument: bool,
    #[cfg(test)]
    alias_unit_8_5_0_result_returned: bool,
    #[cfg(test)]
    alias_unit_8_5_0_result_caller: bool,
    #[cfg(test)]
    mir_unit_9_0_source: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_9_0_argument: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_9_0_returned: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_9_0_caller: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_9_2_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, Value>,
    #[cfg(test)]
    mir_unit_9_2_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, Value>,
    #[cfg(test)]
    mir_unit_9_2_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, Value>,
    #[cfg(test)]
    mir_unit_9_2_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, Value>,
    #[cfg(test)]
    mir_unit_9_3_source: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_9_3_argument: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_9_3_returned: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_9_3_caller: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_9_4_source: isize,
    #[cfg(test)]
    mir_unit_9_4_argument: isize,
    #[cfg(test)]
    mir_unit_9_4_returned: isize,
    #[cfg(test)]
    mir_unit_9_4_caller: isize,
    #[cfg(test)]
    mir_unit_9_5_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_9_5_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_9_5_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_9_5_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_9_5_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_9_5_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_9_5_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_9_5_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_9_6_source: Value,
    #[cfg(test)]
    mir_unit_9_6_argument: Value,
    #[cfg(test)]
    mir_unit_9_6_returned: Value,
    #[cfg(test)]
    mir_unit_9_6_caller: Value,
    #[cfg(test)]
    alias_unit_9_6_0_val_source: Value,
    #[cfg(test)]
    alias_unit_9_6_0_val_argument: Value,
    #[cfg(test)]
    alias_unit_9_6_0_val_returned: Value,
    #[cfg(test)]
    alias_unit_9_6_0_val_caller: Value,
    #[cfg(test)]
    mir_unit_9_7_source: isize,
    #[cfg(test)]
    mir_unit_9_7_argument: isize,
    #[cfg(test)]
    mir_unit_9_7_returned: isize,
    #[cfg(test)]
    mir_unit_9_7_caller: isize,
    #[cfg(test)]
    mir_unit_9_8_source: i32,
    #[cfg(test)]
    mir_unit_9_8_argument: i32,
    #[cfg(test)]
    mir_unit_9_8_returned: i32,
    #[cfg(test)]
    mir_unit_9_8_caller: i32,
    #[cfg(test)]
    alias_unit_9_8_0_value_source: i32,
    #[cfg(test)]
    alias_unit_9_8_0_value_argument: i32,
    #[cfg(test)]
    alias_unit_9_8_0_value_returned: i32,
    #[cfg(test)]
    alias_unit_9_8_0_value_caller: i32,
    #[cfg(test)]
    mir_unit_9_9_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_9_9_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_9_9_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_9_9_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_9_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_9_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_9_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_9_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_9_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_9_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_9_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_9_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    literal_unit_9_0_source: &'static str,
    #[cfg(test)]
    literal_unit_9_0_argument: &'static str,
    #[cfg(test)]
    literal_unit_9_0_returned: &'static str,
    #[cfg(test)]
    literal_unit_9_0_caller: &'static str,
    #[cfg(test)]
    mir_unit_10_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_3_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_3_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_3_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_3_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_4_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_4_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_4_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_4_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_5_source: isize,
    #[cfg(test)]
    mir_unit_10_5_argument: isize,
    #[cfg(test)]
    mir_unit_10_5_returned: isize,
    #[cfg(test)]
    mir_unit_10_5_caller: isize,
    #[cfg(test)]
    mir_unit_10_6_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_6_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_6_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_6_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_6_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_6_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_6_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_6_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_7_source: std::option::Option<Value>,
    #[cfg(test)]
    mir_unit_10_7_argument: std::option::Option<Value>,
    #[cfg(test)]
    mir_unit_10_7_returned: std::option::Option<Value>,
    #[cfg(test)]
    mir_unit_10_7_caller: std::option::Option<Value>,
    #[cfg(test)]
    alias_unit_10_7_0_value_source: std::option::Option<Value>,
    #[cfg(test)]
    alias_unit_10_7_0_value_argument: std::option::Option<Value>,
    #[cfg(test)]
    alias_unit_10_7_0_value_returned: std::option::Option<Value>,
    #[cfg(test)]
    alias_unit_10_7_0_value_caller: std::option::Option<Value>,
    #[cfg(test)]
    mir_unit_10_8_source: bool,
    #[cfg(test)]
    mir_unit_10_8_argument: bool,
    #[cfg(test)]
    mir_unit_10_8_returned: bool,
    #[cfg(test)]
    mir_unit_10_8_caller: bool,
    #[cfg(test)]
    mir_unit_10_9_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, Value>,
    #[cfg(test)]
    mir_unit_10_9_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, Value>,
    #[cfg(test)]
    mir_unit_10_9_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, Value>,
    #[cfg(test)]
    mir_unit_10_9_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, Value>,
    #[cfg(test)]
    mir_unit_10_10_source: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_10_argument: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_10_returned: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_10_caller: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_11_source: isize,
    #[cfg(test)]
    mir_unit_10_11_argument: isize,
    #[cfg(test)]
    mir_unit_10_11_returned: isize,
    #[cfg(test)]
    mir_unit_10_11_caller: isize,
    #[cfg(test)]
    mir_unit_10_12_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_12_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_12_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_12_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_12_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_12_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_12_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_12_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_13_source: Value,
    #[cfg(test)]
    mir_unit_10_13_argument: Value,
    #[cfg(test)]
    mir_unit_10_13_returned: Value,
    #[cfg(test)]
    mir_unit_10_13_caller: Value,
    #[cfg(test)]
    alias_unit_10_13_0_val_source: Value,
    #[cfg(test)]
    alias_unit_10_13_0_val_argument: Value,
    #[cfg(test)]
    alias_unit_10_13_0_val_returned: Value,
    #[cfg(test)]
    alias_unit_10_13_0_val_caller: Value,
    #[cfg(test)]
    mir_unit_10_14_source: bool,
    #[cfg(test)]
    mir_unit_10_14_argument: bool,
    #[cfg(test)]
    mir_unit_10_14_returned: bool,
    #[cfg(test)]
    mir_unit_10_14_caller: bool,
    #[cfg(test)]
    mir_unit_10_15_source: usize,
    #[cfg(test)]
    mir_unit_10_15_argument: usize,
    #[cfg(test)]
    mir_unit_10_15_returned: usize,
    #[cfg(test)]
    mir_unit_10_15_caller: usize,
    #[cfg(test)]
    mir_unit_10_16_source: usize,
    #[cfg(test)]
    mir_unit_10_16_argument: usize,
    #[cfg(test)]
    mir_unit_10_16_returned: usize,
    #[cfg(test)]
    mir_unit_10_16_caller: usize,
    #[cfg(test)]
    mir_unit_10_17_source: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_10_17_argument: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_10_17_returned: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_10_17_caller: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_10_18_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_10_18_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_10_18_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_10_18_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_10_19_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_19_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_19_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_19_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_20_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_20_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_20_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_20_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_21_source: usize,
    #[cfg(test)]
    mir_unit_10_21_argument: usize,
    #[cfg(test)]
    mir_unit_10_21_returned: usize,
    #[cfg(test)]
    mir_unit_10_21_caller: usize,
    #[cfg(test)]
    mir_unit_10_22_source: usize,
    #[cfg(test)]
    mir_unit_10_22_argument: usize,
    #[cfg(test)]
    mir_unit_10_22_returned: usize,
    #[cfg(test)]
    mir_unit_10_22_caller: usize,
    #[cfg(test)]
    mir_unit_10_23_source: usize,
    #[cfg(test)]
    mir_unit_10_23_argument: usize,
    #[cfg(test)]
    mir_unit_10_23_returned: usize,
    #[cfg(test)]
    mir_unit_10_23_caller: usize,
    #[cfg(test)]
    mir_unit_10_24_source: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_10_24_argument: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_10_24_returned: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_10_24_caller: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_10_25_source: usize,
    #[cfg(test)]
    mir_unit_10_25_argument: usize,
    #[cfg(test)]
    mir_unit_10_25_returned: usize,
    #[cfg(test)]
    mir_unit_10_25_caller: usize,
    #[cfg(test)]
    mir_unit_10_26_source: (usize, bool),
    #[cfg(test)]
    mir_unit_10_26_argument: (usize, bool),
    #[cfg(test)]
    mir_unit_10_26_returned: (usize, bool),
    #[cfg(test)]
    mir_unit_10_26_caller: (usize, bool),
    #[cfg(test)]
    mir_unit_10_27_source: (usize, bool),
    #[cfg(test)]
    mir_unit_10_27_argument: (usize, bool),
    #[cfg(test)]
    mir_unit_10_27_returned: (usize, bool),
    #[cfg(test)]
    mir_unit_10_27_caller: (usize, bool),
    #[cfg(test)]
    mir_unit_10_28_source: isize,
    #[cfg(test)]
    mir_unit_10_28_argument: isize,
    #[cfg(test)]
    mir_unit_10_28_returned: isize,
    #[cfg(test)]
    mir_unit_10_28_caller: isize,
    #[cfg(test)]
    mir_unit_10_30_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_30_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_30_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_30_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_31_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_31_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_31_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_31_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_32_source: usize,
    #[cfg(test)]
    mir_unit_10_32_argument: usize,
    #[cfg(test)]
    mir_unit_10_32_returned: usize,
    #[cfg(test)]
    mir_unit_10_32_caller: usize,
    #[cfg(test)]
    mir_unit_10_33_source: isize,
    #[cfg(test)]
    mir_unit_10_33_argument: isize,
    #[cfg(test)]
    mir_unit_10_33_returned: isize,
    #[cfg(test)]
    mir_unit_10_33_caller: isize,
    #[cfg(test)]
    mir_unit_10_35_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_35_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_35_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_35_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_36_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_36_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_36_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_36_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_37_source: isize,
    #[cfg(test)]
    mir_unit_10_37_argument: isize,
    #[cfg(test)]
    mir_unit_10_37_returned: isize,
    #[cfg(test)]
    mir_unit_10_37_caller: isize,
    #[cfg(test)]
    mir_unit_10_39_source: isize,
    #[cfg(test)]
    mir_unit_10_39_argument: isize,
    #[cfg(test)]
    mir_unit_10_39_returned: isize,
    #[cfg(test)]
    mir_unit_10_39_caller: isize,
    #[cfg(test)]
    mir_unit_10_41_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_41_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_41_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_41_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_10_42_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_42_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_42_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_42_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_43_source: &'static mut crate::experimental_swift_reactor::execution::ExecutionOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_10_43_argument: &'static mut crate::experimental_swift_reactor::execution::ExecutionOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_10_43_returned: &'static mut crate::experimental_swift_reactor::execution::ExecutionOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_10_43_caller: &'static mut crate::experimental_swift_reactor::execution::ExecutionOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_10_44_source: isize,
    #[cfg(test)]
    mir_unit_10_44_argument: isize,
    #[cfg(test)]
    mir_unit_10_44_returned: isize,
    #[cfg(test)]
    mir_unit_10_44_caller: isize,
    #[cfg(test)]
    mir_unit_10_46_source: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_10_46_argument: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_10_46_returned: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_10_46_caller: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_10_47_source: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_10_47_argument: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_10_47_returned: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_10_47_caller: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_10_29_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_29_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_29_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_29_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_29_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_29_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_29_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_29_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_34_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_34_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_34_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_34_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_34_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_34_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_34_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_34_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_38_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_38_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_38_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_38_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_38_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_38_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_38_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_38_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_40_source: Value,
    #[cfg(test)]
    mir_unit_10_40_argument: Value,
    #[cfg(test)]
    mir_unit_10_40_returned: Value,
    #[cfg(test)]
    mir_unit_10_40_caller: Value,
    #[cfg(test)]
    alias_unit_10_40_0_value_source: Value,
    #[cfg(test)]
    alias_unit_10_40_0_value_argument: Value,
    #[cfg(test)]
    alias_unit_10_40_0_value_returned: Value,
    #[cfg(test)]
    alias_unit_10_40_0_value_caller: Value,
    #[cfg(test)]
    mir_unit_10_45_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_45_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_45_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_45_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_45_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_45_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_45_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_10_45_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_10_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_10_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_10_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_10_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_10_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_10_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_10_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_10_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_10_2_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_10_2_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_10_2_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_10_2_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_10_2_0_control_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_10_2_0_control_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_10_2_0_control_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_10_2_0_control_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    literal_unit_10_0_source: &'static str,
    #[cfg(test)]
    literal_unit_10_0_argument: &'static str,
    #[cfg(test)]
    literal_unit_10_0_returned: &'static str,
    #[cfg(test)]
    literal_unit_10_0_caller: &'static str,
    #[cfg(test)]
    literal_unit_10_1_source: usize,
    #[cfg(test)]
    literal_unit_10_1_argument: usize,
    #[cfg(test)]
    literal_unit_10_1_returned: usize,
    #[cfg(test)]
    literal_unit_10_1_caller: usize,
    #[cfg(test)]
    literal_unit_10_2_source: usize,
    #[cfg(test)]
    literal_unit_10_2_argument: usize,
    #[cfg(test)]
    literal_unit_10_2_returned: usize,
    #[cfg(test)]
    literal_unit_10_2_caller: usize,
    #[cfg(test)]
    mir_unit_11_0_source: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_0_argument: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_0_returned: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_0_caller: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_3_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_11_3_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_11_3_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_11_3_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_11_3_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_11_3_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_11_3_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_11_3_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_11_4_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_11_4_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_11_4_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_11_4_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_11_5_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_5_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_5_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_5_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_6_source: isize,
    #[cfg(test)]
    mir_unit_11_6_argument: isize,
    #[cfg(test)]
    mir_unit_11_6_returned: isize,
    #[cfg(test)]
    mir_unit_11_6_caller: isize,
    #[cfg(test)]
    mir_unit_11_7_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_7_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_7_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_7_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_7_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_7_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_7_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_7_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_8_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_11_8_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_11_8_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_11_8_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_11_8_0_val_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_11_8_0_val_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_11_8_0_val_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_11_8_0_val_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_11_9_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_11_9_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_11_9_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_11_9_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_11_10_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_10_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_10_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_10_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_11_source: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_11_argument: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_11_returned: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_11_caller: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_12_source: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_12_argument: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_12_returned: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_12_caller: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_13_source: usize,
    #[cfg(test)]
    mir_unit_11_13_argument: usize,
    #[cfg(test)]
    mir_unit_11_13_returned: usize,
    #[cfg(test)]
    mir_unit_11_13_caller: usize,
    #[cfg(test)]
    mir_unit_11_14_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_14_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_14_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_14_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_15_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_11_15_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_11_15_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_11_15_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_11_16_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_16_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_16_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_16_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_17_source: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_17_argument: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_17_returned: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_17_caller: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_18_source: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_18_argument: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_18_returned: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_18_caller: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_19_source: std::result::Result<usize, std::num::TryFromIntError>,
    #[cfg(test)]
    mir_unit_11_19_argument: std::result::Result<usize, std::num::TryFromIntError>,
    #[cfg(test)]
    mir_unit_11_19_returned: std::result::Result<usize, std::num::TryFromIntError>,
    #[cfg(test)]
    mir_unit_11_19_caller: std::result::Result<usize, std::num::TryFromIntError>,
    #[cfg(test)]
    mir_unit_11_20_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_11_20_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_11_20_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_11_20_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_11_21_source: isize,
    #[cfg(test)]
    mir_unit_11_21_argument: isize,
    #[cfg(test)]
    mir_unit_11_21_returned: isize,
    #[cfg(test)]
    mir_unit_11_21_caller: isize,
    #[cfg(test)]
    mir_unit_11_24_source: (&'static usize,),
    #[cfg(test)]
    mir_unit_11_24_argument: (&'static usize,),
    #[cfg(test)]
    mir_unit_11_24_returned: (&'static usize,),
    #[cfg(test)]
    mir_unit_11_24_caller: (&'static usize,),
    #[cfg(test)]
    mir_unit_11_25_source: &'static usize,
    #[cfg(test)]
    mir_unit_11_25_argument: &'static usize,
    #[cfg(test)]
    mir_unit_11_25_returned: &'static usize,
    #[cfg(test)]
    mir_unit_11_25_caller: &'static usize,
    #[cfg(test)]
    mir_unit_11_26_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_11_26_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_11_26_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_11_26_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_11_27_source: isize,
    #[cfg(test)]
    mir_unit_11_27_argument: isize,
    #[cfg(test)]
    mir_unit_11_27_returned: isize,
    #[cfg(test)]
    mir_unit_11_27_caller: isize,
    #[cfg(test)]
    mir_unit_11_31_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_31_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_31_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_31_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_32_source: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_32_argument: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_32_returned: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_32_caller: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_33_source: isize,
    #[cfg(test)]
    mir_unit_11_33_argument: isize,
    #[cfg(test)]
    mir_unit_11_33_returned: isize,
    #[cfg(test)]
    mir_unit_11_33_caller: isize,
    #[cfg(test)]
    mir_unit_11_36_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_36_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_36_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_36_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_37_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_37_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_37_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_37_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_38_source: usize,
    #[cfg(test)]
    mir_unit_11_38_argument: usize,
    #[cfg(test)]
    mir_unit_11_38_returned: usize,
    #[cfg(test)]
    mir_unit_11_38_caller: usize,
    #[cfg(test)]
    mir_unit_11_39_source: usize,
    #[cfg(test)]
    mir_unit_11_39_argument: usize,
    #[cfg(test)]
    mir_unit_11_39_returned: usize,
    #[cfg(test)]
    mir_unit_11_39_caller: usize,
    #[cfg(test)]
    mir_unit_11_40_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_40_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_40_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_40_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_41_source: (usize, bool),
    #[cfg(test)]
    mir_unit_11_41_argument: (usize, bool),
    #[cfg(test)]
    mir_unit_11_41_returned: (usize, bool),
    #[cfg(test)]
    mir_unit_11_41_caller: (usize, bool),
    #[cfg(test)]
    mir_unit_11_42_source: isize,
    #[cfg(test)]
    mir_unit_11_42_argument: isize,
    #[cfg(test)]
    mir_unit_11_42_returned: isize,
    #[cfg(test)]
    mir_unit_11_42_caller: isize,
    #[cfg(test)]
    mir_unit_11_44_source: bool,
    #[cfg(test)]
    mir_unit_11_44_argument: bool,
    #[cfg(test)]
    mir_unit_11_44_returned: bool,
    #[cfg(test)]
    mir_unit_11_44_caller: bool,
    #[cfg(test)]
    mir_unit_11_45_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_45_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_45_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_45_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_46_source: (),
    #[cfg(test)]
    mir_unit_11_46_argument: (),
    #[cfg(test)]
    mir_unit_11_46_returned: (),
    #[cfg(test)]
    mir_unit_11_46_caller: (),
    #[cfg(test)]
    mir_unit_11_47_source: &'static mut crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_47_argument: &'static mut crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_47_returned: &'static mut crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_47_caller: &'static mut crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_48_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_48_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_48_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_48_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_49_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_49_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_49_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_49_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_50_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_50_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_50_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_50_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_51_source: isize,
    #[cfg(test)]
    mir_unit_11_51_argument: isize,
    #[cfg(test)]
    mir_unit_11_51_returned: isize,
    #[cfg(test)]
    mir_unit_11_51_caller: isize,
    #[cfg(test)]
    mir_unit_11_53_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_53_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_53_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_53_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_54_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_54_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_54_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_54_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_55_source: usize,
    #[cfg(test)]
    mir_unit_11_55_argument: usize,
    #[cfg(test)]
    mir_unit_11_55_returned: usize,
    #[cfg(test)]
    mir_unit_11_55_caller: usize,
    #[cfg(test)]
    mir_unit_11_56_source: bool,
    #[cfg(test)]
    mir_unit_11_56_argument: bool,
    #[cfg(test)]
    mir_unit_11_56_returned: bool,
    #[cfg(test)]
    mir_unit_11_56_caller: bool,
    #[cfg(test)]
    mir_unit_11_57_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_57_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_57_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_57_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_58_source: (usize, bool),
    #[cfg(test)]
    mir_unit_11_58_argument: (usize, bool),
    #[cfg(test)]
    mir_unit_11_58_returned: (usize, bool),
    #[cfg(test)]
    mir_unit_11_58_caller: (usize, bool),
    #[cfg(test)]
    mir_unit_11_59_source: isize,
    #[cfg(test)]
    mir_unit_11_59_argument: isize,
    #[cfg(test)]
    mir_unit_11_59_returned: isize,
    #[cfg(test)]
    mir_unit_11_59_caller: isize,
    #[cfg(test)]
    mir_unit_11_62_source: bool,
    #[cfg(test)]
    mir_unit_11_62_argument: bool,
    #[cfg(test)]
    mir_unit_11_62_returned: bool,
    #[cfg(test)]
    mir_unit_11_62_caller: bool,
    #[cfg(test)]
    mir_unit_11_63_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_63_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_63_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_63_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_64_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_64_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_64_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_64_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_65_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_11_65_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_11_65_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_11_65_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_11_66_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_66_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_66_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_66_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_67_source: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_67_argument: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_67_returned: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_67_caller: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_11_68_source: usize,
    #[cfg(test)]
    mir_unit_11_68_argument: usize,
    #[cfg(test)]
    mir_unit_11_68_returned: usize,
    #[cfg(test)]
    mir_unit_11_68_caller: usize,
    #[cfg(test)]
    mir_unit_11_69_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_69_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_69_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_69_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_70_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_11_70_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_11_70_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_11_70_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_11_71_source: isize,
    #[cfg(test)]
    mir_unit_11_71_argument: isize,
    #[cfg(test)]
    mir_unit_11_71_returned: isize,
    #[cfg(test)]
    mir_unit_11_71_caller: isize,
    #[cfg(test)]
    mir_unit_11_74_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_74_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_74_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_74_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_75_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_75_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_75_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_75_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_76_source: usize,
    #[cfg(test)]
    mir_unit_11_76_argument: usize,
    #[cfg(test)]
    mir_unit_11_76_returned: usize,
    #[cfg(test)]
    mir_unit_11_76_caller: usize,
    #[cfg(test)]
    mir_unit_11_77_source: isize,
    #[cfg(test)]
    mir_unit_11_77_argument: isize,
    #[cfg(test)]
    mir_unit_11_77_returned: isize,
    #[cfg(test)]
    mir_unit_11_77_caller: isize,
    #[cfg(test)]
    mir_unit_11_79_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_79_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_79_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_79_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_11_80_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_80_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_80_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_80_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_81_source: isize,
    #[cfg(test)]
    mir_unit_11_81_argument: isize,
    #[cfg(test)]
    mir_unit_11_81_returned: isize,
    #[cfg(test)]
    mir_unit_11_81_caller: isize,
    #[cfg(test)]
    mir_unit_11_83_source: bool,
    #[cfg(test)]
    mir_unit_11_83_argument: bool,
    #[cfg(test)]
    mir_unit_11_83_returned: bool,
    #[cfg(test)]
    mir_unit_11_83_caller: bool,
    #[cfg(test)]
    mir_unit_11_84_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_84_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_84_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_84_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_85_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_85_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_85_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_85_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_86_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_86_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_86_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_86_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_11_22_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_22_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_22_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_22_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_22_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_22_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_22_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_22_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_23_source: usize,
    #[cfg(test)]
    mir_unit_11_23_argument: usize,
    #[cfg(test)]
    mir_unit_11_23_returned: usize,
    #[cfg(test)]
    mir_unit_11_23_caller: usize,
    #[cfg(test)]
    alias_unit_11_23_0_val_source: usize,
    #[cfg(test)]
    alias_unit_11_23_0_val_argument: usize,
    #[cfg(test)]
    alias_unit_11_23_0_val_returned: usize,
    #[cfg(test)]
    alias_unit_11_23_0_val_caller: usize,
    #[cfg(test)]
    mir_unit_11_28_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_28_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_28_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_28_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_28_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_28_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_28_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_28_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_29_source: usize,
    #[cfg(test)]
    mir_unit_11_29_argument: usize,
    #[cfg(test)]
    mir_unit_11_29_returned: usize,
    #[cfg(test)]
    mir_unit_11_29_caller: usize,
    #[cfg(test)]
    alias_unit_11_29_0_index_source: usize,
    #[cfg(test)]
    alias_unit_11_29_0_index_argument: usize,
    #[cfg(test)]
    alias_unit_11_29_0_index_returned: usize,
    #[cfg(test)]
    alias_unit_11_29_0_index_caller: usize,
    #[cfg(test)]
    alias_unit_11_29_1_val_source: usize,
    #[cfg(test)]
    alias_unit_11_29_1_val_argument: usize,
    #[cfg(test)]
    alias_unit_11_29_1_val_returned: usize,
    #[cfg(test)]
    alias_unit_11_29_1_val_caller: usize,
    #[cfg(test)]
    mir_unit_11_30_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_30_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_30_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_30_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_11_30_0_control_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_11_30_0_control_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_11_30_0_control_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_11_30_0_control_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_34_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_34_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_34_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_34_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_34_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_34_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_34_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_34_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_35_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_35_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_35_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_35_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_11_35_0_val_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_11_35_0_val_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_11_35_0_val_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_11_35_0_val_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_11_43_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_43_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_43_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_43_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_43_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_43_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_43_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_43_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_52_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_52_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_52_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_52_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_52_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_52_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_52_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_52_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_60_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_60_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_60_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_60_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_60_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_60_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_60_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_60_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_61_source: usize,
    #[cfg(test)]
    mir_unit_11_61_argument: usize,
    #[cfg(test)]
    mir_unit_11_61_returned: usize,
    #[cfg(test)]
    mir_unit_11_61_caller: usize,
    #[cfg(test)]
    alias_unit_11_61_0_pc_source: usize,
    #[cfg(test)]
    alias_unit_11_61_0_pc_argument: usize,
    #[cfg(test)]
    alias_unit_11_61_0_pc_returned: usize,
    #[cfg(test)]
    alias_unit_11_61_0_pc_caller: usize,
    #[cfg(test)]
    mir_unit_11_72_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_72_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_72_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_72_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_72_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_72_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_72_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_72_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_73_source: usize,
    #[cfg(test)]
    mir_unit_11_73_argument: usize,
    #[cfg(test)]
    mir_unit_11_73_returned: usize,
    #[cfg(test)]
    mir_unit_11_73_caller: usize,
    #[cfg(test)]
    alias_unit_11_73_0_val_source: usize,
    #[cfg(test)]
    alias_unit_11_73_0_val_argument: usize,
    #[cfg(test)]
    alias_unit_11_73_0_val_returned: usize,
    #[cfg(test)]
    alias_unit_11_73_0_val_caller: usize,
    #[cfg(test)]
    mir_unit_11_78_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_78_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_78_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_78_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_78_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_78_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_78_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_78_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_82_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_82_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_82_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_82_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_82_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_82_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_82_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_11_82_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_11_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_11_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_11_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_11_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_11_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_11_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_11_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_11_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_11_2_source: u32,
    #[cfg(test)]
    mir_unit_11_2_argument: u32,
    #[cfg(test)]
    mir_unit_11_2_returned: u32,
    #[cfg(test)]
    mir_unit_11_2_caller: u32,
    #[cfg(test)]
    alias_unit_11_2_0_depth_source: u32,
    #[cfg(test)]
    alias_unit_11_2_0_depth_argument: u32,
    #[cfg(test)]
    alias_unit_11_2_0_depth_returned: u32,
    #[cfg(test)]
    alias_unit_11_2_0_depth_caller: u32,
    #[cfg(test)]
    literal_unit_11_0_source: usize,
    #[cfg(test)]
    literal_unit_11_0_argument: usize,
    #[cfg(test)]
    literal_unit_11_0_returned: usize,
    #[cfg(test)]
    literal_unit_11_0_caller: usize,
    #[cfg(test)]
    literal_unit_11_1_source: usize,
    #[cfg(test)]
    literal_unit_11_1_argument: usize,
    #[cfg(test)]
    literal_unit_11_1_returned: usize,
    #[cfg(test)]
    literal_unit_11_1_caller: usize,
    #[cfg(test)]
    literal_unit_11_2_source: usize,
    #[cfg(test)]
    literal_unit_11_2_argument: usize,
    #[cfg(test)]
    literal_unit_11_2_returned: usize,
    #[cfg(test)]
    literal_unit_11_2_caller: usize,
    #[cfg(test)]
    mir_unit_12_0_source: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_12_0_argument: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_12_0_returned: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_12_0_caller: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_12_1_source: (),
    #[cfg(test)]
    mir_unit_12_1_argument: (),
    #[cfg(test)]
    mir_unit_12_1_returned: (),
    #[cfg(test)]
    mir_unit_12_1_caller: (),
    #[cfg(test)]
    mir_unit_12_2_source: usize,
    #[cfg(test)]
    mir_unit_12_2_argument: usize,
    #[cfg(test)]
    mir_unit_12_2_returned: usize,
    #[cfg(test)]
    mir_unit_12_2_caller: usize,
    #[cfg(test)]
    alias_unit_12_2_0_n_source: usize,
    #[cfg(test)]
    alias_unit_12_2_0_n_argument: usize,
    #[cfg(test)]
    alias_unit_12_2_0_n_returned: usize,
    #[cfg(test)]
    alias_unit_12_2_0_n_caller: usize,
    #[cfg(test)]
    literal_unit_12_0_source: usize,
    #[cfg(test)]
    literal_unit_12_0_argument: usize,
    #[cfg(test)]
    literal_unit_12_0_returned: usize,
    #[cfg(test)]
    literal_unit_12_0_caller: usize,
    #[cfg(test)]
    mir_unit_13_0_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_13_0_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_13_0_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_13_0_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_13_2_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_13_2_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_13_2_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_13_2_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_13_1_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_13_1_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_13_1_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_13_1_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    literal_unit_13_0_source: &'static str,
    #[cfg(test)]
    literal_unit_13_0_argument: &'static str,
    #[cfg(test)]
    literal_unit_13_0_returned: &'static str,
    #[cfg(test)]
    literal_unit_13_0_caller: &'static str,
    #[cfg(test)]
    mir_unit_14_0_source: bool,
    #[cfg(test)]
    mir_unit_14_0_argument: bool,
    #[cfg(test)]
    mir_unit_14_0_returned: bool,
    #[cfg(test)]
    mir_unit_14_0_caller: bool,
    #[cfg(test)]
    mir_unit_14_3_source: usize,
    #[cfg(test)]
    mir_unit_14_3_argument: usize,
    #[cfg(test)]
    mir_unit_14_3_returned: usize,
    #[cfg(test)]
    mir_unit_14_3_caller: usize,
    #[cfg(test)]
    mir_unit_14_4_source: usize,
    #[cfg(test)]
    mir_unit_14_4_argument: usize,
    #[cfg(test)]
    mir_unit_14_4_returned: usize,
    #[cfg(test)]
    mir_unit_14_4_caller: usize,
    #[cfg(test)]
    mir_unit_14_5_source: &'static usize,
    #[cfg(test)]
    mir_unit_14_5_argument: &'static usize,
    #[cfg(test)]
    mir_unit_14_5_returned: &'static usize,
    #[cfg(test)]
    mir_unit_14_5_caller: &'static usize,
    #[cfg(test)]
    mir_unit_14_1_source: (&'static usize,),
    #[cfg(test)]
    mir_unit_14_1_argument: (&'static usize,),
    #[cfg(test)]
    mir_unit_14_1_returned: (&'static usize,),
    #[cfg(test)]
    mir_unit_14_1_caller: (&'static usize,),
    #[cfg(test)]
    mir_unit_14_2_source: &'static usize,
    #[cfg(test)]
    mir_unit_14_2_argument: &'static usize,
    #[cfg(test)]
    mir_unit_14_2_returned: &'static usize,
    #[cfg(test)]
    mir_unit_14_2_caller: &'static usize,
    #[cfg(test)]
    alias_unit_14_2_0_i_source: &'static usize,
    #[cfg(test)]
    alias_unit_14_2_0_i_argument: &'static usize,
    #[cfg(test)]
    alias_unit_14_2_0_i_returned: &'static usize,
    #[cfg(test)]
    alias_unit_14_2_0_i_caller: &'static usize,
    #[cfg(test)]
    mir_unit_15_0_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_15_0_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_15_0_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_15_0_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_15_2_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_15_2_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_15_2_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_15_2_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_15_1_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_15_1_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_15_1_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_15_1_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    literal_unit_15_0_source: &'static str,
    #[cfg(test)]
    literal_unit_15_0_argument: &'static str,
    #[cfg(test)]
    literal_unit_15_0_returned: &'static str,
    #[cfg(test)]
    literal_unit_15_0_caller: &'static str,
    #[cfg(test)]
    mir_unit_16_0_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_16_0_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_16_0_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_16_0_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_16_2_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_16_2_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_16_2_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_16_2_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_16_1_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_16_1_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_16_1_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_16_1_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    literal_unit_16_0_source: &'static str,
    #[cfg(test)]
    literal_unit_16_0_argument: &'static str,
    #[cfg(test)]
    literal_unit_16_0_returned: &'static str,
    #[cfg(test)]
    literal_unit_16_0_caller: &'static str,
    #[cfg(test)]
    mir_unit_17_0_source: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_17_0_argument: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_17_0_returned: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_17_0_caller: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_17_0_0_result_source: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_17_0_0_result_argument: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_17_0_0_result_returned: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_17_0_0_result_caller: std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_17_2_source: usize,
    #[cfg(test)]
    mir_unit_17_2_argument: usize,
    #[cfg(test)]
    mir_unit_17_2_returned: usize,
    #[cfg(test)]
    mir_unit_17_2_caller: usize,
    #[cfg(test)]
    alias_unit_17_2_0_previous_length_source: usize,
    #[cfg(test)]
    alias_unit_17_2_0_previous_length_argument: usize,
    #[cfg(test)]
    alias_unit_17_2_0_previous_length_returned: usize,
    #[cfg(test)]
    alias_unit_17_2_0_previous_length_caller: usize,
    #[cfg(test)]
    mir_unit_17_3_source: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_17_3_argument: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_17_3_returned: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_17_3_caller: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_17_4_source: &'static mut crate::experimental_swift_reactor::execution::ExecutionOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_17_4_argument: &'static mut crate::experimental_swift_reactor::execution::ExecutionOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_17_4_returned: &'static mut crate::experimental_swift_reactor::execution::ExecutionOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_17_4_caller: &'static mut crate::experimental_swift_reactor::execution::ExecutionOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_17_5_source: bool,
    #[cfg(test)]
    mir_unit_17_5_argument: bool,
    #[cfg(test)]
    mir_unit_17_5_returned: bool,
    #[cfg(test)]
    mir_unit_17_5_caller: bool,
    #[cfg(test)]
    mir_unit_17_6_source: &'static std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_17_6_argument: &'static std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_17_6_returned: &'static std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_17_6_caller: &'static std::result::Result<Value, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_17_7_source: bool,
    #[cfg(test)]
    mir_unit_17_7_argument: bool,
    #[cfg(test)]
    mir_unit_17_7_returned: bool,
    #[cfg(test)]
    mir_unit_17_7_caller: bool,
    #[cfg(test)]
    mir_unit_17_8_source: usize,
    #[cfg(test)]
    mir_unit_17_8_argument: usize,
    #[cfg(test)]
    mir_unit_17_8_returned: usize,
    #[cfg(test)]
    mir_unit_17_8_caller: usize,
    #[cfg(test)]
    mir_unit_17_9_source: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_17_9_argument: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_17_9_returned: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_17_9_caller: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_17_10_source: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_17_10_argument: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_17_10_returned: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_17_10_caller: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_17_11_source: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_17_11_argument: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_17_11_returned: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_17_11_caller: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_17_12_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameCleanupState,
    #[cfg(test)]
    mir_unit_17_12_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameCleanupState,
    #[cfg(test)]
    mir_unit_17_12_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameCleanupState,
    #[cfg(test)]
    mir_unit_17_12_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameCleanupState,
    #[cfg(test)]
    mir_unit_17_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_17_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_17_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_17_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_17_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_17_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_17_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_17_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    literal_unit_17_0_source: bool,
    #[cfg(test)]
    literal_unit_17_0_argument: bool,
    #[cfg(test)]
    literal_unit_17_0_returned: bool,
    #[cfg(test)]
    literal_unit_17_0_caller: bool,
    #[cfg(test)]
    mir_unit_18_0_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_18_0_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_18_0_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_18_0_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_18_2_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_18_2_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_18_2_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_18_2_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_18_2_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_18_2_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_18_2_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_18_2_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_18_3_source: std::option::Option<&'static crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_18_3_argument: std::option::Option<&'static crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_18_3_returned: std::option::Option<&'static crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_18_3_caller: std::option::Option<&'static crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_18_4_source: &'static [crate::experimental_swift_reactor::execution::SwiftFrame],
    #[cfg(test)]
    mir_unit_18_4_argument: &'static [crate::experimental_swift_reactor::execution::SwiftFrame],
    #[cfg(test)]
    mir_unit_18_4_returned: &'static [crate::experimental_swift_reactor::execution::SwiftFrame],
    #[cfg(test)]
    mir_unit_18_4_caller: &'static [crate::experimental_swift_reactor::execution::SwiftFrame],
    #[cfg(test)]
    mir_unit_18_5_source: &'static std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_18_5_argument: &'static std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_18_5_returned: &'static std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_18_5_caller: &'static std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_18_6_source: isize,
    #[cfg(test)]
    mir_unit_18_6_argument: isize,
    #[cfg(test)]
    mir_unit_18_6_returned: isize,
    #[cfg(test)]
    mir_unit_18_6_caller: isize,
    #[cfg(test)]
    mir_unit_18_7_source: &'static crate::experimental_swift_reactor::execution::SwiftFrame,
    #[cfg(test)]
    mir_unit_18_7_argument: &'static crate::experimental_swift_reactor::execution::SwiftFrame,
    #[cfg(test)]
    mir_unit_18_7_returned: &'static crate::experimental_swift_reactor::execution::SwiftFrame,
    #[cfg(test)]
    mir_unit_18_7_caller: &'static crate::experimental_swift_reactor::execution::SwiftFrame,
    #[cfg(test)]
    alias_unit_18_7_0_frame_source: &'static crate::experimental_swift_reactor::execution::SwiftFrame,
    #[cfg(test)]
    alias_unit_18_7_0_frame_argument: &'static crate::experimental_swift_reactor::execution::SwiftFrame,
    #[cfg(test)]
    alias_unit_18_7_0_frame_returned: &'static crate::experimental_swift_reactor::execution::SwiftFrame,
    #[cfg(test)]
    alias_unit_18_7_0_frame_caller: &'static crate::experimental_swift_reactor::execution::SwiftFrame,
    #[cfg(test)]
    mir_unit_18_8_source: u32,
    #[cfg(test)]
    mir_unit_18_8_argument: u32,
    #[cfg(test)]
    mir_unit_18_8_returned: u32,
    #[cfg(test)]
    mir_unit_18_8_caller: u32,
    #[cfg(test)]
    mir_unit_18_9_source: usize,
    #[cfg(test)]
    mir_unit_18_9_argument: usize,
    #[cfg(test)]
    mir_unit_18_9_returned: usize,
    #[cfg(test)]
    mir_unit_18_9_caller: usize,
    #[cfg(test)]
    mir_unit_18_10_source: usize,
    #[cfg(test)]
    mir_unit_18_10_argument: usize,
    #[cfg(test)]
    mir_unit_18_10_returned: usize,
    #[cfg(test)]
    mir_unit_18_10_caller: usize,
    #[cfg(test)]
    mir_unit_18_11_source: usize,
    #[cfg(test)]
    mir_unit_18_11_argument: usize,
    #[cfg(test)]
    mir_unit_18_11_returned: usize,
    #[cfg(test)]
    mir_unit_18_11_caller: usize,
    #[cfg(test)]
    mir_unit_18_12_source: usize,
    #[cfg(test)]
    mir_unit_18_12_argument: usize,
    #[cfg(test)]
    mir_unit_18_12_returned: usize,
    #[cfg(test)]
    mir_unit_18_12_caller: usize,
    #[cfg(test)]
    mir_unit_18_13_source: bool,
    #[cfg(test)]
    mir_unit_18_13_argument: bool,
    #[cfg(test)]
    mir_unit_18_13_returned: bool,
    #[cfg(test)]
    mir_unit_18_13_caller: bool,
    #[cfg(test)]
    mir_unit_18_14_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_18_14_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_18_14_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_18_14_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_18_15_source: bool,
    #[cfg(test)]
    mir_unit_18_15_argument: bool,
    #[cfg(test)]
    mir_unit_18_15_returned: bool,
    #[cfg(test)]
    mir_unit_18_15_caller: bool,
    #[cfg(test)]
    mir_unit_18_16_source: usize,
    #[cfg(test)]
    mir_unit_18_16_argument: usize,
    #[cfg(test)]
    mir_unit_18_16_returned: usize,
    #[cfg(test)]
    mir_unit_18_16_caller: usize,
    #[cfg(test)]
    mir_unit_18_17_source: usize,
    #[cfg(test)]
    mir_unit_18_17_argument: usize,
    #[cfg(test)]
    mir_unit_18_17_returned: usize,
    #[cfg(test)]
    mir_unit_18_17_caller: usize,
    #[cfg(test)]
    mir_unit_18_18_source: bool,
    #[cfg(test)]
    mir_unit_18_18_argument: bool,
    #[cfg(test)]
    mir_unit_18_18_returned: bool,
    #[cfg(test)]
    mir_unit_18_18_caller: bool,
    #[cfg(test)]
    mir_unit_18_19_source: usize,
    #[cfg(test)]
    mir_unit_18_19_argument: usize,
    #[cfg(test)]
    mir_unit_18_19_returned: usize,
    #[cfg(test)]
    mir_unit_18_19_caller: usize,
    #[cfg(test)]
    mir_unit_18_20_source: usize,
    #[cfg(test)]
    mir_unit_18_20_argument: usize,
    #[cfg(test)]
    mir_unit_18_20_returned: usize,
    #[cfg(test)]
    mir_unit_18_20_caller: usize,
    #[cfg(test)]
    mir_unit_18_21_source: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_18_21_argument: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_18_21_returned: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_18_21_caller: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_18_22_source: bool,
    #[cfg(test)]
    mir_unit_18_22_argument: bool,
    #[cfg(test)]
    mir_unit_18_22_returned: bool,
    #[cfg(test)]
    mir_unit_18_22_caller: bool,
    #[cfg(test)]
    mir_unit_18_23_source: usize,
    #[cfg(test)]
    mir_unit_18_23_argument: usize,
    #[cfg(test)]
    mir_unit_18_23_returned: usize,
    #[cfg(test)]
    mir_unit_18_23_caller: usize,
    #[cfg(test)]
    mir_unit_18_24_source: usize,
    #[cfg(test)]
    mir_unit_18_24_argument: usize,
    #[cfg(test)]
    mir_unit_18_24_returned: usize,
    #[cfg(test)]
    mir_unit_18_24_caller: usize,
    #[cfg(test)]
    mir_unit_18_25_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_18_25_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_18_25_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_18_25_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_18_26_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_18_26_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_18_26_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_18_26_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_18_27_source: &'static mut std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_18_27_argument: &'static mut std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_18_27_returned: &'static mut std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_18_27_caller: &'static mut std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_18_28_source: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_18_28_argument: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_18_28_returned: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_18_28_caller: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_18_29_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_18_29_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_18_29_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_18_29_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_18_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_18_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_18_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_18_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_18_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_18_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_18_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_18_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    literal_unit_18_0_source: &'static str,
    #[cfg(test)]
    literal_unit_18_0_argument: &'static str,
    #[cfg(test)]
    literal_unit_18_0_returned: &'static str,
    #[cfg(test)]
    literal_unit_18_0_caller: &'static str,
    #[cfg(test)]
    literal_unit_18_1_source: &'static str,
    #[cfg(test)]
    literal_unit_18_1_argument: &'static str,
    #[cfg(test)]
    literal_unit_18_1_returned: &'static str,
    #[cfg(test)]
    literal_unit_18_1_caller: &'static str,
    #[cfg(test)]
    mir_unit_19_0_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_19_0_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_19_0_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_19_0_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_19_2_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_19_2_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_19_2_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_19_2_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_19_3_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_19_3_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_19_3_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_19_3_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_19_4_source: isize,
    #[cfg(test)]
    mir_unit_19_4_argument: isize,
    #[cfg(test)]
    mir_unit_19_4_returned: isize,
    #[cfg(test)]
    mir_unit_19_4_caller: isize,
    #[cfg(test)]
    mir_unit_19_5_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_19_5_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_19_5_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_19_5_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_19_5_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_19_5_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_19_5_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_19_5_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_19_6_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_19_6_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_19_6_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_19_6_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_19_6_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_19_6_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_19_6_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_19_6_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_19_6_1_val_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_19_6_1_val_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_19_6_1_val_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_19_6_1_val_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_19_7_source: std::option::Option<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_19_7_argument: std::option::Option<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_19_7_returned: std::option::Option<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_19_7_caller: std::option::Option<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_19_8_source: std::option::Option<&'static crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_19_8_argument: std::option::Option<&'static crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_19_8_returned: std::option::Option<&'static crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_19_8_caller: std::option::Option<&'static crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_19_9_source: &'static [crate::experimental::execution::Control],
    #[cfg(test)]
    mir_unit_19_9_argument: &'static [crate::experimental::execution::Control],
    #[cfg(test)]
    mir_unit_19_9_returned: &'static [crate::experimental::execution::Control],
    #[cfg(test)]
    mir_unit_19_9_caller: &'static [crate::experimental::execution::Control],
    #[cfg(test)]
    mir_unit_19_10_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_19_10_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_19_10_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_19_10_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_19_11_source: usize,
    #[cfg(test)]
    mir_unit_19_11_argument: usize,
    #[cfg(test)]
    mir_unit_19_11_returned: usize,
    #[cfg(test)]
    mir_unit_19_11_caller: usize,
    #[cfg(test)]
    mir_unit_19_12_source: isize,
    #[cfg(test)]
    mir_unit_19_12_argument: isize,
    #[cfg(test)]
    mir_unit_19_12_returned: isize,
    #[cfg(test)]
    mir_unit_19_12_caller: isize,
    #[cfg(test)]
    mir_unit_19_14_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_19_14_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_19_14_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_19_14_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_19_15_source: bool,
    #[cfg(test)]
    mir_unit_19_15_argument: bool,
    #[cfg(test)]
    mir_unit_19_15_returned: bool,
    #[cfg(test)]
    mir_unit_19_15_caller: bool,
    #[cfg(test)]
    mir_unit_19_16_source: bool,
    #[cfg(test)]
    mir_unit_19_16_argument: bool,
    #[cfg(test)]
    mir_unit_19_16_returned: bool,
    #[cfg(test)]
    mir_unit_19_16_caller: bool,
    #[cfg(test)]
    mir_unit_19_17_source: usize,
    #[cfg(test)]
    mir_unit_19_17_argument: usize,
    #[cfg(test)]
    mir_unit_19_17_returned: usize,
    #[cfg(test)]
    mir_unit_19_17_caller: usize,
    #[cfg(test)]
    mir_unit_19_18_source: usize,
    #[cfg(test)]
    mir_unit_19_18_argument: usize,
    #[cfg(test)]
    mir_unit_19_18_returned: usize,
    #[cfg(test)]
    mir_unit_19_18_caller: usize,
    #[cfg(test)]
    mir_unit_19_19_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_19_19_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_19_19_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_19_19_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_19_20_source: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_19_20_argument: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_19_20_returned: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_19_20_caller: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_19_21_source: usize,
    #[cfg(test)]
    mir_unit_19_21_argument: usize,
    #[cfg(test)]
    mir_unit_19_21_returned: usize,
    #[cfg(test)]
    mir_unit_19_21_caller: usize,
    #[cfg(test)]
    mir_unit_19_22_source: isize,
    #[cfg(test)]
    mir_unit_19_22_argument: isize,
    #[cfg(test)]
    mir_unit_19_22_returned: isize,
    #[cfg(test)]
    mir_unit_19_22_caller: isize,
    #[cfg(test)]
    mir_unit_19_24_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_19_24_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_19_24_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_19_24_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_19_25_source: bool,
    #[cfg(test)]
    mir_unit_19_25_argument: bool,
    #[cfg(test)]
    mir_unit_19_25_returned: bool,
    #[cfg(test)]
    mir_unit_19_25_caller: bool,
    #[cfg(test)]
    mir_unit_19_26_source: usize,
    #[cfg(test)]
    mir_unit_19_26_argument: usize,
    #[cfg(test)]
    mir_unit_19_26_returned: usize,
    #[cfg(test)]
    mir_unit_19_26_caller: usize,
    #[cfg(test)]
    mir_unit_19_27_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_19_27_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_19_27_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_19_27_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_19_28_source: usize,
    #[cfg(test)]
    mir_unit_19_28_argument: usize,
    #[cfg(test)]
    mir_unit_19_28_returned: usize,
    #[cfg(test)]
    mir_unit_19_28_caller: usize,
    #[cfg(test)]
    mir_unit_19_29_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_19_29_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_19_29_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_19_29_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_19_13_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_19_13_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_19_13_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_19_13_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_19_13_0_sentinel_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_19_13_0_sentinel_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_19_13_0_sentinel_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_19_13_0_sentinel_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_19_13_1_control_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_19_13_1_control_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_19_13_1_control_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_19_13_1_control_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_19_23_source: usize,
    #[cfg(test)]
    mir_unit_19_23_argument: usize,
    #[cfg(test)]
    mir_unit_19_23_returned: usize,
    #[cfg(test)]
    mir_unit_19_23_caller: usize,
    #[cfg(test)]
    alias_unit_19_23_0_after_end_source: usize,
    #[cfg(test)]
    alias_unit_19_23_0_after_end_argument: usize,
    #[cfg(test)]
    alias_unit_19_23_0_after_end_returned: usize,
    #[cfg(test)]
    alias_unit_19_23_0_after_end_caller: usize,
    #[cfg(test)]
    alias_unit_19_23_1_pc_source: usize,
    #[cfg(test)]
    alias_unit_19_23_1_pc_argument: usize,
    #[cfg(test)]
    alias_unit_19_23_1_pc_returned: usize,
    #[cfg(test)]
    alias_unit_19_23_1_pc_caller: usize,
    #[cfg(test)]
    mir_unit_19_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_19_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_19_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_19_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_19_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_19_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_19_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_19_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    literal_unit_19_0_source: &'static str,
    #[cfg(test)]
    literal_unit_19_0_argument: &'static str,
    #[cfg(test)]
    literal_unit_19_0_returned: &'static str,
    #[cfg(test)]
    literal_unit_19_0_caller: &'static str,
    #[cfg(test)]
    literal_unit_19_1_source: &'static str,
    #[cfg(test)]
    literal_unit_19_1_argument: &'static str,
    #[cfg(test)]
    literal_unit_19_1_returned: &'static str,
    #[cfg(test)]
    literal_unit_19_1_caller: &'static str,
    #[cfg(test)]
    literal_unit_19_2_source: usize,
    #[cfg(test)]
    literal_unit_19_2_argument: usize,
    #[cfg(test)]
    literal_unit_19_2_returned: usize,
    #[cfg(test)]
    literal_unit_19_2_caller: usize,
    #[cfg(test)]
    literal_unit_19_3_source: &'static str,
    #[cfg(test)]
    literal_unit_19_3_argument: &'static str,
    #[cfg(test)]
    literal_unit_19_3_returned: &'static str,
    #[cfg(test)]
    literal_unit_19_3_caller: &'static str,
    #[cfg(test)]
    literal_unit_19_4_source: &'static str,
    #[cfg(test)]
    literal_unit_19_4_argument: &'static str,
    #[cfg(test)]
    literal_unit_19_4_returned: &'static str,
    #[cfg(test)]
    literal_unit_19_4_caller: &'static str,
    #[cfg(test)]
    mir_unit_20_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_5_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_20_5_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_20_5_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_20_5_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_20_6_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_6_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_6_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_6_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_7_source: isize,
    #[cfg(test)]
    mir_unit_20_7_argument: isize,
    #[cfg(test)]
    mir_unit_20_7_returned: isize,
    #[cfg(test)]
    mir_unit_20_7_caller: isize,
    #[cfg(test)]
    mir_unit_20_8_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_8_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_8_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_8_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_20_8_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_20_8_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_20_8_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_20_8_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_9_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_20_9_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_20_9_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_20_9_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_20_9_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_20_9_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_20_9_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_20_9_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_20_9_1_val_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_20_9_1_val_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_20_9_1_val_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_20_9_1_val_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_20_10_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_20_10_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_20_10_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_20_10_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_20_11_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_11_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_11_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_11_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_12_source: isize,
    #[cfg(test)]
    mir_unit_20_12_argument: isize,
    #[cfg(test)]
    mir_unit_20_12_returned: isize,
    #[cfg(test)]
    mir_unit_20_12_caller: isize,
    #[cfg(test)]
    mir_unit_20_15_source: bool,
    #[cfg(test)]
    mir_unit_20_15_argument: bool,
    #[cfg(test)]
    mir_unit_20_15_returned: bool,
    #[cfg(test)]
    mir_unit_20_15_caller: bool,
    #[cfg(test)]
    mir_unit_20_16_source: usize,
    #[cfg(test)]
    mir_unit_20_16_argument: usize,
    #[cfg(test)]
    mir_unit_20_16_returned: usize,
    #[cfg(test)]
    mir_unit_20_16_caller: usize,
    #[cfg(test)]
    mir_unit_20_17_source: bool,
    #[cfg(test)]
    mir_unit_20_17_argument: bool,
    #[cfg(test)]
    mir_unit_20_17_returned: bool,
    #[cfg(test)]
    mir_unit_20_17_caller: bool,
    #[cfg(test)]
    mir_unit_20_18_source: bool,
    #[cfg(test)]
    mir_unit_20_18_argument: bool,
    #[cfg(test)]
    mir_unit_20_18_returned: bool,
    #[cfg(test)]
    mir_unit_20_18_caller: bool,
    #[cfg(test)]
    mir_unit_20_19_source: &'static crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_20_19_argument: &'static crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_20_19_returned: &'static crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_20_19_caller: &'static crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_20_20_source: &'static crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_20_20_argument: &'static crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_20_20_returned: &'static crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_20_20_caller: &'static crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_20_21_source: bool,
    #[cfg(test)]
    mir_unit_20_21_argument: bool,
    #[cfg(test)]
    mir_unit_20_21_returned: bool,
    #[cfg(test)]
    mir_unit_20_21_caller: bool,
    #[cfg(test)]
    mir_unit_20_22_source: &'static std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_22_argument: &'static std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_22_returned: &'static std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_22_caller: &'static std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_23_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_20_23_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_20_23_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_20_23_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_20_24_source: isize,
    #[cfg(test)]
    mir_unit_20_24_argument: isize,
    #[cfg(test)]
    mir_unit_20_24_returned: isize,
    #[cfg(test)]
    mir_unit_20_24_caller: isize,
    #[cfg(test)]
    mir_unit_20_26_source: bool,
    #[cfg(test)]
    mir_unit_20_26_argument: bool,
    #[cfg(test)]
    mir_unit_20_26_returned: bool,
    #[cfg(test)]
    mir_unit_20_26_caller: bool,
    #[cfg(test)]
    mir_unit_20_27_source: usize,
    #[cfg(test)]
    mir_unit_20_27_argument: usize,
    #[cfg(test)]
    mir_unit_20_27_returned: usize,
    #[cfg(test)]
    mir_unit_20_27_caller: usize,
    #[cfg(test)]
    mir_unit_20_28_source: bool,
    #[cfg(test)]
    mir_unit_20_28_argument: bool,
    #[cfg(test)]
    mir_unit_20_28_returned: bool,
    #[cfg(test)]
    mir_unit_20_28_caller: bool,
    #[cfg(test)]
    mir_unit_20_29_source: bool,
    #[cfg(test)]
    mir_unit_20_29_argument: bool,
    #[cfg(test)]
    mir_unit_20_29_returned: bool,
    #[cfg(test)]
    mir_unit_20_29_caller: bool,
    #[cfg(test)]
    mir_unit_20_30_source: &'static std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_30_argument: &'static std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_30_returned: &'static std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_30_caller: &'static std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_31_source: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_31_argument: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_31_returned: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_31_caller: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_32_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_20_32_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_20_32_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_20_32_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_20_33_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_20_33_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_20_33_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_20_33_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_20_34_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_34_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_34_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_34_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_35_source: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_35_argument: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_35_returned: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_35_caller: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_36_source: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_36_argument: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_36_returned: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_36_caller: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_20_37_source: usize,
    #[cfg(test)]
    mir_unit_20_37_argument: usize,
    #[cfg(test)]
    mir_unit_20_37_returned: usize,
    #[cfg(test)]
    mir_unit_20_37_caller: usize,
    #[cfg(test)]
    mir_unit_20_38_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_20_38_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_20_38_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_20_38_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_20_39_source: usize,
    #[cfg(test)]
    mir_unit_20_39_argument: usize,
    #[cfg(test)]
    mir_unit_20_39_returned: usize,
    #[cfg(test)]
    mir_unit_20_39_caller: usize,
    #[cfg(test)]
    mir_unit_20_40_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_20_40_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_20_40_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_20_40_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_20_41_source: isize,
    #[cfg(test)]
    mir_unit_20_41_argument: isize,
    #[cfg(test)]
    mir_unit_20_41_returned: isize,
    #[cfg(test)]
    mir_unit_20_41_caller: isize,
    #[cfg(test)]
    mir_unit_20_44_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_20_44_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_20_44_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_20_44_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_20_13_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_13_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_13_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_13_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_20_13_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_20_13_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_20_13_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_20_13_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_14_source: usize,
    #[cfg(test)]
    mir_unit_20_14_argument: usize,
    #[cfg(test)]
    mir_unit_20_14_returned: usize,
    #[cfg(test)]
    mir_unit_20_14_caller: usize,
    #[cfg(test)]
    alias_unit_20_14_0_bound_source: usize,
    #[cfg(test)]
    alias_unit_20_14_0_bound_argument: usize,
    #[cfg(test)]
    alias_unit_20_14_0_bound_returned: usize,
    #[cfg(test)]
    alias_unit_20_14_0_bound_caller: usize,
    #[cfg(test)]
    alias_unit_20_14_1_val_source: usize,
    #[cfg(test)]
    alias_unit_20_14_1_val_argument: usize,
    #[cfg(test)]
    alias_unit_20_14_1_val_returned: usize,
    #[cfg(test)]
    alias_unit_20_14_1_val_caller: usize,
    #[cfg(test)]
    mir_unit_20_42_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_42_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_42_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_42_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_20_42_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_20_42_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_20_42_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_20_42_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_20_43_source: usize,
    #[cfg(test)]
    mir_unit_20_43_argument: usize,
    #[cfg(test)]
    mir_unit_20_43_returned: usize,
    #[cfg(test)]
    mir_unit_20_43_caller: usize,
    #[cfg(test)]
    alias_unit_20_43_0_val_source: usize,
    #[cfg(test)]
    alias_unit_20_43_0_val_argument: usize,
    #[cfg(test)]
    alias_unit_20_43_0_val_returned: usize,
    #[cfg(test)]
    alias_unit_20_43_0_val_caller: usize,
    #[cfg(test)]
    mir_unit_20_25_source: usize,
    #[cfg(test)]
    mir_unit_20_25_argument: usize,
    #[cfg(test)]
    mir_unit_20_25_returned: usize,
    #[cfg(test)]
    mir_unit_20_25_caller: usize,
    #[cfg(test)]
    alias_unit_20_25_0_alternative_source: usize,
    #[cfg(test)]
    alias_unit_20_25_0_alternative_argument: usize,
    #[cfg(test)]
    alias_unit_20_25_0_alternative_returned: usize,
    #[cfg(test)]
    alias_unit_20_25_0_alternative_caller: usize,
    #[cfg(test)]
    mir_unit_20_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_20_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_20_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_20_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_20_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_20_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_20_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_20_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_20_2_source: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_20_2_argument: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_20_2_returned: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_20_2_caller: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    alias_unit_20_2_0_kind_source: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    alias_unit_20_2_0_kind_argument: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    alias_unit_20_2_0_kind_returned: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    alias_unit_20_2_0_kind_caller: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_20_3_source: usize,
    #[cfg(test)]
    mir_unit_20_3_argument: usize,
    #[cfg(test)]
    mir_unit_20_3_returned: usize,
    #[cfg(test)]
    mir_unit_20_3_caller: usize,
    #[cfg(test)]
    alias_unit_20_3_0_end_source: usize,
    #[cfg(test)]
    alias_unit_20_3_0_end_argument: usize,
    #[cfg(test)]
    alias_unit_20_3_0_end_returned: usize,
    #[cfg(test)]
    alias_unit_20_3_0_end_caller: usize,
    #[cfg(test)]
    mir_unit_20_4_source: Option<usize>,
    #[cfg(test)]
    mir_unit_20_4_argument: Option<usize>,
    #[cfg(test)]
    mir_unit_20_4_returned: Option<usize>,
    #[cfg(test)]
    mir_unit_20_4_caller: Option<usize>,
    #[cfg(test)]
    alias_unit_20_4_0_alternative_source: Option<usize>,
    #[cfg(test)]
    alias_unit_20_4_0_alternative_argument: Option<usize>,
    #[cfg(test)]
    alias_unit_20_4_0_alternative_returned: Option<usize>,
    #[cfg(test)]
    alias_unit_20_4_0_alternative_caller: Option<usize>,
    #[cfg(test)]
    literal_unit_20_0_source: &'static str,
    #[cfg(test)]
    literal_unit_20_0_argument: &'static str,
    #[cfg(test)]
    literal_unit_20_0_returned: &'static str,
    #[cfg(test)]
    literal_unit_20_0_caller: &'static str,
    #[cfg(test)]
    literal_unit_20_1_source: usize,
    #[cfg(test)]
    literal_unit_20_1_argument: usize,
    #[cfg(test)]
    literal_unit_20_1_returned: usize,
    #[cfg(test)]
    literal_unit_20_1_caller: usize,
    #[cfg(test)]
    literal_unit_20_2_source: &'static str,
    #[cfg(test)]
    literal_unit_20_2_argument: &'static str,
    #[cfg(test)]
    literal_unit_20_2_returned: &'static str,
    #[cfg(test)]
    literal_unit_20_2_caller: &'static str,
    #[cfg(test)]
    mir_unit_21_0_source: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_21_0_argument: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_21_0_returned: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_21_0_caller: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_21_1_source: (),
    #[cfg(test)]
    mir_unit_21_1_argument: (),
    #[cfg(test)]
    mir_unit_21_1_returned: (),
    #[cfg(test)]
    mir_unit_21_1_caller: (),
    #[cfg(test)]
    mir_unit_21_2_source: usize,
    #[cfg(test)]
    mir_unit_21_2_argument: usize,
    #[cfg(test)]
    mir_unit_21_2_returned: usize,
    #[cfg(test)]
    mir_unit_21_2_caller: usize,
    #[cfg(test)]
    alias_unit_21_2_0_depth_source: usize,
    #[cfg(test)]
    alias_unit_21_2_0_depth_argument: usize,
    #[cfg(test)]
    alias_unit_21_2_0_depth_returned: usize,
    #[cfg(test)]
    alias_unit_21_2_0_depth_caller: usize,
    #[cfg(test)]
    literal_unit_21_0_source: usize,
    #[cfg(test)]
    literal_unit_21_0_argument: usize,
    #[cfg(test)]
    literal_unit_21_0_returned: usize,
    #[cfg(test)]
    literal_unit_21_0_caller: usize,
    #[cfg(test)]
    mir_unit_22_0_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_22_0_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_22_0_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_22_0_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_22_2_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_22_2_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_22_2_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_22_2_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_22_1_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_22_1_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_22_1_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_22_1_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    literal_unit_22_0_source: &'static str,
    #[cfg(test)]
    literal_unit_22_0_argument: &'static str,
    #[cfg(test)]
    literal_unit_22_0_returned: &'static str,
    #[cfg(test)]
    literal_unit_22_0_caller: &'static str,
    #[cfg(test)]
    mir_unit_23_0_source: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_0_argument: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_0_returned: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_0_caller: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_3_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_23_3_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_23_3_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_23_3_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_23_4_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_4_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_4_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_4_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_5_source: isize,
    #[cfg(test)]
    mir_unit_23_5_argument: isize,
    #[cfg(test)]
    mir_unit_23_5_returned: isize,
    #[cfg(test)]
    mir_unit_23_5_caller: isize,
    #[cfg(test)]
    mir_unit_23_6_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_6_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_6_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_6_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_23_6_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_23_6_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_23_6_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_23_6_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_7_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_23_7_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_23_7_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_23_7_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_23_7_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_23_7_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_23_7_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_23_7_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_23_7_1_val_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_23_7_1_val_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_23_7_1_val_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_23_7_1_val_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_23_8_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_23_8_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_23_8_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_23_8_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_23_9_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_9_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_9_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_9_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_10_source: isize,
    #[cfg(test)]
    mir_unit_23_10_argument: isize,
    #[cfg(test)]
    mir_unit_23_10_returned: isize,
    #[cfg(test)]
    mir_unit_23_10_caller: isize,
    #[cfg(test)]
    mir_unit_23_13_source: std::option::Option<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_23_13_argument: std::option::Option<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_23_13_returned: std::option::Option<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_23_13_caller: std::option::Option<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_23_14_source: std::option::Option<&'static crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_23_14_argument: std::option::Option<&'static crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_23_14_returned: std::option::Option<&'static crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_23_14_caller: std::option::Option<&'static crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_23_15_source: &'static [crate::experimental::execution::Control],
    #[cfg(test)]
    mir_unit_23_15_argument: &'static [crate::experimental::execution::Control],
    #[cfg(test)]
    mir_unit_23_15_returned: &'static [crate::experimental::execution::Control],
    #[cfg(test)]
    mir_unit_23_15_caller: &'static [crate::experimental::execution::Control],
    #[cfg(test)]
    mir_unit_23_16_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_23_16_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_23_16_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_23_16_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_23_17_source: isize,
    #[cfg(test)]
    mir_unit_23_17_argument: isize,
    #[cfg(test)]
    mir_unit_23_17_returned: isize,
    #[cfg(test)]
    mir_unit_23_17_caller: isize,
    #[cfg(test)]
    mir_unit_23_20_source: bool,
    #[cfg(test)]
    mir_unit_23_20_argument: bool,
    #[cfg(test)]
    mir_unit_23_20_returned: bool,
    #[cfg(test)]
    mir_unit_23_20_caller: bool,
    #[cfg(test)]
    mir_unit_23_21_source: usize,
    #[cfg(test)]
    mir_unit_23_21_argument: usize,
    #[cfg(test)]
    mir_unit_23_21_returned: usize,
    #[cfg(test)]
    mir_unit_23_21_caller: usize,
    #[cfg(test)]
    mir_unit_23_22_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_23_22_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_23_22_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_23_22_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_23_23_source: bool,
    #[cfg(test)]
    mir_unit_23_23_argument: bool,
    #[cfg(test)]
    mir_unit_23_23_returned: bool,
    #[cfg(test)]
    mir_unit_23_23_caller: bool,
    #[cfg(test)]
    mir_unit_23_24_source: usize,
    #[cfg(test)]
    mir_unit_23_24_argument: usize,
    #[cfg(test)]
    mir_unit_23_24_returned: usize,
    #[cfg(test)]
    mir_unit_23_24_caller: usize,
    #[cfg(test)]
    mir_unit_23_25_source: bool,
    #[cfg(test)]
    mir_unit_23_25_argument: bool,
    #[cfg(test)]
    mir_unit_23_25_returned: bool,
    #[cfg(test)]
    mir_unit_23_25_caller: bool,
    #[cfg(test)]
    mir_unit_23_26_source: usize,
    #[cfg(test)]
    mir_unit_23_26_argument: usize,
    #[cfg(test)]
    mir_unit_23_26_returned: usize,
    #[cfg(test)]
    mir_unit_23_26_caller: usize,
    #[cfg(test)]
    mir_unit_23_27_source: usize,
    #[cfg(test)]
    mir_unit_23_27_argument: usize,
    #[cfg(test)]
    mir_unit_23_27_returned: usize,
    #[cfg(test)]
    mir_unit_23_27_caller: usize,
    #[cfg(test)]
    mir_unit_23_28_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_23_28_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_23_28_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_23_28_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_23_29_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_23_29_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_23_29_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_23_29_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_23_11_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_11_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_11_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_11_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_23_11_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_23_11_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_23_11_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_23_11_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_23_12_source: usize,
    #[cfg(test)]
    mir_unit_23_12_argument: usize,
    #[cfg(test)]
    mir_unit_23_12_returned: usize,
    #[cfg(test)]
    mir_unit_23_12_caller: usize,
    #[cfg(test)]
    alias_unit_23_12_0_bound_source: usize,
    #[cfg(test)]
    alias_unit_23_12_0_bound_argument: usize,
    #[cfg(test)]
    alias_unit_23_12_0_bound_returned: usize,
    #[cfg(test)]
    alias_unit_23_12_0_bound_caller: usize,
    #[cfg(test)]
    alias_unit_23_12_1_val_source: usize,
    #[cfg(test)]
    alias_unit_23_12_1_val_argument: usize,
    #[cfg(test)]
    alias_unit_23_12_1_val_returned: usize,
    #[cfg(test)]
    alias_unit_23_12_1_val_caller: usize,
    #[cfg(test)]
    mir_unit_23_18_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_23_18_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_23_18_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_23_18_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_23_18_0_control_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_23_18_0_control_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_23_18_0_control_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_23_18_0_control_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_23_18_1_control_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_23_18_1_control_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_23_18_1_control_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_23_18_1_control_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_23_19_source: &'static crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_23_19_argument: &'static crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_23_19_returned: &'static crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_23_19_caller: &'static crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_23_19_0_control_source: &'static crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_23_19_0_control_argument: &'static crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_23_19_0_control_returned: &'static crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_23_19_0_control_caller: &'static crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_23_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_23_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_23_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_23_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_23_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_23_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_23_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_23_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_23_2_source: usize,
    #[cfg(test)]
    mir_unit_23_2_argument: usize,
    #[cfg(test)]
    mir_unit_23_2_returned: usize,
    #[cfg(test)]
    mir_unit_23_2_caller: usize,
    #[cfg(test)]
    alias_unit_23_2_0_index_source: usize,
    #[cfg(test)]
    alias_unit_23_2_0_index_argument: usize,
    #[cfg(test)]
    alias_unit_23_2_0_index_returned: usize,
    #[cfg(test)]
    alias_unit_23_2_0_index_caller: usize,
    #[cfg(test)]
    literal_unit_23_0_source: &'static str,
    #[cfg(test)]
    literal_unit_23_0_argument: &'static str,
    #[cfg(test)]
    literal_unit_23_0_returned: &'static str,
    #[cfg(test)]
    literal_unit_23_0_caller: &'static str,
    #[cfg(test)]
    literal_unit_23_1_source: &'static str,
    #[cfg(test)]
    literal_unit_23_1_argument: &'static str,
    #[cfg(test)]
    literal_unit_23_1_returned: &'static str,
    #[cfg(test)]
    literal_unit_23_1_caller: &'static str,
    #[cfg(test)]
    mir_unit_24_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_24_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_24_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_24_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_24_3_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_24_3_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_24_3_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_24_3_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_24_4_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_24_4_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_24_4_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_24_4_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_24_5_source: isize,
    #[cfg(test)]
    mir_unit_24_5_argument: isize,
    #[cfg(test)]
    mir_unit_24_5_returned: isize,
    #[cfg(test)]
    mir_unit_24_5_caller: isize,
    #[cfg(test)]
    mir_unit_24_6_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_24_6_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_24_6_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_24_6_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_24_6_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_24_6_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_24_6_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_24_6_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_24_7_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_24_7_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_24_7_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_24_7_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_24_7_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_24_7_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_24_7_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_24_7_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_24_7_1_val_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_24_7_1_val_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_24_7_1_val_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_24_7_1_val_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_24_9_source: bool,
    #[cfg(test)]
    mir_unit_24_9_argument: bool,
    #[cfg(test)]
    mir_unit_24_9_returned: bool,
    #[cfg(test)]
    mir_unit_24_9_caller: bool,
    #[cfg(test)]
    mir_unit_24_10_source: usize,
    #[cfg(test)]
    mir_unit_24_10_argument: usize,
    #[cfg(test)]
    mir_unit_24_10_returned: usize,
    #[cfg(test)]
    mir_unit_24_10_caller: usize,
    #[cfg(test)]
    mir_unit_24_11_source: bool,
    #[cfg(test)]
    mir_unit_24_11_argument: bool,
    #[cfg(test)]
    mir_unit_24_11_returned: bool,
    #[cfg(test)]
    mir_unit_24_11_caller: bool,
    #[cfg(test)]
    mir_unit_24_12_source: usize,
    #[cfg(test)]
    mir_unit_24_12_argument: usize,
    #[cfg(test)]
    mir_unit_24_12_returned: usize,
    #[cfg(test)]
    mir_unit_24_12_caller: usize,
    #[cfg(test)]
    mir_unit_24_13_source: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_24_13_argument: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_24_13_returned: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_24_13_caller: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_24_14_source: bool,
    #[cfg(test)]
    mir_unit_24_14_argument: bool,
    #[cfg(test)]
    mir_unit_24_14_returned: bool,
    #[cfg(test)]
    mir_unit_24_14_caller: bool,
    #[cfg(test)]
    mir_unit_24_15_source: bool,
    #[cfg(test)]
    mir_unit_24_15_argument: bool,
    #[cfg(test)]
    mir_unit_24_15_returned: bool,
    #[cfg(test)]
    mir_unit_24_15_caller: bool,
    #[cfg(test)]
    mir_unit_24_16_source: usize,
    #[cfg(test)]
    mir_unit_24_16_argument: usize,
    #[cfg(test)]
    mir_unit_24_16_returned: usize,
    #[cfg(test)]
    mir_unit_24_16_caller: usize,
    #[cfg(test)]
    mir_unit_24_17_source: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_24_17_argument: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_24_17_returned: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_24_17_caller: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_24_18_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_24_18_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_24_18_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_24_18_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_24_19_source: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_24_19_argument: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_24_19_returned: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_24_19_caller: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_24_20_source: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_24_20_argument: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_24_20_returned: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_24_20_caller: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_24_8_source: usize,
    #[cfg(test)]
    mir_unit_24_8_argument: usize,
    #[cfg(test)]
    mir_unit_24_8_returned: usize,
    #[cfg(test)]
    mir_unit_24_8_caller: usize,
    #[cfg(test)]
    alias_unit_24_8_0_height_source: usize,
    #[cfg(test)]
    alias_unit_24_8_0_height_argument: usize,
    #[cfg(test)]
    alias_unit_24_8_0_height_returned: usize,
    #[cfg(test)]
    alias_unit_24_8_0_height_caller: usize,
    #[cfg(test)]
    mir_unit_24_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_24_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_24_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_24_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_24_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_24_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_24_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_24_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_24_2_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_24_2_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_24_2_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_24_2_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_24_2_0_control_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_24_2_0_control_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_24_2_0_control_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_24_2_0_control_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    literal_unit_24_0_source: &'static str,
    #[cfg(test)]
    literal_unit_24_0_argument: &'static str,
    #[cfg(test)]
    literal_unit_24_0_returned: &'static str,
    #[cfg(test)]
    literal_unit_24_0_caller: &'static str,
    #[cfg(test)]
    mir_unit_25_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_25_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_25_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_25_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_25_2_source: usize,
    #[cfg(test)]
    mir_unit_25_2_argument: usize,
    #[cfg(test)]
    mir_unit_25_2_returned: usize,
    #[cfg(test)]
    mir_unit_25_2_caller: usize,
    #[cfg(test)]
    alias_unit_25_2_0_length_source: usize,
    #[cfg(test)]
    alias_unit_25_2_0_length_argument: usize,
    #[cfg(test)]
    alias_unit_25_2_0_length_returned: usize,
    #[cfg(test)]
    alias_unit_25_2_0_length_caller: usize,
    #[cfg(test)]
    mir_unit_25_3_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_25_3_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_25_3_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_25_3_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_25_5_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_25_5_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_25_5_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_25_5_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_25_6_source: bool,
    #[cfg(test)]
    mir_unit_25_6_argument: bool,
    #[cfg(test)]
    mir_unit_25_6_returned: bool,
    #[cfg(test)]
    mir_unit_25_6_caller: bool,
    #[cfg(test)]
    mir_unit_25_7_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_25_7_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_25_7_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_25_7_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_25_8_source: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    #[cfg(test)]
    mir_unit_25_8_argument: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    #[cfg(test)]
    mir_unit_25_8_returned: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    #[cfg(test)]
    mir_unit_25_8_caller: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    #[cfg(test)]
    mir_unit_25_9_source: crate::experimental_swift_reactor::control::SwiftRunResource,
    #[cfg(test)]
    mir_unit_25_9_argument: crate::experimental_swift_reactor::control::SwiftRunResource,
    #[cfg(test)]
    mir_unit_25_9_returned: crate::experimental_swift_reactor::control::SwiftRunResource,
    #[cfg(test)]
    mir_unit_25_9_caller: crate::experimental_swift_reactor::control::SwiftRunResource,
    #[cfg(test)]
    mir_unit_25_10_source: usize,
    #[cfg(test)]
    mir_unit_25_10_argument: usize,
    #[cfg(test)]
    mir_unit_25_10_returned: usize,
    #[cfg(test)]
    mir_unit_25_10_caller: usize,
    #[cfg(test)]
    mir_unit_25_11_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_25_11_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_25_11_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_25_11_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_25_12_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_25_12_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_25_12_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_25_12_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_25_4_source: usize,
    #[cfg(test)]
    mir_unit_25_4_argument: usize,
    #[cfg(test)]
    mir_unit_25_4_returned: usize,
    #[cfg(test)]
    mir_unit_25_4_caller: usize,
    #[cfg(test)]
    alias_unit_25_4_0_capacity_source: usize,
    #[cfg(test)]
    alias_unit_25_4_0_capacity_argument: usize,
    #[cfg(test)]
    alias_unit_25_4_0_capacity_returned: usize,
    #[cfg(test)]
    alias_unit_25_4_0_capacity_caller: usize,
    #[cfg(test)]
    mir_unit_25_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_25_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_25_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_25_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_25_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_25_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_25_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_25_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    literal_unit_25_0_source: usize,
    #[cfg(test)]
    literal_unit_25_0_argument: usize,
    #[cfg(test)]
    literal_unit_25_0_returned: usize,
    #[cfg(test)]
    literal_unit_25_0_caller: usize,
    #[cfg(test)]
    literal_unit_25_1_source: &'static str,
    #[cfg(test)]
    literal_unit_25_1_argument: &'static str,
    #[cfg(test)]
    literal_unit_25_1_returned: &'static str,
    #[cfg(test)]
    literal_unit_25_1_caller: &'static str,
    #[cfg(test)]
    mir_unit_26_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_26_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_26_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_26_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_26_7_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_26_7_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_26_7_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_26_7_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_26_7_0_control_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_26_7_0_control_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_26_7_0_control_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_26_7_0_control_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_26_8_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_26_8_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_26_8_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_26_8_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_26_9_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_26_9_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_26_9_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_26_9_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_26_10_source: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_26_10_argument: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_26_10_returned: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_26_10_caller: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_26_11_source: isize,
    #[cfg(test)]
    mir_unit_26_11_argument: isize,
    #[cfg(test)]
    mir_unit_26_11_returned: isize,
    #[cfg(test)]
    mir_unit_26_11_caller: isize,
    #[cfg(test)]
    mir_unit_26_13_source: (),
    #[cfg(test)]
    mir_unit_26_13_argument: (),
    #[cfg(test)]
    mir_unit_26_13_returned: (),
    #[cfg(test)]
    mir_unit_26_13_caller: (),
    #[cfg(test)]
    mir_unit_26_14_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_26_14_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_26_14_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_26_14_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_26_12_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_26_12_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_26_12_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_26_12_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_26_12_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_26_12_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_26_12_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_26_12_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_26_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_26_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_26_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_26_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_26_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_26_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_26_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_26_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_26_2_source: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_26_2_argument: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_26_2_returned: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_26_2_caller: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    alias_unit_26_2_0_kind_source: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    alias_unit_26_2_0_kind_argument: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    alias_unit_26_2_0_kind_returned: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    alias_unit_26_2_0_kind_caller: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_26_3_source: usize,
    #[cfg(test)]
    mir_unit_26_3_argument: usize,
    #[cfg(test)]
    mir_unit_26_3_returned: usize,
    #[cfg(test)]
    mir_unit_26_3_caller: usize,
    #[cfg(test)]
    alias_unit_26_3_0_start_source: usize,
    #[cfg(test)]
    alias_unit_26_3_0_start_argument: usize,
    #[cfg(test)]
    alias_unit_26_3_0_start_returned: usize,
    #[cfg(test)]
    alias_unit_26_3_0_start_caller: usize,
    #[cfg(test)]
    mir_unit_26_4_source: usize,
    #[cfg(test)]
    mir_unit_26_4_argument: usize,
    #[cfg(test)]
    mir_unit_26_4_returned: usize,
    #[cfg(test)]
    mir_unit_26_4_caller: usize,
    #[cfg(test)]
    alias_unit_26_4_0_end_source: usize,
    #[cfg(test)]
    alias_unit_26_4_0_end_argument: usize,
    #[cfg(test)]
    alias_unit_26_4_0_end_returned: usize,
    #[cfg(test)]
    alias_unit_26_4_0_end_caller: usize,
    #[cfg(test)]
    mir_unit_26_5_source: usize,
    #[cfg(test)]
    mir_unit_26_5_argument: usize,
    #[cfg(test)]
    mir_unit_26_5_returned: usize,
    #[cfg(test)]
    mir_unit_26_5_caller: usize,
    #[cfg(test)]
    alias_unit_26_5_0_height_source: usize,
    #[cfg(test)]
    alias_unit_26_5_0_height_argument: usize,
    #[cfg(test)]
    alias_unit_26_5_0_height_returned: usize,
    #[cfg(test)]
    alias_unit_26_5_0_height_caller: usize,
    #[cfg(test)]
    mir_unit_26_6_source: bool,
    #[cfg(test)]
    mir_unit_26_6_argument: bool,
    #[cfg(test)]
    mir_unit_26_6_returned: bool,
    #[cfg(test)]
    mir_unit_26_6_caller: bool,
    #[cfg(test)]
    alias_unit_26_6_0_result_source: bool,
    #[cfg(test)]
    alias_unit_26_6_0_result_argument: bool,
    #[cfg(test)]
    alias_unit_26_6_0_result_returned: bool,
    #[cfg(test)]
    alias_unit_26_6_0_result_caller: bool,
    #[cfg(test)]
    mir_unit_27_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_27_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_27_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_27_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_27_0_0_result_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_27_0_0_result_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_27_0_0_result_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_27_0_0_result_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_27_4_source: std::option::Option<crate::experimental_wasi::WasiUsage>,
    #[cfg(test)]
    mir_unit_27_4_argument: std::option::Option<crate::experimental_wasi::WasiUsage>,
    #[cfg(test)]
    mir_unit_27_4_returned: std::option::Option<crate::experimental_wasi::WasiUsage>,
    #[cfg(test)]
    mir_unit_27_4_caller: std::option::Option<crate::experimental_wasi::WasiUsage>,
    #[cfg(test)]
    mir_unit_27_5_source: crate::experimental_wasi::WasiUsage,
    #[cfg(test)]
    mir_unit_27_5_argument: crate::experimental_wasi::WasiUsage,
    #[cfg(test)]
    mir_unit_27_5_returned: crate::experimental_wasi::WasiUsage,
    #[cfg(test)]
    mir_unit_27_5_caller: crate::experimental_wasi::WasiUsage,
    #[cfg(test)]
    mir_unit_27_6_source: &'static crate::experimental_wasi::accounted::AccountedWasi,
    #[cfg(test)]
    mir_unit_27_6_argument: &'static crate::experimental_wasi::accounted::AccountedWasi,
    #[cfg(test)]
    mir_unit_27_6_returned: &'static crate::experimental_wasi::accounted::AccountedWasi,
    #[cfg(test)]
    mir_unit_27_6_caller: &'static crate::experimental_wasi::accounted::AccountedWasi,
    #[cfg(test)]
    mir_unit_27_7_source: bool,
    #[cfg(test)]
    mir_unit_27_7_argument: bool,
    #[cfg(test)]
    mir_unit_27_7_returned: bool,
    #[cfg(test)]
    mir_unit_27_7_caller: bool,
    #[cfg(test)]
    mir_unit_27_8_source: &'static std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_27_8_argument: &'static std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_27_8_returned: &'static std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_27_8_caller: &'static std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_27_9_source: &'static mut crate::experimental_swift_reactor::control::RuntimeControl,
    #[cfg(test)]
    mir_unit_27_9_argument: &'static mut crate::experimental_swift_reactor::control::RuntimeControl,
    #[cfg(test)]
    mir_unit_27_9_returned: &'static mut crate::experimental_swift_reactor::control::RuntimeControl,
    #[cfg(test)]
    mir_unit_27_9_caller: &'static mut crate::experimental_swift_reactor::control::RuntimeControl,
    #[cfg(test)]
    mir_unit_27_10_source: &'static mut crate::experimental_wasi::accounted::AccountedWasi,
    #[cfg(test)]
    mir_unit_27_10_argument: &'static mut crate::experimental_wasi::accounted::AccountedWasi,
    #[cfg(test)]
    mir_unit_27_10_returned: &'static mut crate::experimental_wasi::accounted::AccountedWasi,
    #[cfg(test)]
    mir_unit_27_10_caller: &'static mut crate::experimental_wasi::accounted::AccountedWasi,
    #[cfg(test)]
    mir_unit_27_11_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameCleanupState,
    #[cfg(test)]
    mir_unit_27_11_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameCleanupState,
    #[cfg(test)]
    mir_unit_27_11_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameCleanupState,
    #[cfg(test)]
    mir_unit_27_11_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameCleanupState,
    #[cfg(test)]
    mir_unit_27_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_27_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_27_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_27_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_27_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_27_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_27_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_27_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_27_2_source: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_27_2_argument: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_27_2_returned: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_27_2_caller: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    alias_unit_27_2_0_resource_source: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    alias_unit_27_2_0_resource_argument: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    alias_unit_27_2_0_resource_returned: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    alias_unit_27_2_0_resource_caller: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_27_3_source: usize,
    #[cfg(test)]
    mir_unit_27_3_argument: usize,
    #[cfg(test)]
    mir_unit_27_3_returned: usize,
    #[cfg(test)]
    mir_unit_27_3_caller: usize,
    #[cfg(test)]
    alias_unit_27_3_0_amount_source: usize,
    #[cfg(test)]
    alias_unit_27_3_0_amount_argument: usize,
    #[cfg(test)]
    alias_unit_27_3_0_amount_returned: usize,
    #[cfg(test)]
    alias_unit_27_3_0_amount_caller: usize,
    #[cfg(test)]
    literal_unit_27_0_source: bool,
    #[cfg(test)]
    literal_unit_27_0_argument: bool,
    #[cfg(test)]
    literal_unit_27_0_returned: bool,
    #[cfg(test)]
    literal_unit_27_0_caller: bool,
    #[cfg(test)]
    mir_unit_28_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_28_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_28_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_28_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_28_3_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_28_3_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_28_3_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_28_3_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_28_4_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_28_4_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_28_4_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_28_4_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_28_5_source: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_28_5_argument: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_28_5_returned: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_28_5_caller: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_28_6_source: usize,
    #[cfg(test)]
    mir_unit_28_6_argument: usize,
    #[cfg(test)]
    mir_unit_28_6_returned: usize,
    #[cfg(test)]
    mir_unit_28_6_caller: usize,
    #[cfg(test)]
    mir_unit_28_7_source: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_28_7_argument: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_28_7_returned: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_28_7_caller: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_28_8_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_28_8_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_28_8_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_28_8_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_28_9_source: isize,
    #[cfg(test)]
    mir_unit_28_9_argument: isize,
    #[cfg(test)]
    mir_unit_28_9_returned: isize,
    #[cfg(test)]
    mir_unit_28_9_caller: isize,
    #[cfg(test)]
    mir_unit_28_10_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_28_10_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_28_10_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_28_10_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_28_10_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_28_10_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_28_10_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_28_10_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_28_11_source: usize,
    #[cfg(test)]
    mir_unit_28_11_argument: usize,
    #[cfg(test)]
    mir_unit_28_11_returned: usize,
    #[cfg(test)]
    mir_unit_28_11_caller: usize,
    #[cfg(test)]
    alias_unit_28_11_0_removed_source: usize,
    #[cfg(test)]
    alias_unit_28_11_0_removed_argument: usize,
    #[cfg(test)]
    alias_unit_28_11_0_removed_returned: usize,
    #[cfg(test)]
    alias_unit_28_11_0_removed_caller: usize,
    #[cfg(test)]
    alias_unit_28_11_1_val_source: usize,
    #[cfg(test)]
    alias_unit_28_11_1_val_argument: usize,
    #[cfg(test)]
    alias_unit_28_11_1_val_returned: usize,
    #[cfg(test)]
    alias_unit_28_11_1_val_caller: usize,
    #[cfg(test)]
    mir_unit_28_12_source: (),
    #[cfg(test)]
    mir_unit_28_12_argument: (),
    #[cfg(test)]
    mir_unit_28_12_returned: (),
    #[cfg(test)]
    mir_unit_28_12_caller: (),
    #[cfg(test)]
    mir_unit_28_13_source: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_28_13_argument: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_28_13_returned: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_28_13_caller: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_28_14_source: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_28_14_argument: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_28_14_returned: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_28_14_caller: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_28_15_source: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_28_15_argument: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_28_15_returned: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_28_15_caller: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_28_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_28_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_28_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_28_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_28_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_28_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_28_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_28_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_28_2_source: usize,
    #[cfg(test)]
    mir_unit_28_2_argument: usize,
    #[cfg(test)]
    mir_unit_28_2_returned: usize,
    #[cfg(test)]
    mir_unit_28_2_caller: usize,
    #[cfg(test)]
    alias_unit_28_2_0_height_source: usize,
    #[cfg(test)]
    alias_unit_28_2_0_height_argument: usize,
    #[cfg(test)]
    alias_unit_28_2_0_height_returned: usize,
    #[cfg(test)]
    alias_unit_28_2_0_height_caller: usize,
    #[cfg(test)]
    mir_unit_29_0_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_29_0_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_29_0_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_29_0_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_29_2_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_29_2_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_29_2_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_29_2_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_29_1_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_29_1_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_29_1_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_29_1_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    literal_unit_29_0_source: &'static str,
    #[cfg(test)]
    literal_unit_29_0_argument: &'static str,
    #[cfg(test)]
    literal_unit_29_0_returned: &'static str,
    #[cfg(test)]
    literal_unit_29_0_caller: &'static str,
    #[cfg(test)]
    mir_unit_30_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_30_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_30_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_30_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_30_3_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_30_3_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_30_3_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_30_3_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_30_4_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_30_4_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_30_4_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_30_4_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_30_5_source: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_30_5_argument: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_30_5_returned: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_30_5_caller: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_30_6_source: usize,
    #[cfg(test)]
    mir_unit_30_6_argument: usize,
    #[cfg(test)]
    mir_unit_30_6_returned: usize,
    #[cfg(test)]
    mir_unit_30_6_caller: usize,
    #[cfg(test)]
    mir_unit_30_7_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_30_7_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_30_7_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_30_7_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_30_8_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_30_8_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_30_8_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_30_8_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_30_9_source: isize,
    #[cfg(test)]
    mir_unit_30_9_argument: isize,
    #[cfg(test)]
    mir_unit_30_9_returned: isize,
    #[cfg(test)]
    mir_unit_30_9_caller: isize,
    #[cfg(test)]
    mir_unit_30_10_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_30_10_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_30_10_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_30_10_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_30_10_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_30_10_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_30_10_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_30_10_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_30_11_source: usize,
    #[cfg(test)]
    mir_unit_30_11_argument: usize,
    #[cfg(test)]
    mir_unit_30_11_returned: usize,
    #[cfg(test)]
    mir_unit_30_11_caller: usize,
    #[cfg(test)]
    alias_unit_30_11_0_removed_source: usize,
    #[cfg(test)]
    alias_unit_30_11_0_removed_argument: usize,
    #[cfg(test)]
    alias_unit_30_11_0_removed_returned: usize,
    #[cfg(test)]
    alias_unit_30_11_0_removed_caller: usize,
    #[cfg(test)]
    alias_unit_30_11_1_val_source: usize,
    #[cfg(test)]
    alias_unit_30_11_1_val_argument: usize,
    #[cfg(test)]
    alias_unit_30_11_1_val_returned: usize,
    #[cfg(test)]
    alias_unit_30_11_1_val_caller: usize,
    #[cfg(test)]
    mir_unit_30_12_source: (),
    #[cfg(test)]
    mir_unit_30_12_argument: (),
    #[cfg(test)]
    mir_unit_30_12_returned: (),
    #[cfg(test)]
    mir_unit_30_12_caller: (),
    #[cfg(test)]
    mir_unit_30_13_source: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_30_13_argument: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_30_13_returned: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_30_13_caller: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_30_14_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_30_14_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_30_14_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_30_14_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_30_15_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_30_15_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_30_15_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_30_15_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_30_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_30_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_30_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_30_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_30_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_30_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_30_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_30_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_30_2_source: usize,
    #[cfg(test)]
    mir_unit_30_2_argument: usize,
    #[cfg(test)]
    mir_unit_30_2_returned: usize,
    #[cfg(test)]
    mir_unit_30_2_caller: usize,
    #[cfg(test)]
    alias_unit_30_2_0_height_source: usize,
    #[cfg(test)]
    alias_unit_30_2_0_height_argument: usize,
    #[cfg(test)]
    alias_unit_30_2_0_height_returned: usize,
    #[cfg(test)]
    alias_unit_30_2_0_height_caller: usize,
    #[cfg(test)]
    mir_unit_31_0_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_31_0_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_31_0_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_31_0_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_31_2_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_31_2_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_31_2_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_31_2_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_31_1_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_31_1_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_31_1_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_31_1_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    literal_unit_31_0_source: &'static str,
    #[cfg(test)]
    literal_unit_31_0_argument: &'static str,
    #[cfg(test)]
    literal_unit_31_0_returned: &'static str,
    #[cfg(test)]
    literal_unit_31_0_caller: &'static str,
    #[cfg(test)]
    mir_unit_32_0_source: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_0_argument: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_0_returned: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_0_caller: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_2_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_32_2_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_32_2_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_32_2_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_32_3_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_3_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_3_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_3_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_4_source: isize,
    #[cfg(test)]
    mir_unit_32_4_argument: isize,
    #[cfg(test)]
    mir_unit_32_4_returned: isize,
    #[cfg(test)]
    mir_unit_32_4_caller: isize,
    #[cfg(test)]
    mir_unit_32_5_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_5_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_5_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_5_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_32_5_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_32_5_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_32_5_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_32_5_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_6_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_32_6_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_32_6_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_32_6_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_32_6_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_32_6_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_32_6_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_32_6_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_32_6_1_val_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_32_6_1_val_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_32_6_1_val_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_32_6_1_val_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_32_7_source: bool,
    #[cfg(test)]
    mir_unit_32_7_argument: bool,
    #[cfg(test)]
    mir_unit_32_7_returned: bool,
    #[cfg(test)]
    mir_unit_32_7_caller: bool,
    #[cfg(test)]
    mir_unit_32_8_source: usize,
    #[cfg(test)]
    mir_unit_32_8_argument: usize,
    #[cfg(test)]
    mir_unit_32_8_returned: usize,
    #[cfg(test)]
    mir_unit_32_8_caller: usize,
    #[cfg(test)]
    mir_unit_32_9_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_32_9_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_32_9_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_32_9_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_32_10_source: usize,
    #[cfg(test)]
    mir_unit_32_10_argument: usize,
    #[cfg(test)]
    mir_unit_32_10_returned: usize,
    #[cfg(test)]
    mir_unit_32_10_caller: usize,
    #[cfg(test)]
    mir_unit_32_11_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_32_11_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_32_11_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_32_11_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_32_13_source: std::option::Option<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_32_13_argument: std::option::Option<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_32_13_returned: std::option::Option<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_32_13_caller: std::option::Option<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_32_14_source: &'static str,
    #[cfg(test)]
    mir_unit_32_14_argument: &'static str,
    #[cfg(test)]
    mir_unit_32_14_returned: &'static str,
    #[cfg(test)]
    mir_unit_32_14_caller: &'static str,
    #[cfg(test)]
    mir_unit_32_15_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_32_15_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_32_15_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_32_15_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_32_16_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_16_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_16_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_16_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_17_source: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_32_17_argument: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_32_17_returned: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_32_17_caller: crate::experimental_swift_reactor::control::Live,
    #[cfg(test)]
    mir_unit_32_18_source: isize,
    #[cfg(test)]
    mir_unit_32_18_argument: isize,
    #[cfg(test)]
    mir_unit_32_18_returned: isize,
    #[cfg(test)]
    mir_unit_32_18_caller: isize,
    #[cfg(test)]
    mir_unit_32_20_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_32_20_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_32_20_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_32_20_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_32_21_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_32_21_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_32_21_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_32_21_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_32_12_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_32_12_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_32_12_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_32_12_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_32_12_0_control_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_32_12_0_control_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_32_12_0_control_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_32_12_0_control_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_32_19_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_19_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_19_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_19_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_32_19_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_32_19_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_32_19_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_32_19_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_32_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_32_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_32_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_32_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_32_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_32_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_32_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_32_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    literal_unit_32_0_source: &'static str,
    #[cfg(test)]
    literal_unit_32_0_argument: &'static str,
    #[cfg(test)]
    literal_unit_32_0_returned: &'static str,
    #[cfg(test)]
    literal_unit_32_0_caller: &'static str,
    #[cfg(test)]
    literal_unit_32_1_source: &'static str,
    #[cfg(test)]
    literal_unit_32_1_argument: &'static str,
    #[cfg(test)]
    literal_unit_32_1_returned: &'static str,
    #[cfg(test)]
    literal_unit_32_1_caller: &'static str,
    #[cfg(test)]
    literal_unit_32_2_source: usize,
    #[cfg(test)]
    literal_unit_32_2_argument: usize,
    #[cfg(test)]
    literal_unit_32_2_returned: usize,
    #[cfg(test)]
    literal_unit_32_2_caller: usize,
    #[cfg(test)]
    mir_unit_33_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_33_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_33_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_33_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_33_3_source: std::option::Option<&'static mut crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_33_3_argument: std::option::Option<&'static mut crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_33_3_returned: std::option::Option<&'static mut crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_33_3_caller: std::option::Option<&'static mut crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_33_4_source: &'static mut [crate::experimental_swift_reactor::execution::SwiftFrame],
    #[cfg(test)]
    mir_unit_33_4_argument: &'static mut [crate::experimental_swift_reactor::execution::SwiftFrame],
    #[cfg(test)]
    mir_unit_33_4_returned: &'static mut [crate::experimental_swift_reactor::execution::SwiftFrame],
    #[cfg(test)]
    mir_unit_33_4_caller: &'static mut [crate::experimental_swift_reactor::execution::SwiftFrame],
    #[cfg(test)]
    mir_unit_33_5_source: isize,
    #[cfg(test)]
    mir_unit_33_5_argument: isize,
    #[cfg(test)]
    mir_unit_33_5_returned: isize,
    #[cfg(test)]
    mir_unit_33_5_caller: isize,
    #[cfg(test)]
    mir_unit_33_6_source: &'static mut crate::experimental_swift_reactor::execution::SwiftFrame,
    #[cfg(test)]
    mir_unit_33_6_argument: &'static mut crate::experimental_swift_reactor::execution::SwiftFrame,
    #[cfg(test)]
    mir_unit_33_6_returned: &'static mut crate::experimental_swift_reactor::execution::SwiftFrame,
    #[cfg(test)]
    mir_unit_33_6_caller: &'static mut crate::experimental_swift_reactor::execution::SwiftFrame,
    #[cfg(test)]
    alias_unit_33_6_0_frame_source: &'static mut crate::experimental_swift_reactor::execution::SwiftFrame,
    #[cfg(test)]
    alias_unit_33_6_0_frame_argument: &'static mut crate::experimental_swift_reactor::execution::SwiftFrame,
    #[cfg(test)]
    alias_unit_33_6_0_frame_returned: &'static mut crate::experimental_swift_reactor::execution::SwiftFrame,
    #[cfg(test)]
    alias_unit_33_6_0_frame_caller: &'static mut crate::experimental_swift_reactor::execution::SwiftFrame,
    #[cfg(test)]
    mir_unit_33_7_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_33_7_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_33_7_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_33_7_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_33_8_source: &'static mut std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_33_8_argument: &'static mut std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_33_8_returned: &'static mut std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_33_8_caller: &'static mut std::vec::Vec<crate::experimental_swift_reactor::execution::SwiftFrame>,
    #[cfg(test)]
    mir_unit_33_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_33_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_33_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_33_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_33_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_33_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_33_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_33_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_33_2_source: usize,
    #[cfg(test)]
    mir_unit_33_2_argument: usize,
    #[cfg(test)]
    mir_unit_33_2_returned: usize,
    #[cfg(test)]
    mir_unit_33_2_caller: usize,
    #[cfg(test)]
    alias_unit_33_2_0_pc_source: usize,
    #[cfg(test)]
    alias_unit_33_2_0_pc_argument: usize,
    #[cfg(test)]
    alias_unit_33_2_0_pc_returned: usize,
    #[cfg(test)]
    alias_unit_33_2_0_pc_caller: usize,
    #[cfg(test)]
    literal_unit_33_0_source: &'static str,
    #[cfg(test)]
    literal_unit_33_0_argument: &'static str,
    #[cfg(test)]
    literal_unit_33_0_returned: &'static str,
    #[cfg(test)]
    literal_unit_33_0_caller: &'static str,
    #[cfg(test)]
    mir_unit_34_0_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_0_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_0_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_0_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_3_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_34_3_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_34_3_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_34_3_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_34_4_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_4_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_4_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_4_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_5_source: isize,
    #[cfg(test)]
    mir_unit_34_5_argument: isize,
    #[cfg(test)]
    mir_unit_34_5_returned: isize,
    #[cfg(test)]
    mir_unit_34_5_caller: isize,
    #[cfg(test)]
    mir_unit_34_6_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_6_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_6_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_6_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_34_6_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_34_6_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_34_6_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_34_6_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_7_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_34_7_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_34_7_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_34_7_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_34_7_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_34_7_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_34_7_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_34_7_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_34_7_1_val_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_34_7_1_val_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_34_7_1_val_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_34_7_1_val_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_34_8_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_34_8_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_34_8_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_34_8_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_34_9_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_9_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_9_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_9_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_10_source: isize,
    #[cfg(test)]
    mir_unit_34_10_argument: isize,
    #[cfg(test)]
    mir_unit_34_10_returned: isize,
    #[cfg(test)]
    mir_unit_34_10_caller: isize,
    #[cfg(test)]
    mir_unit_34_13_source: std::option::Option<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_13_argument: std::option::Option<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_13_returned: std::option::Option<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_13_caller: std::option::Option<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_14_source: std::option::Option<&'static crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_14_argument: std::option::Option<&'static crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_14_returned: std::option::Option<&'static crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_14_caller: std::option::Option<&'static crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_15_source: &'static [crate::experimental::execution::Control],
    #[cfg(test)]
    mir_unit_34_15_argument: &'static [crate::experimental::execution::Control],
    #[cfg(test)]
    mir_unit_34_15_returned: &'static [crate::experimental::execution::Control],
    #[cfg(test)]
    mir_unit_34_15_caller: &'static [crate::experimental::execution::Control],
    #[cfg(test)]
    mir_unit_34_16_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_16_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_16_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_16_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_17_source: isize,
    #[cfg(test)]
    mir_unit_34_17_argument: isize,
    #[cfg(test)]
    mir_unit_34_17_returned: isize,
    #[cfg(test)]
    mir_unit_34_17_caller: isize,
    #[cfg(test)]
    mir_unit_34_20_source: bool,
    #[cfg(test)]
    mir_unit_34_20_argument: bool,
    #[cfg(test)]
    mir_unit_34_20_returned: bool,
    #[cfg(test)]
    mir_unit_34_20_caller: bool,
    #[cfg(test)]
    mir_unit_34_21_source: usize,
    #[cfg(test)]
    mir_unit_34_21_argument: usize,
    #[cfg(test)]
    mir_unit_34_21_returned: usize,
    #[cfg(test)]
    mir_unit_34_21_caller: usize,
    #[cfg(test)]
    mir_unit_34_22_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_22_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_22_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_22_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_23_source: usize,
    #[cfg(test)]
    mir_unit_34_23_argument: usize,
    #[cfg(test)]
    mir_unit_34_23_returned: usize,
    #[cfg(test)]
    mir_unit_34_23_caller: usize,
    #[cfg(test)]
    mir_unit_34_24_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_34_24_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_34_24_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_34_24_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_34_25_source: bool,
    #[cfg(test)]
    mir_unit_34_25_argument: bool,
    #[cfg(test)]
    mir_unit_34_25_returned: bool,
    #[cfg(test)]
    mir_unit_34_25_caller: bool,
    #[cfg(test)]
    mir_unit_34_26_source: bool,
    #[cfg(test)]
    mir_unit_34_26_argument: bool,
    #[cfg(test)]
    mir_unit_34_26_returned: bool,
    #[cfg(test)]
    mir_unit_34_26_caller: bool,
    #[cfg(test)]
    mir_unit_34_27_source: usize,
    #[cfg(test)]
    mir_unit_34_27_argument: usize,
    #[cfg(test)]
    mir_unit_34_27_returned: usize,
    #[cfg(test)]
    mir_unit_34_27_caller: usize,
    #[cfg(test)]
    mir_unit_34_28_source: bool,
    #[cfg(test)]
    mir_unit_34_28_argument: bool,
    #[cfg(test)]
    mir_unit_34_28_returned: bool,
    #[cfg(test)]
    mir_unit_34_28_caller: bool,
    #[cfg(test)]
    mir_unit_34_29_source: usize,
    #[cfg(test)]
    mir_unit_34_29_argument: usize,
    #[cfg(test)]
    mir_unit_34_29_returned: usize,
    #[cfg(test)]
    mir_unit_34_29_caller: usize,
    #[cfg(test)]
    mir_unit_34_30_source: bool,
    #[cfg(test)]
    mir_unit_34_30_argument: bool,
    #[cfg(test)]
    mir_unit_34_30_returned: bool,
    #[cfg(test)]
    mir_unit_34_30_caller: bool,
    #[cfg(test)]
    mir_unit_34_31_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_34_31_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_34_31_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_34_31_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_34_32_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_32_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_32_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_32_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_33_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_33_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_33_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_33_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_34_11_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_11_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_11_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_11_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_34_11_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_34_11_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_34_11_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_34_11_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_34_12_source: usize,
    #[cfg(test)]
    mir_unit_34_12_argument: usize,
    #[cfg(test)]
    mir_unit_34_12_returned: usize,
    #[cfg(test)]
    mir_unit_34_12_caller: usize,
    #[cfg(test)]
    alias_unit_34_12_0_bound_source: usize,
    #[cfg(test)]
    alias_unit_34_12_0_bound_argument: usize,
    #[cfg(test)]
    alias_unit_34_12_0_bound_returned: usize,
    #[cfg(test)]
    alias_unit_34_12_0_bound_caller: usize,
    #[cfg(test)]
    alias_unit_34_12_1_val_source: usize,
    #[cfg(test)]
    alias_unit_34_12_1_val_argument: usize,
    #[cfg(test)]
    alias_unit_34_12_1_val_returned: usize,
    #[cfg(test)]
    alias_unit_34_12_1_val_caller: usize,
    #[cfg(test)]
    mir_unit_34_18_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_34_18_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_34_18_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_34_18_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_34_18_0_control_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_34_18_0_control_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_34_18_0_control_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_34_18_0_control_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_34_18_1_control_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_34_18_1_control_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_34_18_1_control_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_34_18_1_control_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_34_19_source: &'static crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_34_19_argument: &'static crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_34_19_returned: &'static crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_34_19_caller: &'static crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_34_19_0_control_source: &'static crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_34_19_0_control_argument: &'static crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_34_19_0_control_returned: &'static crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_34_19_0_control_caller: &'static crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_34_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_34_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_34_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_34_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_34_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_34_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_34_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_34_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_34_2_source: usize,
    #[cfg(test)]
    mir_unit_34_2_argument: usize,
    #[cfg(test)]
    mir_unit_34_2_returned: usize,
    #[cfg(test)]
    mir_unit_34_2_caller: usize,
    #[cfg(test)]
    alias_unit_34_2_0_end_source: usize,
    #[cfg(test)]
    alias_unit_34_2_0_end_argument: usize,
    #[cfg(test)]
    alias_unit_34_2_0_end_returned: usize,
    #[cfg(test)]
    alias_unit_34_2_0_end_caller: usize,
    #[cfg(test)]
    literal_unit_34_0_source: &'static str,
    #[cfg(test)]
    literal_unit_34_0_argument: &'static str,
    #[cfg(test)]
    literal_unit_34_0_returned: &'static str,
    #[cfg(test)]
    literal_unit_34_0_caller: &'static str,
    #[cfg(test)]
    literal_unit_34_1_source: &'static str,
    #[cfg(test)]
    literal_unit_34_1_argument: &'static str,
    #[cfg(test)]
    literal_unit_34_1_returned: &'static str,
    #[cfg(test)]
    literal_unit_34_1_caller: &'static str,
    #[cfg(test)]
    mir_unit_35_0_source: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_35_0_argument: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_35_0_returned: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_35_0_caller: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_35_0_0_result_source: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_35_0_0_result_argument: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_35_0_0_result_returned: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_35_0_0_result_caller: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_35_4_source: bool,
    #[cfg(test)]
    mir_unit_35_4_argument: bool,
    #[cfg(test)]
    mir_unit_35_4_returned: bool,
    #[cfg(test)]
    mir_unit_35_4_caller: bool,
    #[cfg(test)]
    mir_unit_35_5_source: &'static std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_35_5_argument: &'static std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_35_5_returned: &'static std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_35_5_caller: &'static std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_35_6_source: (),
    #[cfg(test)]
    mir_unit_35_6_argument: (),
    #[cfg(test)]
    mir_unit_35_6_returned: (),
    #[cfg(test)]
    mir_unit_35_6_caller: (),
    #[cfg(test)]
    mir_unit_35_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_35_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_35_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_35_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_35_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_35_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_35_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_35_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_35_2_source: crate::experimental::cache::Operation,
    #[cfg(test)]
    mir_unit_35_2_argument: crate::experimental::cache::Operation,
    #[cfg(test)]
    mir_unit_35_2_returned: crate::experimental::cache::Operation,
    #[cfg(test)]
    mir_unit_35_2_caller: crate::experimental::cache::Operation,
    #[cfg(test)]
    alias_unit_35_2_0_operation_source: crate::experimental::cache::Operation,
    #[cfg(test)]
    alias_unit_35_2_0_operation_argument: crate::experimental::cache::Operation,
    #[cfg(test)]
    alias_unit_35_2_0_operation_returned: crate::experimental::cache::Operation,
    #[cfg(test)]
    alias_unit_35_2_0_operation_caller: crate::experimental::cache::Operation,
    #[cfg(test)]
    mir_unit_35_3_source: Option<u32>,
    #[cfg(test)]
    mir_unit_35_3_argument: Option<u32>,
    #[cfg(test)]
    mir_unit_35_3_returned: Option<u32>,
    #[cfg(test)]
    mir_unit_35_3_caller: Option<u32>,
    #[cfg(test)]
    alias_unit_35_3_0_selected_target_source: Option<u32>,
    #[cfg(test)]
    alias_unit_35_3_0_selected_target_argument: Option<u32>,
    #[cfg(test)]
    alias_unit_35_3_0_selected_target_returned: Option<u32>,
    #[cfg(test)]
    alias_unit_35_3_0_selected_target_caller: Option<u32>,
    #[cfg(test)]
    mir_unit_36_0_source: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_0_argument: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_0_returned: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_0_caller: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_4_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_4_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_4_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_4_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_5_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_5_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_5_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_5_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_6_source: isize,
    #[cfg(test)]
    mir_unit_36_6_argument: isize,
    #[cfg(test)]
    mir_unit_36_6_returned: isize,
    #[cfg(test)]
    mir_unit_36_6_caller: isize,
    #[cfg(test)]
    mir_unit_36_7_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_7_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_7_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_7_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_7_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_7_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_7_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_7_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_8_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_36_8_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_36_8_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_36_8_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_36_9_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_9_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_9_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_9_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_10_source: isize,
    #[cfg(test)]
    mir_unit_36_10_argument: isize,
    #[cfg(test)]
    mir_unit_36_10_returned: isize,
    #[cfg(test)]
    mir_unit_36_10_caller: isize,
    #[cfg(test)]
    mir_unit_36_11_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_11_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_11_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_11_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_11_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_11_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_11_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_11_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_12_source: usize,
    #[cfg(test)]
    mir_unit_36_12_argument: usize,
    #[cfg(test)]
    mir_unit_36_12_returned: usize,
    #[cfg(test)]
    mir_unit_36_12_caller: usize,
    #[cfg(test)]
    alias_unit_36_12_0_val_source: usize,
    #[cfg(test)]
    alias_unit_36_12_0_val_argument: usize,
    #[cfg(test)]
    alias_unit_36_12_0_val_returned: usize,
    #[cfg(test)]
    alias_unit_36_12_0_val_caller: usize,
    #[cfg(test)]
    mir_unit_36_13_source: bool,
    #[cfg(test)]
    mir_unit_36_13_argument: bool,
    #[cfg(test)]
    mir_unit_36_13_returned: bool,
    #[cfg(test)]
    mir_unit_36_13_caller: bool,
    #[cfg(test)]
    alias_unit_36_13_0_finished_source: bool,
    #[cfg(test)]
    alias_unit_36_13_0_finished_argument: bool,
    #[cfg(test)]
    alias_unit_36_13_0_finished_returned: bool,
    #[cfg(test)]
    alias_unit_36_13_0_finished_caller: bool,
    #[cfg(test)]
    mir_unit_36_14_source: isize,
    #[cfg(test)]
    mir_unit_36_14_argument: isize,
    #[cfg(test)]
    mir_unit_36_14_returned: isize,
    #[cfg(test)]
    mir_unit_36_14_caller: isize,
    #[cfg(test)]
    mir_unit_36_20_source: bool,
    #[cfg(test)]
    mir_unit_36_20_argument: bool,
    #[cfg(test)]
    mir_unit_36_20_returned: bool,
    #[cfg(test)]
    mir_unit_36_20_caller: bool,
    #[cfg(test)]
    mir_unit_36_21_source: &'static crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_36_21_argument: &'static crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_36_21_returned: &'static crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_36_21_caller: &'static crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_36_22_source: &'static crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_36_22_argument: &'static crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_36_22_returned: &'static crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_36_22_caller: &'static crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_36_23_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    #[cfg(test)]
    mir_unit_36_23_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    #[cfg(test)]
    mir_unit_36_23_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    #[cfg(test)]
    mir_unit_36_23_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    #[cfg(test)]
    mir_unit_36_24_source: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_24_argument: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_24_returned: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_24_caller: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_25_source: isize,
    #[cfg(test)]
    mir_unit_36_25_argument: isize,
    #[cfg(test)]
    mir_unit_36_25_returned: isize,
    #[cfg(test)]
    mir_unit_36_25_caller: isize,
    #[cfg(test)]
    mir_unit_36_28_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_28_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_28_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_28_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_29_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_29_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_29_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_29_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_30_source: isize,
    #[cfg(test)]
    mir_unit_36_30_argument: isize,
    #[cfg(test)]
    mir_unit_36_30_returned: isize,
    #[cfg(test)]
    mir_unit_36_30_caller: isize,
    #[cfg(test)]
    mir_unit_36_32_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_32_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_32_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_32_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_33_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_33_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_33_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_33_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_34_source: isize,
    #[cfg(test)]
    mir_unit_36_34_argument: isize,
    #[cfg(test)]
    mir_unit_36_34_returned: isize,
    #[cfg(test)]
    mir_unit_36_34_caller: isize,
    #[cfg(test)]
    mir_unit_36_36_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_36_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_36_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_36_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_37_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_37_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_37_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_37_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_38_source: isize,
    #[cfg(test)]
    mir_unit_36_38_argument: isize,
    #[cfg(test)]
    mir_unit_36_38_returned: isize,
    #[cfg(test)]
    mir_unit_36_38_caller: isize,
    #[cfg(test)]
    mir_unit_36_40_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_36_40_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_36_40_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_36_40_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental_swift_reactor::execution::frame_operations::FrameScalars>,
    #[cfg(test)]
    mir_unit_36_41_source: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_41_argument: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_41_returned: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_41_caller: std::result::Result<crate::experimental_swift_reactor::execution::frame_operations::FrameScalars, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_42_source: isize,
    #[cfg(test)]
    mir_unit_36_42_argument: isize,
    #[cfg(test)]
    mir_unit_36_42_returned: isize,
    #[cfg(test)]
    mir_unit_36_42_caller: isize,
    #[cfg(test)]
    mir_unit_36_45_source: bool,
    #[cfg(test)]
    mir_unit_36_45_argument: bool,
    #[cfg(test)]
    mir_unit_36_45_returned: bool,
    #[cfg(test)]
    mir_unit_36_45_caller: bool,
    #[cfg(test)]
    mir_unit_36_46_source: usize,
    #[cfg(test)]
    mir_unit_36_46_argument: usize,
    #[cfg(test)]
    mir_unit_36_46_returned: usize,
    #[cfg(test)]
    mir_unit_36_46_caller: usize,
    #[cfg(test)]
    mir_unit_36_47_source: usize,
    #[cfg(test)]
    mir_unit_36_47_argument: usize,
    #[cfg(test)]
    mir_unit_36_47_returned: usize,
    #[cfg(test)]
    mir_unit_36_47_caller: usize,
    #[cfg(test)]
    mir_unit_36_48_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_48_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_48_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_48_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_49_source: usize,
    #[cfg(test)]
    mir_unit_36_49_argument: usize,
    #[cfg(test)]
    mir_unit_36_49_returned: usize,
    #[cfg(test)]
    mir_unit_36_49_caller: usize,
    #[cfg(test)]
    mir_unit_36_50_source: (usize, bool),
    #[cfg(test)]
    mir_unit_36_50_argument: (usize, bool),
    #[cfg(test)]
    mir_unit_36_50_returned: (usize, bool),
    #[cfg(test)]
    mir_unit_36_50_caller: (usize, bool),
    #[cfg(test)]
    mir_unit_36_51_source: usize,
    #[cfg(test)]
    mir_unit_36_51_argument: usize,
    #[cfg(test)]
    mir_unit_36_51_returned: usize,
    #[cfg(test)]
    mir_unit_36_51_caller: usize,
    #[cfg(test)]
    mir_unit_36_52_source: &'static crate::experimental::policy::Policy<'static>,
    #[cfg(test)]
    mir_unit_36_52_argument: &'static crate::experimental::policy::Policy<'static>,
    #[cfg(test)]
    mir_unit_36_52_returned: &'static crate::experimental::policy::Policy<'static>,
    #[cfg(test)]
    mir_unit_36_52_caller: &'static crate::experimental::policy::Policy<'static>,
    #[cfg(test)]
    mir_unit_36_53_source: &'static crate::experimental::swift::ValidatedSwiftReactor,
    #[cfg(test)]
    mir_unit_36_53_argument: &'static crate::experimental::swift::ValidatedSwiftReactor,
    #[cfg(test)]
    mir_unit_36_53_returned: &'static crate::experimental::swift::ValidatedSwiftReactor,
    #[cfg(test)]
    mir_unit_36_53_caller: &'static crate::experimental::swift::ValidatedSwiftReactor,
    #[cfg(test)]
    mir_unit_36_54_source: &'static crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    #[cfg(test)]
    mir_unit_36_54_argument: &'static crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    #[cfg(test)]
    mir_unit_36_54_returned: &'static crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    #[cfg(test)]
    mir_unit_36_54_caller: &'static crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    #[cfg(test)]
    mir_unit_36_55_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_36_55_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_36_55_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_36_55_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_36_56_source: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    #[cfg(test)]
    mir_unit_36_56_argument: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    #[cfg(test)]
    mir_unit_36_56_returned: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    #[cfg(test)]
    mir_unit_36_56_caller: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    #[cfg(test)]
    mir_unit_36_57_source: crate::experimental_swift_reactor::control::SwiftRunResource,
    #[cfg(test)]
    mir_unit_36_57_argument: crate::experimental_swift_reactor::control::SwiftRunResource,
    #[cfg(test)]
    mir_unit_36_57_returned: crate::experimental_swift_reactor::control::SwiftRunResource,
    #[cfg(test)]
    mir_unit_36_57_caller: crate::experimental_swift_reactor::control::SwiftRunResource,
    #[cfg(test)]
    mir_unit_36_58_source: usize,
    #[cfg(test)]
    mir_unit_36_58_argument: usize,
    #[cfg(test)]
    mir_unit_36_58_returned: usize,
    #[cfg(test)]
    mir_unit_36_58_caller: usize,
    #[cfg(test)]
    mir_unit_36_59_source: usize,
    #[cfg(test)]
    mir_unit_36_59_argument: usize,
    #[cfg(test)]
    mir_unit_36_59_returned: usize,
    #[cfg(test)]
    mir_unit_36_59_caller: usize,
    #[cfg(test)]
    mir_unit_36_60_source: usize,
    #[cfg(test)]
    mir_unit_36_60_argument: usize,
    #[cfg(test)]
    mir_unit_36_60_returned: usize,
    #[cfg(test)]
    mir_unit_36_60_caller: usize,
    #[cfg(test)]
    mir_unit_36_61_source: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_61_argument: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_61_returned: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_61_caller: &'static std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_62_source: usize,
    #[cfg(test)]
    mir_unit_36_62_argument: usize,
    #[cfg(test)]
    mir_unit_36_62_returned: usize,
    #[cfg(test)]
    mir_unit_36_62_caller: usize,
    #[cfg(test)]
    mir_unit_36_63_source: (usize, bool),
    #[cfg(test)]
    mir_unit_36_63_argument: (usize, bool),
    #[cfg(test)]
    mir_unit_36_63_returned: (usize, bool),
    #[cfg(test)]
    mir_unit_36_63_caller: (usize, bool),
    #[cfg(test)]
    mir_unit_36_64_source: (usize, bool),
    #[cfg(test)]
    mir_unit_36_64_argument: (usize, bool),
    #[cfg(test)]
    mir_unit_36_64_returned: (usize, bool),
    #[cfg(test)]
    mir_unit_36_64_caller: (usize, bool),
    #[cfg(test)]
    mir_unit_36_65_source: usize,
    #[cfg(test)]
    mir_unit_36_65_argument: usize,
    #[cfg(test)]
    mir_unit_36_65_returned: usize,
    #[cfg(test)]
    mir_unit_36_65_caller: usize,
    #[cfg(test)]
    mir_unit_36_66_source: &'static crate::experimental::policy::Policy<'static>,
    #[cfg(test)]
    mir_unit_36_66_argument: &'static crate::experimental::policy::Policy<'static>,
    #[cfg(test)]
    mir_unit_36_66_returned: &'static crate::experimental::policy::Policy<'static>,
    #[cfg(test)]
    mir_unit_36_66_caller: &'static crate::experimental::policy::Policy<'static>,
    #[cfg(test)]
    mir_unit_36_67_source: &'static crate::experimental::swift::ValidatedSwiftReactor,
    #[cfg(test)]
    mir_unit_36_67_argument: &'static crate::experimental::swift::ValidatedSwiftReactor,
    #[cfg(test)]
    mir_unit_36_67_returned: &'static crate::experimental::swift::ValidatedSwiftReactor,
    #[cfg(test)]
    mir_unit_36_67_caller: &'static crate::experimental::swift::ValidatedSwiftReactor,
    #[cfg(test)]
    mir_unit_36_68_source: &'static crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    #[cfg(test)]
    mir_unit_36_68_argument: &'static crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    #[cfg(test)]
    mir_unit_36_68_returned: &'static crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    #[cfg(test)]
    mir_unit_36_68_caller: &'static crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    #[cfg(test)]
    mir_unit_36_69_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_69_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_69_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_69_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_70_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_70_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_70_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_70_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_71_source: usize,
    #[cfg(test)]
    mir_unit_36_71_argument: usize,
    #[cfg(test)]
    mir_unit_36_71_returned: usize,
    #[cfg(test)]
    mir_unit_36_71_caller: usize,
    #[cfg(test)]
    mir_unit_36_72_source: usize,
    #[cfg(test)]
    mir_unit_36_72_argument: usize,
    #[cfg(test)]
    mir_unit_36_72_returned: usize,
    #[cfg(test)]
    mir_unit_36_72_caller: usize,
    #[cfg(test)]
    mir_unit_36_73_source: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_36_73_argument: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_36_73_returned: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_36_73_caller: &'static std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_36_74_source: bool,
    #[cfg(test)]
    mir_unit_36_74_argument: bool,
    #[cfg(test)]
    mir_unit_36_74_returned: bool,
    #[cfg(test)]
    mir_unit_36_74_caller: bool,
    #[cfg(test)]
    mir_unit_36_75_source: &'static std::option::Option<Type>,
    #[cfg(test)]
    mir_unit_36_75_argument: &'static std::option::Option<Type>,
    #[cfg(test)]
    mir_unit_36_75_returned: &'static std::option::Option<Type>,
    #[cfg(test)]
    mir_unit_36_75_caller: &'static std::option::Option<Type>,
    #[cfg(test)]
    mir_unit_36_76_source: isize,
    #[cfg(test)]
    mir_unit_36_76_argument: isize,
    #[cfg(test)]
    mir_unit_36_76_returned: isize,
    #[cfg(test)]
    mir_unit_36_76_caller: isize,
    #[cfg(test)]
    mir_unit_36_78_source: bool,
    #[cfg(test)]
    mir_unit_36_78_argument: bool,
    #[cfg(test)]
    mir_unit_36_78_returned: bool,
    #[cfg(test)]
    mir_unit_36_78_caller: bool,
    #[cfg(test)]
    mir_unit_36_80_source: isize,
    #[cfg(test)]
    mir_unit_36_80_argument: isize,
    #[cfg(test)]
    mir_unit_36_80_returned: isize,
    #[cfg(test)]
    mir_unit_36_80_caller: isize,
    #[cfg(test)]
    mir_unit_36_82_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_36_82_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_36_82_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_36_82_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, usize>,
    #[cfg(test)]
    mir_unit_36_83_source: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_83_argument: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_83_returned: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_83_caller: std::result::Result<usize, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_84_source: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_36_84_argument: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_36_84_returned: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_36_84_caller: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_36_85_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_36_85_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_36_85_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_36_85_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_36_86_source: isize,
    #[cfg(test)]
    mir_unit_36_86_argument: isize,
    #[cfg(test)]
    mir_unit_36_86_returned: isize,
    #[cfg(test)]
    mir_unit_36_86_caller: isize,
    #[cfg(test)]
    mir_unit_36_89_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_89_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_89_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_89_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_90_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_90_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_90_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_90_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_91_source: usize,
    #[cfg(test)]
    mir_unit_36_91_argument: usize,
    #[cfg(test)]
    mir_unit_36_91_returned: usize,
    #[cfg(test)]
    mir_unit_36_91_caller: usize,
    #[cfg(test)]
    mir_unit_36_92_source: isize,
    #[cfg(test)]
    mir_unit_36_92_argument: isize,
    #[cfg(test)]
    mir_unit_36_92_returned: isize,
    #[cfg(test)]
    mir_unit_36_92_caller: isize,
    #[cfg(test)]
    mir_unit_36_94_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_94_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_94_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_94_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_95_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_95_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_95_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_95_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_96_source: isize,
    #[cfg(test)]
    mir_unit_36_96_argument: isize,
    #[cfg(test)]
    mir_unit_36_96_returned: isize,
    #[cfg(test)]
    mir_unit_36_96_caller: isize,
    #[cfg(test)]
    mir_unit_36_99_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_99_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_99_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_99_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_100_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_100_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_100_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_100_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_101_source: isize,
    #[cfg(test)]
    mir_unit_36_101_argument: isize,
    #[cfg(test)]
    mir_unit_36_101_returned: isize,
    #[cfg(test)]
    mir_unit_36_101_caller: isize,
    #[cfg(test)]
    mir_unit_36_103_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_103_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_103_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_103_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_104_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_104_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_104_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_104_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_105_source: isize,
    #[cfg(test)]
    mir_unit_36_105_argument: isize,
    #[cfg(test)]
    mir_unit_36_105_returned: isize,
    #[cfg(test)]
    mir_unit_36_105_caller: isize,
    #[cfg(test)]
    mir_unit_36_107_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_107_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_107_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_107_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_108_source: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_108_argument: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_108_returned: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_108_caller: std::result::Result<crate::experimental::execution::Control, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_109_source: isize,
    #[cfg(test)]
    mir_unit_36_109_argument: isize,
    #[cfg(test)]
    mir_unit_36_109_returned: isize,
    #[cfg(test)]
    mir_unit_36_109_caller: isize,
    #[cfg(test)]
    mir_unit_36_112_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_112_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_112_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_112_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_113_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_113_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_113_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_113_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_114_source: isize,
    #[cfg(test)]
    mir_unit_36_114_argument: isize,
    #[cfg(test)]
    mir_unit_36_114_returned: isize,
    #[cfg(test)]
    mir_unit_36_114_caller: isize,
    #[cfg(test)]
    mir_unit_36_116_source: bool,
    #[cfg(test)]
    mir_unit_36_116_argument: bool,
    #[cfg(test)]
    mir_unit_36_116_returned: bool,
    #[cfg(test)]
    mir_unit_36_116_caller: bool,
    #[cfg(test)]
    mir_unit_36_117_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_117_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_117_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_117_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>>,
    #[cfg(test)]
    mir_unit_36_118_source: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_118_argument: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_118_returned: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_118_caller: std::result::Result<(), crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_119_source: isize,
    #[cfg(test)]
    mir_unit_36_119_argument: isize,
    #[cfg(test)]
    mir_unit_36_119_returned: isize,
    #[cfg(test)]
    mir_unit_36_119_caller: isize,
    #[cfg(test)]
    mir_unit_36_122_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    #[cfg(test)]
    mir_unit_36_122_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    #[cfg(test)]
    mir_unit_36_122_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    #[cfg(test)]
    mir_unit_36_122_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    #[cfg(test)]
    mir_unit_36_123_source: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_123_argument: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_123_returned: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_123_caller: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_124_source: isize,
    #[cfg(test)]
    mir_unit_36_124_argument: isize,
    #[cfg(test)]
    mir_unit_36_124_returned: isize,
    #[cfg(test)]
    mir_unit_36_124_caller: isize,
    #[cfg(test)]
    mir_unit_36_128_source: bool,
    #[cfg(test)]
    mir_unit_36_128_argument: bool,
    #[cfg(test)]
    mir_unit_36_128_returned: bool,
    #[cfg(test)]
    mir_unit_36_128_caller: bool,
    #[cfg(test)]
    mir_unit_36_129_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    #[cfg(test)]
    mir_unit_36_129_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    #[cfg(test)]
    mir_unit_36_129_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    #[cfg(test)]
    mir_unit_36_129_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    #[cfg(test)]
    mir_unit_36_130_source: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_130_argument: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_130_returned: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_130_caller: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_131_source: isize,
    #[cfg(test)]
    mir_unit_36_131_argument: isize,
    #[cfg(test)]
    mir_unit_36_131_returned: isize,
    #[cfg(test)]
    mir_unit_36_131_caller: isize,
    #[cfg(test)]
    mir_unit_36_134_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    #[cfg(test)]
    mir_unit_36_134_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    #[cfg(test)]
    mir_unit_36_134_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    #[cfg(test)]
    mir_unit_36_134_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    #[cfg(test)]
    mir_unit_36_135_source: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_135_argument: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_135_returned: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_135_caller: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_136_source: isize,
    #[cfg(test)]
    mir_unit_36_136_argument: isize,
    #[cfg(test)]
    mir_unit_36_136_returned: isize,
    #[cfg(test)]
    mir_unit_36_136_caller: isize,
    #[cfg(test)]
    mir_unit_36_140_source: bool,
    #[cfg(test)]
    mir_unit_36_140_argument: bool,
    #[cfg(test)]
    mir_unit_36_140_returned: bool,
    #[cfg(test)]
    mir_unit_36_140_caller: bool,
    #[cfg(test)]
    mir_unit_36_141_source: &'static std::option::Option<u32>,
    #[cfg(test)]
    mir_unit_36_141_argument: &'static std::option::Option<u32>,
    #[cfg(test)]
    mir_unit_36_141_returned: &'static std::option::Option<u32>,
    #[cfg(test)]
    mir_unit_36_141_caller: &'static std::option::Option<u32>,
    #[cfg(test)]
    mir_unit_36_142_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_36_142_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_36_142_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_36_142_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_36_143_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    #[cfg(test)]
    mir_unit_36_143_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    #[cfg(test)]
    mir_unit_36_143_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    #[cfg(test)]
    mir_unit_36_143_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, i32>,
    #[cfg(test)]
    mir_unit_36_144_source: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_144_argument: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_144_returned: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_144_caller: std::result::Result<i32, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_145_source: isize,
    #[cfg(test)]
    mir_unit_36_145_argument: isize,
    #[cfg(test)]
    mir_unit_36_145_returned: isize,
    #[cfg(test)]
    mir_unit_36_145_caller: isize,
    #[cfg(test)]
    mir_unit_36_148_source: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    #[cfg(test)]
    mir_unit_36_148_argument: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    #[cfg(test)]
    mir_unit_36_148_returned: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    #[cfg(test)]
    mir_unit_36_148_caller: std::ops::ControlFlow<std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>, bool>,
    #[cfg(test)]
    mir_unit_36_149_source: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_149_argument: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_149_returned: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_149_caller: std::result::Result<bool, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_150_source: u32,
    #[cfg(test)]
    mir_unit_36_150_argument: u32,
    #[cfg(test)]
    mir_unit_36_150_returned: u32,
    #[cfg(test)]
    mir_unit_36_150_caller: u32,
    #[cfg(test)]
    mir_unit_36_151_source: &'static str,
    #[cfg(test)]
    mir_unit_36_151_argument: &'static str,
    #[cfg(test)]
    mir_unit_36_151_returned: &'static str,
    #[cfg(test)]
    mir_unit_36_151_caller: &'static str,
    #[cfg(test)]
    mir_unit_36_152_source: isize,
    #[cfg(test)]
    mir_unit_36_152_argument: isize,
    #[cfg(test)]
    mir_unit_36_152_returned: isize,
    #[cfg(test)]
    mir_unit_36_152_caller: isize,
    #[cfg(test)]
    mir_unit_36_155_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_36_155_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_36_155_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_36_155_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_36_156_source: crate::experimental_swift_reactor::control::Cursor,
    #[cfg(test)]
    mir_unit_36_156_argument: crate::experimental_swift_reactor::control::Cursor,
    #[cfg(test)]
    mir_unit_36_156_returned: crate::experimental_swift_reactor::control::Cursor,
    #[cfg(test)]
    mir_unit_36_156_caller: crate::experimental_swift_reactor::control::Cursor,
    #[cfg(test)]
    mir_unit_36_157_source: crate::experimental_swift_reactor::control::Fault,
    #[cfg(test)]
    mir_unit_36_157_argument: crate::experimental_swift_reactor::control::Fault,
    #[cfg(test)]
    mir_unit_36_157_returned: crate::experimental_swift_reactor::control::Fault,
    #[cfg(test)]
    mir_unit_36_157_caller: crate::experimental_swift_reactor::control::Fault,
    #[cfg(test)]
    mir_unit_36_158_source: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    #[cfg(test)]
    mir_unit_36_158_argument: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    #[cfg(test)]
    mir_unit_36_158_returned: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    #[cfg(test)]
    mir_unit_36_158_caller: crate::experimental_swift_reactor::control::SwiftRunFailureKind,
    #[cfg(test)]
    mir_unit_36_159_source: std::option::Option<crate::experimental_wasi::WasiUsage>,
    #[cfg(test)]
    mir_unit_36_159_argument: std::option::Option<crate::experimental_wasi::WasiUsage>,
    #[cfg(test)]
    mir_unit_36_159_returned: std::option::Option<crate::experimental_wasi::WasiUsage>,
    #[cfg(test)]
    mir_unit_36_159_caller: std::option::Option<crate::experimental_wasi::WasiUsage>,
    #[cfg(test)]
    mir_unit_36_160_source: crate::experimental_wasi::WasiUsage,
    #[cfg(test)]
    mir_unit_36_160_argument: crate::experimental_wasi::WasiUsage,
    #[cfg(test)]
    mir_unit_36_160_returned: crate::experimental_wasi::WasiUsage,
    #[cfg(test)]
    mir_unit_36_160_caller: crate::experimental_wasi::WasiUsage,
    #[cfg(test)]
    mir_unit_36_161_source: &'static crate::experimental_wasi::accounted::AccountedWasi,
    #[cfg(test)]
    mir_unit_36_161_argument: &'static crate::experimental_wasi::accounted::AccountedWasi,
    #[cfg(test)]
    mir_unit_36_161_returned: &'static crate::experimental_wasi::accounted::AccountedWasi,
    #[cfg(test)]
    mir_unit_36_161_caller: &'static crate::experimental_wasi::accounted::AccountedWasi,
    #[cfg(test)]
    mir_unit_36_162_source: bool,
    #[cfg(test)]
    mir_unit_36_162_argument: bool,
    #[cfg(test)]
    mir_unit_36_162_returned: bool,
    #[cfg(test)]
    mir_unit_36_162_caller: bool,
    #[cfg(test)]
    mir_unit_36_163_source: &'static mut crate::experimental_swift_reactor::control::RuntimeControl,
    #[cfg(test)]
    mir_unit_36_163_argument: &'static mut crate::experimental_swift_reactor::control::RuntimeControl,
    #[cfg(test)]
    mir_unit_36_163_returned: &'static mut crate::experimental_swift_reactor::control::RuntimeControl,
    #[cfg(test)]
    mir_unit_36_163_caller: &'static mut crate::experimental_swift_reactor::control::RuntimeControl,
    #[cfg(test)]
    mir_unit_36_164_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_164_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_164_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_164_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_165_source: &'static mut crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    #[cfg(test)]
    mir_unit_36_165_argument: &'static mut crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    #[cfg(test)]
    mir_unit_36_165_returned: &'static mut crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    #[cfg(test)]
    mir_unit_36_165_caller: &'static mut crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    #[cfg(test)]
    mir_unit_36_166_source: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_166_argument: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_166_returned: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_166_caller: &'static mut std::vec::Vec<crate::experimental::execution::Control>,
    #[cfg(test)]
    mir_unit_36_167_source: &'static mut crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    #[cfg(test)]
    mir_unit_36_167_argument: &'static mut crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    #[cfg(test)]
    mir_unit_36_167_returned: &'static mut crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    #[cfg(test)]
    mir_unit_36_167_caller: &'static mut crate::experimental_swift_reactor::cache::SwiftFunctionCache,
    #[cfg(test)]
    mir_unit_36_168_source: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_36_168_argument: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_36_168_returned: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_36_168_caller: &'static mut std::vec::Vec<Value>,
    #[cfg(test)]
    mir_unit_36_169_source: &'static mut crate::experimental_wasi::accounted::AccountedWasi,
    #[cfg(test)]
    mir_unit_36_169_argument: &'static mut crate::experimental_wasi::accounted::AccountedWasi,
    #[cfg(test)]
    mir_unit_36_169_returned: &'static mut crate::experimental_wasi::accounted::AccountedWasi,
    #[cfg(test)]
    mir_unit_36_169_caller: &'static mut crate::experimental_wasi::accounted::AccountedWasi,
    #[cfg(test)]
    mir_unit_36_15_source: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_36_15_argument: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_36_15_returned: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_36_15_caller: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    alias_unit_36_15_0_kind_source: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    alias_unit_36_15_0_kind_argument: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    alias_unit_36_15_0_kind_returned: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    alias_unit_36_15_0_kind_caller: crate::experimental::cache::ControlKind,
    #[cfg(test)]
    mir_unit_36_16_source: std::option::Option<Type>,
    #[cfg(test)]
    mir_unit_36_16_argument: std::option::Option<Type>,
    #[cfg(test)]
    mir_unit_36_16_returned: std::option::Option<Type>,
    #[cfg(test)]
    mir_unit_36_16_caller: std::option::Option<Type>,
    #[cfg(test)]
    alias_unit_36_16_0_result_source: std::option::Option<Type>,
    #[cfg(test)]
    alias_unit_36_16_0_result_argument: std::option::Option<Type>,
    #[cfg(test)]
    alias_unit_36_16_0_result_returned: std::option::Option<Type>,
    #[cfg(test)]
    alias_unit_36_16_0_result_caller: std::option::Option<Type>,
    #[cfg(test)]
    mir_unit_36_17_source: usize,
    #[cfg(test)]
    mir_unit_36_17_argument: usize,
    #[cfg(test)]
    mir_unit_36_17_returned: usize,
    #[cfg(test)]
    mir_unit_36_17_caller: usize,
    #[cfg(test)]
    alias_unit_36_17_0_end_source: usize,
    #[cfg(test)]
    alias_unit_36_17_0_end_argument: usize,
    #[cfg(test)]
    alias_unit_36_17_0_end_returned: usize,
    #[cfg(test)]
    alias_unit_36_17_0_end_caller: usize,
    #[cfg(test)]
    mir_unit_36_18_source: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_36_18_argument: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_36_18_returned: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_36_18_caller: std::option::Option<usize>,
    #[cfg(test)]
    alias_unit_36_18_0_alternative_source: std::option::Option<usize>,
    #[cfg(test)]
    alias_unit_36_18_0_alternative_argument: std::option::Option<usize>,
    #[cfg(test)]
    alias_unit_36_18_0_alternative_returned: std::option::Option<usize>,
    #[cfg(test)]
    alias_unit_36_18_0_alternative_caller: std::option::Option<usize>,
    #[cfg(test)]
    mir_unit_36_98_source: usize,
    #[cfg(test)]
    mir_unit_36_98_argument: usize,
    #[cfg(test)]
    mir_unit_36_98_returned: usize,
    #[cfg(test)]
    mir_unit_36_98_caller: usize,
    #[cfg(test)]
    alias_unit_36_98_0_end_source: usize,
    #[cfg(test)]
    alias_unit_36_98_0_end_argument: usize,
    #[cfg(test)]
    alias_unit_36_98_0_end_returned: usize,
    #[cfg(test)]
    alias_unit_36_98_0_end_caller: usize,
    #[cfg(test)]
    mir_unit_36_106_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_106_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_106_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_106_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_106_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_106_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_106_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_106_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_110_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_110_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_110_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_110_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_110_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_110_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_110_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_110_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_111_source: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_36_111_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_36_111_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_36_111_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_36_111_0_control_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_36_111_0_control_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_36_111_0_control_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_36_111_0_control_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_36_111_1_val_source: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_36_111_1_val_argument: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_36_111_1_val_returned: crate::experimental::execution::Control,
    #[cfg(test)]
    alias_unit_36_111_1_val_caller: crate::experimental::execution::Control,
    #[cfg(test)]
    mir_unit_36_121_source: u32,
    #[cfg(test)]
    mir_unit_36_121_argument: u32,
    #[cfg(test)]
    mir_unit_36_121_returned: u32,
    #[cfg(test)]
    mir_unit_36_121_caller: u32,
    #[cfg(test)]
    alias_unit_36_121_0_depth_source: u32,
    #[cfg(test)]
    alias_unit_36_121_0_depth_argument: u32,
    #[cfg(test)]
    alias_unit_36_121_0_depth_returned: u32,
    #[cfg(test)]
    alias_unit_36_121_0_depth_caller: u32,
    #[cfg(test)]
    mir_unit_36_127_source: u32,
    #[cfg(test)]
    mir_unit_36_127_argument: u32,
    #[cfg(test)]
    mir_unit_36_127_returned: u32,
    #[cfg(test)]
    mir_unit_36_127_caller: u32,
    #[cfg(test)]
    alias_unit_36_127_0_depth_source: u32,
    #[cfg(test)]
    alias_unit_36_127_0_depth_argument: u32,
    #[cfg(test)]
    alias_unit_36_127_0_depth_returned: u32,
    #[cfg(test)]
    alias_unit_36_127_0_depth_caller: u32,
    #[cfg(test)]
    mir_unit_36_139_source: std::option::Option<u32>,
    #[cfg(test)]
    mir_unit_36_139_argument: std::option::Option<u32>,
    #[cfg(test)]
    mir_unit_36_139_returned: std::option::Option<u32>,
    #[cfg(test)]
    mir_unit_36_139_caller: std::option::Option<u32>,
    #[cfg(test)]
    alias_unit_36_139_0_target_source: std::option::Option<u32>,
    #[cfg(test)]
    alias_unit_36_139_0_target_argument: std::option::Option<u32>,
    #[cfg(test)]
    alias_unit_36_139_0_target_returned: std::option::Option<u32>,
    #[cfg(test)]
    alias_unit_36_139_0_target_caller: std::option::Option<u32>,
    #[cfg(test)]
    mir_unit_36_19_source: bool,
    #[cfg(test)]
    mir_unit_36_19_argument: bool,
    #[cfg(test)]
    mir_unit_36_19_returned: bool,
    #[cfg(test)]
    mir_unit_36_19_caller: bool,
    #[cfg(test)]
    alias_unit_36_19_0_cond_source: bool,
    #[cfg(test)]
    alias_unit_36_19_0_cond_argument: bool,
    #[cfg(test)]
    alias_unit_36_19_0_cond_returned: bool,
    #[cfg(test)]
    alias_unit_36_19_0_cond_caller: bool,
    #[cfg(test)]
    mir_unit_36_26_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_26_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_26_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_26_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_26_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_26_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_26_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_26_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_27_source: i32,
    #[cfg(test)]
    mir_unit_36_27_argument: i32,
    #[cfg(test)]
    mir_unit_36_27_returned: i32,
    #[cfg(test)]
    mir_unit_36_27_caller: i32,
    #[cfg(test)]
    alias_unit_36_27_0_val_source: i32,
    #[cfg(test)]
    alias_unit_36_27_0_val_argument: i32,
    #[cfg(test)]
    alias_unit_36_27_0_val_returned: i32,
    #[cfg(test)]
    alias_unit_36_27_0_val_caller: i32,
    #[cfg(test)]
    mir_unit_36_31_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_31_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_31_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_31_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_31_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_31_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_31_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_31_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_35_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_35_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_35_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_35_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_35_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_35_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_35_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_35_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_39_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_39_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_39_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_39_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_39_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_39_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_39_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_39_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_43_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_43_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_43_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_43_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_43_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_43_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_43_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_43_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_44_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_36_44_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_36_44_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_36_44_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_36_44_0_frame_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_36_44_0_frame_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_36_44_0_frame_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_36_44_0_frame_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_36_44_1_val_source: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_36_44_1_val_argument: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_36_44_1_val_returned: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    alias_unit_36_44_1_val_caller: crate::experimental_swift_reactor::execution::frame_operations::FrameScalars,
    #[cfg(test)]
    mir_unit_36_77_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_77_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_77_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_77_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_77_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_77_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_77_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_77_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_79_source: usize,
    #[cfg(test)]
    mir_unit_36_79_argument: usize,
    #[cfg(test)]
    mir_unit_36_79_returned: usize,
    #[cfg(test)]
    mir_unit_36_79_caller: usize,
    #[cfg(test)]
    alias_unit_36_79_0_pc_source: usize,
    #[cfg(test)]
    alias_unit_36_79_0_pc_argument: usize,
    #[cfg(test)]
    alias_unit_36_79_0_pc_returned: usize,
    #[cfg(test)]
    alias_unit_36_79_0_pc_caller: usize,
    #[cfg(test)]
    mir_unit_36_81_source: usize,
    #[cfg(test)]
    mir_unit_36_81_argument: usize,
    #[cfg(test)]
    mir_unit_36_81_returned: usize,
    #[cfg(test)]
    mir_unit_36_81_caller: usize,
    #[cfg(test)]
    alias_unit_36_81_0_alternative_source: usize,
    #[cfg(test)]
    alias_unit_36_81_0_alternative_argument: usize,
    #[cfg(test)]
    alias_unit_36_81_0_alternative_returned: usize,
    #[cfg(test)]
    alias_unit_36_81_0_alternative_caller: usize,
    #[cfg(test)]
    mir_unit_36_97_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_97_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_97_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_97_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_97_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_97_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_97_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_97_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_93_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_93_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_93_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_93_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_93_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_93_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_93_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_93_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_87_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_87_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_87_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_87_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_87_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_87_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_87_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_87_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_88_source: usize,
    #[cfg(test)]
    mir_unit_36_88_argument: usize,
    #[cfg(test)]
    mir_unit_36_88_returned: usize,
    #[cfg(test)]
    mir_unit_36_88_caller: usize,
    #[cfg(test)]
    alias_unit_36_88_0_val_source: usize,
    #[cfg(test)]
    alias_unit_36_88_0_val_argument: usize,
    #[cfg(test)]
    alias_unit_36_88_0_val_returned: usize,
    #[cfg(test)]
    alias_unit_36_88_0_val_caller: usize,
    #[cfg(test)]
    mir_unit_36_102_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_102_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_102_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_102_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_102_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_102_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_102_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_102_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_115_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_115_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_115_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_115_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_115_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_115_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_115_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_115_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_120_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_120_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_120_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_120_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_120_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_120_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_120_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_120_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_125_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_125_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_125_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_125_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_125_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_125_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_125_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_125_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_126_source: bool,
    #[cfg(test)]
    mir_unit_36_126_argument: bool,
    #[cfg(test)]
    mir_unit_36_126_returned: bool,
    #[cfg(test)]
    mir_unit_36_126_caller: bool,
    #[cfg(test)]
    alias_unit_36_126_0_val_source: bool,
    #[cfg(test)]
    alias_unit_36_126_0_val_argument: bool,
    #[cfg(test)]
    alias_unit_36_126_0_val_returned: bool,
    #[cfg(test)]
    alias_unit_36_126_0_val_caller: bool,
    #[cfg(test)]
    mir_unit_36_132_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_132_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_132_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_132_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_132_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_132_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_132_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_132_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_133_source: i32,
    #[cfg(test)]
    mir_unit_36_133_argument: i32,
    #[cfg(test)]
    mir_unit_36_133_returned: i32,
    #[cfg(test)]
    mir_unit_36_133_caller: i32,
    #[cfg(test)]
    alias_unit_36_133_0_val_source: i32,
    #[cfg(test)]
    alias_unit_36_133_0_val_argument: i32,
    #[cfg(test)]
    alias_unit_36_133_0_val_returned: i32,
    #[cfg(test)]
    alias_unit_36_133_0_val_caller: i32,
    #[cfg(test)]
    mir_unit_36_137_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_137_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_137_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_137_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_137_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_137_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_137_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_137_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_138_source: bool,
    #[cfg(test)]
    mir_unit_36_138_argument: bool,
    #[cfg(test)]
    mir_unit_36_138_returned: bool,
    #[cfg(test)]
    mir_unit_36_138_caller: bool,
    #[cfg(test)]
    alias_unit_36_138_0_val_source: bool,
    #[cfg(test)]
    alias_unit_36_138_0_val_argument: bool,
    #[cfg(test)]
    alias_unit_36_138_0_val_returned: bool,
    #[cfg(test)]
    alias_unit_36_138_0_val_caller: bool,
    #[cfg(test)]
    mir_unit_36_146_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_146_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_146_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_146_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_146_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_146_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_146_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_146_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_147_source: i32,
    #[cfg(test)]
    mir_unit_36_147_argument: i32,
    #[cfg(test)]
    mir_unit_36_147_returned: i32,
    #[cfg(test)]
    mir_unit_36_147_caller: i32,
    #[cfg(test)]
    alias_unit_36_147_0_val_source: i32,
    #[cfg(test)]
    alias_unit_36_147_0_val_argument: i32,
    #[cfg(test)]
    alias_unit_36_147_0_val_returned: i32,
    #[cfg(test)]
    alias_unit_36_147_0_val_caller: i32,
    #[cfg(test)]
    mir_unit_36_153_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_153_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_153_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_153_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_153_0_residual_source: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_153_0_residual_argument: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_153_0_residual_returned: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    alias_unit_36_153_0_residual_caller: std::result::Result<std::convert::Infallible, crate::experimental_swift_reactor::control::SwiftRunFailure>,
    #[cfg(test)]
    mir_unit_36_154_source: bool,
    #[cfg(test)]
    mir_unit_36_154_argument: bool,
    #[cfg(test)]
    mir_unit_36_154_returned: bool,
    #[cfg(test)]
    mir_unit_36_154_caller: bool,
    #[cfg(test)]
    alias_unit_36_154_0_val_source: bool,
    #[cfg(test)]
    alias_unit_36_154_0_val_argument: bool,
    #[cfg(test)]
    alias_unit_36_154_0_val_returned: bool,
    #[cfg(test)]
    alias_unit_36_154_0_val_caller: bool,
    #[cfg(test)]
    mir_unit_36_1_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_36_1_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_36_1_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_36_1_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_36_1_0_self_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_36_1_0_self_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_36_1_0_self_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    alias_unit_36_1_0_self_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_36_2_source: crate::experimental::cache::Operation,
    #[cfg(test)]
    mir_unit_36_2_argument: crate::experimental::cache::Operation,
    #[cfg(test)]
    mir_unit_36_2_returned: crate::experimental::cache::Operation,
    #[cfg(test)]
    mir_unit_36_2_caller: crate::experimental::cache::Operation,
    #[cfg(test)]
    alias_unit_36_2_0_operation_source: crate::experimental::cache::Operation,
    #[cfg(test)]
    alias_unit_36_2_0_operation_argument: crate::experimental::cache::Operation,
    #[cfg(test)]
    alias_unit_36_2_0_operation_returned: crate::experimental::cache::Operation,
    #[cfg(test)]
    alias_unit_36_2_0_operation_caller: crate::experimental::cache::Operation,
    #[cfg(test)]
    mir_unit_36_3_source: Option<u32>,
    #[cfg(test)]
    mir_unit_36_3_argument: Option<u32>,
    #[cfg(test)]
    mir_unit_36_3_returned: Option<u32>,
    #[cfg(test)]
    mir_unit_36_3_caller: Option<u32>,
    #[cfg(test)]
    alias_unit_36_3_0_selected_target_source: Option<u32>,
    #[cfg(test)]
    alias_unit_36_3_0_selected_target_argument: Option<u32>,
    #[cfg(test)]
    alias_unit_36_3_0_selected_target_returned: Option<u32>,
    #[cfg(test)]
    alias_unit_36_3_0_selected_target_caller: Option<u32>,
    #[cfg(test)]
    literal_unit_36_0_source: bool,
    #[cfg(test)]
    literal_unit_36_0_argument: bool,
    #[cfg(test)]
    literal_unit_36_0_returned: bool,
    #[cfg(test)]
    literal_unit_36_0_caller: bool,
    #[cfg(test)]
    literal_unit_36_1_source: &'static str,
    #[cfg(test)]
    literal_unit_36_1_argument: &'static str,
    #[cfg(test)]
    literal_unit_36_1_returned: &'static str,
    #[cfg(test)]
    literal_unit_36_1_caller: &'static str,
    #[cfg(test)]
    literal_unit_36_2_source: bool,
    #[cfg(test)]
    literal_unit_36_2_argument: bool,
    #[cfg(test)]
    literal_unit_36_2_returned: bool,
    #[cfg(test)]
    literal_unit_36_2_caller: bool,
    #[cfg(test)]
    literal_unit_36_3_source: usize,
    #[cfg(test)]
    literal_unit_36_3_argument: usize,
    #[cfg(test)]
    literal_unit_36_3_returned: usize,
    #[cfg(test)]
    literal_unit_36_3_caller: usize,
    #[cfg(test)]
    literal_unit_36_4_source: i32,
    #[cfg(test)]
    literal_unit_36_4_argument: i32,
    #[cfg(test)]
    literal_unit_36_4_returned: i32,
    #[cfg(test)]
    literal_unit_36_4_caller: i32,
    #[cfg(test)]
    literal_unit_36_5_source: bool,
    #[cfg(test)]
    literal_unit_36_5_argument: bool,
    #[cfg(test)]
    literal_unit_36_5_returned: bool,
    #[cfg(test)]
    literal_unit_36_5_caller: bool,
    #[cfg(test)]
    literal_unit_36_6_source: usize,
    #[cfg(test)]
    literal_unit_36_6_argument: usize,
    #[cfg(test)]
    literal_unit_36_6_returned: usize,
    #[cfg(test)]
    literal_unit_36_6_caller: usize,
    #[cfg(test)]
    literal_unit_36_7_source: usize,
    #[cfg(test)]
    literal_unit_36_7_argument: usize,
    #[cfg(test)]
    literal_unit_36_7_returned: usize,
    #[cfg(test)]
    literal_unit_36_7_caller: usize,
    #[cfg(test)]
    literal_unit_36_8_source: usize,
    #[cfg(test)]
    literal_unit_36_8_argument: usize,
    #[cfg(test)]
    literal_unit_36_8_returned: usize,
    #[cfg(test)]
    literal_unit_36_8_caller: usize,
    #[cfg(test)]
    literal_unit_36_9_source: &'static str,
    #[cfg(test)]
    literal_unit_36_9_argument: &'static str,
    #[cfg(test)]
    literal_unit_36_9_returned: &'static str,
    #[cfg(test)]
    literal_unit_36_9_caller: &'static str,
    #[cfg(test)]
    literal_unit_36_10_source: usize,
    #[cfg(test)]
    literal_unit_36_10_argument: usize,
    #[cfg(test)]
    literal_unit_36_10_returned: usize,
    #[cfg(test)]
    literal_unit_36_10_caller: usize,
    #[cfg(test)]
    literal_unit_36_11_source: i32,
    #[cfg(test)]
    literal_unit_36_11_argument: i32,
    #[cfg(test)]
    literal_unit_36_11_returned: i32,
    #[cfg(test)]
    literal_unit_36_11_caller: i32,
    #[cfg(test)]
    literal_unit_36_12_source: &'static str,
    #[cfg(test)]
    literal_unit_36_12_argument: &'static str,
    #[cfg(test)]
    literal_unit_36_12_returned: &'static str,
    #[cfg(test)]
    literal_unit_36_12_caller: &'static str,
    #[cfg(test)]
    literal_unit_36_13_source: &'static str,
    #[cfg(test)]
    literal_unit_36_13_argument: &'static str,
    #[cfg(test)]
    literal_unit_36_13_returned: &'static str,
    #[cfg(test)]
    literal_unit_36_13_caller: &'static str,
    #[cfg(test)]
    mir_unit_37_0_source: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_37_0_argument: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_37_0_returned: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_37_0_caller: crate::experimental_swift_reactor::control::SwiftRunFailure,
    #[cfg(test)]
    mir_unit_37_2_source: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_37_2_argument: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_37_2_returned: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_37_2_caller: &'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,
    #[cfg(test)]
    mir_unit_37_1_source: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_37_1_argument: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_37_1_returned: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    mir_unit_37_1_caller: (&'static mut crate::experimental_swift_reactor::execution::frame_operations::FrameOperationPhase<'static>,),
    #[cfg(test)]
    literal_unit_37_0_source: &'static str,
    #[cfg(test)]
    literal_unit_37_0_argument: &'static str,
    #[cfg(test)]
    literal_unit_37_0_returned: &'static str,
    #[cfg(test)]
    literal_unit_37_0_caller: &'static str,
}
pub(in crate::experimental_swift_reactor::execution) const PERMANENT_BYTES: usize =
    size_of::<PermanentPositions>() + {
        #[cfg(test)]
        {
            super::tests::CONTROL_HOOK_PERMANENT_BYTES
        }
        #[cfg(not(test))]
        {
            0
        }
    };
pub(super) const ACTIVE_BYTES: usize = size_of::<ActivePositions>() + {
    #[cfg(test)]
    {
        super::tests::CONTROL_HOOK_ACTIVE_BYTES
    }
    #[cfg(not(test))]
    {
        0
    }
};
