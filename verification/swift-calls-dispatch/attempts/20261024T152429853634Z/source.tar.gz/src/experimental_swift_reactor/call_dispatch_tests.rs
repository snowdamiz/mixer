//! Independently authored binary fixtures execute the admitted production loop.
use super::*;
use super::super::tests as frame_tests;
use crate::experimental_swift_reactor::{validate_swift_reactor,SwiftValidationBudget,allocation_tests::measure_extended};
use crate::experimental_wasi::WasiFunction;
use crate::Cancellation;
use std::cell::Cell;
thread_local! {
    pub(super) static PC_OVERFLOW:Cell<bool>=const {Cell::new(false)};
    static CHECK_COUNT:Cell<usize>=const {Cell::new(0)};
    static CANCEL_AT:Cell<Option<usize>>=const {Cell::new(None)};
}
pub(super) fn checkpoint(control:&RuntimeControl) {
    let at=CHECK_COUNT.with(|n|{let at=n.get();n.set(at+1);at});
    if CANCEL_AT.with(Cell::get)==Some(at){control.cancellation().cancel();}
}
#[derive(Clone)]
struct Function {params:Vec<Type>,result:Option<Type>,locals:Vec<Type>,body:Vec<u8>}
impl Function {
    fn void(body:&[u8])->Self {Self{params:vec![],result:None,locals:vec![],body:body.to_vec()}}
    fn scalar(body:&[u8],ty:Type)->Self {Self{result:Some(ty),..Self::void(body)}}
}
fn uint(mut n:u32,out:&mut Vec<u8>){loop{let b=(n&127)as u8;n>>=7;out.push(b|if n==0{0}else{128});if n==0{break;}}}
fn text(bytes:&[u8],out:&mut Vec<u8>){uint(bytes.len()as u32,out);out.extend_from_slice(bytes);}
fn section(id:u8,bytes:&[u8],out:&mut Vec<u8>){out.push(id);uint(bytes.len()as u32,out);out.extend_from_slice(bytes);}
fn ty(t:Type)->u8 {match t{Type::I32=>0x7f,Type::I64=>0x7e,Type::F32=>0x7d,Type::F64=>0x7c}}
fn module(spec:&[(usize,Function)],table:&[u32])->(Vec<u8>,Vec<usize>){
    let mut functions=vec![Function::void(&[0x0b]);29];functions[28]=Function::scalar(&[0x41,0,0x0b],Type::I32);
    for(index,function)in spec{functions[*index]=function.clone();}
    let mut out=b"\0asm\x01\0\0\0".to_vec();let mut types=vec![65];
    for f in WasiFunction::ALL {types.push(0x60);uint(f.parameters().len()as u32,&mut types);types.extend(f.parameters().iter().copied().map(ty));uint(f.results().len()as u32,&mut types);types.extend(f.results().iter().copied().map(ty));}
    types.extend([0x60,0,0,0x60,0,1,0x7f]);
    for f in &functions {types.push(0x60);uint(f.params.len()as u32,&mut types);types.extend(f.params.iter().copied().map(ty));uint(u32::from(f.result.is_some()),&mut types);if let Some(result)=f.result{types.push(ty(result));}}
    section(1,&types,&mut out);let mut imports=vec![34];
    for(index,f)in WasiFunction::ALL.into_iter().enumerate(){text(b"wasi_snapshot_preview1",&mut imports);text(f.name(),&mut imports);imports.push(0);uint(index as u32,&mut imports);}
    section(2,&imports,&mut out);let mut declarations=vec![29];for index in 0..29 {uint(36+index,&mut declarations);}section(3,&declarations,&mut out);
    let mut table_section=vec![1,0x70,1];uint(46713,&mut table_section);uint(46713,&mut table_section);section(4,&table_section,&mut out);
    let mut memory=vec![1,1];uint(584,&mut memory);uint(768,&mut memory);section(5,&memory,&mut out);
    let globals=[4,0x7f,1,0x41,0,0x0b,0x7e,0,0x42,0,0x0b,0x7d,1,0x43,0,0,0,0,0x0b,0x7c,1,0x44,0,0,0,0,0,0,0,0,0x0b];section(6,&globals,&mut out);
    let mut exports=vec![3];for(name,kind,index)in[(b"memory".as_slice(),2,0),(b"_initialize".as_slice(),0,35),(b"mixer_fieldlog_corpus_v1".as_slice(),0,62)]{text(name,&mut exports);exports.push(kind);uint(index,&mut exports);}section(7,&exports,&mut out);
    if !table.is_empty(){let mut elements=vec![1,0,0x41,0,0x0b];uint(table.len()as u32,&mut elements);for function in table {uint(*function,&mut elements);}section(9,&elements,&mut out);}
    let mut code=vec![29];let mut starts=Vec::new();
    for f in &functions {let mut body=vec![];uint(f.locals.len()as u32,&mut body);for local in &f.locals {body.extend([1,ty(*local)]);}let prefix=body.len();body.extend_from_slice(&f.body);uint(body.len()as u32,&mut code);starts.push(code.len()+prefix);code.extend(body);}
    let mut length=vec![];uint(code.len()as u32,&mut length);let begin=out.len()+1+length.len();for at in &mut starts {*at+=begin;}section(10,&code,&mut out);(out,starts)
}
fn owner(spec:&[(usize,Function)],table:&[u32],budget:SwiftRunBudget)->(SwiftReactorInstance,Vec<usize>){
    frame_tests::hooks(frame_tests::Hooks::default());PC_OVERFLOW.with(|x|x.set(false));CHECK_COUNT.with(|x|x.set(0));CANCEL_AT.with(|x|x.set(None));
    let(bytes,starts)=module(spec,table);let proof=validate_swift_reactor(&bytes,SwiftValidationBudget::default(),&Cancellation::default()).unwrap();
    let mut pair=Some(RuntimeControl::adopt(proof,budget,Instant::now(),Cancellation::default()).unwrap());
    let owner=SwiftReactorInstance::construct(&mut pair,WasiGrants::default(),WasiBudget::default(),Instant::now(),frame_tests::cursor()).unwrap();(owner,starts)
}
fn storage<'a>()->FrameOperationStorage<'a>{FrameOperationStorage{preparation:None,entry:None,returned:None,drained:None,controlled:None}}
fn usage(p:&FrameOperationPhase<'_>)->SwiftRunUsage{p.phase.operation.control.usage(Some(p.phase.operation.wasi.usage()))}
fn execute(spec:&[(usize,Function)],table:&[u32],budget:SwiftRunBudget,action:impl for<'a> FnOnce(&mut FrameOperationPhase<'a>,&mut SwiftGrowthContext<'a>,&mut SwiftGrowthStorage,&mut FrameOperationStorage<'a>,&[usize])){
    let(mut owner,starts)=owner(spec,table,budget);let mut preparation=Some(owner.prepare_growth(frame_tests::cursor()));let(mut phase,mut context)=preparation.take().unwrap().unwrap();phase.enter(34).unwrap();let mut pending=SwiftGrowthStorage::empty();let mut storage=storage();
    action(&mut phase,&mut context,&mut pending,&mut storage,&starts);
    PC_OVERFLOW.with(|x|x.set(false));CANCEL_AT.with(|x|x.set(None));frame_tests::hooks(frame_tests::Hooks::default());
    growth::release_growth_pending(&mut phase,&mut context,&mut pending).unwrap();
    if !phase.phase.parts.frames.is_empty()||phase.cleanup.entry.is_some(){let report=phase.drain();assert_eq!(report.retained_frames,0);assert!(!report.retained_entry);assert!(!report.live_unreconciled);storage.drained=Some(report);}
    assert!(matches!(complete(phase,context,pending,storage,preparation),GrowthCompletion::Completed(FrameCompletion::Completed)));
    assert!(!matches!(owner.lifecycle,Lifecycle::Ready));frame_tests::retire(owner);
}
fn run_ok(p:&mut FrameOperationPhase<'_>,c:&mut SwiftGrowthContext<'_>,g:&mut SwiftGrowthStorage,s:&mut FrameOperationStorage<'_>){
    // All arguments share the original owner's lifetime; callers invoke run directly.
    let _=(p,c,g,s);
}
fn result(s:&FrameOperationStorage<'_>)->Option<Value>{match s.returned.as_ref().unwrap(){Ok(FrameReturn::Outermost(value))=>*value,other=>panic!("unexpected outcome {other:?}")}}
fn failure(s:&FrameOperationStorage<'_>)->SwiftRunFailure{*s.returned.as_ref().unwrap().as_ref().unwrap_err()}
#[test]fn swift_dispatch_cd01_original_authority(){
    for index in 0..7 {let(mut o,_)=owner(&[],&[],SwiftRunBudget::default());if index==6 {let ticket=o.state.as_mut().unwrap().execution_header.take();let before=o.control.as_ref().unwrap().usage(None);assert!(o.prepare_growth(frame_tests::cursor()).is_err());assert_eq!(o.control.as_ref().unwrap().usage(None).instructions,before.instructions);o.state.as_mut().unwrap().execution_header=ticket;}else{let ticket=o.state.as_mut().unwrap().buffers[index].take();assert!(o.prepare_growth(frame_tests::cursor()).is_err());o.state.as_mut().unwrap().buffers[index]=ticket;}frame_tests::retire(o);}
}
#[test]fn swift_dispatch_cd02_single_prefix(){
    for fuel in [0,1,2,3] {execute(&[(0,Function::scalar(&[0x41,7,0x01,0x0b],Type::I32))],&[],SwiftRunBudget{instruction_fuel:fuel,..SwiftRunBudget::default()},|p,c,g,s,starts|{let before=usage(p);run(p,c,g,s).unwrap();let after=usage(p);assert_eq!(after.instructions-before.instructions,fuel.min(3));assert_eq!(after.instruction_fuel-before.instruction_fuel,fuel.min(3));if fuel<3 {let f=failure(s);assert_eq!(f.kind,SwiftRunFailureKind::FuelExhausted);assert_eq!(f.offset,Some(starts[0]+if fuel==0{0}else{fuel as usize+1}));}else{assert_eq!(result(s),Some(Value::I32(7)));assert_eq!(after.execution_work-before.execution_work,6);}});}
    execute(&[(0,Function::void(&[0x01,0x0b]))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{PC_OVERFLOW.with(|x|x.set(true));let before=usage(p);run(p,c,g,s).unwrap();assert_eq!(failure(s).code,"swift_dispatch_pc_overflow");assert_eq!(usage(p).instructions-before.instructions,1);assert_eq!(usage(p).execution_work-before.execution_work,1);});
}
#[test]fn swift_dispatch_cd03_slot_publication(){for slot in 0..4{execute(&[(0,Function::void(&[0x01,0x0b]))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{match slot{0=>s.entry=Some(Ok(())),1=>s.returned=Some(Ok(FrameReturn::Outermost(None))),2=>s.controlled=Some(Ok(false)),_=>s.drained=Some(p.drain())};let before=usage(p);assert!(run(p,c,g,s).is_err());assert_eq!(usage(p).instructions,before.instructions);assert_eq!(usage(p).execution_work,before.execution_work);});}}
#[test]fn swift_dispatch_cd04_direct_defined(){let main=Function::scalar(&[0x41,9,0x10,36,0x0b],Type::I32);let callee=Function{params:vec![Type::I32],result:Some(Type::I32),locals:vec![Type::I64,Type::F32],body:vec![0x20,0,0x41,1,0x6a,0x0b]};execute(&[(0,main),(2,callee)],&[],SwiftRunBudget::default(),|p,c,g,s,_|{let before=usage(p);run(p,c,g,s).unwrap();assert_eq!(result(s),Some(Value::I32(10)));assert_eq!(usage(p).instructions-before.instructions,7);assert_eq!(usage(p).live.frames.current,0);assert_eq!(usage(p).live.active_pins.current,0);});}
#[test]fn swift_dispatch_cd05_recursive_pins(){execute(&[(0,Function::void(&[0x10,34,0x0b]))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();assert_eq!(failure(s).kind,SwiftRunFailureKind::FrameLimit);assert_eq!(p.phase.parts.frames.len(),64);assert_eq!(p.phase.parts.cache.usage().active_pins,64);assert_eq!(usage(p).instructions,64);});}
#[test]fn swift_dispatch_cd06_indirect_structure(){let main=Function::scalar(&[0x41,11,0x41,0,0x11,38,0,0x0b],Type::I32);let callee=Function{params:vec![Type::I32],result:Some(Type::I32),locals:vec![],body:vec![0x20,0,0x0b]};execute(&[(0,main),(2,callee.clone()),(3,callee)],&[37],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();assert_eq!(result(s),Some(Value::I32(11)));});}
#[test]fn swift_dispatch_cd07_indirect_table(){for(selector,code)in[(-1,"table_out_of_bounds"),(46713,"table_out_of_bounds"),(0,"indirect_call_null")]{let mut body=vec![0x41];if selector == -1{body.push(0x7f);}else if selector==0{body.push(0);}else{uint(selector as u32,&mut body);}body.extend([0x11,34,0,0x0b]);execute(&[(0,Function::void(&body))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();assert_eq!(failure(s).code,code);assert!(p.phase.parts.values.is_empty());assert_eq!(p.phase.parts.frames.len(),1);});}}
#[test]fn swift_dispatch_cd08_indirect_import(){let function=WasiFunction::SchedYield;let index=WasiFunction::ALL.iter().position(|f|*f==function).unwrap()as u8;for indirect_call in [false,true]{let body=if indirect_call{vec![0x41,0,0x11,index,0,0x0b]}else{vec![0x10,index,0x0b]};execute(&[(0,Function::scalar(&body,Type::I32))],&[u32::from(index)],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();assert_eq!(result(s),Some(Value::I32(0)));assert_eq!(usage(p).host_calls,1);assert_eq!(usage(p).live.frames.peak,1);});}}
#[test]fn swift_dispatch_cd09_entry_completion(){execute(&[(0,Function::void(&[0x10,36,0x0b]))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{frame_tests::hooks(frame_tests::Hooks{reject_cache_completion:true,..Default::default()});run(p,c,g,s).unwrap();assert!(s.returned.as_ref().unwrap().is_err());assert!(p.cleanup.entry.is_some());assert!(p.cleanup.nested_restore.is_some());});}
#[test]fn swift_dispatch_cd10_function_return(){for(ty,constant)in[(Type::I32,vec![0x41,9]),(Type::I64,vec![0x42,9]),(Type::F32,vec![0x43,0,0,0,0x80]),(Type::F64,vec![0x44,0,0,0,0,0,0,0,0x80])]{for explicit in [false,true]{let mut body=constant.clone();if explicit{body.push(0x0f);}body.push(0x0b);execute(&[(0,Function::scalar(&[0x10,36,0x0b],ty)),(2,Function::scalar(&body,ty))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();assert_eq!(result(s).unwrap().ty(),ty);assert_eq!(usage(p).live.values.current,0);assert!(p.phase.parts.frames.is_empty());});}}}
#[test]fn swift_dispatch_cd11_return_failure(){execute(&[(0,Function::scalar(&[0x41,7,0x0b],Type::I32))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{let base=usage(p).execution_work;let previous=p.phase.operation.control.test_replace_execution_work_limit(base+4);run(p,c,g,s).unwrap();assert_eq!(failure(s).kind,SwiftRunFailureKind::WorkExhausted);assert!(p.phase.parts.values.is_empty());p.phase.operation.control.test_replace_execution_work_limit(previous);});}
#[test]fn swift_dispatch_cd12_scalar_arms(){for(condition,expected)in[(0,2),(1,1)]{let body=[0x01,0x41,55,0x1a,0x41,1,0x41,2,0x41,condition,0x1b,0x0b];execute(&[(0,Function::scalar(&body,Type::I32))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();assert_eq!(result(s),Some(Value::I32(expected)));});}execute(&[(0,Function::void(&[0x00,0x0b]))],&[],SwiftRunBudget::default(),|p,c,g,s,starts|{run(p,c,g,s).unwrap();assert_eq!(failure(s).code,"unreachable");assert_eq!(failure(s).offset,Some(starts[0]));});}
#[test]fn swift_dispatch_cd13_local_arms(){let f=Function{params:vec![],result:Some(Type::I32),locals:vec![Type::I32],body:vec![0x41,17,0x21,0,0x20,0,0x22,0,0x0b]};execute(&[(0,f)],&[],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();assert_eq!(result(s),Some(Value::I32(17)));});}
#[test]fn swift_dispatch_cd14_global_arms(){execute(&[(0,Function::scalar(&[0x41,17,0x24,0,0x23,0,0x0b],Type::I32))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();assert_eq!(result(s),Some(Value::I32(17)));assert_eq!(p.phase.parts.globals[0],Value::I32(17));});}
#[test]fn swift_dispatch_cd15_all_control(){for selector in [0,1,2]{let body=[0x02,0x7f,0x41,9,0x41,selector,0x0e,1,0,0,0x0b,0x0b];execute(&[(0,Function::scalar(&body,Type::I32))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();assert_eq!(result(s),Some(Value::I32(9)));});}for condition in [0,1]{let body=[0x41,condition,0x04,0x7f,0x41,1,0x05,0x41,2,0x0b,0x0b];execute(&[(0,Function::scalar(&body,Type::I32))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();assert_eq!(result(s),Some(Value::I32(if condition==0{2}else{1})));});}}
#[test]fn swift_dispatch_cd16_numeric_memory(){execute(&[(0,Function::scalar(&[0x41,0,0x41,31,0x36,2,0,0x41,0,0x28,2,0,0x41,1,0x6a,0x0b],Type::I32))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();assert_eq!(result(s),Some(Value::I32(32)));assert_eq!(&p.phase.parts.memory[..4],&31i32.to_le_bytes());});execute(&[(0,Function::scalar(&[0x41,1,0x41,0,0x6d,0x0b],Type::I32))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();assert_eq!(failure(s).kind,SwiftRunFailureKind::GuestTrap);});}
#[test]fn swift_dispatch_cd17_bulk_growth(){execute(&[(0,Function::scalar(&[0x41,0,0x41,17,0x41,8,0xfc,11,0,0x41,2,0x41,0,0x41,6,0xfc,10,0,0,0x41,0,0x40,0,0x1a,0x3f,0,0x0b],Type::I32))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();assert_eq!(result(s),Some(Value::I32(584)));assert_eq!(&p.phase.parts.memory[..8],&[17;8]);});}
#[test]fn swift_dispatch_cd18_growth_completion(){execute(&[(0,Function::scalar(&[0x41,1,0x40,0,0x0b],Type::I32))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();assert_eq!(result(s),Some(Value::I32(584)));assert_eq!(p.phase.parts.memory.len(),585*PAGE);assert!(c.memory_ticket.as_ref().unwrap().matches_layout(SwiftReservationCategory::State,585*PAGE));assert!(g.transfer.ticket.is_none());assert!(g.transfer.old_ticket.is_none());});}
#[test]fn swift_dispatch_cd19_host_outcomes(){let index=WasiFunction::ALL.iter().position(|f|*f==WasiFunction::ProcExit).unwrap()as u8;for exit in [0,7]{execute(&[(0,Function::void(&[0x41,exit,0x10,index,0x0b]))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();assert_eq!(failure(s).kind,SwiftRunFailureKind::GuestExit);assert_eq!(failure(s).exit_code,Some(u32::from(exit)));assert_eq!(usage(p).host_calls,1);});}}
#[test]fn swift_dispatch_cd20_first_cause(){execute(&[(0,Function::void(&[0x00,0x0b]))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();let first=failure(s);p.phase.operation.control.cancellation().cancel();let second=p.invariant("later_failure");assert_eq!(first.code,second.code);assert_eq!(first.at_failure,second.at_failure);});}
#[test]fn swift_dispatch_cd21_terminal_drain(){execute(&[(0,Function::void(&[0x10,36,0x0b])),(2,Function::void(&[0x10,37,0x0b])),(3,Function::void(&[0x00,0x0b]))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();assert_eq!(p.phase.parts.frames.len(),3);let first=failure(s);let report=p.drain();assert_eq!(report.retained_frames,0);assert_eq!(report.first_failure.unwrap().code,first.code);assert_eq!(p.phase.parts.cache.usage().active_pins,0);s.drained=Some(report);});}
#[test]fn swift_dispatch_cd22_allocation_accounting(){execute(&[(0,Function::scalar(&[0x41,3,0x10,36,0x0b],Type::I32)),(2,Function{params:vec![Type::I32],result:Some(Type::I32),locals:vec![],body:vec![0x20,0,0x41,4,0x6a,0x0b]})],&[],SwiftRunBudget::default(),|p,c,g,s,_|{let mut warm=p.acquire_pin(36);assert!(warm.failure.is_none());p.release(warm.pin.take().unwrap(),36).unwrap();let(_,stats)=measure_extended(Some(0),||run(p,c,g,s).unwrap());assert_eq!(stats.attempts,0);assert_eq!(result(s),Some(Value::I32(7)));println!("CD22_WARM attempts={} alloc={} realloc={} frame={} header={} ticketsMax={}",stats.attempts,stats.allocations,stats.reallocations,FRAME_OPERATION_BYTES.unwrap(),execution_header_bytes().unwrap(),MAX_RESERVATION_TICKETS);});}
#[test]fn swift_dispatch_cd23_frozen_regression(){assert_eq!(MAX_RESERVATION_TICKETS,86);assert_eq!(SwiftRunBudget::default().state_bytes,128*1024*1024);assert_eq!(SwiftRunBudget::default().combined_bytes,256*1024*1024);execute(&[(0,Function::void(&[0x01,0x0b]))],&[],SwiftRunBudget::default(),|p,c,g,s,_|{run(p,c,g,s).unwrap();assert_eq!(result(s),None);});}
#[test]fn swift_dispatch_cd24_meaningful_program(){let yield_index=WasiFunction::ALL.iter().position(|f|*f==WasiFunction::SchedYield).unwrap()as u8;let body=[0x41,0,0x41,10,0x10,36,0x36,2,0,0x41,1,0x40,0,0x1a,0x10,yield_index,0x1a,0x41,0,0x28,2,0,0x0b];let callee=Function{params:vec![Type::I32],result:Some(Type::I32),locals:vec![],body:vec![0x20,0,0x41,2,0x6c,0x0b]};execute(&[(0,Function::scalar(&body,Type::I32)),(2,callee)],&[],SwiftRunBudget::default(),|p,c,g,s,_|{let before=usage(p);run(p,c,g,s).unwrap();assert_eq!(result(s),Some(Value::I32(20)));assert_eq!(&p.phase.parts.memory[..4],&20i32.to_le_bytes());assert_eq!(p.phase.parts.memory.len(),585*PAGE);assert_eq!(usage(p).host_calls,1);assert_eq!(usage(p).instructions-before.instructions,17);assert_eq!(usage(p).live.active_pins.current,0);println!("CD24_TRACE result=20 memoryI32=20 pages=585 imports=34 table=46713 instructions={} hostCalls=1 pins=0",usage(p).instructions-before.instructions);});}
