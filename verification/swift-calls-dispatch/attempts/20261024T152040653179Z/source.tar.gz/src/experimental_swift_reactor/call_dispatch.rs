//! Private full dispatcher over the original admitted owners. No lifecycle route.
use super::*;
use super::memory_growth_operations::{self as growth, SwiftGrowthContext, SwiftGrowthStorage, GrowthCompletion};
use crate::experimental::execution::borrowed::{shared_run, shared_call, shared_indirect};

fn check(phase: &mut FrameOperationPhase<'_>) -> Result<(), SwiftRunFailure> {
    phase.phase.operation.control.check_with_wasi(phase.phase.operation.cursor, Some(phase.phase.operation.wasi.usage()))
}
fn trap(phase: &mut FrameOperationPhase<'_>, code: &'static str) -> SwiftRunFailure {
    phase.phase.operation.control.fail(phase.phase.operation.cursor,
        Fault::new(SwiftRunFailureKind::GuestTrap, code), Some(phase.phase.operation.wasi.usage()))
}
fn pop_checked(phase: &mut FrameOperationPhase<'_>) -> Result<Value, SwiftRunFailure> {
    let before = phase.phase.parts.values.len();
    let outcome = phase.phase.pop_value();
    if outcome.is_err() && phase.phase.parts.values.len() != before { phase.cleanup.live_unreconciled = true; }
    outcome
}
fn typed_i32(phase: &mut FrameOperationPhase<'_>) -> Result<i32, SwiftRunFailure> {
    match pop_checked(phase)? { Value::I32(n) => Ok(n), _ => Err(phase.invariant("swift_dispatch_i32")) }
}
fn frame_guard(phase: &mut FrameOperationPhase<'_>) -> Result<(), SwiftRunFailure> {
    let frame = match phase.phase.parts.frames.last() {
        Some(frame) => frame, None => return Err(phase.invariant("swift_dispatch_frame_missing")),
    };
    if frame.base > frame.operands || frame.operands > phase.phase.parts.values.len()
        || frame.controls > phase.phase.parts.controls.len() {
        return Err(phase.invariant("swift_dispatch_frame_floor"));
    }
    // A finished function may have consumed its sentinel, but fetch may not.
    let sentinel = match phase.phase.parts.controls.get(frame.controls).copied() {
        Some(sentinel) => sentinel, None => return Err(phase.invariant("swift_dispatch_sentinel_missing")),
    };
    if !sentinel.is_function() || sentinel.height() != frame.operands || sentinel.result() != frame.result {
        return Err(phase.invariant("swift_dispatch_sentinel"));
    }
    Ok(())
}
fn fetch(phase: &mut FrameOperationPhase<'_>) -> Result<SelectedInstruction, SwiftRunFailure> {
    phase.active()?;
    check(phase)?;
    frame_guard(phase)?;
    // Attribute failed instruction metadata to the actual attempted frame/PC.
    let function = phase.phase.parts.frames.last().expect("checked original frame").function;
    phase.phase.operation.cursor.function = Some(function);
    phase.phase.operation.cursor.offset = None;
    let (instruction, branch_target) = {
        let frame = phase.phase.parts.frames.last().expect("checked original frame");
        let view = phase.phase.parts.cache.view(&frame.pin, phase.phase.operation.control, Some(&*phase.phase.operation.wasi))?;
        let instruction = match view.instructions.get(frame.pc).copied() {
            Some(instruction) => instruction, None => return Err(phase.invariant("swift_dispatch_instruction")),
        };
        phase.phase.operation.cursor.offset = Some(instruction.offset);
        let branch_target = if let Operation::BrTable { first, count, default } = instruction.operation {
            if phase.phase.parts.values.len() <= frame.operands { return Err(phase.invariant("swift_dispatch_branch_selector_floor")); }
            let selector = match phase.phase.parts.values.last() {
                Some(Value::I32(n)) => *n as u32 as usize, _ => return Err(phase.invariant("swift_dispatch_branch_selector_type")),
            };
            Some(if selector < count {
                let at = match first.checked_add(selector) { Some(at) => at, None => return Err(phase.invariant("swift_dispatch_branch_index")) };
                match view.branch_targets.get(at).copied() { Some(target) => target, None => return Err(phase.invariant("swift_dispatch_branch_bound")) }
            } else { default })
        } else { None };
        (instruction, branch_target)
    };
    Ok(SelectedInstruction { instruction, branch_target, cursor: phase.phase.operation.cursor })
}
fn prefix(phase: &mut FrameOperationPhase<'_>, instruction: DecodedInstruction) -> Result<(), SwiftRunFailure> {
    phase.phase.operation.cursor.offset = Some(instruction.offset);
    phase.phase.operation.control.instruction_with_wasi(phase.phase.operation.cursor, Some(phase.phase.operation.wasi.usage()))?;
    phase.work(1)?;
    let pc = match phase.phase.parts.frames.last().and_then(|frame| frame.pc.checked_add(1)) {
        Some(pc) => pc, None => return Err(phase.invariant("swift_dispatch_pc_overflow")),
    };
    phase.phase.parts.frames.last_mut().expect("active original frame").pc = pc;
    Ok(())
}
fn call_selected(phase: &mut FrameOperationPhase<'_>, function: u32, storage: &mut FrameOperationStorage<'_>) -> Result<(), SwiftRunFailure> {
    macro_rules! swift_call_leaf {
        (parameters $s:ident, $function:ident) => {{
            match $s.phase.parts.cache.proof().execution_signature($function) {
                Some(signature) => signature.params.len(), None => return Err($s.invariant("swift_dispatch_signature")),
            }
        }};
        (parameter_work $s:ident, $params:ident, $function:ident) => {{
            if ($function as usize) < $s.phase.parts.cache.proof().execution_imports().len() { Ok(()) } else { $s.work($params) }
        }};
        (base $s:ident, $params:ident, $base:ident) => {
            let $base = match $s.phase.parts.values.len().checked_sub($params) {
                Some(base) => base, None => return Err($s.invariant("swift_dispatch_parameters")),
            };
            frame_guard($s)?;
            if $base < $s.phase.parts.frames.last().expect("checked original caller").operands {
                return Err($s.invariant("swift_dispatch_parameter_floor"));
            }
        };
        (is_import $s:ident, $function:ident) => { ($function as usize) < $s.phase.parts.cache.proof().execution_imports().len() };
        (import $s:ident, $function:ident, $base:ident) => {{
            let _ = $base;
            $s.host_operation($function, &mut storage.entry)?;
            publication($s, storage)
        }};
    }
    shared_call!{phase, swift_call_leaf, function}
}
fn signature_mismatch(phase: &mut FrameOperationPhase<'_>, index: u32, function: u32) -> Result<bool, SwiftRunFailure> {
    check(phase)?;
    let expected_params = phase.phase.parts.cache.proof().execution_type(index).expect("retained validated type").params.len();
    let actual_params = phase.phase.parts.cache.proof().execution_signature(function).expect("retained validated signature").params.len();
    if expected_params != actual_params { check(phase)?; return Ok(true); }
    for at in 0..expected_params {
        if at != 0 && at % 64 == 0 { check(phase)?; }
        let expected = phase.phase.parts.cache.proof().execution_type(index).expect("retained validated type").params[at];
        let actual = phase.phase.parts.cache.proof().execution_signature(function).expect("retained validated signature").params[at];
        if expected != actual { check(phase)?; return Ok(true); }
    }
    let expected_result = phase.phase.parts.cache.proof().execution_type(index).expect("retained validated type").result;
    let actual_result = phase.phase.parts.cache.proof().execution_signature(function).expect("retained validated signature").result;
    check(phase)?;
    Ok(expected_result != actual_result)
}
fn indirect(phase: &mut FrameOperationPhase<'_>, index: u32, storage: &mut FrameOperationStorage<'_>) -> Result<(), SwiftRunFailure> {
    macro_rules! swift_indirect_leaf {
        (pop32 $s:ident) => { typed_i32($s) };
        (table_target $s:ident,$selector:ident) => {
            match $s.phase.parts.table.get($selector).copied() {
                None => return Err(trap($s,"table_out_of_bounds")),Some(None)=>return Err(trap($s,"indirect_call_null")),Some(Some(function))=>function,
            }
        };
        (expected_type $s:ident,$index:ident) => {
            match $s.phase.parts.cache.proof().execution_type($index) {
                Some(expected)=>expected,None=>return Err($s.invariant("swift_dispatch_expected_type")),
            }
        };
        (actual_type $s:ident,$function:ident) => {
            match $s.phase.parts.cache.proof().execution_signature($function) {
                Some(actual)=>actual,None=>return Err($s.invariant("swift_dispatch_actual_type")),
            }
        };
        (invariant $s:ident) => { $s.invariant("swift_dispatch_signature_work") };
        (signature_mismatch $s:ident,$index:ident,$function:ident) => {signature_mismatch($s,$index,$function)?};
        (trap $s:ident,$code:expr) => {trap($s,$code)};
        (call $s:ident,$function:ident) => {call_selected($s,$function,storage)};
    }
    shared_indirect! {phase,swift_indirect_leaf,index}
    Ok(())
}
fn local_slot(phase: &mut FrameOperationPhase<'_>, index: u32) -> Result<(usize, Type), SwiftRunFailure> {
    let frame = phase.phase.parts.frames.last().expect("checked original frame");
    let at = match frame.base.checked_add(index as usize) {
        Some(at) if at < frame.operands && at < phase.phase.parts.values.len() => at,
        _ => return Err(phase.invariant("swift_dispatch_local_slot")),
    };
    let signature = match phase.phase.parts.cache.proof().execution_signature(frame.function) {
        Some(signature) => signature, None => return Err(phase.invariant("swift_dispatch_local_signature")),
    };
    let ty = if let Some(ty) = signature.params.get(index as usize).copied() { ty } else {
        let local = match (index as usize).checked_sub(signature.params.len()) {
            Some(local) => local, None => return Err(phase.invariant("swift_dispatch_local_index")),
        };
        let view = phase.phase.parts.cache.view(&frame.pin, phase.phase.operation.control, Some(&*phase.phase.operation.wasi))?;
        match view.locals.get(local).copied() { Some(ty) => ty, None => return Err(phase.invariant("swift_dispatch_local_declaration")) }
    };
    Ok((at, ty))
}
fn local_get(phase: &mut FrameOperationPhase<'_>, index: u32) -> Result<(), SwiftRunFailure> {
    let (at, ty) = local_slot(phase, index)?;
    let value = phase.phase.parts.values[at];
    if value.ty() != ty { return Err(phase.invariant("swift_dispatch_local_value_type")); }
    phase.phase.push_value(value)
}
fn local_set(phase: &mut FrameOperationPhase<'_>, index: u32, tee: bool) -> Result<(), SwiftRunFailure> {
    let value = if tee {
        phase.work(1)?;
        let floor = phase.phase.parts.frames.last().expect("checked original frame").operands;
        if phase.phase.parts.values.len() <= floor { return Err(phase.invariant("swift_dispatch_tee_floor")); }
        *phase.phase.parts.values.last().expect("checked operand")
    } else { pop_checked(phase)? };
    let (at, ty) = local_slot(phase, index)?;
    if value.ty() != ty { return Err(phase.invariant("swift_dispatch_local_write_type")); }
    phase.phase.parts.values[at] = value;
    Ok(())
}
fn global_get(phase: &mut FrameOperationPhase<'_>, index: u32) -> Result<(), SwiftRunFailure> {
    let ty = match phase.phase.parts.cache.proof().execution_global(index as usize) {
        Some(descriptor) => descriptor.ty, None => return Err(phase.invariant("swift_dispatch_global_declaration")),
    };
    let value = match phase.phase.parts.globals.get(index as usize).copied() {
        Some(value) => value, None => return Err(phase.invariant("swift_dispatch_global_slot")),
    };
    if ty != value.ty() { return Err(phase.invariant("swift_dispatch_global_read_type")); }
    phase.phase.push_value(value)
}
fn global_set(phase: &mut FrameOperationPhase<'_>, index: u32) -> Result<(), SwiftRunFailure> {
    let value = pop_checked(phase)?;
    let (mutable, ty) = match phase.phase.parts.cache.proof().execution_global(index as usize) {
        Some(descriptor) => (descriptor.mutable, descriptor.ty), None => return Err(phase.invariant("swift_dispatch_global_declaration")),
    };
    if !mutable || ty != value.ty() { return Err(phase.invariant("swift_dispatch_global_write_type")); }
    match phase.phase.parts.globals.get_mut(index as usize) {
        Some(slot) => *slot = value, None => return Err(phase.invariant("swift_dispatch_global_slot")),
    }
    Ok(())
}
fn select_guard(phase: &mut FrameOperationPhase<'_>) -> Result<(), SwiftRunFailure> {
    let floor = phase.phase.parts.frames.last().expect("checked original frame").operands;
    let values = &phase.phase.parts.values;
    if values.len().checked_sub(floor).unwrap_or(0) < 3 { return Err(phase.invariant("swift_dispatch_select_count")); }
    if !matches!(values[values.len()-1], Value::I32(_)) || values[values.len()-2].ty() != values[values.len()-3].ty() {
        return Err(phase.invariant("swift_dispatch_select_type"));
    }
    Ok(())
}
fn publication(phase: &mut FrameOperationPhase<'_>, storage: &mut FrameOperationStorage<'_>) -> Result<(), SwiftRunFailure> {
    match storage.entry.as_ref() {
        Some(Err(failure)) => Err(*failure), Some(Ok(())) => { storage.entry.take(); Ok(()) }, None => Ok(()),
    }.map_err(|failure| { phase.terminal(); failure })
}
fn result_guard(phase: &mut FrameOperationPhase<'_>) -> Result<(), SwiftRunFailure> {
    let frame = phase.phase.parts.frames.last().expect("actual finished frame");
    let expected = match phase.phase.parts.cache.proof().execution_signature(frame.function) {
        Some(signature) => signature.result, None => return Err(phase.invariant("swift_dispatch_result_signature")),
    };
    if expected.is_some() != frame.result || frame.base > frame.operands || frame.operands > phase.phase.parts.values.len() {
        return Err(phase.invariant("swift_dispatch_result_floor"));
    }
    if let Some(expected) = expected {
        if phase.phase.parts.values.len() <= frame.operands || phase.phase.parts.values.last().map(|value| value.ty()) != Some(expected) {
            return Err(phase.invariant("swift_dispatch_result_type"));
        }
    }
    Ok(())
}
macro_rules! swift_control {
    (Block,$s:ident,$leaf:ident,$finished:ident,$kind:ident,$result:ident,$end:ident,$alternative:ident) => { $finished=$s.control_operation(Operation::Block{kind:$kind,result:$result,end:$end,alternative:$alternative},None)?; };
    (Else,$s:ident,$leaf:ident,$finished:ident,$end:ident) => { $finished=$s.control_operation(Operation::Else{end:$end},None)?; };
    (End,$s:ident,$leaf:ident,$finished:ident) => { $finished=$s.control_operation(Operation::End,None)?; };
    (Br,$s:ident,$leaf:ident,$finished:ident,$depth:ident) => { $finished=$s.control_operation(Operation::Br($depth),None)? };
    (BrIf,$s:ident,$leaf:ident,$finished:ident,$depth:ident) => { $finished=$s.control_operation(Operation::BrIf($depth),None)?; };
    (BrTable,$s:ident,$leaf:ident,$finished:ident,$target:ident) => { $finished=$s.control_operation(Operation::BrTable{first:0,count:0,default:0},$target)?; };
    (Return,$s:ident,$leaf:ident,$finished:ident) => { $finished=$s.control_operation(Operation::Return,None)? };
}
pub(super) fn run<'a>(phase: &mut FrameOperationPhase<'a>, context: &mut SwiftGrowthContext<'a>, pending: &mut SwiftGrowthStorage, storage: &mut FrameOperationStorage<'a>) -> Result<(), SwiftRunFailure> {
    if storage.entry.is_some() || storage.returned.is_some() || storage.controlled.is_some() || storage.drained.is_some() || storage.preparation.is_some() {
        let failure=phase.invariant("swift_dispatch_occupied");phase.terminal();return Err(failure);
    }
    macro_rules! swift_dispatch_leaf {
        (fetch $s:ident,$instruction:ident,$target:ident,$frame:ident) => {
            let selected=fetch($s)?; let $instruction=selected.instruction; let $target=selected.branch_target;
        };
        (prefix $s:ident,$instruction:ident,$frame:ident) => {prefix($s,$instruction)?;};
        (trap $s:ident,$code:expr) => {trap($s,$code)};
        (push $s:ident,$value:expr) => {$s.phase.push_value($value)};
        (pop $s:ident) => {pop_checked($s)};
        (pop32 $s:ident) => {typed_i32($s)};
        (select_guard $s:ident) => {select_guard($s)?;};
        (local_get $s:ident,$index:ident) => {local_get($s,$index)?;};
        (local_set $s:ident,$index:ident,$instruction:ident) => {local_set($s,$index,matches!($instruction.operation,Operation::LocalTee(_)))?;};
        (global_get $s:ident,$index:ident) => {global_get($s,$index)?;};
        (global_set $s:ident,$index:ident) => {global_set($s,$index)?;};
        (call $s:ident,$function:ident) => {call_selected($s,$function,storage)};
        (indirect $s:ident,$index:ident) => {indirect($s,$index,storage)?;};
        (memory_size $s:ident) => {$s.bulk_memory_operation(Operation::MemorySize,&mut storage.entry)};
        (copy $s:ident) => {$s.bulk_memory_operation(Operation::MemoryCopy,&mut storage.entry)};
        (fill $s:ident) => {$s.bulk_memory_operation(Operation::MemoryFill,&mut storage.entry)};
        (growth $s:ident) => {growth::growth_operation($s,context,pending,Operation::MemoryGrow,&mut storage.entry)};
        (load $s:ident,$opcode:ident,$offset:ident) => {$s.memory_operation(Operation::Load{opcode:$opcode,offset:$offset},&mut storage.entry)};
        (store $s:ident,$opcode:ident,$offset:ident) => {$s.memory_operation(Operation::Store{opcode:$opcode,offset:$offset},&mut storage.entry)};
        (numeric $s:ident,$opcode:ident) => {$s.phase.numeric_value($opcode,false)};
        (saturating $s:ident,$opcode:ident) => {$s.phase.numeric_value($opcode,true)};
        (publication $s:ident) => {publication($s,storage)?;};
        (finish $s:ident,$finished:ident) => {
            if $finished {result_guard($s)?;match $s.finish()? {FrameReturn::CallerContinues=>{},outer@FrameReturn::Outermost(_)=>return Ok(outer)}}
        };
    }
    let outcome=(|| {shared_run!(phase,swift_dispatch_leaf,swift_control,unused)})();
    if outcome.is_err(){phase.terminal();}
    storage.returned=Some(outcome);
    Ok(())
}
pub(super) fn complete<'a>(phase:FrameOperationPhase<'a>,context:SwiftGrowthContext<'a>,pending:SwiftGrowthStorage,storage:FrameOperationStorage<'a>,preparation:Option<Result<(FrameOperationPhase<'a>,SwiftGrowthContext<'a>),SwiftRunFailure>>) -> GrowthCompletion<'a> {
    growth::complete_growth(phase,context,pending,storage,preparation)
}
#[cfg(test)]
#[path="call_dispatch_tests.rs"]
mod tests;
