defmodule Oban.Pruner do
  @moduledoc """
  Periodically delete `completed`, `cancelled`, and `discarded` jobs based on their age.

  Pruning is critical for maintaining table size and continued responsive job processing. It
  is recommended for all production applications. See also the
  [*Operational Maintenance* guide](operational_maintenance.html).

  > #### 🌟 Oban Pro's Pruner {: .info}
  >
  > This plugin is limited to a fixed interval and a single `max_age` check for all jobs. To prune
  > on a cron-style schedule, retain jobs by a limit or age, provide override rules for select
  > queues/workers/states, and automatically archive select jobs, see
  > [`Oban.Pro.Pruner`](https://oban.pro/docs/pro/Oban.Pro.Pruner.html).

  ## Using the Plugin

  The following example demonstrates using the plugin without any configuration, which will prune
  jobs older than the default of 60 seconds:

      config :my_app, Oban,
        pruner: Oban.Pruner,
        ...

  Override the default options to prune jobs after 1 day:

      config :my_app, Oban,
        pruner: [max_age: {1, :day}],
        ...

  ## Options

  * `:interval` — the time between pruning attempts, as either an integer number of milliseconds
    or an `Oban.Period` tuple like `{30, :seconds}`. The default is `30_000ms`.

  * `:limit` — the maximum number of jobs to prune at one time. The default is 10,000 to prevent
    request timeouts. Applications that steadily generate more than 10k jobs a minute should
    increase this value.

  * `:max_age` — how long to keep jobs before they may be pruned, as either an integer number of
    seconds or an `Oban.Period` tuple like `{1, :day}`. Defaults to 60s.

  ## Instrumenting with Telemetry

  The `Oban.Pruner` plugin adds the following metadata to the `[:oban, :plugin, :stop]` event:

  * `:pruned_jobs` - the jobs that were deleted from the database

  When a run can't reach the database the list is empty, the count is zero, and an `:error` is
  added to the metadata, as described in `Oban.Telemetry`.

  _Note: jobs only include `id`, `queue`, `state` fields._
  """

  @behaviour Oban.Plugin

  use GenServer

  alias Oban.{Engine, Job, Peer, Period, Plugin, Repo, Validation}
  alias __MODULE__, as: State

  require Logger

  @type option ::
          Plugin.option()
          | {:interval, Period.t()}
          | {:limit, pos_integer()}
          | {:max_age, Period.t()}

  defstruct [
    :conf,
    :timer,
    interval: :timer.seconds(30),
    limit: 10_000,
    max_age: 60
  ]

  @doc false
  @spec child_spec(Keyword.t()) :: Supervisor.child_spec()
  def child_spec(opts), do: super(opts)

  @impl Plugin
  @spec start_link([option()]) :: GenServer.on_start()
  def start_link(opts) do
    {name, opts} = Keyword.pop(opts, :name)

    state = struct!(State, opts)

    state = %{
      state
      | interval: Period.to_milliseconds(state.interval),
        max_age: Period.to_seconds(state.max_age)
    }

    GenServer.start_link(__MODULE__, state, name: name)
  end

  @impl Plugin
  def validate(opts) do
    Validation.validate_schema(opts,
      conf: :any,
      name: :any,
      interval: :period,
      limit: :pos_integer,
      max_age: :period
    )
  end

  @impl Plugin
  def format_logger_output(_conf, meta), do: Map.take(meta, [:pruned_count])

  @impl GenServer
  def init(state) do
    Process.flag(:trap_exit, true)

    :telemetry.execute([:oban, :plugin, :init], %{}, %{conf: state.conf, plugin: __MODULE__})

    {:ok, schedule_prune(state)}
  end

  @impl GenServer
  def terminate(_reason, state) do
    if is_reference(state.timer), do: Process.cancel_timer(state.timer)

    :ok
  end

  @impl GenServer
  def handle_info(:prune, %State{} = state) do
    meta = %{conf: state.conf, plugin: __MODULE__}

    :telemetry.span([:oban, :plugin], meta, fn ->
      case check_leadership_and_delete_jobs(state) do
        {:ok, extra} ->
          {:ok, Map.merge(meta, extra)}

        {:error, error} ->
          {:error, Map.merge(meta, %{error: error, pruned_count: 0, pruned_jobs: []})}
      end
    end)

    {:noreply, schedule_prune(state)}
  end

  def handle_info(message, state) do
    Logger.warning(
      [
        message: "Received unexpected message: #{inspect(message)}",
        source: :oban,
        module: __MODULE__
      ],
      domain: [:oban]
    )

    {:noreply, state}
  end

  defp schedule_prune(state) do
    %{state | timer: Process.send_after(self(), :prune, state.interval)}
  end

  defp check_leadership_and_delete_jobs(state) do
    if Peer.leader?(state.conf) do
      fun = fn ->
        {:ok, jobs} =
          Engine.prune_jobs(state.conf, Job, limit: state.limit, max_age: state.max_age)

        %{pruned_count: length(jobs), pruned_jobs: jobs}
      end

      Repo.transaction(state.conf, fun, on_exhausted: :log)
    else
      {:ok, %{pruned_count: 0, pruned_jobs: []}}
    end
  end
end
