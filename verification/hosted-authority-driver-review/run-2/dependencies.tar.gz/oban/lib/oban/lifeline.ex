defmodule Oban.Lifeline do
  @moduledoc """
  Naively transition jobs stuck `executing` back to `available`.

  The `Lifeline` plugin periodically rescues orphaned jobs, i.e. jobs that are stuck in the
  `executing` state because the node was shut down before the job could finish. Rescuing is
  purely based on time, rather than any heuristic about the job's expected execution time or
  whether the node is still alive.

  If an executing job has exhausted all attempts, the Lifeline plugin will mark it `discarded`
  rather than `available`.

  > #### 🌟 Oban Pro's Lifeline {: .info}
  >
  > This plugin may transition jobs that are genuinely `executing` and cause duplicate execution.
  > For more accurate rescuing or to rescue jobs that have exhausted retry attempts, see
  > [`Oban.Pro.Lifeline`](https://oban.pro/docs/pro/Oban.Pro.Lifeline.html).

  ## Using the Plugin

  Rescue orphaned jobs that are still `executing` after the default of 1 hour:

      config :my_app, Oban,
        lifeline: Oban.Lifeline,
        ...

  Override the default period to rescue orphans after a more aggressive period of 5 minutes:

      config :my_app, Oban,
        lifeline: [rescue_after: {5, :minutes}],
        ...

  ## Options

  * `:interval` — the time between rescue attempts, as either an integer number of milliseconds
    or an `Oban.Period` tuple like `{1, :minute}`. The default is `60_000ms`.

  * `:rescue_after` — the maximum amount of time a job may execute before being rescued, as either
    an integer number of milliseconds or an `Oban.Period` tuple like `{1, :hour}`. 1 hour
    by default, and rescuing is performed once a minute.

  ## Instrumenting with Telemetry

  The `Oban.Lifeline` plugin adds the following metadata to the `[:oban, :plugin, :stop]`
  event:

  * `:rescued_jobs` — a list of jobs transitioned back to `available`

  * `:discarded_jobs` — a list of jobs transitioned to `discarded`

  When a run can't reach the database both lists are empty and an `:error` is added to the
  metadata, as described in `Oban.Telemetry`.

  _Note: jobs only include `id`, `queue`, `state` fields._
  """

  @behaviour Oban.Plugin

  use GenServer

  alias Oban.{Engine, Job, Peer, Period, Plugin, Repo, Validation}
  alias __MODULE__, as: State

  require Logger

  @type option ::
          Plugin.option()
          | {:interval, Period.t()}
          | {:rescue_after, Period.t()}

  defstruct [
    :conf,
    :timer,
    interval: :timer.minutes(1),
    rescue_after: :timer.minutes(60)
  ]

  @doc false
  @spec child_spec(Keyword.t()) :: Supervisor.child_spec()
  def child_spec(opts), do: super(opts)

  @impl Plugin
  @spec start_link([option()]) :: GenServer.on_start()
  def start_link(opts) do
    {name, opts} = Keyword.pop(opts, :name)

    state = struct!(State, opts)

    state = %{
      state
      | interval: Period.to_milliseconds(state.interval),
        rescue_after: Period.to_milliseconds(state.rescue_after)
    }

    GenServer.start_link(__MODULE__, state, name: name)
  end

  @impl Plugin
  def validate(opts) do
    Validation.validate_schema(opts,
      conf: :any,
      name: :any,
      interval: :period,
      rescue_after: :period
    )
  end

  @impl Plugin
  def format_logger_output(_conf, meta) do
    for {key, val} <- meta,
        key in ~w(discarded_jobs rescued_jobs)a,
        into: %{},
        do: {key, Enum.map(val, & &1.id)}
  end

  @impl GenServer
  def init(state) do
    :telemetry.execute([:oban, :plugin, :init], %{}, %{conf: state.conf, plugin: __MODULE__})

    {:ok, schedule_rescue(state)}
  end

  @impl GenServer
  def terminate(_reason, %State{timer: timer}) do
    if is_reference(timer), do: Process.cancel_timer(timer)

    :ok
  end

  @impl GenServer
  def handle_info(:rescue, %State{} = state) do
    meta = %{conf: state.conf, plugin: __MODULE__}

    :telemetry.span([:oban, :plugin], meta, fn ->
      case check_leadership_and_rescue_jobs(state) do
        {:ok, extra} ->
          {:ok, Map.merge(meta, extra)}

        {:error, error} ->
          {:error, Map.merge(meta, %{discarded_jobs: [], error: error, rescued_jobs: []})}
      end
    end)

    {:noreply, schedule_rescue(state)}
  end

  def handle_info(message, state) do
    Logger.warning(
      [
        message: "Received unexpected message: #{inspect(message)}",
        source: :oban,
        module: __MODULE__
      ],
      domain: [:oban]
    )

    {:noreply, state}
  end

  # Scheduling

  defp schedule_rescue(state) do
    timer = Process.send_after(self(), :rescue, state.interval)

    %{state | timer: timer}
  end

  # Rescuing

  defp check_leadership_and_rescue_jobs(state) do
    if Peer.leader?(state.conf) do
      fun = fn ->
        {:ok, rescued} = Engine.rescue_jobs(state.conf, Job, rescue_after: state.rescue_after)

        {rescued, discarded} = Enum.split_with(rescued, &(&1.state == "available"))

        %{discarded_jobs: discarded, rescued_jobs: rescued}
      end

      Repo.transaction(state.conf, fun, on_exhausted: :log)
    else
      {:ok, %{discarded_jobs: [], rescued_jobs: []}}
    end
  end
end
