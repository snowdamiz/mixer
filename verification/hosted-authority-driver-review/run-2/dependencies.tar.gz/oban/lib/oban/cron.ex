defmodule Oban.Cron do
  @moduledoc """
  Periodically enqueue jobs through [cron](https://en.wikipedia.org/wiki/Cron)-based scheduling.

  This plugin registers workers a cron-like schedule and enqueues jobs automatically. To know
  more about periodic jobs in Oban, see the [*Periodic Jobs* guide][perjob].

  > #### 🌟 Oban Pro's Cron {: .info}
  >
  > This plugin only loads the crontab statically, at boot time. To configure cron scheduling at
  > runtime, globally, across an entire cluster with scheduling guarantees and management tools,
  > see [`Oban.Pro.Cron`](https://oban.pro/docs/pro/Oban.Pro.Cron.html).

  ## Usage

  Periodic jobs are declared as a list of `{cron, worker}` or `{cron, worker, options}` tuples:

  ```elixir
  config :my_app, Oban,
    cron: [
      crontab: [
        {"* * * * *", MyApp.MinuteWorker},
        {"0 * * * *", MyApp.HourlyWorker, args: %{custom: "arg"}},
        {"0 0 * * *", MyApp.DailyWorker, max_attempts: 1},
        {"0 9 * * *", MyApp.LocalWorker, timezone: "America/Chicago"},
        {"0 12 * * MON", MyApp.MondayWorker, queue: :scheduled, tags: ["mondays"]},
        {"@daily", MyApp.AnotherDailyWorker}
      ]
    ]
  ```

  ### Identifying Cron Jobs

  Jobs inserted by the cron plugin are marked with a `cron` flag and the _original_ expression is
  stored as `cron_expr` in the job's `meta` field. For example, the meta for a `@daily` cron job
  would look like this:

  ```elixir
  %Oban.Job{meta: %{"cron" => true, "cron_expr" => "@daily", "cron_tz" => "Etc/UTC"}}
  ```

  ## Options

  You can pass the following options to this plugin:

  * `:crontab` — a list of cron expressions that enqueue jobs on a periodic basis. See [*Periodic
    Jobs* guide][perjob] for syntax and details.

  * `:timezone` — which timezone to use when scheduling cron jobs. To use a timezone other than
    the default of `Etc/UTC` you *must* have a timezone database like [tz][tz] installed and
    configured. Individual crontab entries may override the default by specifying `:timezone` in
    their options.

  ## Instrumenting with Telemetry

  The `Oban.Cron` plugin adds the following metadata to the `[:oban, :plugin, :stop]`
  event (see `Oban.Telemetry`):

  * `:jobs` — a list of jobs that were inserted into the database

  When a run can't reach the database the list is empty and an `:error` is added to the metadata,
  as described in `Oban.Telemetry`.

  [tz]: https://tz.hexdocs.pm
  [perjob]: periodic_jobs.html
  """

  @behaviour Oban.Plugin

  use GenServer

  alias Oban.Cron.Expression
  alias Oban.{Job, Peer, Plugin, Repo, Validation, Worker}
  alias __MODULE__, as: State

  require Logger

  @opaque expression :: Expression.t()

  @type cron_input :: {binary(), module()} | {binary(), module(), [cron_option()]}
  @type cron_option :: Job.option() | {:timezone, Calendar.time_zone()}

  @type option ::
          Plugin.option()
          | {:crontab, [cron_input()]}
          | {:timezone, Calendar.time_zone()}

  defstruct [
    :conf,
    :timer,
    crontab: [],
    timezone: "Etc/UTC"
  ]

  @doc false
  @spec child_spec(Keyword.t()) :: Supervisor.child_spec()
  def child_spec(opts), do: super(opts)

  @impl Plugin
  @spec start_link([option()]) :: GenServer.on_start()
  def start_link(opts) do
    {name, opts} = Keyword.pop(opts, :name)

    state =
      State
      |> struct!(opts)
      |> parse_crontab()

    GenServer.start_link(__MODULE__, state, name: name)
  end

  @impl Plugin
  def validate(opts) do
    Validation.validate_schema(opts,
      conf: :any,
      crontab: {:custom, &validate_crontab/1},
      name: :any,
      timezone: :timezone
    )
  end

  @impl Plugin
  def format_logger_output(_conf, %{jobs: jobs}), do: %{jobs: Enum.map(jobs, & &1.id)}

  @doc """
  Parse a crontab expression into a cron struct.

  This is provided as a convenience for validating and testing cron expressions. As such, the cron
  struct itself is opaque and the internals may change at any time.

  The parser can handle common expressions that use minutes, hours, days, months and weekdays,
  along with ranges and steps. It also supports common extensions, also called nicknames.

  Returns `{:error, %ArgumentError{}}` with a detailed error if the expression cannot be parsed.

  ## Nicknames

  The following special nicknames are supported in addition to standard cron expressions:

    * `@yearly`—Run once a year, "0 0 1 1 *"
    * `@annually`—Same as `@yearly`
    * `@monthly`—Run once a month, "0 0 1 * *"
    * `@weekly`—Run once a week, "0 0 * * 0"
    * `@daily`—Run once a day, "0 0 * * *"
    * `@midnight`—Same as `@daily`
    * `@hourly`—Run once an hour, "0 * * * *"
    * `@reboot`—Run once at boot

  ## Examples

      iex> Oban.Cron.parse("@hourly")
      {:ok, #Oban.Cron.Expression<...>}

      iex> Oban.Cron.parse("0 * * * *")
      {:ok, #Oban.Cron.Expression<...>}

      iex> Oban.Cron.parse("60 * * * *")
      {:error, %ArgumentError{message: "expression field 60 is out of range 0..59"}}
  """
  @spec parse(input :: binary()) :: {:ok, expression()} | {:error, Exception.t()}
  defdelegate parse(input), to: Expression

  @doc false
  @spec schedule_interval(pid(), term(), binary(), Calendar.time_zone()) :: :ok
  def schedule_interval(pid, message, schedule, timezone \\ "Etc/UTC") do
    :timer.apply_after(
      interval_to_next_minute(),
      __MODULE__,
      :__schedule_interval__,
      [pid, message, schedule, timezone]
    )

    :ok
  end

  @doc false
  def __schedule_interval__(pid, message, schedule, timezone) do
    exp = Expression.parse!(schedule)
    now = DateTime.now!(timezone)

    if Expression.now?(exp, now) do
      send(pid, message)
    end

    schedule_interval(pid, message, schedule, timezone)
  end

  @doc false
  @spec interval_to_next_minute(Time.t()) :: pos_integer()
  def interval_to_next_minute(time \\ Time.utc_now()) do
    time
    |> Time.add(60)
    |> Map.put(:second, 0)
    |> Time.diff(time)
    |> Integer.mod(86_400)
    |> :timer.seconds()
  end

  @doc false
  def entry_name({expr, worker, opts}) do
    opts =
      opts
      |> Map.new()
      |> stringify()
      |> Map.replace_lazy("args", &stringify/1)

    {expr, Worker.to_string(worker), opts}
    |> :erlang.phash2()
    |> to_string()
  end

  defp stringify(map) when is_map(map) do
    Map.new(map, fn {key, val} -> {to_string(key), val} end)
  end

  defp stringify(val), do: val

  @impl GenServer
  def init(state) do
    Process.flag(:trap_exit, true)

    :telemetry.execute([:oban, :plugin, :init], %{}, %{conf: state.conf, plugin: __MODULE__})

    {:ok, schedule_evaluate(state)}
  end

  @impl GenServer
  def terminate(_reason, %State{timer: timer}) do
    if is_reference(timer), do: Process.cancel_timer(timer)

    :ok
  end

  @impl GenServer
  def handle_info(:evaluate, %State{} = state) do
    if Peer.leader?(state.conf) do
      insert_scheduled_jobs(state)

      {:noreply,
       state
       |> discard_reboots()
       |> schedule_evaluate()}
    else
      {:noreply, schedule_evaluate(state)}
    end
  end

  def handle_info(message, state) do
    Logger.warning(
      [
        message: "Received unexpected message: #{inspect(message)}",
        source: :oban,
        module: __MODULE__
      ],
      domain: [:oban]
    )

    {:noreply, state}
  end

  # Parsing & Validation Helpers

  defp parse_crontab(%State{crontab: crontab} = state) do
    parsed =
      Enum.map(crontab, fn
        {expr, worker} ->
          {expr, Expression.parse!(expr), worker, [], state.timezone}

        {expr, worker, opts} ->
          timezone = Keyword.get(opts, :timezone, state.timezone)

          {expr, Expression.parse!(expr), worker, opts, timezone}
      end)

    %{state | crontab: parsed}
  end

  defp validate_crontab(crontab) when is_list(crontab) do
    Validation.validate(:crontab, crontab, &validate_crontab/1)
  end

  defp validate_crontab({expr, worker, opts}) when is_list(opts) do
    timezone = Keyword.get(opts, :timezone, "Etc/UTC")

    with {:ok, _} <- parse(expr),
         :ok <- Validation.validate_timezone(:timezone, timezone) do
      cond do
        not Code.ensure_loaded?(worker) ->
          {:error, "#{inspect(worker)} not found or can't be loaded"}

        not function_exported?(worker, :perform, 1) ->
          {:error, "#{inspect(worker)} does not implement `perform/1` callback"}

        not Keyword.keyword?(opts) ->
          {:error, "options must be a keyword list, got: #{inspect(opts)}"}

        not build_changeset(worker, opts, expr, timezone).valid? ->
          {:error, "expected valid job options, got: #{inspect(opts)}"}

        true ->
          :ok
      end
    end
  end

  defp validate_crontab({expr, worker}) do
    validate_crontab({expr, worker, []})
  end

  defp validate_crontab({_expr, _worker, opts}) do
    {:error, "options must be a keyword list, got: #{inspect(opts)}"}
  end

  defp validate_crontab(invalid) do
    {:error,
     "expected crontab entry to be an {expression, worker} or " <>
       "{expression, worker, options} tuple, got: #{inspect(invalid)}"}
  end

  # Scheduling Helpers

  defp schedule_evaluate(state) do
    timer = Process.send_after(self(), :evaluate, interval_to_next_minute())

    %{state | timer: timer}
  end

  # Inserting Helpers

  defp discard_reboots(state) do
    crontab =
      Enum.reject(state.crontab, fn {_expr, parsed, _worker, _opts, _timezone} ->
        parsed.reboot?
      end)

    %{state | crontab: crontab}
  end

  defp insert_scheduled_jobs(state) do
    fun = fn ->
      now = DateTime.utc_now()

      for {expr, parsed, worker, opts, timezone} <- state.crontab,
          Expression.now?(parsed, DateTime.shift_zone!(now, timezone)) do
        Oban.insert!(state.conf.name, build_changeset(worker, opts, expr, timezone))
      end
    end

    meta = %{conf: state.conf, plugin: __MODULE__}

    :telemetry.span([:oban, :plugin], meta, fn ->
      case Repo.transaction(state.conf, fun, on_exhausted: :log) do
        {:ok, inserted_jobs} ->
          {:ok, Map.put(meta, :jobs, inserted_jobs)}

        {:error, error} ->
          {:error, Map.merge(meta, %{error: error, jobs: []})}
      end
    end)
  end

  defp build_changeset(worker, opts, expr, timezone) do
    name = entry_name({expr, worker, opts})

    {args, opts} =
      opts
      |> Keyword.delete(:timezone)
      |> Keyword.pop(:args, %{})

    meta = %{cron: true, cron_expr: expr, cron_name: name, cron_tz: timezone}

    opts =
      worker.__opts__()
      |> Worker.merge_opts(opts)
      |> Keyword.update(:meta, meta, &Map.merge(&1, meta))

    worker.new(args, opts)
  end
end
