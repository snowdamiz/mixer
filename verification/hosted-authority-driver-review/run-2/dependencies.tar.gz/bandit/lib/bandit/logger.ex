defmodule Bandit.Logger do
  @moduledoc false

  require Logger

  # Posix reasons that a peer socket can surface as once the client has gone away.
  # `:closed` is the common case, but an abortive close (RST) can also surface as
  # `:enotconn` / `:einval` / `:econnaborted` / `:econnreset` depending on platform
  # and on how far along the connection was when the peer disappeared.
  @client_closure_errors [:closed, :enotconn, :einval, :econnaborted, :econnreset]

  def maybe_log_protocol_error(error, stacktrace, opts, metadata) do
    logging_verbosity =
      case error do
        %Bandit.TransportError{error: transport_error}
        when transport_error in @client_closure_errors ->
          Keyword.get(opts.http, :log_client_closures, false)

        _error ->
          Keyword.get(opts.http, :log_protocol_errors, :short)
      end

    case logging_verbosity do
      :short ->
        logger_metadata = logger_metadata_for(:error, error, stacktrace, metadata)
        Logger.error(Exception.format_banner(:error, error, stacktrace), logger_metadata)

      :verbose ->
        logger_metadata = logger_metadata_for(:error, error, stacktrace, metadata)
        Logger.error(Exception.format(:error, error, stacktrace), logger_metadata)

      false ->
        :ok
    end
  end

  def maybe_log_websocket_protocol_error(reason, connection) do
    case Keyword.get(connection.opts, :log_protocol_errors, :short) do
      false ->
        :ok

      _short_or_verbose ->
        logger_metadata = logger_metadata_for(:exit, reason, [], websock: connection.websock)
        Logger.error(Exception.format_banner(:exit, reason), logger_metadata)
    end
  end

  def logger_metadata_for(kind, reason, stacktrace, metadata) do
    crash_reason = crash_reason(kind, reason, stacktrace)

    case reason do
      %Bandit.HTTP2.Errors.StreamError{stream_id: stream_id} when is_integer(stream_id) ->
        [stream_id: stream_id, domain: [:bandit], crash_reason: crash_reason]
        |> Keyword.merge(metadata)

      _ ->
        [domain: [:bandit], crash_reason: crash_reason]
        |> Keyword.merge(metadata)
    end
  end

  defp crash_reason(:throw, reason, stacktrace), do: {{:nocatch, reason}, stacktrace}
  defp crash_reason(_, reason, stacktrace), do: {reason, stacktrace}
end
