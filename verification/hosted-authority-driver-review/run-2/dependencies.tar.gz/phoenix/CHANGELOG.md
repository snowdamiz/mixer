# Changelog for v1.8

This release requires Erlang/OTP 25+.

## Streamlined generators

  * Extend tailwindcss support in new apps with [daisyUI](https://daisyui.com/) for light/dark/system mode support for entire app, including core components
  * Simplify layout handling for new apps. Now there is only a single `root.html.heex` which wraps the render pipeline. Other dynamic layouts, like `app.html.heex` are called as needed within templates as regular function components
  * Simplify core components and live generators to more closely match basic `phx.gen.html` crud. This serves as a better base for seasoned devs to start with, and lessens the amount of code newcomers need to get up to speed with on the basics
  * Introduce magic links (passwordless auth) and "sudo mode" to `mix phx.gen.auth` while simplifying the generated structure
  * Introduce scopes to Phoenix generators, designed to make secure data access the *default*, not something you remember (or forget) to do later

## `put_secure_browser_headers`

`put_secure_browser_headers` has been updated to the latest security practices. In particular, it sets the `content-security-policy` header to `"base-uri 'self'; frame-ancestors 'self';"` if none is set, restricting embedding of your application and the use of `<base>` element to same origin respectively. If you expect your application to be embedded by third-parties, you want to consult the documentation.

The headers `x-download-options` and `x-frame-options` are no longer set as they have been deprecated by standards.

## Deprecations

This release introduces deprecation warnings for several features that have been soft-deprecated in the past.

  * `use Phoenix.Controller` must now specify the `:formats` option, which may be set to an empty list if the formats are not known upfront
  * The `:namespace` and `:put_default_views` options on `use Phoenix.Controller` are deprecated and emit a warning on use
  * Specifying layouts without modules, such as `put_layout(conn, :print)` or `put_layout(conn, html: :print)` is deprecated
  * The `:trailing_slash` option in `Phoenix.Router` has been deprecated in favor of using `Phoenix.VerifiedRoutes`. The overall usage of helpers will be deprecated in the future

## Potential breaking changes

  * The `config` variable is no longer available in `Phoenix.Endpoint`. In the past, it was possible to read your endpoint configuration at compile-time via an injected variable named `config`, which is no longer supported. Use `Application.compile_env/3` instead, which is tracked by the Elixir compiler and lead to a better developer experience. This may also lead to errors on application boot if you were previously incorrectly setting compile time config at runtime.

## v1.8.16 (2026-10-20)

### Bug fixes

* [phoenix.js] Fix a lot of connection handling races ([#6867](https://github.com/phoenixframework/phoenix/pull/6867))
* [phoenix.js] Don't treat WebSocket close code 1000 as special ([#6880](https://github.com/phoenixframework/phoenix/pull/6880))

### Enhancements

* Allow setting `max_channels_per_transport` in `Phoenix.Endpoint.socket/3`

## v1.8.15 (2026-09-25)

### Bug fixes

* [phx.gen.cert] Fix certificate not being accepted by Chromium ([#6847](https://github.com/phoenixframework/phoenix/issues/6847))
* [phoenix.js] Fix asynchronous transport close tearing down the replacement transport ([#6852](https://github.com/phoenixframework/phoenix/issues/6852))

### Enhancements

* [phx.new] Update Tailwind version to 4.3.3

## v1.8.14 (2026-09-14)

### Bug fixes

* Fix timer leak in LongPoll fetch requests (only used in service or web workers) ([#6811](https://github.com/phoenixframework/phoenix/pull/6811))

### Enhancements

* Raise when `:router` given to `use Phoenix.VerifiedRoutes` is not a compile time literal ([#6806](https://github.com/phoenixframework/phoenix/pull/6806))
* Align `nil` host handling in endpoint configuration and transport
* Unify path validation for static paths, verified routes and redirects

## v1.8.13 (2026-08-25)

### Bug fixes

* Workaround issue where Mobile Chrome 149+ would not reconnect after tab is resumed ([#6804](https://github.com/phoenixframework/phoenix/issues/6804))

## v1.8.12 (2026-08-20)

### Bug fixes

* [phx.gen.auth] Fix return_to session key not being cleared after logging in ([#6798](https://github.com/phoenixframework/phoenix/issues/6798))
* [Channels] Fix channel messages being invalidly dropped when receiving messages without a join_ref (introduced in 1.8.3) ([#6800](https://github.com/phoenixframework/phoenix/pull/6800))

## v1.8.11 (2026-08-12)

### Bug fixes

* Fix Phoenix crashing on boot if Mix is available, but not started ([#6789](https://github.com/phoenixframework/phoenix/issues/6789))

## v1.8.10 (2026-08-10)

### Bug fixes

* [Phoenix.CodeReloader] Fix "must restart your server" messages from code reloader when compile.lock mtime changes without a content change ([#6753](https://github.com/phoenixframework/phoenix/issues/6753))
* [Phoenix.Endpoint] add missing websocket options ([#6758](https://github.com/phoenixframework/phoenix/pull/6758))
* [phoenix.js] Close and retry the longpoll transport when a batch POST times out ([#6769](https://github.com/phoenixframework/phoenix/pull/6769))
* [phoenix.js] Release the stale reply binding of a buffered push ([#6788](https://github.com/phoenixframework/phoenix/pull/6788))

### Enhancements

* [phx.gen.release] Use Bob API to find Docker images in `phx.gen.release --docker`
* [Channels] Allow LongPoll transport token to be sent in header (this will change in 1.9)
* [Phoenix.Router] Support plugs with options in `pipe_throught` ([#6755](https://github.com/phoenixframework/phoenix/pull/6755))
* [Phoenix.Token] document encode options (see [the change in plug_crypto](https://github.com/elixir-plug/plug_crypto/commit/35dd3d3da1b8b2e0009e3efc40bc67d3822f7210))
* [phoenix.js] Ensure transport errors are identifiable ([#6763](https://github.com/phoenixframework/phoenix/pull/6763))

## v1.8.9 (2026-07-07)

### Security fixes
- [CVE-2026-56811](https://github.com/phoenixframework/phoenix/security/advisories/GHSA-6983-jfq8-485w): Add a `max_channels_per_transport` option (defaulting to 100) to prevent a single client from spawning an unbounded number of channels (processes), eventually exhausting the server's memory or process limit.
- [CVE-2026-56812](https://github.com/phoenixframework/phoenix/security/advisories/GHSA-63mc-hw7g-86rr): Prevent presence keys from colliding with `Object.prototype` properties members, crashing the JS Presence client
- Enforce longpoll batch size introduced in 1.8.6. This is additional hardening against [CVE-2026-32689](https://github.com/phoenixframework/phoenix/security/advisories/GHSA-628h-q48j-jr6q). If your application sends events with a very high frequency and uses long polling, such that a single longpoll request would exceed 100 events, you should update to 1.8.7 first.

## v1.8.8 (2026-06-10)

### Enhancements
- [phx.new] Use LiveView 1.2.0

## v1.8.7 (2026-05-06)

### Bug fixes
- Fix invalid status when longpoll request times out

### Enhancements
- Mask `token` parameter [in logs](https://phoenix.hexdocs.pm/Phoenix.Logger.html#module-parameter-filtering) by default (in addition to "password")

### JavaScript Client Bug Fixes
- Fix encoding of non-ASCII metadata in binary channel messages

## v1.8.6 (2026-05-05)

### Security fixes
- [CVE-2026-32689](https://github.com/phoenixframework/phoenix/security/advisories/GHSA-628h-q48j-jr6q): Fix Phoenix.Socket Longpoll transport memory exhaustion in nd-JSON body splitting

### Enhancements
- [phoenix] Raise if `use Phoenix.VerifiedRoutes` is called multiple times in the same module
- [phoenix] Fix more deprecation and type checker warnings on Elixir 1.20
- [phoenix] Raise when interpolating a list in `Phoenix.VerifiedRoutes` ([#6632](https://github.com/phoenixframework/phoenix/pull/6632))
- [phoenix] Gracefully handle non-binary `vsn` socket parameter ([#6662](https://github.com/phoenixframework/phoenix/pull/6662))
- [phx.gen.*] Use `.eex` filename suffix in generator files
- [phx.new] Add interactive mode: `mix phx.new --interactive` ([#6630](https://github.com/phoenixframework/phoenix/pull/6630))
- [phx.new] Add `phx-no-format` to generated `<.live_title>` tag ([#6667](https://github.com/phoenixframework/phoenix/pull/6667))

### Bug fixes
- [phx.gen.*] Fix generated migrations for myxql when using scopes ([#6635](https://github.com/phoenixframework/phoenix/pull/6635))
- [phx.new] Fix crash when parent directory contains a colon ([#6633](https://github.com/phoenixframework/phoenix/pull/6633))

## v1.8.5 (2026-03-05)

### JavaScript Client Bug Fixes
- Fix socket connecting on visibility change when never established

### Enhancements
- Fix warnings on Elixir 1.20

## v1.8.4 (2026-02-23)

### JavaScript Client Bug Fixes
- Fix bug reconnecting connections when close was gracefully initiated by server
- Fix LongPoll transport name in sessionStorage and logs

### Enhancements
- Adds guards support in `assert_push`, `assert_broadcast`, and `assert_reply`
- Enable purging in Phoenix code server for Elixir 1.20

## v1.8.3 (2025-12-08)

### Enhancements
- Add top-level phoenix config: `sort_verified_routes_query_params` to enable sorting query params in verified routes during tests

### Bug fixes
- Fix endpoint port config in an umbrella application. ([#6549](https://github.com/phoenixframework/phoenix/pull/6549))
- Drop incoming channel messages with stale join refs

## v1.8.2 (2025-11-26)

### Bug fixes
- [phoenix.js] fix issue where LongPoll can cause "unmatched topic" errors (observed on iOS only) ([#6538](https://github.com/phoenixframework/phoenix/pull/6538))
- [phx.gen.live] fix tests when schema and table names are equal ([#6477](https://github.com/phoenixframework/phoenix/pull/6477))
- [Verified Routes] do not add path prefixes for static routes
- [Phoenix.Endpoint] fix LongPoll being active by default since 1.8.0 ([#6487](https://github.com/phoenixframework/phoenix/pull/6487))

### Enhancements
- [phoenix.js] socket now stops reconnection attempts while the page is hidden ([#6534](https://github.com/phoenixframework/phoenix/pull/6534))
- [phx.new] (re-)add `<.input field={@form[:foo]} type="hidden" />` support in core components
- [phx.new] set `force_ssl` in `prod.exs` by default ([#6435](https://github.com/phoenixframework/phoenix/pull/6435))
- [phx.new] change `--docker` base image to debian trixie ([#6521](https://github.com/phoenixframework/phoenix/pull/6521))
- [Phoenix.Socket.assign/2] allow passing a function as second argument `assign(socket, fn _existing_assigns -> %{this_gets: "merged"} end)` ([#6530](https://github.com/phoenixframework/phoenix/pull/6530))
- [Phoenix.Controller.assign/2] allow passing a function as second argument ([#6542](https://github.com/phoenixframework/phoenix/pull/6542))
- [Phoenix.Controller.assign/2] support keyword lists and maps as second argument similar to LiveView ([#6513](https://github.com/phoenixframework/phoenix/pull/6513))
- [Presence] support custom dispatcher for `presence_diff` broadcast ([#6500](https://github.com/phoenixframework/phoenix/pull/6500))
- [AGENTS.md] add short test guidelines to usage rules

## v1.8.1 (2025-08-28)

### Bug fixes
- [phx.new] Fix AGENTS.md failing to include CSS and JavaScript sections

## v1.8.0 (2025-08-05)

### Bug fixes
- [phx.new] Don't include node_modules override in generated `tsconfig.json`

### Enhancements
- [phx.gen.live|html|json] - Make context argument optional. Defaults to the plural name.
- [phx.new] Add `mix precommit` alias
- [phx.new] Add `AGENTS.md` generation compatible with [`usage_rules`](https://usage-rules.hexdocs.pm/)
- [phx.new] Add `usage_rules` folder to installer, allowing to sync generic Phoenix rules into new projects
- [phx.new] Use LiveView 1.1 release in generated code
- [phx.new] Ensure theme selector and flash closing works without LiveView

## v1.8.0-rc.4 (2025-07-14)

### Bug Fixes
- Fix phx.gen.presence PubSub server name for umbrella apps
- Fix `phx.gen.live` subscribing to pubsub in disconnected mounts

### Enhancements
- [phx.new] Initialize initial git repo when git is installed
- [phx.new] Opt-in to HEEx `:debug_tags_location` in development
- [phx.gen.live|html|json|context] Make context name optional and inflect based on schema when missing
- [phx.gen.*] Use new Ecto 3.13 `Repo.transact/2` in generators
- [phx.gen.auth] Warn when using `phx.gen.auth` without esbuild as features assume `phoenix_html.js` in bundle
- Add `security.md` guide for security best practices
- [phoenix.js] - Add fetch() support to LongPoll when XMLHTTPRequest is not available
- Optimize parameter scrubbing by precompiling patterns

## v1.8.0-rc.3 (2025-05-07)

### Enhancements
- [phx.gen.auth] Allow configuring the scope's assign key in phx.gen.auth
- [phx.new] Do not override theme in root layout if explicitly set

## v1.8.0-rc.2 (2025-04-29)

### Bug Fixes
- [phx.gen.live] Only subscribe to pubsub if connected
- [phx.gen.auth] Remove unused current_password field
- [phx.gen.auth] Use context_app for scopes to fix generated scopes in umbrella apps

## v1.8.0-rc.1 (2025-04-16)

### Enhancements
- [phx.new] Support PORT in dev
- [phx.gen.auth] Replace `utc_now/0 + truncate/1` with `utc_now/1`
- [phx.gen.auth] Make dev mailbox link more obvious

### Bug Fixes
- [phx.new] Fix Tailwind custom variants for loading classes (#6194)
- [phx.new] Fix heroicons path for umbrella apps
- [phx.gen.auth] Fix missing index for scoped resources (#6186)
- [phx.gen.live] Fix crash when an open :show page gets a PubSub broadcast for items (#6197)

## v1.8.0-rc.0 (2025-04-01) 🚀

- First release candidate!

## v1.7

The CHANGELOG for v1.7 releases can be found in the [v1.7 branch](https://github.com/phoenixframework/phoenix/blob/v1.7/CHANGELOG.md).
