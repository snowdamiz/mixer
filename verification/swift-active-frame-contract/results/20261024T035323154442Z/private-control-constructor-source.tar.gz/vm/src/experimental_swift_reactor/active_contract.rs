//! Isolated contract/type/lifetime proposal only. Never linked into product.
#![allow(dead_code, clippy::result_large_err)]
use super::*;
use std::convert::Infallible;
use std::ops::ControlFlow;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum FrameDisposition { Idle, Active, Draining, Retained, RestorePending }
#[derive(Clone, Copy)]
pub(super) struct FrameBound { pub previous: usize, pub admitted: usize }
pub(crate) struct FrameCleanupState {
    pub disposition: FrameDisposition,
    pub bound: Option<FrameBound>,
    pub unvisited: usize,
    pub nested_restore: Option<usize>,
    pub live_unreconciled: bool,
    pub entry_attempted: bool,
    pub entry: Option<EntryGuard>,
}
impl Default for FrameCleanupState { fn default() -> Self { Self::empty() } }
impl FrameCleanupState {
    pub(super) const fn empty() -> Self {
        Self { disposition: FrameDisposition::Idle, bound: None, unvisited: 0, nested_restore: None, live_unreconciled: false, entry_attempted: false, entry: None }
    }
}
#[must_use = "The actual State owns every pin; the recorded envelope remains until explicit completion"]
pub(super) struct FrameOperationPhase<'a> {
    pub phase: ExecutionOperationPhase<'a>,
    pub cleanup: &'a mut FrameCleanupState,
    pub lifecycle: &'a mut Lifecycle,
}
pub(super) struct PinAttempt {
    pub pin: Option<SwiftFunctionPin>,
    pub failure: Option<SwiftRunFailure>,
    pub nested_restore: Option<usize>,
}
#[derive(Clone, Copy)]
pub(super) struct FrameScalars {
    pub function: u32, pub pc: usize, pub base: usize, pub operands: usize,
    pub controls: usize, pub result: bool,
}
#[derive(Clone, Copy)]
pub(super) enum FrameReturn { CallerContinues, Outermost(Option<Value>) }
#[derive(Clone, Copy)]
pub(super) struct FrameDrainReport {
    pub retained_frames: usize,
    pub retained_entry: bool,
    pub live_unreconciled: bool,
    pub live: SwiftLiveUsage,
    pub cache: super::super::cache::SwiftCacheUsage,
    pub usage: SwiftRunUsage,
    pub bound: Option<FrameBound>,
    pub nested_restore: Option<usize>,
    pub first_failure: Option<SwiftRunFailure>,
}
#[derive(Clone, Copy)]
pub(super) enum FrameCompletion {
    Completed,
    Retained(FrameDrainReport),
    RestoreRejected(FrameDrainReport),
}
/// Exact fixed caller storage. No generic T at this boundary.
pub(super) struct FrameOperationStorage<'a> {
    pub preparation: Option<Result<FrameOperationPhase<'a>, SwiftRunFailure>>,
    pub entry: Option<Result<(), SwiftRunFailure>>,
    pub returned: Option<Result<FrameReturn, SwiftRunFailure>>,
    pub drained: Option<FrameDrainReport>,
}

// Signature freeze only. These bodies intentionally do not implement product behavior.
impl SwiftReactorInstance {
    pub(super) fn prepare_frames(&mut self, _: Cursor) -> Result<FrameOperationPhase<'_>, SwiftRunFailure> {
        unimplemented!("contract only")
    }
    pub(super) fn resume_frame_cleanup(&mut self) -> Result<FrameOperationPhase<'_>, SwiftRunFailure> {
        unimplemented!("contract only")
    }
}
impl<'a> FrameOperationPhase<'a> {
    pub(super) fn enter(&mut self, _: u32) -> Result<(), SwiftRunFailure> { unimplemented!("contract only") }
    pub(super) fn finish(&mut self) -> Result<FrameReturn, SwiftRunFailure> { unimplemented!("contract only") }
    pub(super) fn drain(&mut self) -> FrameDrainReport { unimplemented!("contract only") }
    pub(super) fn complete(self, _: FrameOperationStorage<'a>) -> FrameCompletion { unimplemented!("contract only") }
}

/// Never called. Real cache types/APIs prove the short phase ends before the
/// acquired authority and optional completion failure are returned together.
fn acquire_pin_lifetime_witness(
    parts: &mut ExecutionParts<'_, SwiftMode>,
    operation: &mut SwiftExecutionOperation<'_>, function: u32,
) -> PinAttempt {
    let frame_bound = operation.control.usage(Some(operation.wasi.usage())).reservations.construction.current;
    let mut preparation = Some(parts.cache.prepare_operation(
        operation.control, Some(&*operation.wasi), operation.cursor));
    match preparation.take().expect("occupied local slot") {
        Err(failure) => PinAttempt { pin: None, failure: Some(failure), nested_restore: None },
        Ok(mut phase) => {
            let mut returned = Some(phase.pin(parts.cache, function));
            let (pin, mut failure) = match returned.take().expect("occupied local slot") {
                Ok(pin) => (Some(pin), None),
                Err(failure) => (None, Some(failure)),
            };
            let completion = phase.complete((preparation, returned));
            let nested_restore = if completion.is_err() { Some(frame_bound) } else { None };
            if let Err(completion_failure) = completion {
                failure = failure.or(Some(completion_failure));
            }
            PinAttempt { pin, failure, nested_restore }
        }
    }
}

/// Never called. A rejected release reconstitutes the SAME moved actual frame
/// and SAME pin at the SAME index; no clone/new/PinToken constructor exists here.
/// Successful lower removals shift a retained suffix, never the next prefix.
fn drain_frame_transfer_witness(
    parts: &mut ExecutionParts<'_, SwiftMode>,
    operation: &mut SwiftExecutionOperation<'_>, cleanup: &mut FrameCleanupState,
) {
    while cleanup.unvisited != 0 {
        cleanup.unvisited -= 1;
        let index = cleanup.unvisited;
        let frame = parts.frames.remove(index);
        let SwiftFrame { function, pc, base, operands, controls, result, pin } = frame;
        match parts.cache.release(pin, operation.control, Some(&*operation.wasi)) {
            Ok(()) => {
                // Failure here retains conservative count and does not stop drain.
                let removed = operation.control.remove_live_with_wasi(
                    Live::Frames, 1, Some(operation.wasi.usage()));
                if removed.is_err() { cleanup.live_unreconciled = true; }
            }
            Err(rejected) => {
                let _failure = rejected.failure;
                let pin = rejected.into_pin();
                parts.frames.insert(index, SwiftFrame { function, pc, base, operands, controls, result, pin });
            }
        }
    }
}

fn original_state_borrow_witness(instance: &mut SwiftReactorInstance, cursor: Cursor) -> FrameOperationPhase<'_> {
    // Never called. Demonstrates disjoint actual owner field borrows, no cloned owner.
    let state = instance.state.as_mut().unwrap();
    FrameOperationPhase {
        phase: ExecutionOperationPhase {
            parts: ExecutionParts { cache: instance.cache.as_mut().unwrap(),
                memory: &mut state.memory, table: &mut state.table, globals: &mut state.globals,
                values: &mut state.values, controls: &mut state.controls, frames: &mut state.frames },
            operation: SwiftExecutionOperation { control: instance.control.as_mut().unwrap(),
                wasi: instance.wasi.as_mut().unwrap(), cursor },
            previous_bound: 0, // Type witness only; production must use recorded exact bound.
        },
        cleanup: &mut state.frame_cleanup,
        lifecycle: &mut instance.lifecycle,
    }
}

struct PermanentPositions {
    owner_instance_source: SwiftReactorInstance,
    owner_instance_argument: SwiftReactorInstance,
    owner_instance_return: SwiftReactorInstance,
    owner_instance_caller: SwiftReactorInstance,
    owner_state_source: SwiftExecutionState,
    owner_state_argument: SwiftExecutionState,
    owner_state_return: SwiftExecutionState,
    owner_state_caller: SwiftExecutionState,
    owner_cleanup_state_source: FrameCleanupState,
    owner_cleanup_state_argument: FrameCleanupState,
    owner_cleanup_state_return: FrameCleanupState,
    owner_cleanup_state_caller: FrameCleanupState,
    owner_cleanup_option_source: Option<EntryGuard>,
    owner_cleanup_option_argument: Option<EntryGuard>,
    owner_cleanup_option_return: Option<EntryGuard>,
    owner_cleanup_option_caller: Option<EntryGuard>,
    owner_bound_source: Option<FrameBound>,
    owner_bound_argument: Option<FrameBound>,
    owner_bound_return: Option<FrameBound>,
    owner_bound_caller: Option<FrameBound>,
    owner_nested_bound_source: Option<usize>,
    owner_nested_bound_argument: Option<usize>,
    owner_nested_bound_return: Option<usize>,
    owner_nested_bound_caller: Option<usize>,
    prepare_owner_source: &'static mut SwiftReactorInstance,
    prepare_owner_argument: &'static mut SwiftReactorInstance,
    prepare_owner_return: &'static mut SwiftReactorInstance,
    prepare_owner_caller: &'static mut SwiftReactorInstance,
    prepare_control_source: &'static mut RuntimeControl,
    prepare_control_argument: &'static mut RuntimeControl,
    prepare_control_return: &'static mut RuntimeControl,
    prepare_control_caller: &'static mut RuntimeControl,
    prepare_cache_source: &'static mut SwiftFunctionCache,
    prepare_cache_argument: &'static mut SwiftFunctionCache,
    prepare_cache_return: &'static mut SwiftFunctionCache,
    prepare_cache_caller: &'static mut SwiftFunctionCache,
    prepare_wasi_source: &'static mut AccountedWasi,
    prepare_wasi_argument: &'static mut AccountedWasi,
    prepare_wasi_return: &'static mut AccountedWasi,
    prepare_wasi_caller: &'static mut AccountedWasi,
    prepare_state_source: &'static mut SwiftExecutionState,
    prepare_state_argument: &'static mut SwiftExecutionState,
    prepare_state_return: &'static mut SwiftExecutionState,
    prepare_state_caller: &'static mut SwiftExecutionState,
    prepare_lifecycle_source: &'static mut Lifecycle,
    prepare_lifecycle_argument: &'static mut Lifecycle,
    prepare_lifecycle_return: &'static mut Lifecycle,
    prepare_lifecycle_caller: &'static mut Lifecycle,
    prepare_cleanup_source: &'static mut FrameCleanupState,
    prepare_cleanup_argument: &'static mut FrameCleanupState,
    prepare_cleanup_return: &'static mut FrameCleanupState,
    prepare_cleanup_caller: &'static mut FrameCleanupState,
    prepare_ticket_source: &'static ReservationTicket,
    prepare_ticket_argument: &'static ReservationTicket,
    prepare_ticket_return: &'static ReservationTicket,
    prepare_ticket_caller: &'static ReservationTicket,
    prepare_cursor_source: Cursor,
    prepare_cursor_argument: Cursor,
    prepare_cursor_return: Cursor,
    prepare_cursor_caller: Cursor,
    prepare_usage_source: SwiftRunUsage,
    prepare_usage_argument: SwiftRunUsage,
    prepare_usage_return: SwiftRunUsage,
    prepare_usage_caller: SwiftRunUsage,
    prepare_cache_usage_source: super::super::cache::SwiftCacheUsage,
    prepare_cache_usage_argument: super::super::cache::SwiftCacheUsage,
    prepare_cache_usage_return: super::super::cache::SwiftCacheUsage,
    prepare_cache_usage_caller: super::super::cache::SwiftCacheUsage,
    prepare_wasi_usage_source: WasiUsage,
    prepare_wasi_usage_argument: WasiUsage,
    prepare_wasi_usage_return: WasiUsage,
    prepare_wasi_usage_caller: WasiUsage,
    prepare_live_source: SwiftLiveUsage,
    prepare_live_argument: SwiftLiveUsage,
    prepare_live_return: SwiftLiveUsage,
    prepare_live_caller: SwiftLiveUsage,
    prepare_budget_source: SwiftRunBudget,
    prepare_budget_argument: SwiftRunBudget,
    prepare_budget_return: SwiftRunBudget,
    prepare_budget_caller: SwiftRunBudget,
    prepare_previous_source: usize,
    prepare_previous_argument: usize,
    prepare_previous_return: usize,
    prepare_previous_caller: usize,
    prepare_admitted_source: usize,
    prepare_admitted_argument: usize,
    prepare_admitted_return: usize,
    prepare_admitted_caller: usize,
    prepare_byte_option_source: Option<usize>,
    prepare_byte_option_argument: Option<usize>,
    prepare_byte_option_return: Option<usize>,
    prepare_byte_option_caller: Option<usize>,
    prepare_check_source: Result<(), SwiftRunFailure>,
    prepare_check_argument: Result<(), SwiftRunFailure>,
    prepare_check_return: Result<(), SwiftRunFailure>,
    prepare_check_caller: Result<(), SwiftRunFailure>,
    prepare_fault_source: Fault,
    prepare_fault_argument: Fault,
    prepare_fault_return: Fault,
    prepare_fault_caller: Fault,
    prepare_failure_source: SwiftRunFailure,
    prepare_failure_argument: SwiftRunFailure,
    prepare_failure_return: SwiftRunFailure,
    prepare_failure_caller: SwiftRunFailure,
    prepare_ticket_option_source: Option<&'static ReservationTicket>,
    prepare_ticket_option_argument: Option<&'static ReservationTicket>,
    prepare_ticket_option_return: Option<&'static ReservationTicket>,
    prepare_ticket_option_caller: Option<&'static ReservationTicket>,
    prepare_tickets_iterator_source: std::slice::Iter<'static, Option<ReservationTicket>>,
    prepare_tickets_iterator_argument: std::slice::Iter<'static, Option<ReservationTicket>>,
    prepare_tickets_iterator_return: std::slice::Iter<'static, Option<ReservationTicket>>,
    prepare_tickets_iterator_caller: std::slice::Iter<'static, Option<ReservationTicket>>,
    prepare_ticket_option_borrow_source: &'static Option<ReservationTicket>,
    prepare_ticket_option_borrow_argument: &'static Option<ReservationTicket>,
    prepare_ticket_option_borrow_return: &'static Option<ReservationTicket>,
    prepare_ticket_option_borrow_caller: &'static Option<ReservationTicket>,
    prepare_gate_source: bool,
    prepare_gate_argument: bool,
    prepare_gate_return: bool,
    prepare_gate_caller: bool,
    prepare_disposition_source: FrameDisposition,
    prepare_disposition_argument: FrameDisposition,
    prepare_disposition_return: FrameDisposition,
    prepare_disposition_caller: FrameDisposition,
    completion_phase_source: FrameOperationPhase<'static>,
    completion_phase_argument: FrameOperationPhase<'static>,
    completion_phase_return: FrameOperationPhase<'static>,
    completion_phase_caller: FrameOperationPhase<'static>,
    completion_phase_return_source: Result<FrameOperationPhase<'static>, SwiftRunFailure>,
    completion_phase_return_argument: Result<FrameOperationPhase<'static>, SwiftRunFailure>,
    completion_phase_return_return: Result<FrameOperationPhase<'static>, SwiftRunFailure>,
    completion_phase_return_caller: Result<FrameOperationPhase<'static>, SwiftRunFailure>,
    completion_phase_option_source: Option<Result<FrameOperationPhase<'static>, SwiftRunFailure>>,
    completion_phase_option_argument: Option<Result<FrameOperationPhase<'static>, SwiftRunFailure>>,
    completion_phase_option_return: Option<Result<FrameOperationPhase<'static>, SwiftRunFailure>>,
    completion_phase_option_caller: Option<Result<FrameOperationPhase<'static>, SwiftRunFailure>>,
    completion_storage_source: FrameOperationStorage<'static>,
    completion_storage_argument: FrameOperationStorage<'static>,
    completion_storage_return: FrameOperationStorage<'static>,
    completion_storage_caller: FrameOperationStorage<'static>,
    completion_completion_source: FrameCompletion,
    completion_completion_argument: FrameCompletion,
    completion_completion_return: FrameCompletion,
    completion_completion_caller: FrameCompletion,
    completion_report_source: FrameDrainReport,
    completion_report_argument: FrameDrainReport,
    completion_report_return: FrameDrainReport,
    completion_report_caller: FrameDrainReport,
    completion_report_option_source: Option<FrameDrainReport>,
    completion_report_option_argument: Option<FrameDrainReport>,
    completion_report_option_return: Option<FrameDrainReport>,
    completion_report_option_caller: Option<FrameDrainReport>,
    completion_bound_source: FrameBound,
    completion_bound_argument: FrameBound,
    completion_bound_return: FrameBound,
    completion_bound_caller: FrameBound,
    completion_parts_source: ExecutionParts<'static, SwiftMode>,
    completion_parts_argument: ExecutionParts<'static, SwiftMode>,
    completion_parts_return: ExecutionParts<'static, SwiftMode>,
    completion_parts_caller: ExecutionParts<'static, SwiftMode>,
    completion_operation_source: SwiftExecutionOperation<'static>,
    completion_operation_argument: SwiftExecutionOperation<'static>,
    completion_operation_return: SwiftExecutionOperation<'static>,
    completion_operation_caller: SwiftExecutionOperation<'static>,
    completion_first_failure_source: Option<SwiftRunFailure>,
    completion_first_failure_argument: Option<SwiftRunFailure>,
    completion_first_failure_return: Option<SwiftRunFailure>,
    completion_first_failure_caller: Option<SwiftRunFailure>,
    completion_usage_source: SwiftRunUsage,
    completion_usage_argument: SwiftRunUsage,
    completion_usage_return: SwiftRunUsage,
    completion_usage_caller: SwiftRunUsage,
    completion_wasi_source: Option<WasiUsage>,
    completion_wasi_argument: Option<WasiUsage>,
    completion_wasi_return: Option<WasiUsage>,
    completion_wasi_caller: Option<WasiUsage>,
    completion_restore_source: Result<(), SwiftRunFailure>,
    completion_restore_argument: Result<(), SwiftRunFailure>,
    completion_restore_return: Result<(), SwiftRunFailure>,
    completion_restore_caller: Result<(), SwiftRunFailure>,
    completion_empty_source: bool,
    completion_empty_argument: bool,
    completion_empty_return: bool,
    completion_empty_caller: bool,
    completion_previous_source: usize,
    completion_previous_argument: usize,
    completion_previous_return: usize,
    completion_previous_caller: usize,
    completion_remaining_source: usize,
    completion_remaining_argument: usize,
    completion_remaining_return: usize,
    completion_remaining_caller: usize,
    after_step_entry_source: Option<Result<(), SwiftRunFailure>>,
    after_step_entry_argument: Option<Result<(), SwiftRunFailure>>,
    after_step_entry_return: Option<Result<(), SwiftRunFailure>>,
    after_step_entry_caller: Option<Result<(), SwiftRunFailure>>,
    after_step_return_source: Option<Result<FrameReturn, SwiftRunFailure>>,
    after_step_return_argument: Option<Result<FrameReturn, SwiftRunFailure>>,
    after_step_return_return: Option<Result<FrameReturn, SwiftRunFailure>>,
    after_step_return_caller: Option<Result<FrameReturn, SwiftRunFailure>>,
    after_completion_option_source: Option<FrameCompletion>,
    after_completion_option_argument: Option<FrameCompletion>,
    after_completion_option_return: Option<FrameCompletion>,
    after_completion_option_caller: Option<FrameCompletion>,
    after_copied_outer_result_source: Option<Value>,
    after_copied_outer_result_argument: Option<Value>,
    after_copied_outer_result_return: Option<Value>,
    after_copied_outer_result_caller: Option<Value>,
    after_final_failure_source: Option<SwiftRunFailure>,
    after_final_failure_argument: Option<SwiftRunFailure>,
    after_final_failure_return: Option<SwiftRunFailure>,
    after_final_failure_caller: Option<SwiftRunFailure>,
    after_final_usage_source: Option<SwiftRunUsage>,
    after_final_usage_argument: Option<SwiftRunUsage>,
    after_final_usage_return: Option<SwiftRunUsage>,
    after_final_usage_caller: Option<SwiftRunUsage>,
    after_cleanup_tail_source: ExecutionCleanupTail,
    after_cleanup_tail_argument: ExecutionCleanupTail,
    after_cleanup_tail_return: ExecutionCleanupTail,
    after_cleanup_tail_caller: ExecutionCleanupTail,
    after_cleanup_result_source: Option<Result<ExecutionCleanupTail, SwiftRunFailure>>,
    after_cleanup_result_argument: Option<Result<ExecutionCleanupTail, SwiftRunFailure>>,
    after_cleanup_result_return: Option<Result<ExecutionCleanupTail, SwiftRunFailure>>,
    after_cleanup_result_caller: Option<Result<ExecutionCleanupTail, SwiftRunFailure>>,
    prepare_try_branch_source: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    prepare_try_branch_return: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    prepare_try_branch_caller: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    prepare_try_residual_source: Result<Infallible, SwiftRunFailure>,
    prepare_try_residual_return: Result<Infallible, SwiftRunFailure>,
    prepare_try_residual_caller: Result<Infallible, SwiftRunFailure>,
    completion_try_branch_source: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    completion_try_branch_return: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    completion_try_branch_caller: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    completion_try_residual_source: Result<Infallible, SwiftRunFailure>,
    completion_try_residual_return: Result<Infallible, SwiftRunFailure>,
    completion_try_residual_caller: Result<Infallible, SwiftRunFailure>,
}
struct ActivePositions {
    common_phase_source: &'static mut FrameOperationPhase<'static>,
    common_phase_argument: &'static mut FrameOperationPhase<'static>,
    common_phase_return: &'static mut FrameOperationPhase<'static>,
    common_phase_caller: &'static mut FrameOperationPhase<'static>,
    common_parts_source: ExecutionParts<'static, SwiftMode>,
    common_parts_argument: ExecutionParts<'static, SwiftMode>,
    common_parts_return: ExecutionParts<'static, SwiftMode>,
    common_parts_caller: ExecutionParts<'static, SwiftMode>,
    common_parts_borrow_source: &'static mut ExecutionParts<'static, SwiftMode>,
    common_parts_borrow_argument: &'static mut ExecutionParts<'static, SwiftMode>,
    common_parts_borrow_return: &'static mut ExecutionParts<'static, SwiftMode>,
    common_parts_borrow_caller: &'static mut ExecutionParts<'static, SwiftMode>,
    common_operation_source: SwiftExecutionOperation<'static>,
    common_operation_argument: SwiftExecutionOperation<'static>,
    common_operation_return: SwiftExecutionOperation<'static>,
    common_operation_caller: SwiftExecutionOperation<'static>,
    common_operation_borrow_source: &'static mut SwiftExecutionOperation<'static>,
    common_operation_borrow_argument: &'static mut SwiftExecutionOperation<'static>,
    common_operation_borrow_return: &'static mut SwiftExecutionOperation<'static>,
    common_operation_borrow_caller: &'static mut SwiftExecutionOperation<'static>,
    common_control_source: &'static mut RuntimeControl,
    common_control_argument: &'static mut RuntimeControl,
    common_control_return: &'static mut RuntimeControl,
    common_control_caller: &'static mut RuntimeControl,
    common_wasi_source: &'static AccountedWasi,
    common_wasi_argument: &'static AccountedWasi,
    common_wasi_return: &'static AccountedWasi,
    common_wasi_caller: &'static AccountedWasi,
    common_values_source: &'static mut Vec<Value>,
    common_values_argument: &'static mut Vec<Value>,
    common_values_return: &'static mut Vec<Value>,
    common_values_caller: &'static mut Vec<Value>,
    common_controls_source: &'static mut Vec<Control>,
    common_controls_argument: &'static mut Vec<Control>,
    common_controls_return: &'static mut Vec<Control>,
    common_controls_caller: &'static mut Vec<Control>,
    common_frames_source: &'static mut Vec<SwiftFrame>,
    common_frames_argument: &'static mut Vec<SwiftFrame>,
    common_frames_return: &'static mut Vec<SwiftFrame>,
    common_frames_caller: &'static mut Vec<SwiftFrame>,
    common_cache_source: &'static mut SwiftFunctionCache,
    common_cache_argument: &'static mut SwiftFunctionCache,
    common_cache_return: &'static mut SwiftFunctionCache,
    common_cache_caller: &'static mut SwiftFunctionCache,
    common_usage_source: SwiftRunUsage,
    common_usage_argument: SwiftRunUsage,
    common_usage_return: SwiftRunUsage,
    common_usage_caller: SwiftRunUsage,
    common_observation_source: Option<WasiUsage>,
    common_observation_argument: Option<WasiUsage>,
    common_observation_return: Option<WasiUsage>,
    common_observation_caller: Option<WasiUsage>,
    common_cursor_source: Cursor,
    common_cursor_argument: Cursor,
    common_cursor_return: Cursor,
    common_cursor_caller: Cursor,
    common_live_source: SwiftLiveUsage,
    common_live_argument: SwiftLiveUsage,
    common_live_return: SwiftLiveUsage,
    common_live_caller: SwiftLiveUsage,
    common_fault_source: Fault,
    common_fault_argument: Fault,
    common_fault_return: Fault,
    common_fault_caller: Fault,
    common_failure_source: SwiftRunFailure,
    common_failure_argument: SwiftRunFailure,
    common_failure_return: SwiftRunFailure,
    common_failure_caller: SwiftRunFailure,
    common_unit_result_source: Result<(), SwiftRunFailure>,
    common_unit_result_argument: Result<(), SwiftRunFailure>,
    common_unit_result_return: Result<(), SwiftRunFailure>,
    common_unit_result_caller: Result<(), SwiftRunFailure>,
    common_gate_source: bool,
    common_gate_argument: bool,
    common_gate_return: bool,
    common_gate_caller: bool,
    acquire_phase_source: CacheOperationPhase<'static>,
    acquire_phase_argument: CacheOperationPhase<'static>,
    acquire_phase_return: CacheOperationPhase<'static>,
    acquire_phase_caller: CacheOperationPhase<'static>,
    acquire_prepare_result_source: Result<CacheOperationPhase<'static>, SwiftRunFailure>,
    acquire_prepare_result_argument: Result<CacheOperationPhase<'static>, SwiftRunFailure>,
    acquire_prepare_result_return: Result<CacheOperationPhase<'static>, SwiftRunFailure>,
    acquire_prepare_result_caller: Result<CacheOperationPhase<'static>, SwiftRunFailure>,
    acquire_prepare_option_source: Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>,
    acquire_prepare_option_argument: Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>,
    acquire_prepare_option_return: Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>,
    acquire_prepare_option_caller: Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>,
    acquire_pin_source: SwiftFunctionPin,
    acquire_pin_argument: SwiftFunctionPin,
    acquire_pin_return: SwiftFunctionPin,
    acquire_pin_caller: SwiftFunctionPin,
    acquire_pin_option_source: Option<SwiftFunctionPin>,
    acquire_pin_option_argument: Option<SwiftFunctionPin>,
    acquire_pin_option_return: Option<SwiftFunctionPin>,
    acquire_pin_option_caller: Option<SwiftFunctionPin>,
    acquire_pin_result_source: Result<SwiftFunctionPin, SwiftRunFailure>,
    acquire_pin_result_argument: Result<SwiftFunctionPin, SwiftRunFailure>,
    acquire_pin_result_return: Result<SwiftFunctionPin, SwiftRunFailure>,
    acquire_pin_result_caller: Result<SwiftFunctionPin, SwiftRunFailure>,
    acquire_pin_return_slot_source: Option<Result<SwiftFunctionPin, SwiftRunFailure>>,
    acquire_pin_return_slot_argument: Option<Result<SwiftFunctionPin, SwiftRunFailure>>,
    acquire_pin_return_slot_return: Option<Result<SwiftFunctionPin, SwiftRunFailure>>,
    acquire_pin_return_slot_caller: Option<Result<SwiftFunctionPin, SwiftRunFailure>>,
    acquire_attempt_source: PinAttempt,
    acquire_attempt_argument: PinAttempt,
    acquire_attempt_return: PinAttempt,
    acquire_attempt_caller: PinAttempt,
    acquire_first_source: Option<SwiftRunFailure>,
    acquire_first_argument: Option<SwiftRunFailure>,
    acquire_first_return: Option<SwiftRunFailure>,
    acquire_first_caller: Option<SwiftRunFailure>,
    acquire_nested_restore_source: Option<usize>,
    acquire_nested_restore_argument: Option<usize>,
    acquire_nested_restore_return: Option<usize>,
    acquire_nested_restore_caller: Option<usize>,
    acquire_frame_bound_source: usize,
    acquire_frame_bound_argument: usize,
    acquire_frame_bound_return: usize,
    acquire_frame_bound_caller: usize,
    acquire_completion_source: Result<(), SwiftRunFailure>,
    acquire_completion_argument: Result<(), SwiftRunFailure>,
    acquire_completion_return: Result<(), SwiftRunFailure>,
    acquire_completion_caller: Result<(), SwiftRunFailure>,
    acquire_function_source: u32,
    acquire_function_argument: u32,
    acquire_function_return: u32,
    acquire_function_caller: u32,
    acquire_empty_pair_source: (Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>, Option<Result<SwiftFunctionPin, SwiftRunFailure>>),
    acquire_empty_pair_argument: (Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>, Option<Result<SwiftFunctionPin, SwiftRunFailure>>),
    acquire_empty_pair_return: (Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>, Option<Result<SwiftFunctionPin, SwiftRunFailure>>),
    acquire_empty_pair_caller: (Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>, Option<Result<SwiftFunctionPin, SwiftRunFailure>>),
    entry_guard_source: EntryGuard,
    entry_guard_argument: EntryGuard,
    entry_guard_return: EntryGuard,
    entry_guard_caller: EntryGuard,
    entry_guard_option_source: Option<EntryGuard>,
    entry_guard_option_argument: Option<EntryGuard>,
    entry_guard_option_return: Option<EntryGuard>,
    entry_guard_option_caller: Option<EntryGuard>,
    entry_guard_borrow_source: &'static mut EntryGuard,
    entry_guard_borrow_argument: &'static mut EntryGuard,
    entry_guard_borrow_return: &'static mut EntryGuard,
    entry_guard_borrow_caller: &'static mut EntryGuard,
    entry_signature_source: SignatureView<'static>,
    entry_signature_argument: SignatureView<'static>,
    entry_signature_return: SignatureView<'static>,
    entry_signature_caller: SignatureView<'static>,
    entry_signature_option_source: Option<SignatureView<'static>>,
    entry_signature_option_argument: Option<SignatureView<'static>>,
    entry_signature_option_return: Option<SignatureView<'static>>,
    entry_signature_option_caller: Option<SignatureView<'static>>,
    entry_view_source: FunctionView<'static>,
    entry_view_argument: FunctionView<'static>,
    entry_view_return: FunctionView<'static>,
    entry_view_caller: FunctionView<'static>,
    entry_view_result_source: Result<FunctionView<'static>, SwiftRunFailure>,
    entry_view_result_argument: Result<FunctionView<'static>, SwiftRunFailure>,
    entry_view_result_return: Result<FunctionView<'static>, SwiftRunFailure>,
    entry_view_result_caller: Result<FunctionView<'static>, SwiftRunFailure>,
    entry_params_source: usize,
    entry_params_argument: usize,
    entry_params_return: usize,
    entry_params_caller: usize,
    entry_locals_source: usize,
    entry_locals_argument: usize,
    entry_locals_return: usize,
    entry_locals_caller: usize,
    entry_total_locals_source: Option<usize>,
    entry_total_locals_argument: Option<usize>,
    entry_total_locals_return: Option<usize>,
    entry_total_locals_caller: Option<usize>,
    entry_base_source: usize,
    entry_base_argument: usize,
    entry_base_return: usize,
    entry_base_caller: usize,
    entry_base_option_source: Option<usize>,
    entry_base_option_argument: Option<usize>,
    entry_base_option_return: Option<usize>,
    entry_base_option_caller: Option<usize>,
    entry_end_source: usize,
    entry_end_argument: usize,
    entry_end_return: usize,
    entry_end_caller: usize,
    entry_end_option_source: Option<usize>,
    entry_end_option_argument: Option<usize>,
    entry_end_option_return: Option<usize>,
    entry_end_option_caller: Option<usize>,
    entry_operands_source: usize,
    entry_operands_argument: usize,
    entry_operands_return: usize,
    entry_operands_caller: usize,
    entry_control_base_source: usize,
    entry_control_base_argument: usize,
    entry_control_base_return: usize,
    entry_control_base_caller: usize,
    entry_frame_count_source: usize,
    entry_frame_count_argument: usize,
    entry_frame_count_return: usize,
    entry_frame_count_caller: usize,
    entry_frame_limit_source: usize,
    entry_frame_limit_argument: usize,
    entry_frame_limit_return: usize,
    entry_frame_limit_caller: usize,
    entry_control_limit_source: usize,
    entry_control_limit_argument: usize,
    entry_control_limit_return: usize,
    entry_control_limit_caller: usize,
    entry_value_capacity_source: usize,
    entry_value_capacity_argument: usize,
    entry_value_capacity_return: usize,
    entry_value_capacity_caller: usize,
    entry_control_capacity_source: usize,
    entry_control_capacity_argument: usize,
    entry_control_capacity_return: usize,
    entry_control_capacity_caller: usize,
    entry_frame_capacity_source: usize,
    entry_frame_capacity_argument: usize,
    entry_frame_capacity_return: usize,
    entry_frame_capacity_caller: usize,
    entry_local_index_source: usize,
    entry_local_index_argument: usize,
    entry_local_index_return: usize,
    entry_local_index_caller: usize,
    entry_parameter_index_source: usize,
    entry_parameter_index_argument: usize,
    entry_parameter_index_return: usize,
    entry_parameter_index_caller: usize,
    entry_parameter_type_source: Option<Type>,
    entry_parameter_type_argument: Option<Type>,
    entry_parameter_type_return: Option<Type>,
    entry_parameter_type_caller: Option<Type>,
    entry_parameter_value_source: Option<&'static Value>,
    entry_parameter_value_argument: Option<&'static Value>,
    entry_parameter_value_return: Option<&'static Value>,
    entry_parameter_value_caller: Option<&'static Value>,
    entry_type_borrow_source: Option<&'static Type>,
    entry_type_borrow_argument: Option<&'static Type>,
    entry_type_borrow_return: Option<&'static Type>,
    entry_type_borrow_caller: Option<&'static Type>,
    entry_type_copy_source: Option<Type>,
    entry_type_copy_argument: Option<Type>,
    entry_type_copy_return: Option<Type>,
    entry_type_copy_caller: Option<Type>,
    entry_ty_source: Type,
    entry_ty_argument: Type,
    entry_ty_return: Type,
    entry_ty_caller: Type,
    entry_value_source: Value,
    entry_value_argument: Value,
    entry_value_return: Value,
    entry_value_caller: Value,
    entry_function_control_source: Control,
    entry_function_control_argument: Control,
    entry_function_control_return: Control,
    entry_function_control_caller: Control,
    entry_frame_source: SwiftFrame,
    entry_frame_argument: SwiftFrame,
    entry_frame_return: SwiftFrame,
    entry_frame_caller: SwiftFrame,
    entry_scalars_source: FrameScalars,
    entry_scalars_argument: FrameScalars,
    entry_scalars_return: FrameScalars,
    entry_scalars_caller: FrameScalars,
    entry_debit_source: Live,
    entry_debit_argument: Live,
    entry_debit_return: Live,
    entry_debit_caller: Live,
    entry_work_source: usize,
    entry_work_argument: usize,
    entry_work_return: usize,
    entry_work_caller: usize,
    entry_work_option_source: Option<usize>,
    entry_work_option_argument: Option<usize>,
    entry_work_option_return: Option<usize>,
    entry_work_option_caller: Option<usize>,
    entry_work_u64_source: u64,
    entry_work_u64_argument: u64,
    entry_work_u64_return: u64,
    entry_work_u64_caller: u64,
    entry_debit_result_source: Result<(), SwiftRunFailure>,
    entry_debit_result_argument: Result<(), SwiftRunFailure>,
    entry_debit_result_return: Result<(), SwiftRunFailure>,
    entry_debit_result_caller: Result<(), SwiftRunFailure>,
    entry_checked_result_source: Result<(), SwiftRunFailure>,
    entry_checked_result_argument: Result<(), SwiftRunFailure>,
    entry_checked_result_return: Result<(), SwiftRunFailure>,
    entry_checked_result_caller: Result<(), SwiftRunFailure>,
    entry_pin_source: Option<SwiftFunctionPin>,
    entry_pin_argument: Option<SwiftFunctionPin>,
    entry_pin_return: Option<SwiftFunctionPin>,
    entry_pin_caller: Option<SwiftFunctionPin>,
    entry_result_source: Result<(), SwiftRunFailure>,
    entry_result_argument: Result<(), SwiftRunFailure>,
    entry_result_return: Result<(), SwiftRunFailure>,
    entry_result_caller: Result<(), SwiftRunFailure>,
    finish_frame_borrow_source: Option<&'static SwiftFrame>,
    finish_frame_borrow_argument: Option<&'static SwiftFrame>,
    finish_frame_borrow_return: Option<&'static SwiftFrame>,
    finish_frame_borrow_caller: Option<&'static SwiftFrame>,
    finish_scalars_source: FrameScalars,
    finish_scalars_argument: FrameScalars,
    finish_scalars_return: FrameScalars,
    finish_scalars_caller: FrameScalars,
    finish_saved_source: Option<Value>,
    finish_saved_argument: Option<Value>,
    finish_saved_return: Option<Value>,
    finish_saved_caller: Option<Value>,
    finish_saved_value_source: Value,
    finish_saved_value_argument: Value,
    finish_saved_value_return: Value,
    finish_saved_value_caller: Value,
    finish_pop_source: Result<Value, SwiftRunFailure>,
    finish_pop_argument: Result<Value, SwiftRunFailure>,
    finish_pop_return: Result<Value, SwiftRunFailure>,
    finish_pop_caller: Result<Value, SwiftRunFailure>,
    finish_value_len_source: usize,
    finish_value_len_argument: usize,
    finish_value_len_return: usize,
    finish_value_len_caller: usize,
    finish_control_len_source: usize,
    finish_control_len_argument: usize,
    finish_control_len_return: usize,
    finish_control_len_caller: usize,
    finish_base_source: usize,
    finish_base_argument: usize,
    finish_base_return: usize,
    finish_base_caller: usize,
    finish_control_base_source: usize,
    finish_control_base_argument: usize,
    finish_control_base_return: usize,
    finish_control_base_caller: usize,
    finish_work_source: Option<usize>,
    finish_work_argument: Option<usize>,
    finish_work_return: Option<usize>,
    finish_work_caller: Option<usize>,
    finish_value_delta_source: usize,
    finish_value_delta_argument: usize,
    finish_value_delta_return: usize,
    finish_value_delta_caller: usize,
    finish_control_delta_source: usize,
    finish_control_delta_argument: usize,
    finish_control_delta_return: usize,
    finish_control_delta_caller: usize,
    finish_frame_source: SwiftFrame,
    finish_frame_argument: SwiftFrame,
    finish_frame_return: SwiftFrame,
    finish_frame_caller: SwiftFrame,
    finish_frame_option_source: Option<SwiftFrame>,
    finish_frame_option_argument: Option<SwiftFrame>,
    finish_frame_option_return: Option<SwiftFrame>,
    finish_frame_option_caller: Option<SwiftFrame>,
    finish_pin_source: SwiftFunctionPin,
    finish_pin_argument: SwiftFunctionPin,
    finish_pin_return: SwiftFunctionPin,
    finish_pin_caller: SwiftFunctionPin,
    finish_release_source: Result<(), SwiftReleaseFailure>,
    finish_release_argument: Result<(), SwiftReleaseFailure>,
    finish_release_return: Result<(), SwiftReleaseFailure>,
    finish_release_caller: Result<(), SwiftReleaseFailure>,
    finish_rejected_source: SwiftReleaseFailure,
    finish_rejected_argument: SwiftReleaseFailure,
    finish_rejected_return: SwiftReleaseFailure,
    finish_rejected_caller: SwiftReleaseFailure,
    finish_restored_frame_source: SwiftFrame,
    finish_restored_frame_argument: SwiftFrame,
    finish_restored_frame_return: SwiftFrame,
    finish_restored_frame_caller: SwiftFrame,
    finish_push_source: Result<(), SwiftRunFailure>,
    finish_push_argument: Result<(), SwiftRunFailure>,
    finish_push_return: Result<(), SwiftRunFailure>,
    finish_push_caller: Result<(), SwiftRunFailure>,
    finish_result_source: Result<FrameReturn, SwiftRunFailure>,
    finish_result_argument: Result<FrameReturn, SwiftRunFailure>,
    finish_result_return: Result<FrameReturn, SwiftRunFailure>,
    finish_result_caller: Result<FrameReturn, SwiftRunFailure>,
    finish_returned_source: FrameReturn,
    finish_returned_argument: FrameReturn,
    finish_returned_return: FrameReturn,
    finish_returned_caller: FrameReturn,
    rejection_guard_source: EntryGuard,
    rejection_guard_argument: EntryGuard,
    rejection_guard_return: EntryGuard,
    rejection_guard_caller: EntryGuard,
    rejection_guard_option_source: Option<EntryGuard>,
    rejection_guard_option_argument: Option<EntryGuard>,
    rejection_guard_option_return: Option<EntryGuard>,
    rejection_guard_option_caller: Option<EntryGuard>,
    rejection_guard_pin_source: Option<SwiftFunctionPin>,
    rejection_guard_pin_argument: Option<SwiftFunctionPin>,
    rejection_guard_pin_return: Option<SwiftFunctionPin>,
    rejection_guard_pin_caller: Option<SwiftFunctionPin>,
    rejection_release_source: Result<(), SwiftReleaseFailure>,
    rejection_release_argument: Result<(), SwiftReleaseFailure>,
    rejection_release_return: Result<(), SwiftReleaseFailure>,
    rejection_release_caller: Result<(), SwiftReleaseFailure>,
    rejection_rejected_source: SwiftReleaseFailure,
    rejection_rejected_argument: SwiftReleaseFailure,
    rejection_rejected_return: SwiftReleaseFailure,
    rejection_rejected_caller: SwiftReleaseFailure,
    rejection_rejected_pin_source: SwiftFunctionPin,
    rejection_rejected_pin_argument: SwiftFunctionPin,
    rejection_rejected_pin_return: SwiftFunctionPin,
    rejection_rejected_pin_caller: SwiftFunctionPin,
    rejection_values_actual_source: usize,
    rejection_values_actual_argument: usize,
    rejection_values_actual_return: usize,
    rejection_values_actual_caller: usize,
    rejection_controls_actual_source: usize,
    rejection_controls_actual_argument: usize,
    rejection_controls_actual_return: usize,
    rejection_controls_actual_caller: usize,
    rejection_value_debit_source: usize,
    rejection_value_debit_argument: usize,
    rejection_value_debit_return: usize,
    rejection_value_debit_caller: usize,
    rejection_control_debit_source: usize,
    rejection_control_debit_argument: usize,
    rejection_control_debit_return: usize,
    rejection_control_debit_caller: usize,
    rejection_frame_debit_source: bool,
    rejection_frame_debit_argument: bool,
    rejection_frame_debit_return: bool,
    rejection_frame_debit_caller: bool,
    rejection_removal_source: Result<(), SwiftRunFailure>,
    rejection_removal_argument: Result<(), SwiftRunFailure>,
    rejection_removal_return: Result<(), SwiftRunFailure>,
    rejection_removal_caller: Result<(), SwiftRunFailure>,
    drain_cleanup_source: &'static mut FrameCleanupState,
    drain_cleanup_argument: &'static mut FrameCleanupState,
    drain_cleanup_return: &'static mut FrameCleanupState,
    drain_cleanup_caller: &'static mut FrameCleanupState,
    drain_unvisited_source: &'static mut usize,
    drain_unvisited_argument: &'static mut usize,
    drain_unvisited_return: &'static mut usize,
    drain_unvisited_caller: &'static mut usize,
    drain_index_source: usize,
    drain_index_argument: usize,
    drain_index_return: usize,
    drain_index_caller: usize,
    drain_frame_source: SwiftFrame,
    drain_frame_argument: SwiftFrame,
    drain_frame_return: SwiftFrame,
    drain_frame_caller: SwiftFrame,
    drain_scalars_source: FrameScalars,
    drain_scalars_argument: FrameScalars,
    drain_scalars_return: FrameScalars,
    drain_scalars_caller: FrameScalars,
    drain_pin_source: SwiftFunctionPin,
    drain_pin_argument: SwiftFunctionPin,
    drain_pin_return: SwiftFunctionPin,
    drain_pin_caller: SwiftFunctionPin,
    drain_release_source: Result<(), SwiftReleaseFailure>,
    drain_release_argument: Result<(), SwiftReleaseFailure>,
    drain_release_return: Result<(), SwiftReleaseFailure>,
    drain_release_caller: Result<(), SwiftReleaseFailure>,
    drain_rejected_source: SwiftReleaseFailure,
    drain_rejected_argument: SwiftReleaseFailure,
    drain_rejected_return: SwiftReleaseFailure,
    drain_rejected_caller: SwiftReleaseFailure,
    drain_restored_pin_source: SwiftFunctionPin,
    drain_restored_pin_argument: SwiftFunctionPin,
    drain_restored_pin_return: SwiftFunctionPin,
    drain_restored_pin_caller: SwiftFunctionPin,
    drain_restored_frame_source: SwiftFrame,
    drain_restored_frame_argument: SwiftFrame,
    drain_restored_frame_return: SwiftFrame,
    drain_restored_frame_caller: SwiftFrame,
    drain_first_source: Option<SwiftRunFailure>,
    drain_first_argument: Option<SwiftRunFailure>,
    drain_first_return: Option<SwiftRunFailure>,
    drain_first_caller: Option<SwiftRunFailure>,
    drain_value_len_source: usize,
    drain_value_len_argument: usize,
    drain_value_len_return: usize,
    drain_value_len_caller: usize,
    drain_control_len_source: usize,
    drain_control_len_argument: usize,
    drain_control_len_return: usize,
    drain_control_len_caller: usize,
    drain_live_before_source: SwiftLiveUsage,
    drain_live_before_argument: SwiftLiveUsage,
    drain_live_before_return: SwiftLiveUsage,
    drain_live_before_caller: SwiftLiveUsage,
    drain_live_after_source: SwiftLiveUsage,
    drain_live_after_argument: SwiftLiveUsage,
    drain_live_after_return: SwiftLiveUsage,
    drain_live_after_caller: SwiftLiveUsage,
    drain_cache_before_source: super::super::cache::SwiftCacheUsage,
    drain_cache_before_argument: super::super::cache::SwiftCacheUsage,
    drain_cache_before_return: super::super::cache::SwiftCacheUsage,
    drain_cache_before_caller: super::super::cache::SwiftCacheUsage,
    drain_cache_after_source: super::super::cache::SwiftCacheUsage,
    drain_cache_after_argument: super::super::cache::SwiftCacheUsage,
    drain_cache_after_return: super::super::cache::SwiftCacheUsage,
    drain_cache_after_caller: super::super::cache::SwiftCacheUsage,
    drain_report_source: FrameDrainReport,
    drain_report_argument: FrameDrainReport,
    drain_report_return: FrameDrainReport,
    drain_report_caller: FrameDrainReport,
    drain_remaining_source: usize,
    drain_remaining_argument: usize,
    drain_remaining_return: usize,
    drain_remaining_caller: usize,
    drain_removed_source: Result<(), SwiftRunFailure>,
    drain_removed_argument: Result<(), SwiftRunFailure>,
    drain_removed_return: Result<(), SwiftRunFailure>,
    drain_removed_caller: Result<(), SwiftRunFailure>,
    entry_frame_function_source: u32,
    entry_frame_function_argument: u32,
    entry_frame_function_restore: u32,
    entry_frame_function_caller: u32,
    entry_frame_pc_source: usize,
    entry_frame_pc_argument: usize,
    entry_frame_pc_restore: usize,
    entry_frame_pc_caller: usize,
    entry_frame_base_source: usize,
    entry_frame_base_argument: usize,
    entry_frame_base_restore: usize,
    entry_frame_base_caller: usize,
    entry_frame_operands_source: usize,
    entry_frame_operands_argument: usize,
    entry_frame_operands_restore: usize,
    entry_frame_operands_caller: usize,
    entry_frame_controls_source: usize,
    entry_frame_controls_argument: usize,
    entry_frame_controls_restore: usize,
    entry_frame_controls_caller: usize,
    entry_frame_result_source: bool,
    entry_frame_result_argument: bool,
    entry_frame_result_restore: bool,
    entry_frame_result_caller: bool,
    finish_frame_function_source: u32,
    finish_frame_function_argument: u32,
    finish_frame_function_restore: u32,
    finish_frame_function_caller: u32,
    finish_frame_pc_source: usize,
    finish_frame_pc_argument: usize,
    finish_frame_pc_restore: usize,
    finish_frame_pc_caller: usize,
    finish_frame_base_source: usize,
    finish_frame_base_argument: usize,
    finish_frame_base_restore: usize,
    finish_frame_base_caller: usize,
    finish_frame_operands_source: usize,
    finish_frame_operands_argument: usize,
    finish_frame_operands_restore: usize,
    finish_frame_operands_caller: usize,
    finish_frame_controls_source: usize,
    finish_frame_controls_argument: usize,
    finish_frame_controls_restore: usize,
    finish_frame_controls_caller: usize,
    finish_frame_result_source: bool,
    finish_frame_result_argument: bool,
    finish_frame_result_restore: bool,
    finish_frame_result_caller: bool,
    drain_frame_function_source: u32,
    drain_frame_function_argument: u32,
    drain_frame_function_restore: u32,
    drain_frame_function_caller: u32,
    drain_frame_pc_source: usize,
    drain_frame_pc_argument: usize,
    drain_frame_pc_restore: usize,
    drain_frame_pc_caller: usize,
    drain_frame_base_source: usize,
    drain_frame_base_argument: usize,
    drain_frame_base_restore: usize,
    drain_frame_base_caller: usize,
    drain_frame_operands_source: usize,
    drain_frame_operands_argument: usize,
    drain_frame_operands_restore: usize,
    drain_frame_operands_caller: usize,
    drain_frame_controls_source: usize,
    drain_frame_controls_argument: usize,
    drain_frame_controls_restore: usize,
    drain_frame_controls_caller: usize,
    drain_frame_result_source: bool,
    drain_frame_result_argument: bool,
    drain_frame_result_restore: bool,
    drain_frame_result_caller: bool,
    entry_try_branch_unit_source: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    entry_try_branch_unit_argument: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    entry_try_branch_unit_return: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    entry_try_branch_unit_caller: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    entry_try_branch_value_source: ControlFlow<Result<Infallible, SwiftRunFailure>, Value>,
    entry_try_branch_value_argument: ControlFlow<Result<Infallible, SwiftRunFailure>, Value>,
    entry_try_branch_value_return: ControlFlow<Result<Infallible, SwiftRunFailure>, Value>,
    entry_try_branch_value_caller: ControlFlow<Result<Infallible, SwiftRunFailure>, Value>,
    entry_try_branch_usize_source: ControlFlow<Result<Infallible, SwiftRunFailure>, usize>,
    entry_try_branch_usize_argument: ControlFlow<Result<Infallible, SwiftRunFailure>, usize>,
    entry_try_branch_usize_return: ControlFlow<Result<Infallible, SwiftRunFailure>, usize>,
    entry_try_branch_usize_caller: ControlFlow<Result<Infallible, SwiftRunFailure>, usize>,
    entry_try_residual_source: Result<Infallible, SwiftRunFailure>,
    entry_try_residual_argument: Result<Infallible, SwiftRunFailure>,
    entry_try_residual_return: Result<Infallible, SwiftRunFailure>,
    entry_try_residual_caller: Result<Infallible, SwiftRunFailure>,
    entry_closure_capture_source: (&'static mut RuntimeControl, &'static AccountedWasi, Cursor),
    entry_closure_capture_argument: (&'static mut RuntimeControl, &'static AccountedWasi, Cursor),
    entry_closure_capture_return: (&'static mut RuntimeControl, &'static AccountedWasi, Cursor),
    entry_closure_capture_caller: (&'static mut RuntimeControl, &'static AccountedWasi, Cursor),
    entry_closure_failure_source: SwiftRunFailure,
    entry_closure_failure_argument: SwiftRunFailure,
    entry_closure_failure_return: SwiftRunFailure,
    entry_closure_failure_caller: SwiftRunFailure,
    finish_try_branch_unit_source: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    finish_try_branch_unit_argument: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    finish_try_branch_unit_return: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    finish_try_branch_unit_caller: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    finish_try_branch_value_source: ControlFlow<Result<Infallible, SwiftRunFailure>, Value>,
    finish_try_branch_value_argument: ControlFlow<Result<Infallible, SwiftRunFailure>, Value>,
    finish_try_branch_value_return: ControlFlow<Result<Infallible, SwiftRunFailure>, Value>,
    finish_try_branch_value_caller: ControlFlow<Result<Infallible, SwiftRunFailure>, Value>,
    finish_try_branch_usize_source: ControlFlow<Result<Infallible, SwiftRunFailure>, usize>,
    finish_try_branch_usize_argument: ControlFlow<Result<Infallible, SwiftRunFailure>, usize>,
    finish_try_branch_usize_return: ControlFlow<Result<Infallible, SwiftRunFailure>, usize>,
    finish_try_branch_usize_caller: ControlFlow<Result<Infallible, SwiftRunFailure>, usize>,
    finish_try_residual_source: Result<Infallible, SwiftRunFailure>,
    finish_try_residual_argument: Result<Infallible, SwiftRunFailure>,
    finish_try_residual_return: Result<Infallible, SwiftRunFailure>,
    finish_try_residual_caller: Result<Infallible, SwiftRunFailure>,
    finish_closure_capture_source: (&'static mut RuntimeControl, &'static AccountedWasi, Cursor),
    finish_closure_capture_argument: (&'static mut RuntimeControl, &'static AccountedWasi, Cursor),
    finish_closure_capture_return: (&'static mut RuntimeControl, &'static AccountedWasi, Cursor),
    finish_closure_capture_caller: (&'static mut RuntimeControl, &'static AccountedWasi, Cursor),
    finish_closure_failure_source: SwiftRunFailure,
    finish_closure_failure_argument: SwiftRunFailure,
    finish_closure_failure_return: SwiftRunFailure,
    finish_closure_failure_caller: SwiftRunFailure,
    rejection_try_branch_unit_source: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    rejection_try_branch_unit_argument: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    rejection_try_branch_unit_return: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    rejection_try_branch_unit_caller: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    rejection_try_branch_value_source: ControlFlow<Result<Infallible, SwiftRunFailure>, Value>,
    rejection_try_branch_value_argument: ControlFlow<Result<Infallible, SwiftRunFailure>, Value>,
    rejection_try_branch_value_return: ControlFlow<Result<Infallible, SwiftRunFailure>, Value>,
    rejection_try_branch_value_caller: ControlFlow<Result<Infallible, SwiftRunFailure>, Value>,
    rejection_try_branch_usize_source: ControlFlow<Result<Infallible, SwiftRunFailure>, usize>,
    rejection_try_branch_usize_argument: ControlFlow<Result<Infallible, SwiftRunFailure>, usize>,
    rejection_try_branch_usize_return: ControlFlow<Result<Infallible, SwiftRunFailure>, usize>,
    rejection_try_branch_usize_caller: ControlFlow<Result<Infallible, SwiftRunFailure>, usize>,
    rejection_try_residual_source: Result<Infallible, SwiftRunFailure>,
    rejection_try_residual_argument: Result<Infallible, SwiftRunFailure>,
    rejection_try_residual_return: Result<Infallible, SwiftRunFailure>,
    rejection_try_residual_caller: Result<Infallible, SwiftRunFailure>,
    rejection_closure_capture_source: (&'static mut RuntimeControl, &'static AccountedWasi, Cursor),
    rejection_closure_capture_argument: (&'static mut RuntimeControl, &'static AccountedWasi, Cursor),
    rejection_closure_capture_return: (&'static mut RuntimeControl, &'static AccountedWasi, Cursor),
    rejection_closure_capture_caller: (&'static mut RuntimeControl, &'static AccountedWasi, Cursor),
    rejection_closure_failure_source: SwiftRunFailure,
    rejection_closure_failure_argument: SwiftRunFailure,
    rejection_closure_failure_return: SwiftRunFailure,
    rejection_closure_failure_caller: SwiftRunFailure,
    drain_try_branch_unit_source: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    drain_try_branch_unit_argument: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    drain_try_branch_unit_return: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    drain_try_branch_unit_caller: ControlFlow<Result<Infallible, SwiftRunFailure>, ()>,
    drain_try_branch_value_source: ControlFlow<Result<Infallible, SwiftRunFailure>, Value>,
    drain_try_branch_value_argument: ControlFlow<Result<Infallible, SwiftRunFailure>, Value>,
    drain_try_branch_value_return: ControlFlow<Result<Infallible, SwiftRunFailure>, Value>,
    drain_try_branch_value_caller: ControlFlow<Result<Infallible, SwiftRunFailure>, Value>,
    drain_try_branch_usize_source: ControlFlow<Result<Infallible, SwiftRunFailure>, usize>,
    drain_try_branch_usize_argument: ControlFlow<Result<Infallible, SwiftRunFailure>, usize>,
    drain_try_branch_usize_return: ControlFlow<Result<Infallible, SwiftRunFailure>, usize>,
    drain_try_branch_usize_caller: ControlFlow<Result<Infallible, SwiftRunFailure>, usize>,
    drain_try_residual_source: Result<Infallible, SwiftRunFailure>,
    drain_try_residual_argument: Result<Infallible, SwiftRunFailure>,
    drain_try_residual_return: Result<Infallible, SwiftRunFailure>,
    drain_try_residual_caller: Result<Infallible, SwiftRunFailure>,
    drain_closure_capture_source: (&'static mut RuntimeControl, &'static AccountedWasi, Cursor),
    drain_closure_capture_argument: (&'static mut RuntimeControl, &'static AccountedWasi, Cursor),
    drain_closure_capture_return: (&'static mut RuntimeControl, &'static AccountedWasi, Cursor),
    drain_closure_capture_caller: (&'static mut RuntimeControl, &'static AccountedWasi, Cursor),
    drain_closure_failure_source: SwiftRunFailure,
    drain_closure_failure_argument: SwiftRunFailure,
    drain_closure_failure_return: SwiftRunFailure,
    drain_closure_failure_caller: SwiftRunFailure,
}
pub(super) const PERMANENT_BYTES: usize = size_of::<PermanentPositions>();
pub(super) const ACTIVE_BYTES: usize = size_of::<ActivePositions>();
pub(super) const FRAME_OPERATION_BYTES: Option<usize> = match super::value_operations::VALUE_OPERATION_BYTES {
    Some(nested) => ACTIVE_BYTES.checked_add(nested),
    None => None,
};


pub(super) fn print_contract_layout() {
    macro_rules! ty { ($t:ty) => { println!("AF_TYPE {} {} {}", stringify!($t), size_of::<$t>(), std::mem::align_of::<$t>()); }; }
    ty!(FrameCleanupState); ty!(FrameOperationPhase<'static>); ty!(FrameBound);
    ty!(PinAttempt); ty!(FrameScalars); ty!(FrameReturn); ty!(FrameDrainReport);
    ty!(FrameCompletion); ty!(FrameOperationStorage<'static>);
    ty!(PermanentPositions); ty!(ActivePositions);
    println!("AF_BOUNDS {} {}", PERMANENT_BYTES, ACTIVE_BYTES);
    println!("AF_FRAME_ENVELOPE {} {} {}", ACTIVE_BYTES, super::value_operations::VALUE_OPERATION_BYTES.unwrap(), FRAME_OPERATION_BYTES.unwrap());
    println!("AF_FIELD owner_instance_source {} {} {}", std::mem::offset_of!(PermanentPositions, owner_instance_source), size_of::<SwiftReactorInstance>(), std::mem::align_of::<SwiftReactorInstance>());
println!("AF_FIELD owner_instance_argument {} {} {}", std::mem::offset_of!(PermanentPositions, owner_instance_argument), size_of::<SwiftReactorInstance>(), std::mem::align_of::<SwiftReactorInstance>());
println!("AF_FIELD owner_instance_return {} {} {}", std::mem::offset_of!(PermanentPositions, owner_instance_return), size_of::<SwiftReactorInstance>(), std::mem::align_of::<SwiftReactorInstance>());
println!("AF_FIELD owner_instance_caller {} {} {}", std::mem::offset_of!(PermanentPositions, owner_instance_caller), size_of::<SwiftReactorInstance>(), std::mem::align_of::<SwiftReactorInstance>());
println!("AF_FIELD owner_state_source {} {} {}", std::mem::offset_of!(PermanentPositions, owner_state_source), size_of::<SwiftExecutionState>(), std::mem::align_of::<SwiftExecutionState>());
println!("AF_FIELD owner_state_argument {} {} {}", std::mem::offset_of!(PermanentPositions, owner_state_argument), size_of::<SwiftExecutionState>(), std::mem::align_of::<SwiftExecutionState>());
println!("AF_FIELD owner_state_return {} {} {}", std::mem::offset_of!(PermanentPositions, owner_state_return), size_of::<SwiftExecutionState>(), std::mem::align_of::<SwiftExecutionState>());
println!("AF_FIELD owner_state_caller {} {} {}", std::mem::offset_of!(PermanentPositions, owner_state_caller), size_of::<SwiftExecutionState>(), std::mem::align_of::<SwiftExecutionState>());
println!("AF_FIELD owner_cleanup_state_source {} {} {}", std::mem::offset_of!(PermanentPositions, owner_cleanup_state_source), size_of::<FrameCleanupState>(), std::mem::align_of::<FrameCleanupState>());
println!("AF_FIELD owner_cleanup_state_argument {} {} {}", std::mem::offset_of!(PermanentPositions, owner_cleanup_state_argument), size_of::<FrameCleanupState>(), std::mem::align_of::<FrameCleanupState>());
println!("AF_FIELD owner_cleanup_state_return {} {} {}", std::mem::offset_of!(PermanentPositions, owner_cleanup_state_return), size_of::<FrameCleanupState>(), std::mem::align_of::<FrameCleanupState>());
println!("AF_FIELD owner_cleanup_state_caller {} {} {}", std::mem::offset_of!(PermanentPositions, owner_cleanup_state_caller), size_of::<FrameCleanupState>(), std::mem::align_of::<FrameCleanupState>());
println!("AF_FIELD owner_cleanup_option_source {} {} {}", std::mem::offset_of!(PermanentPositions, owner_cleanup_option_source), size_of::<Option<EntryGuard>>(), std::mem::align_of::<Option<EntryGuard>>());
println!("AF_FIELD owner_cleanup_option_argument {} {} {}", std::mem::offset_of!(PermanentPositions, owner_cleanup_option_argument), size_of::<Option<EntryGuard>>(), std::mem::align_of::<Option<EntryGuard>>());
println!("AF_FIELD owner_cleanup_option_return {} {} {}", std::mem::offset_of!(PermanentPositions, owner_cleanup_option_return), size_of::<Option<EntryGuard>>(), std::mem::align_of::<Option<EntryGuard>>());
println!("AF_FIELD owner_cleanup_option_caller {} {} {}", std::mem::offset_of!(PermanentPositions, owner_cleanup_option_caller), size_of::<Option<EntryGuard>>(), std::mem::align_of::<Option<EntryGuard>>());
println!("AF_FIELD owner_bound_source {} {} {}", std::mem::offset_of!(PermanentPositions, owner_bound_source), size_of::<Option<FrameBound>>(), std::mem::align_of::<Option<FrameBound>>());
println!("AF_FIELD owner_bound_argument {} {} {}", std::mem::offset_of!(PermanentPositions, owner_bound_argument), size_of::<Option<FrameBound>>(), std::mem::align_of::<Option<FrameBound>>());
println!("AF_FIELD owner_bound_return {} {} {}", std::mem::offset_of!(PermanentPositions, owner_bound_return), size_of::<Option<FrameBound>>(), std::mem::align_of::<Option<FrameBound>>());
println!("AF_FIELD owner_bound_caller {} {} {}", std::mem::offset_of!(PermanentPositions, owner_bound_caller), size_of::<Option<FrameBound>>(), std::mem::align_of::<Option<FrameBound>>());
println!("AF_FIELD owner_nested_bound_source {} {} {}", std::mem::offset_of!(PermanentPositions, owner_nested_bound_source), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD owner_nested_bound_argument {} {} {}", std::mem::offset_of!(PermanentPositions, owner_nested_bound_argument), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD owner_nested_bound_return {} {} {}", std::mem::offset_of!(PermanentPositions, owner_nested_bound_return), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD owner_nested_bound_caller {} {} {}", std::mem::offset_of!(PermanentPositions, owner_nested_bound_caller), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD prepare_owner_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_owner_source), size_of::<&'static mut SwiftReactorInstance>(), std::mem::align_of::<&'static mut SwiftReactorInstance>());
println!("AF_FIELD prepare_owner_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_owner_argument), size_of::<&'static mut SwiftReactorInstance>(), std::mem::align_of::<&'static mut SwiftReactorInstance>());
println!("AF_FIELD prepare_owner_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_owner_return), size_of::<&'static mut SwiftReactorInstance>(), std::mem::align_of::<&'static mut SwiftReactorInstance>());
println!("AF_FIELD prepare_owner_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_owner_caller), size_of::<&'static mut SwiftReactorInstance>(), std::mem::align_of::<&'static mut SwiftReactorInstance>());
println!("AF_FIELD prepare_control_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_control_source), size_of::<&'static mut RuntimeControl>(), std::mem::align_of::<&'static mut RuntimeControl>());
println!("AF_FIELD prepare_control_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_control_argument), size_of::<&'static mut RuntimeControl>(), std::mem::align_of::<&'static mut RuntimeControl>());
println!("AF_FIELD prepare_control_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_control_return), size_of::<&'static mut RuntimeControl>(), std::mem::align_of::<&'static mut RuntimeControl>());
println!("AF_FIELD prepare_control_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_control_caller), size_of::<&'static mut RuntimeControl>(), std::mem::align_of::<&'static mut RuntimeControl>());
println!("AF_FIELD prepare_cache_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_cache_source), size_of::<&'static mut SwiftFunctionCache>(), std::mem::align_of::<&'static mut SwiftFunctionCache>());
println!("AF_FIELD prepare_cache_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_cache_argument), size_of::<&'static mut SwiftFunctionCache>(), std::mem::align_of::<&'static mut SwiftFunctionCache>());
println!("AF_FIELD prepare_cache_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_cache_return), size_of::<&'static mut SwiftFunctionCache>(), std::mem::align_of::<&'static mut SwiftFunctionCache>());
println!("AF_FIELD prepare_cache_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_cache_caller), size_of::<&'static mut SwiftFunctionCache>(), std::mem::align_of::<&'static mut SwiftFunctionCache>());
println!("AF_FIELD prepare_wasi_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_wasi_source), size_of::<&'static mut AccountedWasi>(), std::mem::align_of::<&'static mut AccountedWasi>());
println!("AF_FIELD prepare_wasi_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_wasi_argument), size_of::<&'static mut AccountedWasi>(), std::mem::align_of::<&'static mut AccountedWasi>());
println!("AF_FIELD prepare_wasi_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_wasi_return), size_of::<&'static mut AccountedWasi>(), std::mem::align_of::<&'static mut AccountedWasi>());
println!("AF_FIELD prepare_wasi_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_wasi_caller), size_of::<&'static mut AccountedWasi>(), std::mem::align_of::<&'static mut AccountedWasi>());
println!("AF_FIELD prepare_state_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_state_source), size_of::<&'static mut SwiftExecutionState>(), std::mem::align_of::<&'static mut SwiftExecutionState>());
println!("AF_FIELD prepare_state_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_state_argument), size_of::<&'static mut SwiftExecutionState>(), std::mem::align_of::<&'static mut SwiftExecutionState>());
println!("AF_FIELD prepare_state_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_state_return), size_of::<&'static mut SwiftExecutionState>(), std::mem::align_of::<&'static mut SwiftExecutionState>());
println!("AF_FIELD prepare_state_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_state_caller), size_of::<&'static mut SwiftExecutionState>(), std::mem::align_of::<&'static mut SwiftExecutionState>());
println!("AF_FIELD prepare_lifecycle_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_lifecycle_source), size_of::<&'static mut Lifecycle>(), std::mem::align_of::<&'static mut Lifecycle>());
println!("AF_FIELD prepare_lifecycle_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_lifecycle_argument), size_of::<&'static mut Lifecycle>(), std::mem::align_of::<&'static mut Lifecycle>());
println!("AF_FIELD prepare_lifecycle_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_lifecycle_return), size_of::<&'static mut Lifecycle>(), std::mem::align_of::<&'static mut Lifecycle>());
println!("AF_FIELD prepare_lifecycle_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_lifecycle_caller), size_of::<&'static mut Lifecycle>(), std::mem::align_of::<&'static mut Lifecycle>());
println!("AF_FIELD prepare_cleanup_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_cleanup_source), size_of::<&'static mut FrameCleanupState>(), std::mem::align_of::<&'static mut FrameCleanupState>());
println!("AF_FIELD prepare_cleanup_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_cleanup_argument), size_of::<&'static mut FrameCleanupState>(), std::mem::align_of::<&'static mut FrameCleanupState>());
println!("AF_FIELD prepare_cleanup_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_cleanup_return), size_of::<&'static mut FrameCleanupState>(), std::mem::align_of::<&'static mut FrameCleanupState>());
println!("AF_FIELD prepare_cleanup_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_cleanup_caller), size_of::<&'static mut FrameCleanupState>(), std::mem::align_of::<&'static mut FrameCleanupState>());
println!("AF_FIELD prepare_ticket_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_ticket_source), size_of::<&'static ReservationTicket>(), std::mem::align_of::<&'static ReservationTicket>());
println!("AF_FIELD prepare_ticket_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_ticket_argument), size_of::<&'static ReservationTicket>(), std::mem::align_of::<&'static ReservationTicket>());
println!("AF_FIELD prepare_ticket_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_ticket_return), size_of::<&'static ReservationTicket>(), std::mem::align_of::<&'static ReservationTicket>());
println!("AF_FIELD prepare_ticket_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_ticket_caller), size_of::<&'static ReservationTicket>(), std::mem::align_of::<&'static ReservationTicket>());
println!("AF_FIELD prepare_cursor_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_cursor_source), size_of::<Cursor>(), std::mem::align_of::<Cursor>());
println!("AF_FIELD prepare_cursor_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_cursor_argument), size_of::<Cursor>(), std::mem::align_of::<Cursor>());
println!("AF_FIELD prepare_cursor_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_cursor_return), size_of::<Cursor>(), std::mem::align_of::<Cursor>());
println!("AF_FIELD prepare_cursor_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_cursor_caller), size_of::<Cursor>(), std::mem::align_of::<Cursor>());
println!("AF_FIELD prepare_usage_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_usage_source), size_of::<SwiftRunUsage>(), std::mem::align_of::<SwiftRunUsage>());
println!("AF_FIELD prepare_usage_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_usage_argument), size_of::<SwiftRunUsage>(), std::mem::align_of::<SwiftRunUsage>());
println!("AF_FIELD prepare_usage_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_usage_return), size_of::<SwiftRunUsage>(), std::mem::align_of::<SwiftRunUsage>());
println!("AF_FIELD prepare_usage_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_usage_caller), size_of::<SwiftRunUsage>(), std::mem::align_of::<SwiftRunUsage>());
println!("AF_FIELD prepare_cache_usage_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_cache_usage_source), size_of::<super::super::cache::SwiftCacheUsage>(), std::mem::align_of::<super::super::cache::SwiftCacheUsage>());
println!("AF_FIELD prepare_cache_usage_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_cache_usage_argument), size_of::<super::super::cache::SwiftCacheUsage>(), std::mem::align_of::<super::super::cache::SwiftCacheUsage>());
println!("AF_FIELD prepare_cache_usage_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_cache_usage_return), size_of::<super::super::cache::SwiftCacheUsage>(), std::mem::align_of::<super::super::cache::SwiftCacheUsage>());
println!("AF_FIELD prepare_cache_usage_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_cache_usage_caller), size_of::<super::super::cache::SwiftCacheUsage>(), std::mem::align_of::<super::super::cache::SwiftCacheUsage>());
println!("AF_FIELD prepare_wasi_usage_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_wasi_usage_source), size_of::<WasiUsage>(), std::mem::align_of::<WasiUsage>());
println!("AF_FIELD prepare_wasi_usage_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_wasi_usage_argument), size_of::<WasiUsage>(), std::mem::align_of::<WasiUsage>());
println!("AF_FIELD prepare_wasi_usage_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_wasi_usage_return), size_of::<WasiUsage>(), std::mem::align_of::<WasiUsage>());
println!("AF_FIELD prepare_wasi_usage_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_wasi_usage_caller), size_of::<WasiUsage>(), std::mem::align_of::<WasiUsage>());
println!("AF_FIELD prepare_live_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_live_source), size_of::<SwiftLiveUsage>(), std::mem::align_of::<SwiftLiveUsage>());
println!("AF_FIELD prepare_live_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_live_argument), size_of::<SwiftLiveUsage>(), std::mem::align_of::<SwiftLiveUsage>());
println!("AF_FIELD prepare_live_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_live_return), size_of::<SwiftLiveUsage>(), std::mem::align_of::<SwiftLiveUsage>());
println!("AF_FIELD prepare_live_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_live_caller), size_of::<SwiftLiveUsage>(), std::mem::align_of::<SwiftLiveUsage>());
println!("AF_FIELD prepare_budget_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_budget_source), size_of::<SwiftRunBudget>(), std::mem::align_of::<SwiftRunBudget>());
println!("AF_FIELD prepare_budget_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_budget_argument), size_of::<SwiftRunBudget>(), std::mem::align_of::<SwiftRunBudget>());
println!("AF_FIELD prepare_budget_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_budget_return), size_of::<SwiftRunBudget>(), std::mem::align_of::<SwiftRunBudget>());
println!("AF_FIELD prepare_budget_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_budget_caller), size_of::<SwiftRunBudget>(), std::mem::align_of::<SwiftRunBudget>());
println!("AF_FIELD prepare_previous_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_previous_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD prepare_previous_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_previous_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD prepare_previous_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_previous_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD prepare_previous_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_previous_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD prepare_admitted_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_admitted_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD prepare_admitted_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_admitted_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD prepare_admitted_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_admitted_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD prepare_admitted_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_admitted_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD prepare_byte_option_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_byte_option_source), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD prepare_byte_option_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_byte_option_argument), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD prepare_byte_option_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_byte_option_return), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD prepare_byte_option_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_byte_option_caller), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD prepare_check_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_check_source), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD prepare_check_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_check_argument), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD prepare_check_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_check_return), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD prepare_check_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_check_caller), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD prepare_fault_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_fault_source), size_of::<Fault>(), std::mem::align_of::<Fault>());
println!("AF_FIELD prepare_fault_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_fault_argument), size_of::<Fault>(), std::mem::align_of::<Fault>());
println!("AF_FIELD prepare_fault_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_fault_return), size_of::<Fault>(), std::mem::align_of::<Fault>());
println!("AF_FIELD prepare_fault_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_fault_caller), size_of::<Fault>(), std::mem::align_of::<Fault>());
println!("AF_FIELD prepare_failure_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_failure_source), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD prepare_failure_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_failure_argument), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD prepare_failure_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_failure_return), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD prepare_failure_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_failure_caller), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD prepare_ticket_option_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_ticket_option_source), size_of::<Option<&'static ReservationTicket>>(), std::mem::align_of::<Option<&'static ReservationTicket>>());
println!("AF_FIELD prepare_ticket_option_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_ticket_option_argument), size_of::<Option<&'static ReservationTicket>>(), std::mem::align_of::<Option<&'static ReservationTicket>>());
println!("AF_FIELD prepare_ticket_option_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_ticket_option_return), size_of::<Option<&'static ReservationTicket>>(), std::mem::align_of::<Option<&'static ReservationTicket>>());
println!("AF_FIELD prepare_ticket_option_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_ticket_option_caller), size_of::<Option<&'static ReservationTicket>>(), std::mem::align_of::<Option<&'static ReservationTicket>>());
println!("AF_FIELD prepare_tickets_iterator_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_tickets_iterator_source), size_of::<std::slice::Iter<'static, Option<ReservationTicket>>>(), std::mem::align_of::<std::slice::Iter<'static, Option<ReservationTicket>>>());
println!("AF_FIELD prepare_tickets_iterator_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_tickets_iterator_argument), size_of::<std::slice::Iter<'static, Option<ReservationTicket>>>(), std::mem::align_of::<std::slice::Iter<'static, Option<ReservationTicket>>>());
println!("AF_FIELD prepare_tickets_iterator_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_tickets_iterator_return), size_of::<std::slice::Iter<'static, Option<ReservationTicket>>>(), std::mem::align_of::<std::slice::Iter<'static, Option<ReservationTicket>>>());
println!("AF_FIELD prepare_tickets_iterator_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_tickets_iterator_caller), size_of::<std::slice::Iter<'static, Option<ReservationTicket>>>(), std::mem::align_of::<std::slice::Iter<'static, Option<ReservationTicket>>>());
println!("AF_FIELD prepare_ticket_option_borrow_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_ticket_option_borrow_source), size_of::<&'static Option<ReservationTicket>>(), std::mem::align_of::<&'static Option<ReservationTicket>>());
println!("AF_FIELD prepare_ticket_option_borrow_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_ticket_option_borrow_argument), size_of::<&'static Option<ReservationTicket>>(), std::mem::align_of::<&'static Option<ReservationTicket>>());
println!("AF_FIELD prepare_ticket_option_borrow_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_ticket_option_borrow_return), size_of::<&'static Option<ReservationTicket>>(), std::mem::align_of::<&'static Option<ReservationTicket>>());
println!("AF_FIELD prepare_ticket_option_borrow_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_ticket_option_borrow_caller), size_of::<&'static Option<ReservationTicket>>(), std::mem::align_of::<&'static Option<ReservationTicket>>());
println!("AF_FIELD prepare_gate_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_gate_source), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD prepare_gate_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_gate_argument), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD prepare_gate_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_gate_return), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD prepare_gate_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_gate_caller), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD prepare_disposition_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_disposition_source), size_of::<FrameDisposition>(), std::mem::align_of::<FrameDisposition>());
println!("AF_FIELD prepare_disposition_argument {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_disposition_argument), size_of::<FrameDisposition>(), std::mem::align_of::<FrameDisposition>());
println!("AF_FIELD prepare_disposition_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_disposition_return), size_of::<FrameDisposition>(), std::mem::align_of::<FrameDisposition>());
println!("AF_FIELD prepare_disposition_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_disposition_caller), size_of::<FrameDisposition>(), std::mem::align_of::<FrameDisposition>());
println!("AF_FIELD completion_phase_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_phase_source), size_of::<FrameOperationPhase<'static>>(), std::mem::align_of::<FrameOperationPhase<'static>>());
println!("AF_FIELD completion_phase_argument {} {} {}", std::mem::offset_of!(PermanentPositions, completion_phase_argument), size_of::<FrameOperationPhase<'static>>(), std::mem::align_of::<FrameOperationPhase<'static>>());
println!("AF_FIELD completion_phase_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_phase_return), size_of::<FrameOperationPhase<'static>>(), std::mem::align_of::<FrameOperationPhase<'static>>());
println!("AF_FIELD completion_phase_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_phase_caller), size_of::<FrameOperationPhase<'static>>(), std::mem::align_of::<FrameOperationPhase<'static>>());
println!("AF_FIELD completion_phase_return_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_phase_return_source), size_of::<Result<FrameOperationPhase<'static>, SwiftRunFailure>>(), std::mem::align_of::<Result<FrameOperationPhase<'static>, SwiftRunFailure>>());
println!("AF_FIELD completion_phase_return_argument {} {} {}", std::mem::offset_of!(PermanentPositions, completion_phase_return_argument), size_of::<Result<FrameOperationPhase<'static>, SwiftRunFailure>>(), std::mem::align_of::<Result<FrameOperationPhase<'static>, SwiftRunFailure>>());
println!("AF_FIELD completion_phase_return_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_phase_return_return), size_of::<Result<FrameOperationPhase<'static>, SwiftRunFailure>>(), std::mem::align_of::<Result<FrameOperationPhase<'static>, SwiftRunFailure>>());
println!("AF_FIELD completion_phase_return_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_phase_return_caller), size_of::<Result<FrameOperationPhase<'static>, SwiftRunFailure>>(), std::mem::align_of::<Result<FrameOperationPhase<'static>, SwiftRunFailure>>());
println!("AF_FIELD completion_phase_option_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_phase_option_source), size_of::<Option<Result<FrameOperationPhase<'static>, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<FrameOperationPhase<'static>, SwiftRunFailure>>>());
println!("AF_FIELD completion_phase_option_argument {} {} {}", std::mem::offset_of!(PermanentPositions, completion_phase_option_argument), size_of::<Option<Result<FrameOperationPhase<'static>, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<FrameOperationPhase<'static>, SwiftRunFailure>>>());
println!("AF_FIELD completion_phase_option_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_phase_option_return), size_of::<Option<Result<FrameOperationPhase<'static>, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<FrameOperationPhase<'static>, SwiftRunFailure>>>());
println!("AF_FIELD completion_phase_option_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_phase_option_caller), size_of::<Option<Result<FrameOperationPhase<'static>, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<FrameOperationPhase<'static>, SwiftRunFailure>>>());
println!("AF_FIELD completion_storage_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_storage_source), size_of::<FrameOperationStorage<'static>>(), std::mem::align_of::<FrameOperationStorage<'static>>());
println!("AF_FIELD completion_storage_argument {} {} {}", std::mem::offset_of!(PermanentPositions, completion_storage_argument), size_of::<FrameOperationStorage<'static>>(), std::mem::align_of::<FrameOperationStorage<'static>>());
println!("AF_FIELD completion_storage_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_storage_return), size_of::<FrameOperationStorage<'static>>(), std::mem::align_of::<FrameOperationStorage<'static>>());
println!("AF_FIELD completion_storage_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_storage_caller), size_of::<FrameOperationStorage<'static>>(), std::mem::align_of::<FrameOperationStorage<'static>>());
println!("AF_FIELD completion_completion_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_completion_source), size_of::<FrameCompletion>(), std::mem::align_of::<FrameCompletion>());
println!("AF_FIELD completion_completion_argument {} {} {}", std::mem::offset_of!(PermanentPositions, completion_completion_argument), size_of::<FrameCompletion>(), std::mem::align_of::<FrameCompletion>());
println!("AF_FIELD completion_completion_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_completion_return), size_of::<FrameCompletion>(), std::mem::align_of::<FrameCompletion>());
println!("AF_FIELD completion_completion_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_completion_caller), size_of::<FrameCompletion>(), std::mem::align_of::<FrameCompletion>());
println!("AF_FIELD completion_report_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_report_source), size_of::<FrameDrainReport>(), std::mem::align_of::<FrameDrainReport>());
println!("AF_FIELD completion_report_argument {} {} {}", std::mem::offset_of!(PermanentPositions, completion_report_argument), size_of::<FrameDrainReport>(), std::mem::align_of::<FrameDrainReport>());
println!("AF_FIELD completion_report_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_report_return), size_of::<FrameDrainReport>(), std::mem::align_of::<FrameDrainReport>());
println!("AF_FIELD completion_report_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_report_caller), size_of::<FrameDrainReport>(), std::mem::align_of::<FrameDrainReport>());
println!("AF_FIELD completion_report_option_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_report_option_source), size_of::<Option<FrameDrainReport>>(), std::mem::align_of::<Option<FrameDrainReport>>());
println!("AF_FIELD completion_report_option_argument {} {} {}", std::mem::offset_of!(PermanentPositions, completion_report_option_argument), size_of::<Option<FrameDrainReport>>(), std::mem::align_of::<Option<FrameDrainReport>>());
println!("AF_FIELD completion_report_option_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_report_option_return), size_of::<Option<FrameDrainReport>>(), std::mem::align_of::<Option<FrameDrainReport>>());
println!("AF_FIELD completion_report_option_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_report_option_caller), size_of::<Option<FrameDrainReport>>(), std::mem::align_of::<Option<FrameDrainReport>>());
println!("AF_FIELD completion_bound_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_bound_source), size_of::<FrameBound>(), std::mem::align_of::<FrameBound>());
println!("AF_FIELD completion_bound_argument {} {} {}", std::mem::offset_of!(PermanentPositions, completion_bound_argument), size_of::<FrameBound>(), std::mem::align_of::<FrameBound>());
println!("AF_FIELD completion_bound_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_bound_return), size_of::<FrameBound>(), std::mem::align_of::<FrameBound>());
println!("AF_FIELD completion_bound_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_bound_caller), size_of::<FrameBound>(), std::mem::align_of::<FrameBound>());
println!("AF_FIELD completion_parts_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_parts_source), size_of::<ExecutionParts<'static, SwiftMode>>(), std::mem::align_of::<ExecutionParts<'static, SwiftMode>>());
println!("AF_FIELD completion_parts_argument {} {} {}", std::mem::offset_of!(PermanentPositions, completion_parts_argument), size_of::<ExecutionParts<'static, SwiftMode>>(), std::mem::align_of::<ExecutionParts<'static, SwiftMode>>());
println!("AF_FIELD completion_parts_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_parts_return), size_of::<ExecutionParts<'static, SwiftMode>>(), std::mem::align_of::<ExecutionParts<'static, SwiftMode>>());
println!("AF_FIELD completion_parts_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_parts_caller), size_of::<ExecutionParts<'static, SwiftMode>>(), std::mem::align_of::<ExecutionParts<'static, SwiftMode>>());
println!("AF_FIELD completion_operation_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_operation_source), size_of::<SwiftExecutionOperation<'static>>(), std::mem::align_of::<SwiftExecutionOperation<'static>>());
println!("AF_FIELD completion_operation_argument {} {} {}", std::mem::offset_of!(PermanentPositions, completion_operation_argument), size_of::<SwiftExecutionOperation<'static>>(), std::mem::align_of::<SwiftExecutionOperation<'static>>());
println!("AF_FIELD completion_operation_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_operation_return), size_of::<SwiftExecutionOperation<'static>>(), std::mem::align_of::<SwiftExecutionOperation<'static>>());
println!("AF_FIELD completion_operation_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_operation_caller), size_of::<SwiftExecutionOperation<'static>>(), std::mem::align_of::<SwiftExecutionOperation<'static>>());
println!("AF_FIELD completion_first_failure_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_first_failure_source), size_of::<Option<SwiftRunFailure>>(), std::mem::align_of::<Option<SwiftRunFailure>>());
println!("AF_FIELD completion_first_failure_argument {} {} {}", std::mem::offset_of!(PermanentPositions, completion_first_failure_argument), size_of::<Option<SwiftRunFailure>>(), std::mem::align_of::<Option<SwiftRunFailure>>());
println!("AF_FIELD completion_first_failure_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_first_failure_return), size_of::<Option<SwiftRunFailure>>(), std::mem::align_of::<Option<SwiftRunFailure>>());
println!("AF_FIELD completion_first_failure_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_first_failure_caller), size_of::<Option<SwiftRunFailure>>(), std::mem::align_of::<Option<SwiftRunFailure>>());
println!("AF_FIELD completion_usage_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_usage_source), size_of::<SwiftRunUsage>(), std::mem::align_of::<SwiftRunUsage>());
println!("AF_FIELD completion_usage_argument {} {} {}", std::mem::offset_of!(PermanentPositions, completion_usage_argument), size_of::<SwiftRunUsage>(), std::mem::align_of::<SwiftRunUsage>());
println!("AF_FIELD completion_usage_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_usage_return), size_of::<SwiftRunUsage>(), std::mem::align_of::<SwiftRunUsage>());
println!("AF_FIELD completion_usage_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_usage_caller), size_of::<SwiftRunUsage>(), std::mem::align_of::<SwiftRunUsage>());
println!("AF_FIELD completion_wasi_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_wasi_source), size_of::<Option<WasiUsage>>(), std::mem::align_of::<Option<WasiUsage>>());
println!("AF_FIELD completion_wasi_argument {} {} {}", std::mem::offset_of!(PermanentPositions, completion_wasi_argument), size_of::<Option<WasiUsage>>(), std::mem::align_of::<Option<WasiUsage>>());
println!("AF_FIELD completion_wasi_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_wasi_return), size_of::<Option<WasiUsage>>(), std::mem::align_of::<Option<WasiUsage>>());
println!("AF_FIELD completion_wasi_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_wasi_caller), size_of::<Option<WasiUsage>>(), std::mem::align_of::<Option<WasiUsage>>());
println!("AF_FIELD completion_restore_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_restore_source), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD completion_restore_argument {} {} {}", std::mem::offset_of!(PermanentPositions, completion_restore_argument), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD completion_restore_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_restore_return), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD completion_restore_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_restore_caller), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD completion_empty_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_empty_source), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD completion_empty_argument {} {} {}", std::mem::offset_of!(PermanentPositions, completion_empty_argument), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD completion_empty_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_empty_return), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD completion_empty_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_empty_caller), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD completion_previous_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_previous_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD completion_previous_argument {} {} {}", std::mem::offset_of!(PermanentPositions, completion_previous_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD completion_previous_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_previous_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD completion_previous_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_previous_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD completion_remaining_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_remaining_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD completion_remaining_argument {} {} {}", std::mem::offset_of!(PermanentPositions, completion_remaining_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD completion_remaining_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_remaining_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD completion_remaining_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_remaining_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD after_step_entry_source {} {} {}", std::mem::offset_of!(PermanentPositions, after_step_entry_source), size_of::<Option<Result<(), SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<(), SwiftRunFailure>>>());
println!("AF_FIELD after_step_entry_argument {} {} {}", std::mem::offset_of!(PermanentPositions, after_step_entry_argument), size_of::<Option<Result<(), SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<(), SwiftRunFailure>>>());
println!("AF_FIELD after_step_entry_return {} {} {}", std::mem::offset_of!(PermanentPositions, after_step_entry_return), size_of::<Option<Result<(), SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<(), SwiftRunFailure>>>());
println!("AF_FIELD after_step_entry_caller {} {} {}", std::mem::offset_of!(PermanentPositions, after_step_entry_caller), size_of::<Option<Result<(), SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<(), SwiftRunFailure>>>());
println!("AF_FIELD after_step_return_source {} {} {}", std::mem::offset_of!(PermanentPositions, after_step_return_source), size_of::<Option<Result<FrameReturn, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<FrameReturn, SwiftRunFailure>>>());
println!("AF_FIELD after_step_return_argument {} {} {}", std::mem::offset_of!(PermanentPositions, after_step_return_argument), size_of::<Option<Result<FrameReturn, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<FrameReturn, SwiftRunFailure>>>());
println!("AF_FIELD after_step_return_return {} {} {}", std::mem::offset_of!(PermanentPositions, after_step_return_return), size_of::<Option<Result<FrameReturn, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<FrameReturn, SwiftRunFailure>>>());
println!("AF_FIELD after_step_return_caller {} {} {}", std::mem::offset_of!(PermanentPositions, after_step_return_caller), size_of::<Option<Result<FrameReturn, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<FrameReturn, SwiftRunFailure>>>());
println!("AF_FIELD after_completion_option_source {} {} {}", std::mem::offset_of!(PermanentPositions, after_completion_option_source), size_of::<Option<FrameCompletion>>(), std::mem::align_of::<Option<FrameCompletion>>());
println!("AF_FIELD after_completion_option_argument {} {} {}", std::mem::offset_of!(PermanentPositions, after_completion_option_argument), size_of::<Option<FrameCompletion>>(), std::mem::align_of::<Option<FrameCompletion>>());
println!("AF_FIELD after_completion_option_return {} {} {}", std::mem::offset_of!(PermanentPositions, after_completion_option_return), size_of::<Option<FrameCompletion>>(), std::mem::align_of::<Option<FrameCompletion>>());
println!("AF_FIELD after_completion_option_caller {} {} {}", std::mem::offset_of!(PermanentPositions, after_completion_option_caller), size_of::<Option<FrameCompletion>>(), std::mem::align_of::<Option<FrameCompletion>>());
println!("AF_FIELD after_copied_outer_result_source {} {} {}", std::mem::offset_of!(PermanentPositions, after_copied_outer_result_source), size_of::<Option<Value>>(), std::mem::align_of::<Option<Value>>());
println!("AF_FIELD after_copied_outer_result_argument {} {} {}", std::mem::offset_of!(PermanentPositions, after_copied_outer_result_argument), size_of::<Option<Value>>(), std::mem::align_of::<Option<Value>>());
println!("AF_FIELD after_copied_outer_result_return {} {} {}", std::mem::offset_of!(PermanentPositions, after_copied_outer_result_return), size_of::<Option<Value>>(), std::mem::align_of::<Option<Value>>());
println!("AF_FIELD after_copied_outer_result_caller {} {} {}", std::mem::offset_of!(PermanentPositions, after_copied_outer_result_caller), size_of::<Option<Value>>(), std::mem::align_of::<Option<Value>>());
println!("AF_FIELD after_final_failure_source {} {} {}", std::mem::offset_of!(PermanentPositions, after_final_failure_source), size_of::<Option<SwiftRunFailure>>(), std::mem::align_of::<Option<SwiftRunFailure>>());
println!("AF_FIELD after_final_failure_argument {} {} {}", std::mem::offset_of!(PermanentPositions, after_final_failure_argument), size_of::<Option<SwiftRunFailure>>(), std::mem::align_of::<Option<SwiftRunFailure>>());
println!("AF_FIELD after_final_failure_return {} {} {}", std::mem::offset_of!(PermanentPositions, after_final_failure_return), size_of::<Option<SwiftRunFailure>>(), std::mem::align_of::<Option<SwiftRunFailure>>());
println!("AF_FIELD after_final_failure_caller {} {} {}", std::mem::offset_of!(PermanentPositions, after_final_failure_caller), size_of::<Option<SwiftRunFailure>>(), std::mem::align_of::<Option<SwiftRunFailure>>());
println!("AF_FIELD after_final_usage_source {} {} {}", std::mem::offset_of!(PermanentPositions, after_final_usage_source), size_of::<Option<SwiftRunUsage>>(), std::mem::align_of::<Option<SwiftRunUsage>>());
println!("AF_FIELD after_final_usage_argument {} {} {}", std::mem::offset_of!(PermanentPositions, after_final_usage_argument), size_of::<Option<SwiftRunUsage>>(), std::mem::align_of::<Option<SwiftRunUsage>>());
println!("AF_FIELD after_final_usage_return {} {} {}", std::mem::offset_of!(PermanentPositions, after_final_usage_return), size_of::<Option<SwiftRunUsage>>(), std::mem::align_of::<Option<SwiftRunUsage>>());
println!("AF_FIELD after_final_usage_caller {} {} {}", std::mem::offset_of!(PermanentPositions, after_final_usage_caller), size_of::<Option<SwiftRunUsage>>(), std::mem::align_of::<Option<SwiftRunUsage>>());
println!("AF_FIELD after_cleanup_tail_source {} {} {}", std::mem::offset_of!(PermanentPositions, after_cleanup_tail_source), size_of::<ExecutionCleanupTail>(), std::mem::align_of::<ExecutionCleanupTail>());
println!("AF_FIELD after_cleanup_tail_argument {} {} {}", std::mem::offset_of!(PermanentPositions, after_cleanup_tail_argument), size_of::<ExecutionCleanupTail>(), std::mem::align_of::<ExecutionCleanupTail>());
println!("AF_FIELD after_cleanup_tail_return {} {} {}", std::mem::offset_of!(PermanentPositions, after_cleanup_tail_return), size_of::<ExecutionCleanupTail>(), std::mem::align_of::<ExecutionCleanupTail>());
println!("AF_FIELD after_cleanup_tail_caller {} {} {}", std::mem::offset_of!(PermanentPositions, after_cleanup_tail_caller), size_of::<ExecutionCleanupTail>(), std::mem::align_of::<ExecutionCleanupTail>());
println!("AF_FIELD after_cleanup_result_source {} {} {}", std::mem::offset_of!(PermanentPositions, after_cleanup_result_source), size_of::<Option<Result<ExecutionCleanupTail, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<ExecutionCleanupTail, SwiftRunFailure>>>());
println!("AF_FIELD after_cleanup_result_argument {} {} {}", std::mem::offset_of!(PermanentPositions, after_cleanup_result_argument), size_of::<Option<Result<ExecutionCleanupTail, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<ExecutionCleanupTail, SwiftRunFailure>>>());
println!("AF_FIELD after_cleanup_result_return {} {} {}", std::mem::offset_of!(PermanentPositions, after_cleanup_result_return), size_of::<Option<Result<ExecutionCleanupTail, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<ExecutionCleanupTail, SwiftRunFailure>>>());
println!("AF_FIELD after_cleanup_result_caller {} {} {}", std::mem::offset_of!(PermanentPositions, after_cleanup_result_caller), size_of::<Option<Result<ExecutionCleanupTail, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<ExecutionCleanupTail, SwiftRunFailure>>>());
println!("AF_FIELD prepare_try_branch_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_try_branch_source), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD prepare_try_branch_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_try_branch_return), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD prepare_try_branch_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_try_branch_caller), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD prepare_try_residual_source {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_try_residual_source), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD prepare_try_residual_return {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_try_residual_return), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD prepare_try_residual_caller {} {} {}", std::mem::offset_of!(PermanentPositions, prepare_try_residual_caller), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD completion_try_branch_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_try_branch_source), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD completion_try_branch_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_try_branch_return), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD completion_try_branch_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_try_branch_caller), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD completion_try_residual_source {} {} {}", std::mem::offset_of!(PermanentPositions, completion_try_residual_source), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD completion_try_residual_return {} {} {}", std::mem::offset_of!(PermanentPositions, completion_try_residual_return), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD completion_try_residual_caller {} {} {}", std::mem::offset_of!(PermanentPositions, completion_try_residual_caller), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD common_phase_source {} {} {}", std::mem::offset_of!(ActivePositions, common_phase_source), size_of::<&'static mut FrameOperationPhase<'static>>(), std::mem::align_of::<&'static mut FrameOperationPhase<'static>>());
println!("AF_FIELD common_phase_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_phase_argument), size_of::<&'static mut FrameOperationPhase<'static>>(), std::mem::align_of::<&'static mut FrameOperationPhase<'static>>());
println!("AF_FIELD common_phase_return {} {} {}", std::mem::offset_of!(ActivePositions, common_phase_return), size_of::<&'static mut FrameOperationPhase<'static>>(), std::mem::align_of::<&'static mut FrameOperationPhase<'static>>());
println!("AF_FIELD common_phase_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_phase_caller), size_of::<&'static mut FrameOperationPhase<'static>>(), std::mem::align_of::<&'static mut FrameOperationPhase<'static>>());
println!("AF_FIELD common_parts_source {} {} {}", std::mem::offset_of!(ActivePositions, common_parts_source), size_of::<ExecutionParts<'static, SwiftMode>>(), std::mem::align_of::<ExecutionParts<'static, SwiftMode>>());
println!("AF_FIELD common_parts_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_parts_argument), size_of::<ExecutionParts<'static, SwiftMode>>(), std::mem::align_of::<ExecutionParts<'static, SwiftMode>>());
println!("AF_FIELD common_parts_return {} {} {}", std::mem::offset_of!(ActivePositions, common_parts_return), size_of::<ExecutionParts<'static, SwiftMode>>(), std::mem::align_of::<ExecutionParts<'static, SwiftMode>>());
println!("AF_FIELD common_parts_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_parts_caller), size_of::<ExecutionParts<'static, SwiftMode>>(), std::mem::align_of::<ExecutionParts<'static, SwiftMode>>());
println!("AF_FIELD common_parts_borrow_source {} {} {}", std::mem::offset_of!(ActivePositions, common_parts_borrow_source), size_of::<&'static mut ExecutionParts<'static, SwiftMode>>(), std::mem::align_of::<&'static mut ExecutionParts<'static, SwiftMode>>());
println!("AF_FIELD common_parts_borrow_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_parts_borrow_argument), size_of::<&'static mut ExecutionParts<'static, SwiftMode>>(), std::mem::align_of::<&'static mut ExecutionParts<'static, SwiftMode>>());
println!("AF_FIELD common_parts_borrow_return {} {} {}", std::mem::offset_of!(ActivePositions, common_parts_borrow_return), size_of::<&'static mut ExecutionParts<'static, SwiftMode>>(), std::mem::align_of::<&'static mut ExecutionParts<'static, SwiftMode>>());
println!("AF_FIELD common_parts_borrow_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_parts_borrow_caller), size_of::<&'static mut ExecutionParts<'static, SwiftMode>>(), std::mem::align_of::<&'static mut ExecutionParts<'static, SwiftMode>>());
println!("AF_FIELD common_operation_source {} {} {}", std::mem::offset_of!(ActivePositions, common_operation_source), size_of::<SwiftExecutionOperation<'static>>(), std::mem::align_of::<SwiftExecutionOperation<'static>>());
println!("AF_FIELD common_operation_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_operation_argument), size_of::<SwiftExecutionOperation<'static>>(), std::mem::align_of::<SwiftExecutionOperation<'static>>());
println!("AF_FIELD common_operation_return {} {} {}", std::mem::offset_of!(ActivePositions, common_operation_return), size_of::<SwiftExecutionOperation<'static>>(), std::mem::align_of::<SwiftExecutionOperation<'static>>());
println!("AF_FIELD common_operation_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_operation_caller), size_of::<SwiftExecutionOperation<'static>>(), std::mem::align_of::<SwiftExecutionOperation<'static>>());
println!("AF_FIELD common_operation_borrow_source {} {} {}", std::mem::offset_of!(ActivePositions, common_operation_borrow_source), size_of::<&'static mut SwiftExecutionOperation<'static>>(), std::mem::align_of::<&'static mut SwiftExecutionOperation<'static>>());
println!("AF_FIELD common_operation_borrow_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_operation_borrow_argument), size_of::<&'static mut SwiftExecutionOperation<'static>>(), std::mem::align_of::<&'static mut SwiftExecutionOperation<'static>>());
println!("AF_FIELD common_operation_borrow_return {} {} {}", std::mem::offset_of!(ActivePositions, common_operation_borrow_return), size_of::<&'static mut SwiftExecutionOperation<'static>>(), std::mem::align_of::<&'static mut SwiftExecutionOperation<'static>>());
println!("AF_FIELD common_operation_borrow_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_operation_borrow_caller), size_of::<&'static mut SwiftExecutionOperation<'static>>(), std::mem::align_of::<&'static mut SwiftExecutionOperation<'static>>());
println!("AF_FIELD common_control_source {} {} {}", std::mem::offset_of!(ActivePositions, common_control_source), size_of::<&'static mut RuntimeControl>(), std::mem::align_of::<&'static mut RuntimeControl>());
println!("AF_FIELD common_control_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_control_argument), size_of::<&'static mut RuntimeControl>(), std::mem::align_of::<&'static mut RuntimeControl>());
println!("AF_FIELD common_control_return {} {} {}", std::mem::offset_of!(ActivePositions, common_control_return), size_of::<&'static mut RuntimeControl>(), std::mem::align_of::<&'static mut RuntimeControl>());
println!("AF_FIELD common_control_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_control_caller), size_of::<&'static mut RuntimeControl>(), std::mem::align_of::<&'static mut RuntimeControl>());
println!("AF_FIELD common_wasi_source {} {} {}", std::mem::offset_of!(ActivePositions, common_wasi_source), size_of::<&'static AccountedWasi>(), std::mem::align_of::<&'static AccountedWasi>());
println!("AF_FIELD common_wasi_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_wasi_argument), size_of::<&'static AccountedWasi>(), std::mem::align_of::<&'static AccountedWasi>());
println!("AF_FIELD common_wasi_return {} {} {}", std::mem::offset_of!(ActivePositions, common_wasi_return), size_of::<&'static AccountedWasi>(), std::mem::align_of::<&'static AccountedWasi>());
println!("AF_FIELD common_wasi_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_wasi_caller), size_of::<&'static AccountedWasi>(), std::mem::align_of::<&'static AccountedWasi>());
println!("AF_FIELD common_values_source {} {} {}", std::mem::offset_of!(ActivePositions, common_values_source), size_of::<&'static mut Vec<Value>>(), std::mem::align_of::<&'static mut Vec<Value>>());
println!("AF_FIELD common_values_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_values_argument), size_of::<&'static mut Vec<Value>>(), std::mem::align_of::<&'static mut Vec<Value>>());
println!("AF_FIELD common_values_return {} {} {}", std::mem::offset_of!(ActivePositions, common_values_return), size_of::<&'static mut Vec<Value>>(), std::mem::align_of::<&'static mut Vec<Value>>());
println!("AF_FIELD common_values_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_values_caller), size_of::<&'static mut Vec<Value>>(), std::mem::align_of::<&'static mut Vec<Value>>());
println!("AF_FIELD common_controls_source {} {} {}", std::mem::offset_of!(ActivePositions, common_controls_source), size_of::<&'static mut Vec<Control>>(), std::mem::align_of::<&'static mut Vec<Control>>());
println!("AF_FIELD common_controls_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_controls_argument), size_of::<&'static mut Vec<Control>>(), std::mem::align_of::<&'static mut Vec<Control>>());
println!("AF_FIELD common_controls_return {} {} {}", std::mem::offset_of!(ActivePositions, common_controls_return), size_of::<&'static mut Vec<Control>>(), std::mem::align_of::<&'static mut Vec<Control>>());
println!("AF_FIELD common_controls_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_controls_caller), size_of::<&'static mut Vec<Control>>(), std::mem::align_of::<&'static mut Vec<Control>>());
println!("AF_FIELD common_frames_source {} {} {}", std::mem::offset_of!(ActivePositions, common_frames_source), size_of::<&'static mut Vec<SwiftFrame>>(), std::mem::align_of::<&'static mut Vec<SwiftFrame>>());
println!("AF_FIELD common_frames_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_frames_argument), size_of::<&'static mut Vec<SwiftFrame>>(), std::mem::align_of::<&'static mut Vec<SwiftFrame>>());
println!("AF_FIELD common_frames_return {} {} {}", std::mem::offset_of!(ActivePositions, common_frames_return), size_of::<&'static mut Vec<SwiftFrame>>(), std::mem::align_of::<&'static mut Vec<SwiftFrame>>());
println!("AF_FIELD common_frames_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_frames_caller), size_of::<&'static mut Vec<SwiftFrame>>(), std::mem::align_of::<&'static mut Vec<SwiftFrame>>());
println!("AF_FIELD common_cache_source {} {} {}", std::mem::offset_of!(ActivePositions, common_cache_source), size_of::<&'static mut SwiftFunctionCache>(), std::mem::align_of::<&'static mut SwiftFunctionCache>());
println!("AF_FIELD common_cache_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_cache_argument), size_of::<&'static mut SwiftFunctionCache>(), std::mem::align_of::<&'static mut SwiftFunctionCache>());
println!("AF_FIELD common_cache_return {} {} {}", std::mem::offset_of!(ActivePositions, common_cache_return), size_of::<&'static mut SwiftFunctionCache>(), std::mem::align_of::<&'static mut SwiftFunctionCache>());
println!("AF_FIELD common_cache_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_cache_caller), size_of::<&'static mut SwiftFunctionCache>(), std::mem::align_of::<&'static mut SwiftFunctionCache>());
println!("AF_FIELD common_usage_source {} {} {}", std::mem::offset_of!(ActivePositions, common_usage_source), size_of::<SwiftRunUsage>(), std::mem::align_of::<SwiftRunUsage>());
println!("AF_FIELD common_usage_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_usage_argument), size_of::<SwiftRunUsage>(), std::mem::align_of::<SwiftRunUsage>());
println!("AF_FIELD common_usage_return {} {} {}", std::mem::offset_of!(ActivePositions, common_usage_return), size_of::<SwiftRunUsage>(), std::mem::align_of::<SwiftRunUsage>());
println!("AF_FIELD common_usage_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_usage_caller), size_of::<SwiftRunUsage>(), std::mem::align_of::<SwiftRunUsage>());
println!("AF_FIELD common_observation_source {} {} {}", std::mem::offset_of!(ActivePositions, common_observation_source), size_of::<Option<WasiUsage>>(), std::mem::align_of::<Option<WasiUsage>>());
println!("AF_FIELD common_observation_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_observation_argument), size_of::<Option<WasiUsage>>(), std::mem::align_of::<Option<WasiUsage>>());
println!("AF_FIELD common_observation_return {} {} {}", std::mem::offset_of!(ActivePositions, common_observation_return), size_of::<Option<WasiUsage>>(), std::mem::align_of::<Option<WasiUsage>>());
println!("AF_FIELD common_observation_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_observation_caller), size_of::<Option<WasiUsage>>(), std::mem::align_of::<Option<WasiUsage>>());
println!("AF_FIELD common_cursor_source {} {} {}", std::mem::offset_of!(ActivePositions, common_cursor_source), size_of::<Cursor>(), std::mem::align_of::<Cursor>());
println!("AF_FIELD common_cursor_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_cursor_argument), size_of::<Cursor>(), std::mem::align_of::<Cursor>());
println!("AF_FIELD common_cursor_return {} {} {}", std::mem::offset_of!(ActivePositions, common_cursor_return), size_of::<Cursor>(), std::mem::align_of::<Cursor>());
println!("AF_FIELD common_cursor_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_cursor_caller), size_of::<Cursor>(), std::mem::align_of::<Cursor>());
println!("AF_FIELD common_live_source {} {} {}", std::mem::offset_of!(ActivePositions, common_live_source), size_of::<SwiftLiveUsage>(), std::mem::align_of::<SwiftLiveUsage>());
println!("AF_FIELD common_live_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_live_argument), size_of::<SwiftLiveUsage>(), std::mem::align_of::<SwiftLiveUsage>());
println!("AF_FIELD common_live_return {} {} {}", std::mem::offset_of!(ActivePositions, common_live_return), size_of::<SwiftLiveUsage>(), std::mem::align_of::<SwiftLiveUsage>());
println!("AF_FIELD common_live_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_live_caller), size_of::<SwiftLiveUsage>(), std::mem::align_of::<SwiftLiveUsage>());
println!("AF_FIELD common_fault_source {} {} {}", std::mem::offset_of!(ActivePositions, common_fault_source), size_of::<Fault>(), std::mem::align_of::<Fault>());
println!("AF_FIELD common_fault_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_fault_argument), size_of::<Fault>(), std::mem::align_of::<Fault>());
println!("AF_FIELD common_fault_return {} {} {}", std::mem::offset_of!(ActivePositions, common_fault_return), size_of::<Fault>(), std::mem::align_of::<Fault>());
println!("AF_FIELD common_fault_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_fault_caller), size_of::<Fault>(), std::mem::align_of::<Fault>());
println!("AF_FIELD common_failure_source {} {} {}", std::mem::offset_of!(ActivePositions, common_failure_source), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD common_failure_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_failure_argument), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD common_failure_return {} {} {}", std::mem::offset_of!(ActivePositions, common_failure_return), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD common_failure_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_failure_caller), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD common_unit_result_source {} {} {}", std::mem::offset_of!(ActivePositions, common_unit_result_source), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD common_unit_result_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_unit_result_argument), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD common_unit_result_return {} {} {}", std::mem::offset_of!(ActivePositions, common_unit_result_return), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD common_unit_result_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_unit_result_caller), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD common_gate_source {} {} {}", std::mem::offset_of!(ActivePositions, common_gate_source), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD common_gate_argument {} {} {}", std::mem::offset_of!(ActivePositions, common_gate_argument), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD common_gate_return {} {} {}", std::mem::offset_of!(ActivePositions, common_gate_return), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD common_gate_caller {} {} {}", std::mem::offset_of!(ActivePositions, common_gate_caller), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD acquire_phase_source {} {} {}", std::mem::offset_of!(ActivePositions, acquire_phase_source), size_of::<CacheOperationPhase<'static>>(), std::mem::align_of::<CacheOperationPhase<'static>>());
println!("AF_FIELD acquire_phase_argument {} {} {}", std::mem::offset_of!(ActivePositions, acquire_phase_argument), size_of::<CacheOperationPhase<'static>>(), std::mem::align_of::<CacheOperationPhase<'static>>());
println!("AF_FIELD acquire_phase_return {} {} {}", std::mem::offset_of!(ActivePositions, acquire_phase_return), size_of::<CacheOperationPhase<'static>>(), std::mem::align_of::<CacheOperationPhase<'static>>());
println!("AF_FIELD acquire_phase_caller {} {} {}", std::mem::offset_of!(ActivePositions, acquire_phase_caller), size_of::<CacheOperationPhase<'static>>(), std::mem::align_of::<CacheOperationPhase<'static>>());
println!("AF_FIELD acquire_prepare_result_source {} {} {}", std::mem::offset_of!(ActivePositions, acquire_prepare_result_source), size_of::<Result<CacheOperationPhase<'static>, SwiftRunFailure>>(), std::mem::align_of::<Result<CacheOperationPhase<'static>, SwiftRunFailure>>());
println!("AF_FIELD acquire_prepare_result_argument {} {} {}", std::mem::offset_of!(ActivePositions, acquire_prepare_result_argument), size_of::<Result<CacheOperationPhase<'static>, SwiftRunFailure>>(), std::mem::align_of::<Result<CacheOperationPhase<'static>, SwiftRunFailure>>());
println!("AF_FIELD acquire_prepare_result_return {} {} {}", std::mem::offset_of!(ActivePositions, acquire_prepare_result_return), size_of::<Result<CacheOperationPhase<'static>, SwiftRunFailure>>(), std::mem::align_of::<Result<CacheOperationPhase<'static>, SwiftRunFailure>>());
println!("AF_FIELD acquire_prepare_result_caller {} {} {}", std::mem::offset_of!(ActivePositions, acquire_prepare_result_caller), size_of::<Result<CacheOperationPhase<'static>, SwiftRunFailure>>(), std::mem::align_of::<Result<CacheOperationPhase<'static>, SwiftRunFailure>>());
println!("AF_FIELD acquire_prepare_option_source {} {} {}", std::mem::offset_of!(ActivePositions, acquire_prepare_option_source), size_of::<Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>>());
println!("AF_FIELD acquire_prepare_option_argument {} {} {}", std::mem::offset_of!(ActivePositions, acquire_prepare_option_argument), size_of::<Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>>());
println!("AF_FIELD acquire_prepare_option_return {} {} {}", std::mem::offset_of!(ActivePositions, acquire_prepare_option_return), size_of::<Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>>());
println!("AF_FIELD acquire_prepare_option_caller {} {} {}", std::mem::offset_of!(ActivePositions, acquire_prepare_option_caller), size_of::<Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>>());
println!("AF_FIELD acquire_pin_source {} {} {}", std::mem::offset_of!(ActivePositions, acquire_pin_source), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD acquire_pin_argument {} {} {}", std::mem::offset_of!(ActivePositions, acquire_pin_argument), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD acquire_pin_return {} {} {}", std::mem::offset_of!(ActivePositions, acquire_pin_return), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD acquire_pin_caller {} {} {}", std::mem::offset_of!(ActivePositions, acquire_pin_caller), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD acquire_pin_option_source {} {} {}", std::mem::offset_of!(ActivePositions, acquire_pin_option_source), size_of::<Option<SwiftFunctionPin>>(), std::mem::align_of::<Option<SwiftFunctionPin>>());
println!("AF_FIELD acquire_pin_option_argument {} {} {}", std::mem::offset_of!(ActivePositions, acquire_pin_option_argument), size_of::<Option<SwiftFunctionPin>>(), std::mem::align_of::<Option<SwiftFunctionPin>>());
println!("AF_FIELD acquire_pin_option_return {} {} {}", std::mem::offset_of!(ActivePositions, acquire_pin_option_return), size_of::<Option<SwiftFunctionPin>>(), std::mem::align_of::<Option<SwiftFunctionPin>>());
println!("AF_FIELD acquire_pin_option_caller {} {} {}", std::mem::offset_of!(ActivePositions, acquire_pin_option_caller), size_of::<Option<SwiftFunctionPin>>(), std::mem::align_of::<Option<SwiftFunctionPin>>());
println!("AF_FIELD acquire_pin_result_source {} {} {}", std::mem::offset_of!(ActivePositions, acquire_pin_result_source), size_of::<Result<SwiftFunctionPin, SwiftRunFailure>>(), std::mem::align_of::<Result<SwiftFunctionPin, SwiftRunFailure>>());
println!("AF_FIELD acquire_pin_result_argument {} {} {}", std::mem::offset_of!(ActivePositions, acquire_pin_result_argument), size_of::<Result<SwiftFunctionPin, SwiftRunFailure>>(), std::mem::align_of::<Result<SwiftFunctionPin, SwiftRunFailure>>());
println!("AF_FIELD acquire_pin_result_return {} {} {}", std::mem::offset_of!(ActivePositions, acquire_pin_result_return), size_of::<Result<SwiftFunctionPin, SwiftRunFailure>>(), std::mem::align_of::<Result<SwiftFunctionPin, SwiftRunFailure>>());
println!("AF_FIELD acquire_pin_result_caller {} {} {}", std::mem::offset_of!(ActivePositions, acquire_pin_result_caller), size_of::<Result<SwiftFunctionPin, SwiftRunFailure>>(), std::mem::align_of::<Result<SwiftFunctionPin, SwiftRunFailure>>());
println!("AF_FIELD acquire_pin_return_slot_source {} {} {}", std::mem::offset_of!(ActivePositions, acquire_pin_return_slot_source), size_of::<Option<Result<SwiftFunctionPin, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<SwiftFunctionPin, SwiftRunFailure>>>());
println!("AF_FIELD acquire_pin_return_slot_argument {} {} {}", std::mem::offset_of!(ActivePositions, acquire_pin_return_slot_argument), size_of::<Option<Result<SwiftFunctionPin, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<SwiftFunctionPin, SwiftRunFailure>>>());
println!("AF_FIELD acquire_pin_return_slot_return {} {} {}", std::mem::offset_of!(ActivePositions, acquire_pin_return_slot_return), size_of::<Option<Result<SwiftFunctionPin, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<SwiftFunctionPin, SwiftRunFailure>>>());
println!("AF_FIELD acquire_pin_return_slot_caller {} {} {}", std::mem::offset_of!(ActivePositions, acquire_pin_return_slot_caller), size_of::<Option<Result<SwiftFunctionPin, SwiftRunFailure>>>(), std::mem::align_of::<Option<Result<SwiftFunctionPin, SwiftRunFailure>>>());
println!("AF_FIELD acquire_attempt_source {} {} {}", std::mem::offset_of!(ActivePositions, acquire_attempt_source), size_of::<PinAttempt>(), std::mem::align_of::<PinAttempt>());
println!("AF_FIELD acquire_attempt_argument {} {} {}", std::mem::offset_of!(ActivePositions, acquire_attempt_argument), size_of::<PinAttempt>(), std::mem::align_of::<PinAttempt>());
println!("AF_FIELD acquire_attempt_return {} {} {}", std::mem::offset_of!(ActivePositions, acquire_attempt_return), size_of::<PinAttempt>(), std::mem::align_of::<PinAttempt>());
println!("AF_FIELD acquire_attempt_caller {} {} {}", std::mem::offset_of!(ActivePositions, acquire_attempt_caller), size_of::<PinAttempt>(), std::mem::align_of::<PinAttempt>());
println!("AF_FIELD acquire_first_source {} {} {}", std::mem::offset_of!(ActivePositions, acquire_first_source), size_of::<Option<SwiftRunFailure>>(), std::mem::align_of::<Option<SwiftRunFailure>>());
println!("AF_FIELD acquire_first_argument {} {} {}", std::mem::offset_of!(ActivePositions, acquire_first_argument), size_of::<Option<SwiftRunFailure>>(), std::mem::align_of::<Option<SwiftRunFailure>>());
println!("AF_FIELD acquire_first_return {} {} {}", std::mem::offset_of!(ActivePositions, acquire_first_return), size_of::<Option<SwiftRunFailure>>(), std::mem::align_of::<Option<SwiftRunFailure>>());
println!("AF_FIELD acquire_first_caller {} {} {}", std::mem::offset_of!(ActivePositions, acquire_first_caller), size_of::<Option<SwiftRunFailure>>(), std::mem::align_of::<Option<SwiftRunFailure>>());
println!("AF_FIELD acquire_nested_restore_source {} {} {}", std::mem::offset_of!(ActivePositions, acquire_nested_restore_source), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD acquire_nested_restore_argument {} {} {}", std::mem::offset_of!(ActivePositions, acquire_nested_restore_argument), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD acquire_nested_restore_return {} {} {}", std::mem::offset_of!(ActivePositions, acquire_nested_restore_return), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD acquire_nested_restore_caller {} {} {}", std::mem::offset_of!(ActivePositions, acquire_nested_restore_caller), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD acquire_frame_bound_source {} {} {}", std::mem::offset_of!(ActivePositions, acquire_frame_bound_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD acquire_frame_bound_argument {} {} {}", std::mem::offset_of!(ActivePositions, acquire_frame_bound_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD acquire_frame_bound_return {} {} {}", std::mem::offset_of!(ActivePositions, acquire_frame_bound_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD acquire_frame_bound_caller {} {} {}", std::mem::offset_of!(ActivePositions, acquire_frame_bound_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD acquire_completion_source {} {} {}", std::mem::offset_of!(ActivePositions, acquire_completion_source), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD acquire_completion_argument {} {} {}", std::mem::offset_of!(ActivePositions, acquire_completion_argument), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD acquire_completion_return {} {} {}", std::mem::offset_of!(ActivePositions, acquire_completion_return), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD acquire_completion_caller {} {} {}", std::mem::offset_of!(ActivePositions, acquire_completion_caller), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD acquire_function_source {} {} {}", std::mem::offset_of!(ActivePositions, acquire_function_source), size_of::<u32>(), std::mem::align_of::<u32>());
println!("AF_FIELD acquire_function_argument {} {} {}", std::mem::offset_of!(ActivePositions, acquire_function_argument), size_of::<u32>(), std::mem::align_of::<u32>());
println!("AF_FIELD acquire_function_return {} {} {}", std::mem::offset_of!(ActivePositions, acquire_function_return), size_of::<u32>(), std::mem::align_of::<u32>());
println!("AF_FIELD acquire_function_caller {} {} {}", std::mem::offset_of!(ActivePositions, acquire_function_caller), size_of::<u32>(), std::mem::align_of::<u32>());
println!("AF_FIELD acquire_empty_pair_source {} {} {}", std::mem::offset_of!(ActivePositions, acquire_empty_pair_source), size_of::<(Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>, Option<Result<SwiftFunctionPin, SwiftRunFailure>>)>(), std::mem::align_of::<(Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>, Option<Result<SwiftFunctionPin, SwiftRunFailure>>)>());
println!("AF_FIELD acquire_empty_pair_argument {} {} {}", std::mem::offset_of!(ActivePositions, acquire_empty_pair_argument), size_of::<(Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>, Option<Result<SwiftFunctionPin, SwiftRunFailure>>)>(), std::mem::align_of::<(Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>, Option<Result<SwiftFunctionPin, SwiftRunFailure>>)>());
println!("AF_FIELD acquire_empty_pair_return {} {} {}", std::mem::offset_of!(ActivePositions, acquire_empty_pair_return), size_of::<(Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>, Option<Result<SwiftFunctionPin, SwiftRunFailure>>)>(), std::mem::align_of::<(Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>, Option<Result<SwiftFunctionPin, SwiftRunFailure>>)>());
println!("AF_FIELD acquire_empty_pair_caller {} {} {}", std::mem::offset_of!(ActivePositions, acquire_empty_pair_caller), size_of::<(Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>, Option<Result<SwiftFunctionPin, SwiftRunFailure>>)>(), std::mem::align_of::<(Option<Result<CacheOperationPhase<'static>, SwiftRunFailure>>, Option<Result<SwiftFunctionPin, SwiftRunFailure>>)>());
println!("AF_FIELD entry_guard_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_guard_source), size_of::<EntryGuard>(), std::mem::align_of::<EntryGuard>());
println!("AF_FIELD entry_guard_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_guard_argument), size_of::<EntryGuard>(), std::mem::align_of::<EntryGuard>());
println!("AF_FIELD entry_guard_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_guard_return), size_of::<EntryGuard>(), std::mem::align_of::<EntryGuard>());
println!("AF_FIELD entry_guard_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_guard_caller), size_of::<EntryGuard>(), std::mem::align_of::<EntryGuard>());
println!("AF_FIELD entry_guard_option_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_guard_option_source), size_of::<Option<EntryGuard>>(), std::mem::align_of::<Option<EntryGuard>>());
println!("AF_FIELD entry_guard_option_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_guard_option_argument), size_of::<Option<EntryGuard>>(), std::mem::align_of::<Option<EntryGuard>>());
println!("AF_FIELD entry_guard_option_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_guard_option_return), size_of::<Option<EntryGuard>>(), std::mem::align_of::<Option<EntryGuard>>());
println!("AF_FIELD entry_guard_option_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_guard_option_caller), size_of::<Option<EntryGuard>>(), std::mem::align_of::<Option<EntryGuard>>());
println!("AF_FIELD entry_guard_borrow_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_guard_borrow_source), size_of::<&'static mut EntryGuard>(), std::mem::align_of::<&'static mut EntryGuard>());
println!("AF_FIELD entry_guard_borrow_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_guard_borrow_argument), size_of::<&'static mut EntryGuard>(), std::mem::align_of::<&'static mut EntryGuard>());
println!("AF_FIELD entry_guard_borrow_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_guard_borrow_return), size_of::<&'static mut EntryGuard>(), std::mem::align_of::<&'static mut EntryGuard>());
println!("AF_FIELD entry_guard_borrow_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_guard_borrow_caller), size_of::<&'static mut EntryGuard>(), std::mem::align_of::<&'static mut EntryGuard>());
println!("AF_FIELD entry_signature_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_signature_source), size_of::<SignatureView<'static>>(), std::mem::align_of::<SignatureView<'static>>());
println!("AF_FIELD entry_signature_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_signature_argument), size_of::<SignatureView<'static>>(), std::mem::align_of::<SignatureView<'static>>());
println!("AF_FIELD entry_signature_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_signature_return), size_of::<SignatureView<'static>>(), std::mem::align_of::<SignatureView<'static>>());
println!("AF_FIELD entry_signature_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_signature_caller), size_of::<SignatureView<'static>>(), std::mem::align_of::<SignatureView<'static>>());
println!("AF_FIELD entry_signature_option_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_signature_option_source), size_of::<Option<SignatureView<'static>>>(), std::mem::align_of::<Option<SignatureView<'static>>>());
println!("AF_FIELD entry_signature_option_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_signature_option_argument), size_of::<Option<SignatureView<'static>>>(), std::mem::align_of::<Option<SignatureView<'static>>>());
println!("AF_FIELD entry_signature_option_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_signature_option_return), size_of::<Option<SignatureView<'static>>>(), std::mem::align_of::<Option<SignatureView<'static>>>());
println!("AF_FIELD entry_signature_option_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_signature_option_caller), size_of::<Option<SignatureView<'static>>>(), std::mem::align_of::<Option<SignatureView<'static>>>());
println!("AF_FIELD entry_view_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_view_source), size_of::<FunctionView<'static>>(), std::mem::align_of::<FunctionView<'static>>());
println!("AF_FIELD entry_view_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_view_argument), size_of::<FunctionView<'static>>(), std::mem::align_of::<FunctionView<'static>>());
println!("AF_FIELD entry_view_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_view_return), size_of::<FunctionView<'static>>(), std::mem::align_of::<FunctionView<'static>>());
println!("AF_FIELD entry_view_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_view_caller), size_of::<FunctionView<'static>>(), std::mem::align_of::<FunctionView<'static>>());
println!("AF_FIELD entry_view_result_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_view_result_source), size_of::<Result<FunctionView<'static>, SwiftRunFailure>>(), std::mem::align_of::<Result<FunctionView<'static>, SwiftRunFailure>>());
println!("AF_FIELD entry_view_result_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_view_result_argument), size_of::<Result<FunctionView<'static>, SwiftRunFailure>>(), std::mem::align_of::<Result<FunctionView<'static>, SwiftRunFailure>>());
println!("AF_FIELD entry_view_result_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_view_result_return), size_of::<Result<FunctionView<'static>, SwiftRunFailure>>(), std::mem::align_of::<Result<FunctionView<'static>, SwiftRunFailure>>());
println!("AF_FIELD entry_view_result_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_view_result_caller), size_of::<Result<FunctionView<'static>, SwiftRunFailure>>(), std::mem::align_of::<Result<FunctionView<'static>, SwiftRunFailure>>());
println!("AF_FIELD entry_params_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_params_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_params_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_params_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_params_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_params_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_params_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_params_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_locals_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_locals_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_locals_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_locals_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_locals_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_locals_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_locals_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_locals_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_total_locals_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_total_locals_source), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD entry_total_locals_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_total_locals_argument), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD entry_total_locals_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_total_locals_return), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD entry_total_locals_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_total_locals_caller), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD entry_base_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_base_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_base_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_base_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_base_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_base_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_base_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_base_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_base_option_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_base_option_source), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD entry_base_option_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_base_option_argument), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD entry_base_option_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_base_option_return), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD entry_base_option_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_base_option_caller), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD entry_end_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_end_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_end_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_end_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_end_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_end_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_end_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_end_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_end_option_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_end_option_source), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD entry_end_option_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_end_option_argument), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD entry_end_option_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_end_option_return), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD entry_end_option_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_end_option_caller), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD entry_operands_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_operands_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_operands_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_operands_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_operands_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_operands_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_operands_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_operands_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_control_base_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_control_base_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_control_base_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_control_base_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_control_base_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_control_base_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_control_base_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_control_base_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_count_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_count_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_count_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_count_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_count_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_count_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_count_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_count_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_limit_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_limit_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_limit_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_limit_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_limit_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_limit_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_limit_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_limit_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_control_limit_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_control_limit_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_control_limit_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_control_limit_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_control_limit_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_control_limit_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_control_limit_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_control_limit_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_value_capacity_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_value_capacity_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_value_capacity_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_value_capacity_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_value_capacity_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_value_capacity_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_value_capacity_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_value_capacity_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_control_capacity_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_control_capacity_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_control_capacity_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_control_capacity_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_control_capacity_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_control_capacity_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_control_capacity_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_control_capacity_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_capacity_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_capacity_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_capacity_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_capacity_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_capacity_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_capacity_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_capacity_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_capacity_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_local_index_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_local_index_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_local_index_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_local_index_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_local_index_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_local_index_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_local_index_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_local_index_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_parameter_index_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_parameter_index_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_parameter_index_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_parameter_index_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_parameter_index_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_parameter_index_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_parameter_index_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_parameter_index_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_parameter_type_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_parameter_type_source), size_of::<Option<Type>>(), std::mem::align_of::<Option<Type>>());
println!("AF_FIELD entry_parameter_type_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_parameter_type_argument), size_of::<Option<Type>>(), std::mem::align_of::<Option<Type>>());
println!("AF_FIELD entry_parameter_type_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_parameter_type_return), size_of::<Option<Type>>(), std::mem::align_of::<Option<Type>>());
println!("AF_FIELD entry_parameter_type_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_parameter_type_caller), size_of::<Option<Type>>(), std::mem::align_of::<Option<Type>>());
println!("AF_FIELD entry_parameter_value_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_parameter_value_source), size_of::<Option<&'static Value>>(), std::mem::align_of::<Option<&'static Value>>());
println!("AF_FIELD entry_parameter_value_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_parameter_value_argument), size_of::<Option<&'static Value>>(), std::mem::align_of::<Option<&'static Value>>());
println!("AF_FIELD entry_parameter_value_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_parameter_value_return), size_of::<Option<&'static Value>>(), std::mem::align_of::<Option<&'static Value>>());
println!("AF_FIELD entry_parameter_value_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_parameter_value_caller), size_of::<Option<&'static Value>>(), std::mem::align_of::<Option<&'static Value>>());
println!("AF_FIELD entry_type_borrow_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_type_borrow_source), size_of::<Option<&'static Type>>(), std::mem::align_of::<Option<&'static Type>>());
println!("AF_FIELD entry_type_borrow_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_type_borrow_argument), size_of::<Option<&'static Type>>(), std::mem::align_of::<Option<&'static Type>>());
println!("AF_FIELD entry_type_borrow_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_type_borrow_return), size_of::<Option<&'static Type>>(), std::mem::align_of::<Option<&'static Type>>());
println!("AF_FIELD entry_type_borrow_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_type_borrow_caller), size_of::<Option<&'static Type>>(), std::mem::align_of::<Option<&'static Type>>());
println!("AF_FIELD entry_type_copy_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_type_copy_source), size_of::<Option<Type>>(), std::mem::align_of::<Option<Type>>());
println!("AF_FIELD entry_type_copy_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_type_copy_argument), size_of::<Option<Type>>(), std::mem::align_of::<Option<Type>>());
println!("AF_FIELD entry_type_copy_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_type_copy_return), size_of::<Option<Type>>(), std::mem::align_of::<Option<Type>>());
println!("AF_FIELD entry_type_copy_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_type_copy_caller), size_of::<Option<Type>>(), std::mem::align_of::<Option<Type>>());
println!("AF_FIELD entry_ty_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_ty_source), size_of::<Type>(), std::mem::align_of::<Type>());
println!("AF_FIELD entry_ty_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_ty_argument), size_of::<Type>(), std::mem::align_of::<Type>());
println!("AF_FIELD entry_ty_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_ty_return), size_of::<Type>(), std::mem::align_of::<Type>());
println!("AF_FIELD entry_ty_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_ty_caller), size_of::<Type>(), std::mem::align_of::<Type>());
println!("AF_FIELD entry_value_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_value_source), size_of::<Value>(), std::mem::align_of::<Value>());
println!("AF_FIELD entry_value_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_value_argument), size_of::<Value>(), std::mem::align_of::<Value>());
println!("AF_FIELD entry_value_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_value_return), size_of::<Value>(), std::mem::align_of::<Value>());
println!("AF_FIELD entry_value_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_value_caller), size_of::<Value>(), std::mem::align_of::<Value>());
println!("AF_FIELD entry_function_control_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_function_control_source), size_of::<Control>(), std::mem::align_of::<Control>());
println!("AF_FIELD entry_function_control_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_function_control_argument), size_of::<Control>(), std::mem::align_of::<Control>());
println!("AF_FIELD entry_function_control_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_function_control_return), size_of::<Control>(), std::mem::align_of::<Control>());
println!("AF_FIELD entry_function_control_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_function_control_caller), size_of::<Control>(), std::mem::align_of::<Control>());
println!("AF_FIELD entry_frame_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_source), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD entry_frame_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_argument), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD entry_frame_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_return), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD entry_frame_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_caller), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD entry_scalars_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_scalars_source), size_of::<FrameScalars>(), std::mem::align_of::<FrameScalars>());
println!("AF_FIELD entry_scalars_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_scalars_argument), size_of::<FrameScalars>(), std::mem::align_of::<FrameScalars>());
println!("AF_FIELD entry_scalars_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_scalars_return), size_of::<FrameScalars>(), std::mem::align_of::<FrameScalars>());
println!("AF_FIELD entry_scalars_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_scalars_caller), size_of::<FrameScalars>(), std::mem::align_of::<FrameScalars>());
println!("AF_FIELD entry_debit_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_debit_source), size_of::<Live>(), std::mem::align_of::<Live>());
println!("AF_FIELD entry_debit_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_debit_argument), size_of::<Live>(), std::mem::align_of::<Live>());
println!("AF_FIELD entry_debit_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_debit_return), size_of::<Live>(), std::mem::align_of::<Live>());
println!("AF_FIELD entry_debit_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_debit_caller), size_of::<Live>(), std::mem::align_of::<Live>());
println!("AF_FIELD entry_work_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_work_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_work_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_work_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_work_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_work_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_work_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_work_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_work_option_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_work_option_source), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD entry_work_option_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_work_option_argument), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD entry_work_option_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_work_option_return), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD entry_work_option_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_work_option_caller), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD entry_work_u64_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_work_u64_source), size_of::<u64>(), std::mem::align_of::<u64>());
println!("AF_FIELD entry_work_u64_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_work_u64_argument), size_of::<u64>(), std::mem::align_of::<u64>());
println!("AF_FIELD entry_work_u64_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_work_u64_return), size_of::<u64>(), std::mem::align_of::<u64>());
println!("AF_FIELD entry_work_u64_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_work_u64_caller), size_of::<u64>(), std::mem::align_of::<u64>());
println!("AF_FIELD entry_debit_result_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_debit_result_source), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD entry_debit_result_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_debit_result_argument), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD entry_debit_result_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_debit_result_return), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD entry_debit_result_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_debit_result_caller), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD entry_checked_result_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_checked_result_source), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD entry_checked_result_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_checked_result_argument), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD entry_checked_result_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_checked_result_return), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD entry_checked_result_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_checked_result_caller), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD entry_pin_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_pin_source), size_of::<Option<SwiftFunctionPin>>(), std::mem::align_of::<Option<SwiftFunctionPin>>());
println!("AF_FIELD entry_pin_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_pin_argument), size_of::<Option<SwiftFunctionPin>>(), std::mem::align_of::<Option<SwiftFunctionPin>>());
println!("AF_FIELD entry_pin_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_pin_return), size_of::<Option<SwiftFunctionPin>>(), std::mem::align_of::<Option<SwiftFunctionPin>>());
println!("AF_FIELD entry_pin_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_pin_caller), size_of::<Option<SwiftFunctionPin>>(), std::mem::align_of::<Option<SwiftFunctionPin>>());
println!("AF_FIELD entry_result_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_result_source), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD entry_result_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_result_argument), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD entry_result_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_result_return), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD entry_result_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_result_caller), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD finish_frame_borrow_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_borrow_source), size_of::<Option<&'static SwiftFrame>>(), std::mem::align_of::<Option<&'static SwiftFrame>>());
println!("AF_FIELD finish_frame_borrow_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_borrow_argument), size_of::<Option<&'static SwiftFrame>>(), std::mem::align_of::<Option<&'static SwiftFrame>>());
println!("AF_FIELD finish_frame_borrow_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_borrow_return), size_of::<Option<&'static SwiftFrame>>(), std::mem::align_of::<Option<&'static SwiftFrame>>());
println!("AF_FIELD finish_frame_borrow_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_borrow_caller), size_of::<Option<&'static SwiftFrame>>(), std::mem::align_of::<Option<&'static SwiftFrame>>());
println!("AF_FIELD finish_scalars_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_scalars_source), size_of::<FrameScalars>(), std::mem::align_of::<FrameScalars>());
println!("AF_FIELD finish_scalars_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_scalars_argument), size_of::<FrameScalars>(), std::mem::align_of::<FrameScalars>());
println!("AF_FIELD finish_scalars_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_scalars_return), size_of::<FrameScalars>(), std::mem::align_of::<FrameScalars>());
println!("AF_FIELD finish_scalars_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_scalars_caller), size_of::<FrameScalars>(), std::mem::align_of::<FrameScalars>());
println!("AF_FIELD finish_saved_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_saved_source), size_of::<Option<Value>>(), std::mem::align_of::<Option<Value>>());
println!("AF_FIELD finish_saved_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_saved_argument), size_of::<Option<Value>>(), std::mem::align_of::<Option<Value>>());
println!("AF_FIELD finish_saved_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_saved_return), size_of::<Option<Value>>(), std::mem::align_of::<Option<Value>>());
println!("AF_FIELD finish_saved_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_saved_caller), size_of::<Option<Value>>(), std::mem::align_of::<Option<Value>>());
println!("AF_FIELD finish_saved_value_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_saved_value_source), size_of::<Value>(), std::mem::align_of::<Value>());
println!("AF_FIELD finish_saved_value_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_saved_value_argument), size_of::<Value>(), std::mem::align_of::<Value>());
println!("AF_FIELD finish_saved_value_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_saved_value_return), size_of::<Value>(), std::mem::align_of::<Value>());
println!("AF_FIELD finish_saved_value_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_saved_value_caller), size_of::<Value>(), std::mem::align_of::<Value>());
println!("AF_FIELD finish_pop_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_pop_source), size_of::<Result<Value, SwiftRunFailure>>(), std::mem::align_of::<Result<Value, SwiftRunFailure>>());
println!("AF_FIELD finish_pop_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_pop_argument), size_of::<Result<Value, SwiftRunFailure>>(), std::mem::align_of::<Result<Value, SwiftRunFailure>>());
println!("AF_FIELD finish_pop_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_pop_return), size_of::<Result<Value, SwiftRunFailure>>(), std::mem::align_of::<Result<Value, SwiftRunFailure>>());
println!("AF_FIELD finish_pop_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_pop_caller), size_of::<Result<Value, SwiftRunFailure>>(), std::mem::align_of::<Result<Value, SwiftRunFailure>>());
println!("AF_FIELD finish_value_len_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_value_len_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_value_len_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_value_len_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_value_len_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_value_len_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_value_len_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_value_len_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_control_len_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_control_len_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_control_len_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_control_len_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_control_len_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_control_len_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_control_len_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_control_len_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_base_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_base_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_base_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_base_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_base_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_base_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_base_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_base_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_control_base_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_control_base_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_control_base_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_control_base_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_control_base_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_control_base_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_control_base_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_control_base_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_work_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_work_source), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD finish_work_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_work_argument), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD finish_work_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_work_return), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD finish_work_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_work_caller), size_of::<Option<usize>>(), std::mem::align_of::<Option<usize>>());
println!("AF_FIELD finish_value_delta_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_value_delta_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_value_delta_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_value_delta_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_value_delta_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_value_delta_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_value_delta_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_value_delta_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_control_delta_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_control_delta_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_control_delta_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_control_delta_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_control_delta_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_control_delta_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_control_delta_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_control_delta_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_frame_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_source), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD finish_frame_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_argument), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD finish_frame_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_return), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD finish_frame_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_caller), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD finish_frame_option_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_option_source), size_of::<Option<SwiftFrame>>(), std::mem::align_of::<Option<SwiftFrame>>());
println!("AF_FIELD finish_frame_option_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_option_argument), size_of::<Option<SwiftFrame>>(), std::mem::align_of::<Option<SwiftFrame>>());
println!("AF_FIELD finish_frame_option_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_option_return), size_of::<Option<SwiftFrame>>(), std::mem::align_of::<Option<SwiftFrame>>());
println!("AF_FIELD finish_frame_option_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_option_caller), size_of::<Option<SwiftFrame>>(), std::mem::align_of::<Option<SwiftFrame>>());
println!("AF_FIELD finish_pin_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_pin_source), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD finish_pin_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_pin_argument), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD finish_pin_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_pin_return), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD finish_pin_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_pin_caller), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD finish_release_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_release_source), size_of::<Result<(), SwiftReleaseFailure>>(), std::mem::align_of::<Result<(), SwiftReleaseFailure>>());
println!("AF_FIELD finish_release_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_release_argument), size_of::<Result<(), SwiftReleaseFailure>>(), std::mem::align_of::<Result<(), SwiftReleaseFailure>>());
println!("AF_FIELD finish_release_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_release_return), size_of::<Result<(), SwiftReleaseFailure>>(), std::mem::align_of::<Result<(), SwiftReleaseFailure>>());
println!("AF_FIELD finish_release_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_release_caller), size_of::<Result<(), SwiftReleaseFailure>>(), std::mem::align_of::<Result<(), SwiftReleaseFailure>>());
println!("AF_FIELD finish_rejected_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_rejected_source), size_of::<SwiftReleaseFailure>(), std::mem::align_of::<SwiftReleaseFailure>());
println!("AF_FIELD finish_rejected_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_rejected_argument), size_of::<SwiftReleaseFailure>(), std::mem::align_of::<SwiftReleaseFailure>());
println!("AF_FIELD finish_rejected_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_rejected_return), size_of::<SwiftReleaseFailure>(), std::mem::align_of::<SwiftReleaseFailure>());
println!("AF_FIELD finish_rejected_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_rejected_caller), size_of::<SwiftReleaseFailure>(), std::mem::align_of::<SwiftReleaseFailure>());
println!("AF_FIELD finish_restored_frame_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_restored_frame_source), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD finish_restored_frame_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_restored_frame_argument), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD finish_restored_frame_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_restored_frame_return), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD finish_restored_frame_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_restored_frame_caller), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD finish_push_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_push_source), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD finish_push_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_push_argument), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD finish_push_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_push_return), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD finish_push_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_push_caller), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD finish_result_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_result_source), size_of::<Result<FrameReturn, SwiftRunFailure>>(), std::mem::align_of::<Result<FrameReturn, SwiftRunFailure>>());
println!("AF_FIELD finish_result_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_result_argument), size_of::<Result<FrameReturn, SwiftRunFailure>>(), std::mem::align_of::<Result<FrameReturn, SwiftRunFailure>>());
println!("AF_FIELD finish_result_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_result_return), size_of::<Result<FrameReturn, SwiftRunFailure>>(), std::mem::align_of::<Result<FrameReturn, SwiftRunFailure>>());
println!("AF_FIELD finish_result_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_result_caller), size_of::<Result<FrameReturn, SwiftRunFailure>>(), std::mem::align_of::<Result<FrameReturn, SwiftRunFailure>>());
println!("AF_FIELD finish_returned_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_returned_source), size_of::<FrameReturn>(), std::mem::align_of::<FrameReturn>());
println!("AF_FIELD finish_returned_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_returned_argument), size_of::<FrameReturn>(), std::mem::align_of::<FrameReturn>());
println!("AF_FIELD finish_returned_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_returned_return), size_of::<FrameReturn>(), std::mem::align_of::<FrameReturn>());
println!("AF_FIELD finish_returned_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_returned_caller), size_of::<FrameReturn>(), std::mem::align_of::<FrameReturn>());
println!("AF_FIELD rejection_guard_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_guard_source), size_of::<EntryGuard>(), std::mem::align_of::<EntryGuard>());
println!("AF_FIELD rejection_guard_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_guard_argument), size_of::<EntryGuard>(), std::mem::align_of::<EntryGuard>());
println!("AF_FIELD rejection_guard_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_guard_return), size_of::<EntryGuard>(), std::mem::align_of::<EntryGuard>());
println!("AF_FIELD rejection_guard_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_guard_caller), size_of::<EntryGuard>(), std::mem::align_of::<EntryGuard>());
println!("AF_FIELD rejection_guard_option_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_guard_option_source), size_of::<Option<EntryGuard>>(), std::mem::align_of::<Option<EntryGuard>>());
println!("AF_FIELD rejection_guard_option_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_guard_option_argument), size_of::<Option<EntryGuard>>(), std::mem::align_of::<Option<EntryGuard>>());
println!("AF_FIELD rejection_guard_option_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_guard_option_return), size_of::<Option<EntryGuard>>(), std::mem::align_of::<Option<EntryGuard>>());
println!("AF_FIELD rejection_guard_option_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_guard_option_caller), size_of::<Option<EntryGuard>>(), std::mem::align_of::<Option<EntryGuard>>());
println!("AF_FIELD rejection_guard_pin_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_guard_pin_source), size_of::<Option<SwiftFunctionPin>>(), std::mem::align_of::<Option<SwiftFunctionPin>>());
println!("AF_FIELD rejection_guard_pin_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_guard_pin_argument), size_of::<Option<SwiftFunctionPin>>(), std::mem::align_of::<Option<SwiftFunctionPin>>());
println!("AF_FIELD rejection_guard_pin_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_guard_pin_return), size_of::<Option<SwiftFunctionPin>>(), std::mem::align_of::<Option<SwiftFunctionPin>>());
println!("AF_FIELD rejection_guard_pin_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_guard_pin_caller), size_of::<Option<SwiftFunctionPin>>(), std::mem::align_of::<Option<SwiftFunctionPin>>());
println!("AF_FIELD rejection_release_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_release_source), size_of::<Result<(), SwiftReleaseFailure>>(), std::mem::align_of::<Result<(), SwiftReleaseFailure>>());
println!("AF_FIELD rejection_release_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_release_argument), size_of::<Result<(), SwiftReleaseFailure>>(), std::mem::align_of::<Result<(), SwiftReleaseFailure>>());
println!("AF_FIELD rejection_release_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_release_return), size_of::<Result<(), SwiftReleaseFailure>>(), std::mem::align_of::<Result<(), SwiftReleaseFailure>>());
println!("AF_FIELD rejection_release_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_release_caller), size_of::<Result<(), SwiftReleaseFailure>>(), std::mem::align_of::<Result<(), SwiftReleaseFailure>>());
println!("AF_FIELD rejection_rejected_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_rejected_source), size_of::<SwiftReleaseFailure>(), std::mem::align_of::<SwiftReleaseFailure>());
println!("AF_FIELD rejection_rejected_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_rejected_argument), size_of::<SwiftReleaseFailure>(), std::mem::align_of::<SwiftReleaseFailure>());
println!("AF_FIELD rejection_rejected_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_rejected_return), size_of::<SwiftReleaseFailure>(), std::mem::align_of::<SwiftReleaseFailure>());
println!("AF_FIELD rejection_rejected_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_rejected_caller), size_of::<SwiftReleaseFailure>(), std::mem::align_of::<SwiftReleaseFailure>());
println!("AF_FIELD rejection_rejected_pin_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_rejected_pin_source), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD rejection_rejected_pin_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_rejected_pin_argument), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD rejection_rejected_pin_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_rejected_pin_return), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD rejection_rejected_pin_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_rejected_pin_caller), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD rejection_values_actual_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_values_actual_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD rejection_values_actual_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_values_actual_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD rejection_values_actual_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_values_actual_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD rejection_values_actual_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_values_actual_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD rejection_controls_actual_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_controls_actual_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD rejection_controls_actual_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_controls_actual_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD rejection_controls_actual_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_controls_actual_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD rejection_controls_actual_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_controls_actual_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD rejection_value_debit_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_value_debit_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD rejection_value_debit_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_value_debit_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD rejection_value_debit_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_value_debit_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD rejection_value_debit_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_value_debit_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD rejection_control_debit_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_control_debit_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD rejection_control_debit_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_control_debit_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD rejection_control_debit_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_control_debit_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD rejection_control_debit_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_control_debit_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD rejection_frame_debit_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_frame_debit_source), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD rejection_frame_debit_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_frame_debit_argument), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD rejection_frame_debit_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_frame_debit_return), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD rejection_frame_debit_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_frame_debit_caller), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD rejection_removal_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_removal_source), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD rejection_removal_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_removal_argument), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD rejection_removal_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_removal_return), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD rejection_removal_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_removal_caller), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD drain_cleanup_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_cleanup_source), size_of::<&'static mut FrameCleanupState>(), std::mem::align_of::<&'static mut FrameCleanupState>());
println!("AF_FIELD drain_cleanup_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_cleanup_argument), size_of::<&'static mut FrameCleanupState>(), std::mem::align_of::<&'static mut FrameCleanupState>());
println!("AF_FIELD drain_cleanup_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_cleanup_return), size_of::<&'static mut FrameCleanupState>(), std::mem::align_of::<&'static mut FrameCleanupState>());
println!("AF_FIELD drain_cleanup_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_cleanup_caller), size_of::<&'static mut FrameCleanupState>(), std::mem::align_of::<&'static mut FrameCleanupState>());
println!("AF_FIELD drain_unvisited_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_unvisited_source), size_of::<&'static mut usize>(), std::mem::align_of::<&'static mut usize>());
println!("AF_FIELD drain_unvisited_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_unvisited_argument), size_of::<&'static mut usize>(), std::mem::align_of::<&'static mut usize>());
println!("AF_FIELD drain_unvisited_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_unvisited_return), size_of::<&'static mut usize>(), std::mem::align_of::<&'static mut usize>());
println!("AF_FIELD drain_unvisited_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_unvisited_caller), size_of::<&'static mut usize>(), std::mem::align_of::<&'static mut usize>());
println!("AF_FIELD drain_index_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_index_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_index_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_index_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_index_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_index_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_index_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_index_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_frame_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_source), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD drain_frame_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_argument), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD drain_frame_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_return), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD drain_frame_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_caller), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD drain_scalars_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_scalars_source), size_of::<FrameScalars>(), std::mem::align_of::<FrameScalars>());
println!("AF_FIELD drain_scalars_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_scalars_argument), size_of::<FrameScalars>(), std::mem::align_of::<FrameScalars>());
println!("AF_FIELD drain_scalars_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_scalars_return), size_of::<FrameScalars>(), std::mem::align_of::<FrameScalars>());
println!("AF_FIELD drain_scalars_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_scalars_caller), size_of::<FrameScalars>(), std::mem::align_of::<FrameScalars>());
println!("AF_FIELD drain_pin_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_pin_source), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD drain_pin_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_pin_argument), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD drain_pin_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_pin_return), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD drain_pin_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_pin_caller), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD drain_release_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_release_source), size_of::<Result<(), SwiftReleaseFailure>>(), std::mem::align_of::<Result<(), SwiftReleaseFailure>>());
println!("AF_FIELD drain_release_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_release_argument), size_of::<Result<(), SwiftReleaseFailure>>(), std::mem::align_of::<Result<(), SwiftReleaseFailure>>());
println!("AF_FIELD drain_release_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_release_return), size_of::<Result<(), SwiftReleaseFailure>>(), std::mem::align_of::<Result<(), SwiftReleaseFailure>>());
println!("AF_FIELD drain_release_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_release_caller), size_of::<Result<(), SwiftReleaseFailure>>(), std::mem::align_of::<Result<(), SwiftReleaseFailure>>());
println!("AF_FIELD drain_rejected_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_rejected_source), size_of::<SwiftReleaseFailure>(), std::mem::align_of::<SwiftReleaseFailure>());
println!("AF_FIELD drain_rejected_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_rejected_argument), size_of::<SwiftReleaseFailure>(), std::mem::align_of::<SwiftReleaseFailure>());
println!("AF_FIELD drain_rejected_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_rejected_return), size_of::<SwiftReleaseFailure>(), std::mem::align_of::<SwiftReleaseFailure>());
println!("AF_FIELD drain_rejected_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_rejected_caller), size_of::<SwiftReleaseFailure>(), std::mem::align_of::<SwiftReleaseFailure>());
println!("AF_FIELD drain_restored_pin_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_restored_pin_source), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD drain_restored_pin_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_restored_pin_argument), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD drain_restored_pin_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_restored_pin_return), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD drain_restored_pin_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_restored_pin_caller), size_of::<SwiftFunctionPin>(), std::mem::align_of::<SwiftFunctionPin>());
println!("AF_FIELD drain_restored_frame_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_restored_frame_source), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD drain_restored_frame_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_restored_frame_argument), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD drain_restored_frame_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_restored_frame_return), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD drain_restored_frame_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_restored_frame_caller), size_of::<SwiftFrame>(), std::mem::align_of::<SwiftFrame>());
println!("AF_FIELD drain_first_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_first_source), size_of::<Option<SwiftRunFailure>>(), std::mem::align_of::<Option<SwiftRunFailure>>());
println!("AF_FIELD drain_first_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_first_argument), size_of::<Option<SwiftRunFailure>>(), std::mem::align_of::<Option<SwiftRunFailure>>());
println!("AF_FIELD drain_first_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_first_return), size_of::<Option<SwiftRunFailure>>(), std::mem::align_of::<Option<SwiftRunFailure>>());
println!("AF_FIELD drain_first_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_first_caller), size_of::<Option<SwiftRunFailure>>(), std::mem::align_of::<Option<SwiftRunFailure>>());
println!("AF_FIELD drain_value_len_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_value_len_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_value_len_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_value_len_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_value_len_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_value_len_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_value_len_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_value_len_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_control_len_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_control_len_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_control_len_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_control_len_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_control_len_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_control_len_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_control_len_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_control_len_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_live_before_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_live_before_source), size_of::<SwiftLiveUsage>(), std::mem::align_of::<SwiftLiveUsage>());
println!("AF_FIELD drain_live_before_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_live_before_argument), size_of::<SwiftLiveUsage>(), std::mem::align_of::<SwiftLiveUsage>());
println!("AF_FIELD drain_live_before_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_live_before_return), size_of::<SwiftLiveUsage>(), std::mem::align_of::<SwiftLiveUsage>());
println!("AF_FIELD drain_live_before_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_live_before_caller), size_of::<SwiftLiveUsage>(), std::mem::align_of::<SwiftLiveUsage>());
println!("AF_FIELD drain_live_after_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_live_after_source), size_of::<SwiftLiveUsage>(), std::mem::align_of::<SwiftLiveUsage>());
println!("AF_FIELD drain_live_after_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_live_after_argument), size_of::<SwiftLiveUsage>(), std::mem::align_of::<SwiftLiveUsage>());
println!("AF_FIELD drain_live_after_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_live_after_return), size_of::<SwiftLiveUsage>(), std::mem::align_of::<SwiftLiveUsage>());
println!("AF_FIELD drain_live_after_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_live_after_caller), size_of::<SwiftLiveUsage>(), std::mem::align_of::<SwiftLiveUsage>());
println!("AF_FIELD drain_cache_before_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_cache_before_source), size_of::<super::super::cache::SwiftCacheUsage>(), std::mem::align_of::<super::super::cache::SwiftCacheUsage>());
println!("AF_FIELD drain_cache_before_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_cache_before_argument), size_of::<super::super::cache::SwiftCacheUsage>(), std::mem::align_of::<super::super::cache::SwiftCacheUsage>());
println!("AF_FIELD drain_cache_before_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_cache_before_return), size_of::<super::super::cache::SwiftCacheUsage>(), std::mem::align_of::<super::super::cache::SwiftCacheUsage>());
println!("AF_FIELD drain_cache_before_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_cache_before_caller), size_of::<super::super::cache::SwiftCacheUsage>(), std::mem::align_of::<super::super::cache::SwiftCacheUsage>());
println!("AF_FIELD drain_cache_after_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_cache_after_source), size_of::<super::super::cache::SwiftCacheUsage>(), std::mem::align_of::<super::super::cache::SwiftCacheUsage>());
println!("AF_FIELD drain_cache_after_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_cache_after_argument), size_of::<super::super::cache::SwiftCacheUsage>(), std::mem::align_of::<super::super::cache::SwiftCacheUsage>());
println!("AF_FIELD drain_cache_after_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_cache_after_return), size_of::<super::super::cache::SwiftCacheUsage>(), std::mem::align_of::<super::super::cache::SwiftCacheUsage>());
println!("AF_FIELD drain_cache_after_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_cache_after_caller), size_of::<super::super::cache::SwiftCacheUsage>(), std::mem::align_of::<super::super::cache::SwiftCacheUsage>());
println!("AF_FIELD drain_report_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_report_source), size_of::<FrameDrainReport>(), std::mem::align_of::<FrameDrainReport>());
println!("AF_FIELD drain_report_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_report_argument), size_of::<FrameDrainReport>(), std::mem::align_of::<FrameDrainReport>());
println!("AF_FIELD drain_report_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_report_return), size_of::<FrameDrainReport>(), std::mem::align_of::<FrameDrainReport>());
println!("AF_FIELD drain_report_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_report_caller), size_of::<FrameDrainReport>(), std::mem::align_of::<FrameDrainReport>());
println!("AF_FIELD drain_remaining_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_remaining_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_remaining_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_remaining_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_remaining_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_remaining_return), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_remaining_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_remaining_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_removed_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_removed_source), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD drain_removed_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_removed_argument), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD drain_removed_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_removed_return), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD drain_removed_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_removed_caller), size_of::<Result<(), SwiftRunFailure>>(), std::mem::align_of::<Result<(), SwiftRunFailure>>());
println!("AF_FIELD entry_frame_function_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_function_source), size_of::<u32>(), std::mem::align_of::<u32>());
println!("AF_FIELD entry_frame_function_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_function_argument), size_of::<u32>(), std::mem::align_of::<u32>());
println!("AF_FIELD entry_frame_function_restore {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_function_restore), size_of::<u32>(), std::mem::align_of::<u32>());
println!("AF_FIELD entry_frame_function_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_function_caller), size_of::<u32>(), std::mem::align_of::<u32>());
println!("AF_FIELD entry_frame_pc_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_pc_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_pc_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_pc_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_pc_restore {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_pc_restore), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_pc_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_pc_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_base_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_base_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_base_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_base_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_base_restore {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_base_restore), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_base_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_base_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_operands_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_operands_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_operands_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_operands_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_operands_restore {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_operands_restore), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_operands_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_operands_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_controls_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_controls_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_controls_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_controls_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_controls_restore {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_controls_restore), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_controls_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_controls_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD entry_frame_result_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_result_source), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD entry_frame_result_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_result_argument), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD entry_frame_result_restore {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_result_restore), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD entry_frame_result_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_frame_result_caller), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD finish_frame_function_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_function_source), size_of::<u32>(), std::mem::align_of::<u32>());
println!("AF_FIELD finish_frame_function_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_function_argument), size_of::<u32>(), std::mem::align_of::<u32>());
println!("AF_FIELD finish_frame_function_restore {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_function_restore), size_of::<u32>(), std::mem::align_of::<u32>());
println!("AF_FIELD finish_frame_function_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_function_caller), size_of::<u32>(), std::mem::align_of::<u32>());
println!("AF_FIELD finish_frame_pc_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_pc_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_frame_pc_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_pc_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_frame_pc_restore {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_pc_restore), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_frame_pc_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_pc_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_frame_base_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_base_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_frame_base_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_base_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_frame_base_restore {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_base_restore), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_frame_base_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_base_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_frame_operands_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_operands_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_frame_operands_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_operands_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_frame_operands_restore {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_operands_restore), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_frame_operands_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_operands_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_frame_controls_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_controls_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_frame_controls_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_controls_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_frame_controls_restore {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_controls_restore), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_frame_controls_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_controls_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD finish_frame_result_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_result_source), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD finish_frame_result_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_result_argument), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD finish_frame_result_restore {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_result_restore), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD finish_frame_result_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_frame_result_caller), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD drain_frame_function_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_function_source), size_of::<u32>(), std::mem::align_of::<u32>());
println!("AF_FIELD drain_frame_function_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_function_argument), size_of::<u32>(), std::mem::align_of::<u32>());
println!("AF_FIELD drain_frame_function_restore {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_function_restore), size_of::<u32>(), std::mem::align_of::<u32>());
println!("AF_FIELD drain_frame_function_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_function_caller), size_of::<u32>(), std::mem::align_of::<u32>());
println!("AF_FIELD drain_frame_pc_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_pc_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_frame_pc_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_pc_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_frame_pc_restore {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_pc_restore), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_frame_pc_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_pc_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_frame_base_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_base_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_frame_base_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_base_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_frame_base_restore {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_base_restore), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_frame_base_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_base_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_frame_operands_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_operands_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_frame_operands_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_operands_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_frame_operands_restore {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_operands_restore), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_frame_operands_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_operands_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_frame_controls_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_controls_source), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_frame_controls_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_controls_argument), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_frame_controls_restore {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_controls_restore), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_frame_controls_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_controls_caller), size_of::<usize>(), std::mem::align_of::<usize>());
println!("AF_FIELD drain_frame_result_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_result_source), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD drain_frame_result_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_result_argument), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD drain_frame_result_restore {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_result_restore), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD drain_frame_result_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_frame_result_caller), size_of::<bool>(), std::mem::align_of::<bool>());
println!("AF_FIELD entry_try_branch_unit_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_try_branch_unit_source), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD entry_try_branch_unit_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_try_branch_unit_argument), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD entry_try_branch_unit_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_try_branch_unit_return), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD entry_try_branch_unit_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_try_branch_unit_caller), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD entry_try_branch_value_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_try_branch_value_source), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>());
println!("AF_FIELD entry_try_branch_value_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_try_branch_value_argument), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>());
println!("AF_FIELD entry_try_branch_value_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_try_branch_value_return), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>());
println!("AF_FIELD entry_try_branch_value_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_try_branch_value_caller), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>());
println!("AF_FIELD entry_try_branch_usize_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_try_branch_usize_source), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>());
println!("AF_FIELD entry_try_branch_usize_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_try_branch_usize_argument), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>());
println!("AF_FIELD entry_try_branch_usize_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_try_branch_usize_return), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>());
println!("AF_FIELD entry_try_branch_usize_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_try_branch_usize_caller), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>());
println!("AF_FIELD entry_try_residual_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_try_residual_source), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD entry_try_residual_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_try_residual_argument), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD entry_try_residual_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_try_residual_return), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD entry_try_residual_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_try_residual_caller), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD entry_closure_capture_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_closure_capture_source), size_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>(), std::mem::align_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>());
println!("AF_FIELD entry_closure_capture_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_closure_capture_argument), size_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>(), std::mem::align_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>());
println!("AF_FIELD entry_closure_capture_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_closure_capture_return), size_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>(), std::mem::align_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>());
println!("AF_FIELD entry_closure_capture_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_closure_capture_caller), size_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>(), std::mem::align_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>());
println!("AF_FIELD entry_closure_failure_source {} {} {}", std::mem::offset_of!(ActivePositions, entry_closure_failure_source), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD entry_closure_failure_argument {} {} {}", std::mem::offset_of!(ActivePositions, entry_closure_failure_argument), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD entry_closure_failure_return {} {} {}", std::mem::offset_of!(ActivePositions, entry_closure_failure_return), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD entry_closure_failure_caller {} {} {}", std::mem::offset_of!(ActivePositions, entry_closure_failure_caller), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD finish_try_branch_unit_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_try_branch_unit_source), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD finish_try_branch_unit_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_try_branch_unit_argument), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD finish_try_branch_unit_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_try_branch_unit_return), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD finish_try_branch_unit_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_try_branch_unit_caller), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD finish_try_branch_value_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_try_branch_value_source), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>());
println!("AF_FIELD finish_try_branch_value_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_try_branch_value_argument), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>());
println!("AF_FIELD finish_try_branch_value_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_try_branch_value_return), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>());
println!("AF_FIELD finish_try_branch_value_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_try_branch_value_caller), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>());
println!("AF_FIELD finish_try_branch_usize_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_try_branch_usize_source), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>());
println!("AF_FIELD finish_try_branch_usize_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_try_branch_usize_argument), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>());
println!("AF_FIELD finish_try_branch_usize_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_try_branch_usize_return), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>());
println!("AF_FIELD finish_try_branch_usize_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_try_branch_usize_caller), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>());
println!("AF_FIELD finish_try_residual_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_try_residual_source), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD finish_try_residual_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_try_residual_argument), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD finish_try_residual_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_try_residual_return), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD finish_try_residual_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_try_residual_caller), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD finish_closure_capture_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_closure_capture_source), size_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>(), std::mem::align_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>());
println!("AF_FIELD finish_closure_capture_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_closure_capture_argument), size_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>(), std::mem::align_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>());
println!("AF_FIELD finish_closure_capture_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_closure_capture_return), size_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>(), std::mem::align_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>());
println!("AF_FIELD finish_closure_capture_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_closure_capture_caller), size_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>(), std::mem::align_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>());
println!("AF_FIELD finish_closure_failure_source {} {} {}", std::mem::offset_of!(ActivePositions, finish_closure_failure_source), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD finish_closure_failure_argument {} {} {}", std::mem::offset_of!(ActivePositions, finish_closure_failure_argument), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD finish_closure_failure_return {} {} {}", std::mem::offset_of!(ActivePositions, finish_closure_failure_return), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD finish_closure_failure_caller {} {} {}", std::mem::offset_of!(ActivePositions, finish_closure_failure_caller), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD rejection_try_branch_unit_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_try_branch_unit_source), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD rejection_try_branch_unit_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_try_branch_unit_argument), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD rejection_try_branch_unit_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_try_branch_unit_return), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD rejection_try_branch_unit_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_try_branch_unit_caller), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD rejection_try_branch_value_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_try_branch_value_source), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>());
println!("AF_FIELD rejection_try_branch_value_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_try_branch_value_argument), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>());
println!("AF_FIELD rejection_try_branch_value_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_try_branch_value_return), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>());
println!("AF_FIELD rejection_try_branch_value_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_try_branch_value_caller), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>());
println!("AF_FIELD rejection_try_branch_usize_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_try_branch_usize_source), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>());
println!("AF_FIELD rejection_try_branch_usize_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_try_branch_usize_argument), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>());
println!("AF_FIELD rejection_try_branch_usize_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_try_branch_usize_return), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>());
println!("AF_FIELD rejection_try_branch_usize_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_try_branch_usize_caller), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>());
println!("AF_FIELD rejection_try_residual_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_try_residual_source), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD rejection_try_residual_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_try_residual_argument), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD rejection_try_residual_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_try_residual_return), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD rejection_try_residual_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_try_residual_caller), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD rejection_closure_capture_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_closure_capture_source), size_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>(), std::mem::align_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>());
println!("AF_FIELD rejection_closure_capture_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_closure_capture_argument), size_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>(), std::mem::align_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>());
println!("AF_FIELD rejection_closure_capture_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_closure_capture_return), size_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>(), std::mem::align_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>());
println!("AF_FIELD rejection_closure_capture_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_closure_capture_caller), size_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>(), std::mem::align_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>());
println!("AF_FIELD rejection_closure_failure_source {} {} {}", std::mem::offset_of!(ActivePositions, rejection_closure_failure_source), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD rejection_closure_failure_argument {} {} {}", std::mem::offset_of!(ActivePositions, rejection_closure_failure_argument), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD rejection_closure_failure_return {} {} {}", std::mem::offset_of!(ActivePositions, rejection_closure_failure_return), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD rejection_closure_failure_caller {} {} {}", std::mem::offset_of!(ActivePositions, rejection_closure_failure_caller), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD drain_try_branch_unit_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_try_branch_unit_source), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD drain_try_branch_unit_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_try_branch_unit_argument), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD drain_try_branch_unit_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_try_branch_unit_return), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD drain_try_branch_unit_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_try_branch_unit_caller), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, ()>>());
println!("AF_FIELD drain_try_branch_value_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_try_branch_value_source), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>());
println!("AF_FIELD drain_try_branch_value_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_try_branch_value_argument), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>());
println!("AF_FIELD drain_try_branch_value_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_try_branch_value_return), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>());
println!("AF_FIELD drain_try_branch_value_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_try_branch_value_caller), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, Value>>());
println!("AF_FIELD drain_try_branch_usize_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_try_branch_usize_source), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>());
println!("AF_FIELD drain_try_branch_usize_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_try_branch_usize_argument), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>());
println!("AF_FIELD drain_try_branch_usize_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_try_branch_usize_return), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>());
println!("AF_FIELD drain_try_branch_usize_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_try_branch_usize_caller), size_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>(), std::mem::align_of::<ControlFlow<Result<Infallible, SwiftRunFailure>, usize>>());
println!("AF_FIELD drain_try_residual_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_try_residual_source), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD drain_try_residual_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_try_residual_argument), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD drain_try_residual_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_try_residual_return), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD drain_try_residual_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_try_residual_caller), size_of::<Result<Infallible, SwiftRunFailure>>(), std::mem::align_of::<Result<Infallible, SwiftRunFailure>>());
println!("AF_FIELD drain_closure_capture_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_closure_capture_source), size_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>(), std::mem::align_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>());
println!("AF_FIELD drain_closure_capture_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_closure_capture_argument), size_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>(), std::mem::align_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>());
println!("AF_FIELD drain_closure_capture_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_closure_capture_return), size_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>(), std::mem::align_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>());
println!("AF_FIELD drain_closure_capture_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_closure_capture_caller), size_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>(), std::mem::align_of::<(&'static mut RuntimeControl, &'static AccountedWasi, Cursor)>());
println!("AF_FIELD drain_closure_failure_source {} {} {}", std::mem::offset_of!(ActivePositions, drain_closure_failure_source), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD drain_closure_failure_argument {} {} {}", std::mem::offset_of!(ActivePositions, drain_closure_failure_argument), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD drain_closure_failure_return {} {} {}", std::mem::offset_of!(ActivePositions, drain_closure_failure_return), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
println!("AF_FIELD drain_closure_failure_caller {} {} {}", std::mem::offset_of!(ActivePositions, drain_closure_failure_caller), size_of::<SwiftRunFailure>(), std::mem::align_of::<SwiftRunFailure>());
}

fn function_control_witness(end:usize,height:usize,result:bool)->Control { Control::function_entry(end,height,result) }
