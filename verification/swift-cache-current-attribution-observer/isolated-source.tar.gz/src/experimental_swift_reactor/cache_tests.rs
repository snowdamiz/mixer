//! Original fully validated same-ABI synthetic modules; no guest instantiation.
use super::cache::*;
use super::control::*;
use super::{validate_swift_reactor, SwiftValidationBudget, ValidatedSwiftReactor};
use crate::experimental::cache::{borrowed::CacheStep, decode};
use crate::experimental_swift_reactor::allocation_tests::{measure, measure_extended};
use crate::experimental_wasi::{
    accounted::AccountedWasi, WasiBudget, WasiFunction, WasiGrants, WasiUsage,
};
use crate::{Cancellation, Type, Value};
use std::cell::Cell;
use std::mem::size_of;
use std::time::{Duration, Instant};
#[derive(Clone, Copy)]
struct Hooks {
    checks: usize,
    cancel: Option<usize>,
    step: CacheStep,
    steps: [usize; 8],
    pause: Option<CacheStep>,
    capacity: Option<usize>,
    capacities: usize,
    cancel_pause: bool,
}
impl Default for Hooks {
    fn default() -> Self {
        Self {
            checks: 0,
            cancel: None,
            step: CacheStep::Constructor,
            steps: [0; 8],
            pause: None,
            capacity: None,
            capacities: 0,
            cancel_pause: false,
        }
    }
}
thread_local! {static HOOKS:Cell<Hooks>=Cell::new(Hooks::default());}
fn hooks(value: Hooks) {
    HOOKS.with(|h| h.set(value));
}
pub(super) fn step(step: CacheStep) {
    HOOKS.with(|h| {
        let mut x = h.get();
        x.step = step;
        h.set(x);
    });
}
pub(super) fn checkpoint(control: &RuntimeControl, _: Cursor) {
    elision_observe_checkpoint(control);
    let pause = HOOKS.with(|h| {
        let mut x = h.get();
        let ordinal = x.checks;
        x.checks += 1;
        x.steps[x.step as usize] += 1;
        if x.cancel == Some(ordinal) {
            control.cancellation().cancel();
        }
        let pause = x.pause == Some(x.step);
        if pause {
            if x.cancel_pause {
                control.cancellation().cancel();
            }
            x.pause = None;
        }
        h.set(x);
        pause
    });
    if pause {
        std::thread::sleep(Duration::from_millis(30));
    }
}
pub(super) fn capacity_observation(n: usize) -> usize {
    HOOKS.with(|h| {
        let mut x = h.get();
        let ordinal = x.capacities;
        x.capacities += 1;
        let fail = x.capacity == Some(ordinal);
        h.set(x);
        if fail {
            n.saturating_add(1)
        } else {
            n
        }
    })
}
fn uint(mut n: u32, out: &mut Vec<u8>) {
    loop {
        let byte = (n & 127) as u8;
        n >>= 7;
        out.push(byte | if n == 0 { 0 } else { 128 });
        if n == 0 {
            return;
        }
    }
}
fn text(s: &[u8], out: &mut Vec<u8>) {
    uint(s.len() as u32, out);
    out.extend_from_slice(s);
}
fn section(id: u8, payload: &[u8], out: &mut Vec<u8>) {
    out.push(id);
    uint(payload.len() as u32, out);
    out.extend_from_slice(payload);
}
fn ty(t: Type) -> u8 {
    match t {
        Type::I32 => 0x7f,
        Type::I64 => 0x7e,
        Type::F32 => 0x7d,
        Type::F64 => 0x7c,
    }
}
fn signature(params: &[Type], results: &[Type], out: &mut Vec<u8>) {
    out.push(0x60);
    uint(params.len() as u32, out);
    out.extend(params.iter().copied().map(ty));
    uint(results.len() as u32, out);
    out.extend(results.iter().copied().map(ty));
}
fn fixture(params: usize, helper: &[u8], definitions: usize) -> Vec<u8> {
    assert!(definitions >= 29);
    let mut module = b"\0asm\x01\0\0\0".to_vec();
    let mut types = vec![37];
    for import in WasiFunction::ALL {
        signature(import.parameters(), import.results(), &mut types);
    }
    signature(&[], &[], &mut types);
    signature(&[], &[Type::I32], &mut types);
    signature(&vec![Type::I32; params], &[], &mut types);
    section(1, &types, &mut module);
    let mut imports = vec![34];
    for (index, import) in WasiFunction::ALL.into_iter().enumerate() {
        text(b"wasi_snapshot_preview1", &mut imports);
        text(import.name(), &mut imports);
        imports.push(0);
        uint(index as u32, &mut imports);
    }
    section(2, &imports, &mut module);
    let mut functions = Vec::new();
    uint(definitions as u32, &mut functions);
    for index in 0..definitions {
        uint(
            if index == 0 {
                36
            } else if index == 28 {
                35
            } else {
                34
            },
            &mut functions,
        );
    }
    section(3, &functions, &mut module);
    let mut table = vec![1, 0x70, 1];
    uint(46713, &mut table);
    uint(46713, &mut table);
    section(4, &table, &mut module);
    let mut memory = vec![1, 0];
    uint(584, &mut memory);
    section(5, &memory, &mut module);
    section(6, &[1, 0x7f, 1, 0x41, 0, 0x0b], &mut module);
    let mut exports = vec![3];
    for (name, kind, index) in [
        (b"memory".as_slice(), 2, 0),
        (b"_initialize".as_slice(), 0, 35),
        (b"mixer_fieldlog_corpus_v1".as_slice(), 0, 62),
    ] {
        text(name, &mut exports);
        exports.push(kind);
        uint(index, &mut exports);
    }
    section(7, &exports, &mut module);
    let mut code = Vec::new();
    uint(definitions as u32, &mut code);
    for index in 0..definitions {
        let body: &[u8] = if index == 0 {
            helper
        } else if index == 28 {
            &[0, 0x41, 0, 0x0b]
        } else {
            &[0, 0x0b]
        };
        uint(body.len() as u32, &mut code);
        code.extend_from_slice(body);
    }
    section(10, &code, &mut module);
    module
}
fn body(locals: usize, code: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    if locals == 0 {
        out.push(0);
    } else {
        out.push(1);
        uint(locals as u32, &mut out);
        out.push(0x7f);
    }
    out.extend_from_slice(code);
    out
}
fn proof(bytes: &[u8]) -> ValidatedSwiftReactor {
    validate_swift_reactor(
        bytes,
        SwiftValidationBudget::default(),
        &Cancellation::default(),
    )
    .unwrap()
}
fn adopt(bytes: &[u8], budget: SwiftRunBudget) -> (RuntimeControl, AdoptedProof) {
    RuntimeControl::adopt(
        proof(bytes),
        budget,
        Instant::now(),
        Cancellation::default(),
    )
    .unwrap()
}
fn construct(
    control: &mut RuntimeControl,
    adopted: AdoptedProof,
    wasi: Option<&AccountedWasi>,
) -> Result<SwiftFunctionCache, SwiftRunFailure> {
    let failure = match SwiftFunctionCache::prepare(control, wasi, &adopted, cache_cursor()) {
        Ok(mut phase) => {
            let mut returned = Some(phase.construct(adopted));
            // End the original construction Result/error scope; preserve only
            // the final cache owner or a copied foundation-sized diagnostic.
            let result = {
                match returned.take().unwrap() {
                    Ok(cache) => Ok(cache),
                    Err(error) => {
                        assert!(error.rejected_adopted.is_none());
                        Err(error.failure)
                    }
                }
            };
            phase.complete(returned)?;
            return result;
        }
        Err(failure) => failure,
    };
    // Prepare only borrowed the caller's owner. It must still be explicitly
    // destroyed/refunded against its original ledger on rejected preparation.
    control.drop_proof_with_wasi(adopted, wasi.map(AccountedWasi::usage))?;
    Err(failure)
}
fn new(bytes: &[u8], budget: SwiftRunBudget) -> (RuntimeControl, SwiftFunctionCache) {
    let (mut c, p) = adopt(bytes, budget);
    let cache = construct(&mut c, p, None).unwrap();
    (c, cache)
}
fn pin(
    cache: &mut SwiftFunctionCache,
    control: &mut RuntimeControl,
    function: u32,
    wasi: Option<&AccountedWasi>,
) -> Result<SwiftFunctionPin, SwiftRunFailure> {
    let mut phase = cache.prepare_operation(control, wasi, cache_cursor())?;
    let mut returned = Some(phase.pin(cache, function));
    let result = returned.take().unwrap();
    phase.complete(returned)?;
    result
}
fn cleanup(
    cache: SwiftFunctionCache,
    control: &mut RuntimeControl,
    wasi: Option<&AccountedWasi>,
) -> Option<SwiftRunFailure> {
    let mut owned = Some(cache);
    let tail = { SwiftFunctionCache::cleanup(&mut owned, control, wasi).unwrap() };
    let mut result = None;
    tail.complete(owned, &mut result);
    result
}
fn finish(cache: SwiftFunctionCache, mut control: RuntimeControl) {
    let before_cleanup_work = control.usage(None).cache_work;
    cleanup(cache, &mut control, None);
    let final_usage = control.finish_owned_cleanup(None);
    assert_eq!(
        final_usage.cache_work, before_cleanup_work,
        "consuming cleanup must add no work"
    );
    assert_eq!(final_usage.reservations.combined.current, 0);
    assert_eq!(final_usage.reservations.live_tickets, 0);
    assert_eq!(final_usage.live.active_pins.current, 0);
    assert_eq!(final_usage.live.cache_entries.current, 0);
}
fn wasi(control: &mut RuntimeControl) -> AccountedWasi {
    let mut p = AccountedWasi::prepare(control, cache_cursor()).unwrap();
    let w = p
        .construct(
            WasiGrants::default(),
            WasiBudget {
                one_transfer_bytes: 64,
                log_bytes: 64,
                ..WasiBudget::default()
            },
            Instant::now(),
            cache_cursor(),
        )
        .unwrap();
    p.complete().unwrap();
    w
}
#[test]
fn borrowed_owner_preflight_preserves_storage_and_ignores_ordinary_checks() {
    let bytes = fixture(0, &[0, 0x0b], 29);
    for rejected_owner in 0..3 {
        let (mut control, adopted) = adopt(&bytes, SwiftRunBudget::default());
        let context = wasi(&mut control);
        let cache = construct(&mut control, adopted, Some(&context)).unwrap();
        let (mut other, other_adopted) = adopt(&bytes, SwiftRunBudget::default());
        let other_context = wasi(&mut other);
        let other_cache = construct(&mut other, other_adopted, Some(&other_context)).unwrap();
        let source = cache.proof().source().as_ptr();
        let identity = cache.identity();
        let before = control.usage(Some(context.usage()));
        control.cancellation().cancel();
        hooks(Hooks::default());
        let (result, allocations) = measure(|| match rejected_owner {
            0 => cache.check_owner(&mut control, Some(&context), cache_cursor()),
            1 => cache.check_owner(&mut control, Some(&other_context), cache_cursor()),
            _ => other_cache.check_owner(&mut control, Some(&context), cache_cursor()),
        });
        assert_eq!(allocations.attempts, 0);
        assert_eq!(allocations.deallocations, 0);
        assert_eq!(HOOKS.with(|h| h.get().checks), 0);
        assert_eq!(cache.proof().source().as_ptr(), source);
        assert_eq!(cache.identity(), identity);
        let after = control.usage(Some(context.usage()));
        assert_eq!(before.reservations, after.reservations);
        assert_eq!(before.live, after.live);
        assert_eq!(before.cache_work, after.cache_work);
        assert_eq!(before.execution_work, after.execution_work);
        assert_eq!(before.host_calls, after.host_calls);
        assert_eq!(before.instruction_fuel, after.instruction_fuel);
        assert_eq!(before.instructions, after.instructions);
        if rejected_owner == 0 {
            result.unwrap();
            let terminal = control.fail(
                cache_cursor(),
                Fault::new(SwiftRunFailureKind::GuestTrap, "owner_preflight_prior_trap"),
                Some(context.usage()),
            );
            let (result, allocations) =
                measure(|| cache.check_owner(&mut control, Some(&context), cache_cursor()));
            result.unwrap();
            assert_eq!(allocations.attempts, 0);
            assert_eq!(HOOKS.with(|h| h.get().checks), 0);
            assert_eq!(terminal.code, "owner_preflight_prior_trap");
        } else {
            let failure = result.unwrap_err();
            assert_eq!(failure.kind, SwiftRunFailureKind::Invariant);
            assert_eq!(failure.code, "swift_run_reservation_owner");
            assert_eq!(
                failure.at_failure.wasi,
                if rejected_owner == 1 {
                    None
                } else {
                    Some(context.usage())
                }
            );
        }
        cleanup(cache, &mut control, Some(&context));
        context.cleanup(&mut control).unwrap();
        cleanup(other_cache, &mut other, Some(&other_context));
        other_context.cleanup(&mut other).unwrap();
        assert_eq!(
            control
                .finish_owned_cleanup(None)
                .reservations
                .combined
                .current,
            0
        );
        assert_eq!(
            other
                .finish_owned_cleanup(None)
                .reservations
                .combined
                .current,
            0
        );
    }
}
#[test]
fn same_abi_descriptors_and_authority() {
    let bytes = fixture(0, &[0, 0x0b], 100);
    let p = proof(&bytes);
    let source = p.source().as_ptr();
    let metadata = p.usage().metadata_reserved;
    let (mut c, a) = RuntimeControl::adopt(
        p,
        SwiftRunBudget::default(),
        Instant::now(),
        Cancellation::default(),
    )
    .unwrap();
    let (cache, alloc) = measure(|| construct(&mut c, a, None).unwrap());
    assert_eq!(cache.proof().source().as_ptr(), source);
    assert_eq!(cache.proof().source(), bytes);
    assert_eq!(cache.proof().execution_imports(), &WasiFunction::ALL);
    assert_eq!(cache.proof().execution_table().unwrap().host_maximum, 46713);
    assert_eq!(cache.proof().execution_memory().unwrap().host_maximum, 768);
    assert!(cache.proof().execution_function(33).is_none());
    assert!(cache.proof().execution_function(134).is_none());
    let u = c.usage(None);
    assert_eq!(u.reservations.retained_source.current, bytes.len());
    assert_eq!(u.reservations.retained_metadata.current, metadata);
    assert_eq!(alloc.allocations, 5);
    assert_eq!(alloc.reallocations, 0);
    finish(cache, c);
}
#[test]
fn decoder_opcode_and_count_build_parity() {
    review_every_decoded_instruction_matches_independent_owned_ir();
    let mut code = vec![
        0, 1, 0, 0x0c, 0, 0, 0x0d, 0, 0, 0x0e, 3, 0, 0, 0, 0, 0, 0x0f, 0, 0x10, 35, 0, 0x1a, 0,
        0x1b,
    ];
    for opcode in 0x20..=0x24 {
        code.extend([0, opcode, 0]);
    }
    for opcode in 0x28..=0x3e {
        code.extend([0, opcode, 0, 0x80, 1]);
    }
    code.extend([0, 0x3f, 0, 0, 0x40, 0, 0, 0x41, 0x7f, 0, 0x42, 0x80, 0x7f]);
    for opcode in 0x45..=0xc4 {
        if matches!(opcode,0x45..=0x5a|0x67..=0x8a|0xa7|0xac|0xad|0xc0..=0xc4|0x5b..=0x66|0x8b..=0xa6|0xa8..=0xab|0xae..=0xbf)
        {
            code.extend([0, opcode]);
        }
    }
    code.extend([0, 0x43, 1, 0, 0xc0, 0x7f, 0, 0x44, 1, 2, 3, 4, 5, 6, 7, 8]);
    for sub in 0..=7 {
        code.extend([0, 0xfc, sub]);
    }
    code.extend([
        0, 0x11, 34, 0, 0, 0xfc, 10, 0, 0, 0, 0xfc, 11, 0, 0, 2, 0x40, 3, 0x40, 0, 0x0d, 1, 0x0b,
        0x0b, 0, 4, 0x40, 1, 5, 1, 0x0b, 0x0b,
    ]);
    let helper = body(1, &code);
    let bytes = fixture(0, &helper, 100);
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    let p = pin(&mut cache, &mut c, 34, None).unwrap();
    let view = cache.view(&p, &mut c, None).unwrap();
    assert_eq!(view.locals, &[Type::I32]);
    assert_eq!(view.branch_targets, &[0, 0, 0]);
    assert_eq!(
        view.instructions.last().unwrap().operation,
        crate::experimental::cache::Operation::End
    );
    let source_body = cache.proof().execution_function(34).unwrap();
    assert_eq!(view.body_offset, source_body.body_offset);
    assert!(view
        .instructions
        .iter()
        .all(|i| i.offset >= source_body.body_offset
            && i.offset < source_body.body_offset + helper.len()));
    println!(
        "opcode parity instructions={} targets={} declared_locals={}",
        view.instructions.len(),
        view.branch_targets.len(),
        view.locals.len()
    );
    cache
        .release(p, &mut c, None)
        .map_err(|e| e.failure)
        .unwrap();
    finish(cache, c);
    // Internal invariant injection, not a fabricated Swift validation proof.
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    let failure = inspection::count_build_mismatch(&mut cache, &mut c);
    assert_eq!(failure.kind, SwiftRunFailureKind::DecoderMismatch);
    assert_eq!(failure.code, "decode_count_mismatch");
    assert_eq!(c.usage(None).live.cache_entries.current, 0);
    finish(cache, c);
}
#[test]
fn parameters_and_function_inclusive_depth() {
    review_parameter_and_group_boundaries();
    for (params, locals) in [(128, 128), (1, 255), (0, 256)] {
        let bytes = fixture(params, &body(locals, &[0x0b]), 100);
        let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
        let p = pin(&mut cache, &mut c, 34, None).unwrap();
        assert_eq!(cache.view(&p, &mut c, None).unwrap().locals.len(), locals);
        finish(cache, c);
    }
    let bytes = fixture(128, &body(129, &[0x0b]), 100);
    assert!(validate_swift_reactor(
        &bytes,
        SwiftValidationBudget::default(),
        &Cancellation::default()
    )
    .is_err());
    for depth in [379, 512] {
        let mut code = vec![];
        for _ in 1..depth {
            code.extend([2, 0x40]);
        }
        code.extend(std::iter::repeat_n(0x0b, depth));
        let bytes = fixture(0, &body(0, &code), 100);
        let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
        let p = pin(&mut cache, &mut c, 34, None).unwrap();
        assert_eq!(
            cache.view(&p, &mut c, None).unwrap().instructions.len(),
            2 * depth - 1
        );
        finish(cache, c);
    }
    let mut code = vec![];
    for _ in 0..512 {
        code.extend([2, 0x40]);
    }
    code.extend(std::iter::repeat_n(0x0b, 513));
    let bytes = fixture(0, &body(0, &code), 100);
    assert!(validate_swift_reactor(
        &bytes,
        SwiftValidationBudget::default(),
        &Cancellation::default()
    )
    .is_err());
}
#[test]
fn permanent_patch_arena_exact_requests() {
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
    let (cache, s) = measure(|| construct(&mut c, a, None).unwrap());
    assert_eq!(s.allocations, 5);
    println!("permanent fixed requested allocations {:?}", s);
    let expected = 64 * size_of::<super::cache::SwiftSlot>()
        + 64 * size_of::<crate::experimental::cache::PinRecord>()
        + 512 * size_of::<decode::Patch>()
        + 192
        + 28_672; // Measured 512 optional scan-plan cells, grouped under the header.
    assert_eq!(s.allocated_bytes, expected);
    assert_eq!(
        c.usage(None).reservations.cache.current,
        cache_header_bytes().unwrap() + expected - 192 - 28_672
    );
    inspection::print_layouts();
    finish(cache, c);
}
#[test]
fn entry_and_combined_admission_precedes_allocation() {
    let bytes = fixture(0, &body(1, &[0, 0x0e, 1, 0, 0, 0x0b]), 100);
    let (mut c, mut cache) = new(
        &bytes,
        SwiftRunBudget {
            cache_entry_bytes: 0,
            ..SwiftRunBudget::default()
        },
    );
    let (result, s) = measure(|| pin(&mut cache, &mut c, 34, None));
    let f = result.unwrap_err();
    println!("entry admission failure {f:?}");
    assert_eq!(f.resource, Some(SwiftRunResource::CacheEntryBytes));
    assert_eq!(s.attempts, 0);
    assert_eq!(cache.usage().resident_bytes, 0);
    assert_eq!(c.usage(None).live.active_pins.current, 0);
    finish(cache, c);
    let bytes = fixture(0, &body(1, &[vec![1; 3000], vec![0x0b]].concat()), 100);
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    let p = pin(&mut cache, &mut c, 34, None).unwrap();
    let _entry = cache.usage().resident_bytes;
    cache
        .release(p, &mut c, None)
        .map_err(|e| e.failure)
        .unwrap();
    let peak = c.usage(None).reservations.combined.peak;
    finish(cache, c);
    let (mut c, a) = adopt(
        &bytes,
        SwiftRunBudget {
            combined_bytes: peak - 1,
            ..SwiftRunBudget::default()
        },
    );
    let cache = construct(&mut c, a, None).unwrap();
    let mut cache = cache;
    let (result, s) = measure(|| pin(&mut cache, &mut c, 34, None));
    assert!(result.is_err());
    assert_eq!(s.attempts, 0);
    finish(cache, c);
}
#[test]
fn zero_limits_and_exact_narrowing() {
    let bytes = fixture(0, &[0, 0x0b], 100);
    for (entries, pins) in [(0, 64), (64, 0), (0, 0)] {
        let (mut c, mut cache) = new(
            &bytes,
            SwiftRunBudget {
                cache_entries: entries,
                active_pins: pins,
                ..SwiftRunBudget::default()
            },
        );
        assert!(pin(&mut cache, &mut c, 34, None).is_err());
        assert_eq!(cache.usage().active_pins, 0);
        finish(cache, c);
    }
    for budget in [
        SwiftRunBudget {
            cache_bytes: 0,
            ..SwiftRunBudget::default()
        },
        SwiftRunBudget {
            cache_work: 0,
            ..SwiftRunBudget::default()
        },
    ] {
        let (mut c, a) = adopt(&bytes, budget);
        assert!(construct(&mut c, a, None).is_err());
        assert_eq!(c.usage(None).reservations.cache.current, 0);
        assert_eq!(
            c.finish_owned_cleanup(None).reservations.combined.current,
            0
        );
    }
}
#[test]
fn pins_hits_lru_and_eviction() {
    review_64_distinct_live_pins_then_65th_and_terminal_release();
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    let mut pins = Vec::new();
    for _ in 0..64 {
        pins.push(pin(&mut cache, &mut c, 34, None).unwrap());
    }
    assert_eq!(cache.usage().active_pins, 64);
    assert_eq!(cache.usage().hits, 63);
    assert_eq!(cache.usage().pinned_bytes, cache.usage().resident_bytes);
    let (_, s) = measure(|| {
        for p in pins {
            cache
                .release(p, &mut c, None)
                .map_err(|e| e.failure)
                .unwrap();
        }
    });
    assert_eq!(s.attempts, 0);
    assert_eq!(cache.usage().pinned_bytes, 0);
    finish(cache, c);
    let (mut c, mut cache) = new(
        &bytes,
        SwiftRunBudget {
            cache_entries: 2,
            ..SwiftRunBudget::default()
        },
    );
    for f in [34, 35, 34, 36] {
        let p = pin(&mut cache, &mut c, f, None).unwrap();
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
    }
    assert_eq!(cache.usage().evictions, 1);
    assert_eq!(cache.usage().hits, 1);
    finish(cache, c);
    let (mut c, mut cache) = new(
        &bytes,
        SwiftRunBudget {
            cache_entries: 1,
            ..SwiftRunBudget::default()
        },
    );
    let _p = pin(&mut cache, &mut c, 34, None).unwrap();
    assert_eq!(
        pin(&mut cache, &mut c, 35, None).unwrap_err().code,
        "all_entries_pinned"
    );
    finish(cache, c);
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    for function in 34..98 {
        let p = pin(&mut cache, &mut c, function, None).unwrap();
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
    }
    assert_eq!(c.usage(None).live.cache_entries.current, 64);
    assert_eq!(c.usage(None).reservations.live_tickets, 73);
    assert!(c.usage(None).reservations.peak_tickets <= MAX_RESERVATION_TICKETS);
    let p = pin(&mut cache, &mut c, 98, None).unwrap();
    cache
        .release(p, &mut c, None)
        .map_err(|e| e.failure)
        .unwrap();
    assert_eq!(c.usage(None).reservations.live_tickets, 73);
    assert_eq!(cache.usage().evictions, 1);
    finish(cache, c);
    // Actual release is admission/work/cancellation independent, including the
    // last recursive pin's subset-byte transition.
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    let p = pin(&mut cache, &mut c, 34, None).unwrap();
    let q = pin(&mut cache, &mut c, 34, None).unwrap();
    let work = c.usage(None).cache_work;
    c.cancellation().cancel();
    let (_, stats) = measure(|| {
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
        cache
            .release(q, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
    });
    assert_eq!(stats.attempts, 0);
    assert_eq!(c.usage(None).cache_work, work);
    assert_eq!(cache.usage().pinned_bytes, 0);
    finish(cache, c);
}
#[test]
fn foreign_stale_nonce_and_control_ownership() {
    review_owner_allocator_exhaustion();
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    let p = pin(&mut cache, &mut c, 34, None).unwrap();
    let stale = inspection::stale(&p);
    cache
        .release(p, &mut c, None)
        .map_err(|e| e.failure)
        .unwrap();
    assert_eq!(
        cache.view(&stale, &mut c, None).err().unwrap().code,
        "stale_pin"
    );
    finish(cache, c);
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    inspection::set_nonce(&mut cache, u64::MAX);
    assert_eq!(
        pin(&mut cache, &mut c, 34, None).unwrap_err().code,
        "pin_nonce_exhausted"
    );
    finish(cache, c);
    let (mut c, cache) = new(&bytes, SwiftRunBudget::default());
    let (mut foreign, p) = adopt(&bytes, SwiftRunBudget::default());
    let before = c.usage(None).reservations;
    let mut owned = Some(cache);
    let (result, s) = measure(|| SwiftFunctionCache::cleanup(&mut owned, &mut foreign, None));
    assert!(result.is_err());
    drop(result);
    assert!(owned.is_some());
    assert_eq!(s.attempts, 0);
    assert_eq!(c.usage(None).reservations, before);
    let tail = SwiftFunctionCache::cleanup(&mut owned, &mut c, None).unwrap();
    let mut outcome = None;
    tail.complete(owned, &mut outcome);
    assert_eq!(
        c.finish_owned_cleanup(None).reservations.combined.current,
        0
    );
    foreign.drop_proof(p).unwrap();
    assert_eq!(
        foreign
            .finish_owned_cleanup(None)
            .reservations
            .combined
            .current,
        0
    );
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    let p = pin(&mut cache, &mut c, 34, None).unwrap();
    let (mut other, mut other_cache) = new(&bytes, SwiftRunBudget::default());
    let before = other.usage(None);
    let (rejected, stats) = measure(|| other_cache.release(p, &mut other, None).err().unwrap());
    assert_eq!(rejected.failure.code, "wrong_cache_owner");
    assert_eq!(stats.attempts, 0);
    assert_eq!(other.usage(None).cache_work, before.cache_work);
    assert_eq!(other.usage(None).live, before.live);
    cache
        .release(rejected.into_pin(), &mut c, None)
        .map_err(|e| e.failure)
        .unwrap();
    assert_eq!(cache.usage().active_pins, 0);
    finish(cache, c);
    finish(other_cache, other);
}
#[test]
fn construction_and_operation_phase_boundaries() {
    review_exact_phase_and_header_admission_boundaries();
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
    let previous = c.usage(None).reservations.construction.current;
    let extra = previous + 123;
    c.enlarge_construction(extra, cache_cursor()).unwrap();
    let mut phase = SwiftFunctionCache::prepare(&mut c, None, &a, cache_cursor()).unwrap();
    let cache = phase.construct(a).map_err(|e| e.failure).unwrap();
    phase.complete(()).unwrap();
    assert_eq!(c.usage(None).reservations.construction.current, extra);
    c.end_construction_phase((), previous).unwrap();
    let mut cache = cache;
    let mut op = cache
        .prepare_operation(&mut c, None, cache_cursor())
        .unwrap();
    let p = op.pin(&mut cache, 34).unwrap();
    op.complete(()).unwrap();
    assert_eq!(c.usage(None).reservations.construction.current, previous);
    cache
        .release(p, &mut c, None)
        .map_err(|e| e.failure)
        .unwrap();
    finish(cache, c);
    let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
    let phase = SwiftFunctionCache::prepare(&mut c, None, &a, cache_cursor()).unwrap();
    drop(phase);
    assert!(c.usage(None).reservations.construction.current > previous);
    c.drop_proof(a).unwrap();
    assert!(c.finish_owned_cleanup(None).reservations.combined.current > 0);
    let (mut c, cache) = new(&bytes, SwiftRunBudget::default());
    let floor = c.usage(None).reservations.construction.current;
    let operation = cache
        .prepare_operation(&mut c, None, cache_cursor())
        .unwrap();
    drop(operation);
    assert!(c.usage(None).reservations.construction.current > floor);
    cleanup(cache, &mut c, None);
    assert!(c.finish_owned_cleanup(None).reservations.combined.current > 0);
    let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
    let (mut foreign, b) = adopt(&bytes, SwiftRunBudget::default());
    let mut phase = SwiftFunctionCache::prepare(&mut c, None, &a, cache_cursor()).unwrap();
    let (a, b) = {
        let (error, s) = measure(|| phase.construct(b).err().unwrap());
        assert_eq!(s.attempts, 0);
        let b = error.rejected_adopted.unwrap();
        let again = phase.construct(a).err().unwrap();
        let a = again.rejected_adopted.unwrap();
        (a, b)
    };
    phase.complete(()).unwrap();
    c.drop_proof(a).unwrap();
    foreign.drop_proof(b).unwrap();
    assert_eq!(
        c.finish_owned_cleanup(None).reservations.combined.current,
        0
    );
    assert_eq!(
        foreign
            .finish_owned_cleanup(None)
            .reservations
            .combined
            .current,
        0
    );
}
#[test]
fn every_constructor_allocation_ordinal() {
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
    let (cache, s) = measure(|| construct(&mut c, a, None).unwrap());
    let n = s.attempts;
    assert_eq!(n, 5);
    finish(cache, c);
    let (mut base_control, base_proof) = adopt(&bytes, SwiftRunBudget::default());
    let (_, base_drop) = measure(|| base_control.drop_proof(base_proof).unwrap());
    let _ = base_control.finish_owned_cleanup(None);
    for ordinal in 0..n {
        let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
        let (result, s) = measure_extended(Some(ordinal), || construct(&mut c, a, None));
        assert!(result.is_err());
        assert_eq!(s.injected_failures, 1);
        assert_eq!(
            s.freed_bytes - base_drop.freed_bytes,
            s.allocated_bytes - s.last_size
        );
        assert_eq!(c.usage(None).reservations.cache.current, 0);
        assert_eq!(
            c.finish_owned_cleanup(None).reservations.combined.current,
            0
        );
        println!("constructor allocation ordinal {} observed", ordinal);
    }
    for ordinal in 0..5 {
        hooks(Hooks::default());
        let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
        hooks(Hooks {
            capacity: Some(ordinal),
            ..Hooks::default()
        });
        let f = construct(&mut c, a, None).err().unwrap();
        hooks(Hooks::default());
        assert_eq!(f.resource, Some(SwiftRunResource::ExactCapacity));
        assert_eq!(f.observed_capacity, Some(f.attempted as usize + 1));
        assert_eq!(c.usage(None).reservations.cache.current, 0);
        assert_eq!(
            c.finish_owned_cleanup(None).reservations.combined.current,
            0
        );
    }
}
#[test]
fn every_miss_allocation_ordinal_and_capacity_fault() {
    for helper in [
        body(0, &[0x0b]),
        body(1, &[0x0b]),
        body(1, &[0, 0x0e, 1, 0, 0, 0x0b]),
    ] {
        let bytes = fixture(0, &helper, 100);
        let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
        let (p, s) = measure(|| pin(&mut cache, &mut c, 34, None).unwrap());
        let n = s.attempts;
        assert!((1..=3).contains(&n));
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
        finish(cache, c);
        for ordinal in 0..n {
            let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
            let (result, s) = measure_extended(Some(ordinal), || pin(&mut cache, &mut c, 34, None));
            assert!(result.is_err());
            assert_eq!(s.injected_failures, 1);
            assert_eq!(c.usage(None).live.cache_entries.current, 0);
            assert_eq!(c.usage(None).live.active_pins.current, 0);
            finish(cache, c);
            println!("miss shape {} allocation {} observed", n, ordinal);
        }
    }
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    hooks(Hooks {
        capacity: Some(0),
        ..Hooks::default()
    });
    let f = pin(&mut cache, &mut c, 34, None).unwrap_err();
    hooks(Hooks::default());
    assert_eq!(f.resource, Some(SwiftRunResource::ExactCapacity));
    assert_eq!(f.observed_capacity, Some(f.attempted as usize + 1));
    finish(cache, c);
    for ordinal in 0..3 {
        hooks(Hooks::default());
        let bytes = fixture(0, &body(1, &[0, 0x0e, 1, 0, 0, 0x0b]), 100);
        let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
        hooks(Hooks {
            capacity: Some(ordinal),
            ..Hooks::default()
        });
        let f = pin(&mut cache, &mut c, 34, None).unwrap_err();
        hooks(Hooks::default());
        assert_eq!(f.resource, Some(SwiftRunResource::ExactCapacity));
        assert_eq!(c.usage(None).live.cache_entries.current, 0);
        finish(cache, c);
    }
    for ordinal in 0..3 {
        hooks(Hooks::default());
        let bytes = fixture(0, &body(1, &[0, 0x0e, 1, 0, 0, 0x0b]), 100);
        let (mut c, mut cache) = new(
            &bytes,
            SwiftRunBudget {
                cache_entries: 1,
                ..SwiftRunBudget::default()
            },
        );
        let p = pin(&mut cache, &mut c, 35, None).unwrap();
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
        let old = cache.usage().resident_bytes;
        let (result, stats) = measure_extended(Some(ordinal), || pin(&mut cache, &mut c, 34, None));
        assert!(result.is_err());
        assert_eq!(stats.injected_failures, 1);
        assert_eq!(cache.usage().evictions, 1);
        assert_eq!(
            stats.freed_bytes,
            stats.allocated_bytes - stats.last_size + old
        );
        assert_eq!(c.usage(None).live.cache_entries.current, 0);
        finish(cache, c);
    }
}
#[test]
fn every_work_prefix_and_cancellation_boundary() {
    let bytes = fixture(0, &body(1, &[0, 0x0e, 2, 0, 0, 0, 0x0b]), 29);
    hooks(Hooks::default());
    let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
    let mut cache = construct(&mut c, a, None).unwrap();
    let ctor_work = c.usage(None).cache_work;
    let ctor_checks = HOOKS.with(|h| h.get().checks);
    hooks(Hooks::default());
    let p = pin(&mut cache, &mut c, 34, None).unwrap();
    let final_work = c.usage(None).cache_work;
    let miss_checks = HOOKS.with(|h| h.get().checks);
    cache
        .release(p, &mut c, None)
        .map_err(|e| e.failure)
        .unwrap();
    finish(cache, c);
    for credits in 0..final_work {
        hooks(Hooks::default());
        let (mut c, a) = adopt(
            &bytes,
            SwiftRunBudget {
                cache_work: credits,
                ..SwiftRunBudget::default()
            },
        );
        match construct(&mut c, a, None) {
            Ok(mut cache) => {
                assert!(pin(&mut cache, &mut c, 34, None).is_err());
                assert!(c.usage(None).cache_work <= credits);
                finish(cache, c);
            }
            Err(_) => {
                assert!(credits < ctor_work);
                assert!(c.usage(None).cache_work <= credits);
                assert_eq!(
                    c.finish_owned_cleanup(None).reservations.combined.current,
                    0
                );
            }
        }
    }
    for ordinal in 0..ctor_checks {
        hooks(Hooks {
            cancel: Some(ordinal),
            ..Hooks::default()
        });
        let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
        let result = construct(&mut c, a, None);
        hooks(Hooks::default());
        assert!(
            result.is_err(),
            "constructor cancellation ordinal {ordinal}"
        );
        assert_eq!(
            c.finish_owned_cleanup(None).reservations.combined.current,
            0
        );
    }
    for ordinal in 0..miss_checks {
        hooks(Hooks::default());
        let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
        hooks(Hooks {
            cancel: Some(ordinal),
            ..Hooks::default()
        });
        assert!(
            pin(&mut cache, &mut c, 34, None).is_err(),
            "miss cancellation ordinal {ordinal}"
        );
        hooks(Hooks::default());
        finish(cache, c);
    }
    println!(
        "enumerated constructor_work={} all_work_prefixes={} constructor_checks={} miss_checks={}",
        ctor_work, final_work, ctor_checks, miss_checks
    );
    for target in [34, 35] {
        enumerate_seeded(&bytes, target);
    }
}
fn enumerate_seeded(bytes: &[u8], target: u32) {
    hooks(Hooks::default());
    let (mut c, mut cache) = new(
        bytes,
        SwiftRunBudget {
            cache_entries: 1,
            ..SwiftRunBudget::default()
        },
    );
    let p = pin(&mut cache, &mut c, 34, None).unwrap();
    cache
        .release(p, &mut c, None)
        .map_err(|e| e.failure)
        .unwrap();
    let base = c.usage(None).cache_work;
    hooks(Hooks::default());
    let p = pin(&mut cache, &mut c, target, None).unwrap();
    let credits = c.usage(None).cache_work - base;
    let checks = HOOKS.with(|h| h.get().checks);
    hooks(Hooks::default());
    cache
        .release(p, &mut c, None)
        .map_err(|e| e.failure)
        .unwrap();
    finish(cache, c);
    for prefix in 0..credits {
        hooks(Hooks::default());
        let (mut c, mut cache) = new(
            bytes,
            SwiftRunBudget {
                cache_entries: 1,
                cache_work: base + prefix,
                ..SwiftRunBudget::default()
            },
        );
        let p = pin(&mut cache, &mut c, 34, None).unwrap();
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
        assert!(pin(&mut cache, &mut c, target, None).is_err());
        assert!(c.usage(None).cache_work <= base + prefix);
        assert_eq!(c.usage(None).live.active_pins.current, 0);
        assert_eq!(
            c.usage(None).live.cache_entries.current,
            1 - cache.usage().evictions as usize
        );
        finish(cache, c);
    }
    for ordinal in 0..checks {
        hooks(Hooks::default());
        let (mut c, mut cache) = new(
            bytes,
            SwiftRunBudget {
                cache_entries: 1,
                ..SwiftRunBudget::default()
            },
        );
        let p = pin(&mut cache, &mut c, 34, None).unwrap();
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
        hooks(Hooks {
            cancel: Some(ordinal),
            ..Hooks::default()
        });
        assert!(pin(&mut cache, &mut c, target, None).is_err());
        hooks(Hooks::default());
        assert_eq!(c.usage(None).live.active_pins.current, 0);
        assert_eq!(
            c.usage(None).live.cache_entries.current,
            1 - cache.usage().evictions as usize
        );
        finish(cache, c);
    }
    println!("seeded target={target} credits={credits} checks={checks} all enumerated");
}

#[test]
fn deadline_inside_decode_and_reset() {
    let bytes = fixture(0, &body(1, &[0, 0x0e, 1, 0, 0, 0x0b]), 100);
    for step in [
        CacheStep::ScanReset,
        CacheStep::Scan,
        CacheStep::BuildReset,
        CacheStep::Build,
        CacheStep::Publication,
    ] {
        hooks(Hooks::default());
        let (mut c, mut cache) = new(
            &bytes,
            SwiftRunBudget {
                deadline_ms: 20,
                ..SwiftRunBudget::default()
            },
        );
        hooks(Hooks {
            pause: Some(step),
            ..Hooks::default()
        });
        let f = pin(&mut cache, &mut c, 34, None).unwrap_err();
        let counts = HOOKS.with(|h| h.get().steps);
        hooks(Hooks::default());
        assert_eq!(f.kind, SwiftRunFailureKind::Deadline);
        assert_eq!(f.deadline_origin, SwiftDeadlineOrigin::Run);
        assert!(f.at_failure.deadline_overshoot_micros > 0);
        assert!(counts[step as usize] > 0);
        println!(
            "deadline step={step:?} cursor={:?} overshoot={}",
            f.offset, f.at_failure.deadline_overshoot_micros
        );
        finish(cache, c);
    }
    // The actual carried WASI deadline wins, and cancellation still precedes an
    // expired clock at the exact selected reset/decode boundary.
    for cancel in [false, true] {
        hooks(Hooks::default());
        let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
        let mut phase = AccountedWasi::prepare(&mut c, cache_cursor()).unwrap();
        let w = phase
            .construct(
                WasiGrants::default(),
                WasiBudget {
                    one_transfer_bytes: 64,
                    log_bytes: 64,
                    deadline_ms: 20,
                    ..WasiBudget::default()
                },
                Instant::now(),
                cache_cursor(),
            )
            .unwrap();
        phase.complete().unwrap();
        let mut cache = construct(&mut c, a, Some(&w)).unwrap();
        hooks(Hooks {
            pause: Some(CacheStep::BuildReset),
            cancel_pause: cancel,
            ..Hooks::default()
        });
        let f = pin(&mut cache, &mut c, 34, Some(&w)).unwrap_err();
        hooks(Hooks::default());
        assert_eq!(f.deadline_origin, SwiftDeadlineOrigin::Wasi);
        assert_eq!(
            f.kind,
            if cancel {
                SwiftRunFailureKind::Cancelled
            } else {
                SwiftRunFailureKind::Deadline
            }
        );
        assert_eq!(f.at_failure.wasi, Some(w.usage()));
        assert!(f.at_failure.deadline_overshoot_micros > 0);
        cleanup(cache, &mut c, Some(&w));
        w.cleanup(&mut c).unwrap();
        assert_eq!(
            c.finish_owned_cleanup(None).reservations.combined.current,
            0
        );
    }
}
#[test]
fn first_cause_retains_actual_wasi_usage() {
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (mut c, a) = adopt(
        &bytes,
        SwiftRunBudget {
            cache_work: 1,
            ..SwiftRunBudget::default()
        },
    );
    let mut w = wasi(&mut c);
    let earlier = w.usage();
    w.dispatch(
        &mut c,
        WasiFunction::FdClose,
        &[Value::I32(42)],
        &mut [],
        cache_cursor(),
    )
    .unwrap();
    let actual = w.usage();
    assert_ne!(earlier, actual);
    let f = construct(&mut c, a, Some(&w)).err().unwrap();
    println!("first cache failure actual WASI {f:?}");
    assert_eq!(f.at_failure.wasi, Some(actual));
    let f2 = c
        .check_with_wasi(cache_cursor(), Some(w.usage()))
        .unwrap_err();
    assert_eq!(f, f2);
    w.cleanup(&mut c).unwrap();
    assert_eq!(
        c.finish_owned_cleanup(None).reservations.combined.current,
        0
    );
    let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
    let (mut other, p) = adopt(&bytes, SwiftRunBudget::default());
    let w = wasi(&mut other);
    let before = c.usage(None).reservations;
    let f = SwiftFunctionCache::prepare(&mut c, Some(&w), &a, cache_cursor())
        .err()
        .unwrap();
    assert_eq!(f.at_failure.wasi, None);
    assert_eq!(c.usage(None).reservations, before);
    c.drop_proof(a).unwrap();
    w.cleanup(&mut other).unwrap();
    other.drop_proof(p).unwrap();
    assert_eq!(
        c.finish_owned_cleanup(None).reservations.combined.current,
        0
    );
    assert_eq!(
        other
            .finish_owned_cleanup(None)
            .reservations
            .combined
            .current,
        0
    );
    // Exercise every observed cache control path with a real context whose
    // counters advanced through an accepted errno dispatch.
    for case in ["entry", "category", "capacity"] {
        hooks(Hooks::default());
        let budget = match case {
            "entry" => SwiftRunBudget {
                cache_entry_bytes: 0,
                ..SwiftRunBudget::default()
            },
            "category" => SwiftRunBudget {
                cache_bytes: 0,
                ..SwiftRunBudget::default()
            },
            _ => SwiftRunBudget::default(),
        };
        let (mut c, a) = adopt(&bytes, budget);
        let mut w = wasi(&mut c);
        w.dispatch(
            &mut c,
            WasiFunction::FdClose,
            &[Value::I32(80)],
            &mut [],
            cache_cursor(),
        )
        .unwrap();
        let actual = w.usage();
        let failure = if case == "category" {
            construct(&mut c, a, Some(&w)).err().unwrap()
        } else {
            let mut cache = construct(&mut c, a, Some(&w)).unwrap();
            if case == "capacity" {
                hooks(Hooks {
                    capacity: Some(0),
                    ..Hooks::default()
                });
            }
            let failure = pin(&mut cache, &mut c, 34, Some(&w)).unwrap_err();
            hooks(Hooks::default());
            cleanup(cache, &mut c, Some(&w));
            failure
        };
        assert_eq!(failure.at_failure.wasi, Some(actual));
        println!("observed WASI cache case={case} failure={failure:?}");
        w.cleanup(&mut c).unwrap();
        assert_eq!(
            c.finish_owned_cleanup(None).reservations.combined.current,
            0
        );
    }
    let large = fixture(0, &body(1, &[vec![1; 3000], vec![0x0b]].concat()), 100);
    let (mut c, a) = adopt(&large, SwiftRunBudget::default());
    let w = wasi(&mut c);
    let mut cache = construct(&mut c, a, Some(&w)).unwrap();
    let p = pin(&mut cache, &mut c, 34, Some(&w)).unwrap();
    cache
        .release(p, &mut c, Some(&w))
        .map_err(|e| e.failure)
        .unwrap();
    let peak = c.usage(Some(w.usage())).reservations.combined.peak;
    cleanup(cache, &mut c, Some(&w));
    w.cleanup(&mut c).unwrap();
    let _ = c.finish_owned_cleanup(None);
    let (mut c, a) = adopt(
        &large,
        SwiftRunBudget {
            combined_bytes: peak - 1,
            ..SwiftRunBudget::default()
        },
    );
    let mut w = wasi(&mut c);
    w.dispatch(
        &mut c,
        WasiFunction::FdClose,
        &[Value::I32(81)],
        &mut [],
        cache_cursor(),
    )
    .unwrap();
    let mut cache = construct(&mut c, a, Some(&w)).unwrap();
    let failure = pin(&mut cache, &mut c, 34, Some(&w)).unwrap_err();
    assert_eq!(failure.kind, SwiftRunFailureKind::CombinedExhausted);
    assert_eq!(failure.at_failure.wasi, Some(w.usage()));
    cleanup(cache, &mut c, Some(&w));
    w.cleanup(&mut c).unwrap();
    assert_eq!(
        c.finish_owned_cleanup(None).reservations.combined.current,
        0
    );
}
#[test]
fn component_cleanup_and_first_cleanup_invariant() {
    review_final_header_refund_fault_actual_wasi_and_prior_cause();
    review_cleanup_expired_deadline_exact_work_and_latched_terminal();
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
    let w = wasi(&mut c);
    let mut cache = construct(&mut c, a, Some(&w)).unwrap();
    for f in [34, 35, 34, 36] {
        let _ = pin(&mut cache, &mut c, f, Some(&w)).unwrap();
    }
    let work = c.usage(Some(w.usage())).cache_work;
    c.cancellation().cancel();
    let (mut owned, mut outcome) = (Some(cache), None);
    let (tail, s) = measure(|| SwiftFunctionCache::cleanup(&mut owned, &mut c, Some(&w)).unwrap());
    assert_eq!(s.attempts, 0);
    assert_eq!(
        inspection::tail_construction(&tail),
        foundation_construction_bytes().unwrap()
    );
    let (_, completion) = measure(|| tail.complete(owned, &mut outcome));
    assert_eq!(completion.attempts, 0);
    assert!(outcome.is_none());
    let u = c.usage(Some(w.usage()));
    assert_eq!(u.cache_work, work);
    assert_eq!(u.live.cache_entries.current, 0);
    assert_eq!(u.live.active_pins.current, 0);
    assert_eq!(u.reservations.cache.current, 0);
    assert!(u.reservations.wasi.current > 0);
    w.cleanup(&mut c).unwrap();
    assert_eq!(
        c.finish_owned_cleanup(None).reservations.combined.current,
        0
    );
    let (mut c, cache) = new(&bytes, SwiftRunBudget::default());
    let header = cache_header_bytes().unwrap();
    let mut owner = Some(cache);
    let tail = SwiftFunctionCache::cleanup(&mut owner, &mut c, None).unwrap();
    drop(tail);
    assert!(owner.is_none());
    assert_eq!(c.usage(None).reservations.cache.current, header);
    assert!(c.finish_owned_cleanup(None).reservations.combined.current >= header);
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    let _ = pin(&mut cache, &mut c, 34, None).unwrap();
    let (mut other, p) = adopt(&bytes, SwiftRunBudget::default());
    let foreign = other
        .admit(SwiftReservationCategory::Cache, 1, cache_cursor())
        .unwrap();
    let original = inspection::replace_entry_ticket(&mut cache, foreign);
    let first = cleanup(cache, &mut c, None).unwrap();
    println!("cleanup first invariant {first:?}");
    assert_eq!(first.stage, SwiftRunStage::Cleanup);
    assert_eq!(first.kind, SwiftRunFailureKind::Invariant);
    assert_eq!(c.usage(None).live.cache_entries.current, 0);
    c.drop_reserved((), original).unwrap();
    other.drop_proof(p).unwrap();
    assert!(
        other
            .finish_owned_cleanup(None)
            .reservations
            .combined
            .current
            > 0
    );
    assert_eq!(
        c.finish_owned_cleanup(None).reservations.combined.current,
        0
    );
    // Foreign WASI preflight must preserve the *exact* caller-owned cache slot.
    let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
    let w = wasi(&mut c);
    let cache = construct(&mut c, a, Some(&w)).unwrap();
    let source = cache.proof().source().as_ptr();
    let (mut other, p) = adopt(&bytes, SwiftRunBudget::default());
    let mut foreign = wasi(&mut other);
    foreign
        .dispatch(
            &mut other,
            WasiFunction::FdClose,
            &[Value::I32(99)],
            &mut [],
            cache_cursor(),
        )
        .unwrap();
    assert_ne!(w.usage(), foreign.usage());
    let mut owner = Some(cache);
    let before = c.usage(Some(w.usage())).reservations;
    {
        let result = SwiftFunctionCache::cleanup(&mut owner, &mut c, Some(&foreign));
        let f = result.err().unwrap();
        assert_eq!(f.at_failure.wasi, None);
    }
    assert_eq!(owner.as_ref().unwrap().proof().source().as_ptr(), source);
    assert_eq!(c.usage(Some(w.usage())).reservations, before);
    let tail = SwiftFunctionCache::cleanup(&mut owner, &mut c, Some(&w)).unwrap();
    let mut outcome = None;
    tail.complete(owner, &mut outcome);
    assert!(outcome.is_some());
    w.cleanup(&mut c).unwrap();
    foreign.cleanup(&mut other).unwrap();
    other.drop_proof(p).unwrap();
    assert_eq!(
        c.finish_owned_cleanup(None).reservations.combined.current,
        0
    );
    assert_eq!(
        other
            .finish_owned_cleanup(None)
            .reservations
            .combined
            .current,
        0
    );
    // A later destructive-cleanup invariant carries this owner's actual usage.
    let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
    let mut w = wasi(&mut c);
    w.dispatch(
        &mut c,
        WasiFunction::FdClose,
        &[Value::I32(17)],
        &mut [],
        cache_cursor(),
    )
    .unwrap();
    let mut cache = construct(&mut c, a, Some(&w)).unwrap();
    let _ = pin(&mut cache, &mut c, 34, Some(&w)).unwrap();
    let (mut other, p) = adopt(&bytes, SwiftRunBudget::default());
    let ticket = other
        .admit(SwiftReservationCategory::Cache, 1, cache_cursor())
        .unwrap();
    let original = inspection::replace_entry_ticket(&mut cache, ticket);
    let first = cleanup(cache, &mut c, Some(&w)).unwrap();
    assert_eq!(first.at_failure.wasi, Some(w.usage()));
    println!("cleanup first invariant {first:?}");
    assert_eq!(first.stage, SwiftRunStage::Cleanup);
    c.drop_reserved_with_wasi((), original, Some(w.usage()))
        .unwrap();
    w.cleanup(&mut c).unwrap();
    other.drop_proof(p).unwrap();
    assert_eq!(
        c.finish_owned_cleanup(None).reservations.combined.current,
        0
    );
    assert!(
        other
            .finish_owned_cleanup(None)
            .reservations
            .combined
            .current
            > 0
    );
}
#[test]
fn sticky_failure_has_no_new_effects() {
    // This matrix tests propagation after an explicit control terminal latch.
    // Natural failure-origin coverage remains in the other named tests.
    let kinds = [
        SwiftRunFailureKind::InvalidBudget,
        SwiftRunFailureKind::Cancelled,
        SwiftRunFailureKind::Deadline,
        SwiftRunFailureKind::Allocation,
        SwiftRunFailureKind::Adoption,
        SwiftRunFailureKind::CategoryExhausted,
        SwiftRunFailureKind::CombinedExhausted,
        SwiftRunFailureKind::ResourceExhausted,
        SwiftRunFailureKind::FuelExhausted,
        SwiftRunFailureKind::WorkExhausted,
        SwiftRunFailureKind::HostCallLimit,
        SwiftRunFailureKind::PinLimit,
        SwiftRunFailureKind::FrameLimit,
        SwiftRunFailureKind::ValueLimit,
        SwiftRunFailureKind::ControlLimit,
        SwiftRunFailureKind::DecoderMismatch,
        SwiftRunFailureKind::UnsupportedEnvironment,
        SwiftRunFailureKind::GuestTrap,
        SwiftRunFailureKind::GuestExit,
        SwiftRunFailureKind::Wasi,
        SwiftRunFailureKind::Invariant,
    ];
    let bytes = fixture(0, &[0, 0x0b], 100);
    for kind in kinds {
        hooks(Hooks::default());
        let (mut c, adopted) = adopt(&bytes, SwiftRunBudget::default());
        let mut w = wasi(&mut c);
        w.dispatch(
            &mut c,
            WasiFunction::FdClose,
            &[Value::I32(97)],
            &mut [],
            cache_cursor(),
        )
        .unwrap();
        let actual_wasi = w.usage();
        let mut cache = construct(&mut c, adopted, Some(&w)).unwrap();
        let p = pin(&mut cache, &mut c, 34, Some(&w)).unwrap();
        assert_eq!(cache.usage().decodes, 1);
        let first = {
            let mut phase = cache
                .prepare_operation(&mut c, Some(&w), cache_cursor())
                .unwrap();
            let first = inspection::latch_terminal(&mut phase, kind);
            assert_eq!(first.kind, kind);
            assert_eq!(first.at_failure.wasi, Some(actual_wasi));
            let before = inspection::operation_usage(&phase);
            let cached = cache.usage();
            let steps = HOOKS.with(|h| h.get().steps);
            assert_eq!(before.live.active_pins.current, 1);
            assert_eq!(before.live.cache_entries.current, 1);
            // Hit, fresh miss and invalid function must all retain the first
            // terminal cause before decoding or validating another request.
            for function in [34, 35, 0, 35, 34] {
                let (failure, allocations) =
                    measure(|| phase.pin(&mut cache, function).unwrap_err());
                assert_eq!(failure, first);
                review_assert_no_allocator_effects(allocations);
                assert_eq!(cache.usage(), cached);
                assert_eq!(w.usage(), actual_wasi);
                review_assert_same_control_effects(before, inspection::operation_usage(&phase));
                review_assert_no_decoder_steps(steps);
            }
            phase.complete((before, cached, steps)).unwrap();
            first
        };
        let before = c.usage(Some(actual_wasi));
        let cached = cache.usage();
        let steps = HOOKS.with(|h| h.get().steps);
        for function in [34, 35, 0, 35, 34] {
            let (failure, allocations) =
                measure(|| pin(&mut cache, &mut c, function, Some(&w)).unwrap_err());
            assert_eq!(failure, first);
            review_assert_no_allocator_effects(allocations);
            let (failure, allocations) = measure(|| {
                cache
                    .prepare_operation(&mut c, Some(&w), cache_cursor())
                    .err()
                    .unwrap()
            });
            assert_eq!(failure, first);
            review_assert_no_allocator_effects(allocations);
            assert_eq!(cache.usage(), cached);
            assert_eq!(w.usage(), actual_wasi);
            review_assert_same_control_effects(before, c.usage(Some(actual_wasi)));
            review_assert_no_decoder_steps(steps);
        }
        // Destroy the external token without release; only terminal cache drain
        // may reclaim its still-live pin/entry counts.
        #[allow(clippy::drop_non_drop)]
        drop(p);
        let (outcome, allocations) = measure(|| cleanup(cache, &mut c, Some(&w)).unwrap());
        review_assert_no_allocator_requests(allocations);
        assert_eq!(outcome.kind, first.kind);
        assert_eq!(outcome.code, first.code);
        assert_eq!(outcome.at_failure, first.at_failure);
        assert!(outcome.after_cleanup.is_some());
        let after = outcome.after_cleanup.unwrap();
        assert_eq!(after.wasi, Some(actual_wasi));
        assert_eq!(after.live.active_pins.current, 0);
        assert_eq!(after.live.cache_entries.current, 0);
        assert_eq!(after.cleanup_invariant, None);
        assert!(
            after.reservations.combined.current < first.at_failure.reservations.combined.current
        );
        assert!(after.reservations.combined.peak >= first.at_failure.reservations.combined.peak);
        assert_eq!(w.usage(), actual_wasi);
        w.cleanup(&mut c).unwrap();
        let final_usage = c.finish_owned_cleanup(Some(actual_wasi));
        assert_eq!(final_usage.reservations.combined.current, 0);
        assert_eq!(final_usage.reservations.live_tickets, 0);
        assert_eq!(final_usage.live.active_pins.current, 0);
        assert_eq!(final_usage.live.cache_entries.current, 0);
        assert_eq!(final_usage.cleanup_invariant, None);
        println!("sticky terminal kind={kind:?} phase_repeats=5 full_pin_repeats=5 prepare_repeats=5 decode_delta=0 service_delta=0 allocation_requests=0 work_delta=0 honest_cleanup=true");
    }
}
fn review_assert_same_control_effects(before: SwiftRunUsage, mut after: SwiftRunUsage) {
    // Native elapsed time may advance while every authoritative effect stays equal.
    after.elapsed_micros = before.elapsed_micros;
    after.deadline_overshoot_micros = before.deadline_overshoot_micros;
    assert_eq!(after, before);
}
fn review_assert_no_decoder_steps(before: [usize; 8]) {
    let after = HOOKS.with(|h| h.get().steps);
    for step in [
        CacheStep::Planning,
        CacheStep::ScanReset,
        CacheStep::Scan,
        CacheStep::BuildReset,
        CacheStep::Build,
        CacheStep::Publication,
    ] {
        assert_eq!(after[step as usize], before[step as usize]);
    }
}
fn review_assert_no_allocator_requests(stats: super::allocation_tests::AllocationStats) {
    assert_eq!(stats.attempts, 0);
    assert_eq!(stats.allocations, 0);
    assert_eq!(stats.reallocations, 0);
    assert_eq!(stats.allocated_bytes, 0);
}
fn review_assert_no_allocator_effects(stats: super::allocation_tests::AllocationStats) {
    review_assert_no_allocator_requests(stats);
    assert_eq!(stats.deallocations, 0);
    assert_eq!(stats.freed_bytes, 0);
}

#[test]
fn frozen_layout_allocation_work_error_snapshots() {
    inspection::assert_preflight_inventory();
    inspection::print_layouts();
    assert_eq!(
        size_of::<Option<SwiftRunFailure>>(),
        size_of::<SwiftRunFailure>()
    );
    assert_eq!(
        size_of::<Result<(), SwiftRunFailure>>(),
        size_of::<SwiftRunFailure>()
    );
    assert!(size_of::<Option<WasiUsage>>() >= size_of::<WasiUsage>());
    let named = 3 * size_of::<ValidatedSwiftReactor>()
        + 3 * size_of::<RuntimeControl>()
        + 3 * size_of::<AdoptedProof>()
        + 4 * size_of::<SwiftRunFailure>()
        + 4 * size_of::<SwiftRunUsage>()
        + 6 * size_of::<ReservationTicket>()
        + 6 * size_of::<Option<WasiUsage>>()
        + FOUNDATION_FINAL_BOUNDARY_BYTES
        + super::execution::CONSTRUCTION_BOOTSTRAP_BYTES;
    assert_eq!(foundation_construction_bytes(), Some(named));
    println!("foundation-tail map failure_count=4 usage_count=4 ticket_count=6 optional_wasi_count=6 optional_wasi_bytes={} final_boundary={} total={named}",size_of::<Option<WasiUsage>>(), FOUNDATION_FINAL_BOUNDARY_BYTES);
    assert_eq!(
        size_of::<Option<ReservationTicket>>(),
        size_of::<ReservationTicket>()
    );
}
fn external_privacy() {
    use std::process::Command;
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR"));
    let cargo = std::env::var_os("CARGO").unwrap_or_else(|| "cargo".into());
    let mut build = Command::new(cargo);
    build.current_dir(root).args([
        "build",
        "--locked",
        "--lib",
        "--features",
        "experimental-swift-reactor,experimental-span-execution",
    ]);
    if !cfg!(debug_assertions) {
        build.arg("--release");
    }
    let output = build.output().unwrap();
    assert!(
        output.status.success(),
        "external current library build: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    let deps = std::env::current_exe()
        .unwrap()
        .parent()
        .unwrap()
        .to_path_buf();
    let library = deps.join("libmixer_vm.rlib");
    assert!(library.is_file());
    let folder = std::env::temp_dir().join(format!(
        "mixer-cache-privacy-{}-{}",
        std::process::id(),
        if cfg!(debug_assertions) {
            "debug"
        } else {
            "release"
        }
    ));
    std::fs::create_dir_all(&folder).unwrap();
    let cases=[
        ("positive", "use mixer_vm::experimental::cache::{CacheBudget,FunctionCache};use mixer_vm::experimental_swift_reactor::ValidatedSwiftReactor;fn f(_:CacheBudget,_:Option<FunctionCache>,p:&ValidatedSwiftReactor){let _=p.source();}",None),
        ("private_cache", "use mixer_vm::experimental_swift_reactor::cache::SwiftFunctionCache;",Some("E0603")),
        ("private_parts", "use mixer_vm::experimental::cache::borrowed::{SnapshotView,CacheParts,FrozenMode};",Some("E0603")),
        ("private_control", "use mixer_vm::experimental_swift_reactor::control::RuntimeControl;",Some("E0603")),
        ("proof_forge", "use mixer_vm::experimental_swift_reactor::ValidatedSwiftReactor;fn f(){let _=ValidatedSwiftReactor{};}",Some("private fields")),
        ("proof_clone", "use mixer_vm::experimental_swift_reactor::ValidatedSwiftReactor;fn f(p:ValidatedSwiftReactor){let _=p.clone();}",Some("E0599")),
        ("legacy_conversion", "use mixer_vm::experimental_swift_reactor::ValidatedSwiftReactor;use mixer_vm::experimental::ValidatedSpans;fn f(p:ValidatedSwiftReactor){let _:ValidatedSpans=p;}",Some("E0308")),
        ("mutable_source", "use mixer_vm::experimental_swift_reactor::ValidatedSwiftReactor;fn f(p:ValidatedSwiftReactor){p.source()[0]=1;}",Some("E0594")),
        ("proof_reuse", "use mixer_vm::experimental_swift_reactor::ValidatedSwiftReactor;fn take(_:ValidatedSwiftReactor){}fn f(p:ValidatedSwiftReactor){take(p);take(p);}",Some("E0382")),
        ("view_mutation", "use mixer_vm::{Cancellation};use mixer_vm::experimental::cache::{FunctionCache,FunctionPin};fn f(c:&mut FunctionCache,p:FunctionPin){let v=c.view(&p).unwrap();let _=c.pin(0,&Cancellation::default());let _=v.instructions.len();}",Some("E0502")),
        ("view_release", "use mixer_vm::experimental::cache::{FunctionCache,FunctionPin};fn f(c:&mut FunctionCache,p:FunctionPin){let v=c.view(&p).unwrap();let _=c.release(p);let _=v.instructions.len();}",Some("E0502")),
        ("pin_clone", "use mixer_vm::experimental::cache::FunctionPin;fn f(p:FunctionPin){let _=p.clone();}",Some("E0599")),
        ("pin_forge", "use mixer_vm::experimental::cache::FunctionPin;fn f(){let _=FunctionPin{owner:1,slot:0,nonce:1};}",Some("E0451")),
    ];
    for (name, source, expected) in cases {
        let file = folder.join(format!("{name}.rs"));
        std::fs::write(&file, source).unwrap();
        let output = Command::new("rustc")
            .args([
                "--edition=2021",
                "--crate-type=lib",
                "--emit=metadata",
                "--extern",
            ])
            .arg(format!("mixer_vm={}", library.display()))
            .arg("-L")
            .arg(format!("dependency={}", deps.display()))
            .arg("--out-dir")
            .arg(&folder)
            .arg(&file)
            .output()
            .unwrap();
        let stderr = String::from_utf8_lossy(&output.stderr);
        match expected {
            None => assert!(output.status.success(), "{name}: {stderr}"),
            Some(code) => {
                assert!(!output.status.success(), "{name} unexpectedly compiled");
                assert!(
                    stderr.contains(code),
                    "{name} failed for unexpected reason: {stderr}"
                );
            }
        }
        println!(
            "external privacy {name}: expected={expected:?} exit={}\n{stderr}",
            output.status
        );
    }
}

#[test]
fn external_surface_and_borrow_privacy() {
    external_privacy();
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    let p = pin(&mut cache, &mut c, 34, None).unwrap();
    {
        let view = cache.view(&p, &mut c, None).unwrap();
        assert_eq!(view.function, 34);
    }
    cache
        .release(p, &mut c, None)
        .map_err(|e| e.failure)
        .unwrap();
    assert_eq!(cache.identity().policy, "swift-reactor-experiment-v1");
    finish(cache, c);
}

// Project-authored independent review assertions promoted into the original named tests.
fn review_assert_category_sum(u: SwiftRunUsage) {
    let r = u.reservations;
    assert_eq!(
        r.combined.current,
        r.retained_source.current
            + r.retained_metadata.current
            + r.cache.current
            + r.state.current
            + r.wasi.current
            + r.shared.current
            + r.construction.current
    );
}

fn review_64_distinct_live_pins_then_65th_and_terminal_release() {
    hooks(Hooks::default());
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    let mut pins = Vec::with_capacity(64);
    for function in 34..98 {
        let p = pin(&mut cache, &mut c, function, None).unwrap();
        assert_eq!(cache.view(&p, &mut c, None).unwrap().function, function);
        pins.push(p);
        review_assert_category_sum(c.usage(None));
    }
    let before = cache.usage();
    let ledger = c.usage(None);
    assert_eq!(ledger.live.active_pins.current, 64);
    assert_eq!(ledger.live.cache_entries.current, 64);
    assert_eq!(ledger.reservations.live_tickets, 73);
    assert_eq!(before.pinned_bytes, before.resident_bytes);
    let (failure, stats) = measure(|| pin(&mut cache, &mut c, 98, None).unwrap_err());
    assert_eq!(failure.code, "pin_slots_exhausted");
    assert_eq!(stats.attempts, 0);
    assert_eq!(cache.usage(), before);
    assert_eq!(c.usage(None).live, ledger.live);
    let work = c.usage(None).cache_work;
    let (_, stats) = measure(|| {
        for p in pins {
            cache
                .release(p, &mut c, None)
                .map_err(|e| e.failure)
                .unwrap();
        }
    });
    assert_eq!(stats.attempts, 0);
    assert_eq!(c.usage(None).cache_work, work);
    assert_eq!(cache.usage().pinned_bytes, 0);
    assert_eq!(cache.usage().resident_bytes, before.resident_bytes);
    finish(cache, c);
}

fn review_parameter_and_group_boundaries() {
    for (params, locals, accepted) in [
        (128, 128, true),
        (129, 0, false),
        (128, 129, false),
        (0, 256, true),
        (0, 257, false),
    ] {
        let bytes = fixture(params, &body(locals, &[0x0b]), 100);
        let p = validate_swift_reactor(
            &bytes,
            SwiftValidationBudget::default(),
            &Cancellation::default(),
        );
        assert_eq!(p.is_ok(), accepted, "params={params} locals={locals}");
        if accepted {
            let (mut c, a) = RuntimeControl::adopt(
                p.unwrap(),
                SwiftRunBudget::default(),
                Instant::now(),
                Cancellation::default(),
            )
            .unwrap();
            let mut cache = construct(&mut c, a, None).unwrap();
            let p = pin(&mut cache, &mut c, 34, None).unwrap();
            assert_eq!(cache.view(&p, &mut c, None).unwrap().locals.len(), locals);
            finish(cache, c);
        }
    }
    for groups in [256, 257] {
        let mut helper = Vec::new();
        uint(groups, &mut helper);
        for _ in 0..groups {
            helper.extend([0, 0x7f]);
        }
        helper.push(0x0b);
        let bytes = fixture(0, &helper, 100);
        let p = validate_swift_reactor(
            &bytes,
            SwiftValidationBudget::default(),
            &Cancellation::default(),
        );
        assert_eq!(p.is_ok(), groups == 256);
        if groups == 256 {
            let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
            let p = pin(&mut cache, &mut c, 34, None).unwrap();
            assert!(cache.view(&p, &mut c, None).unwrap().locals.is_empty());
            finish(cache, c);
        }
    }
}

fn review_owned_fixture(helper: &[u8]) -> Vec<u8> {
    let mut module = b"\0asm\x01\0\0\0".to_vec();
    let mut types = vec![37];
    for _ in 0..37 {
        signature(&[], &[], &mut types);
    }
    section(1, &types, &mut module);
    let mut functions = vec![100];
    functions.extend([0; 100]);
    section(3, &functions, &mut module);
    section(4, &[1, 0x70, 1, 1, 1], &mut module);
    section(5, &[1, 0, 1], &mut module);
    section(6, &[1, 0x7f, 1, 0x41, 0, 0x0b], &mut module);
    let mut code = vec![100];
    for index in 0..100 {
        let helper = if index == 0 { helper } else { &[0, 0x0b] };
        uint(helper.len() as u32, &mut code);
        code.extend_from_slice(helper);
    }
    section(10, &code, &mut module);
    module
}

fn review_operation(
    op: &crate::Op,
    targets: &mut Vec<u32>,
) -> crate::experimental::cache::Operation {
    use crate::experimental::cache::{ControlKind as K, Operation as C};
    use crate::{BlockKind as B, Op as O};
    match op {
        O::Unreachable => C::Unreachable,
        O::Nop => C::Nop,
        O::Block {
            kind,
            result,
            end,
            alternative,
        } => C::Block {
            kind: match kind {
                B::Block => K::Block,
                B::Loop => K::Loop,
                B::If => K::If,
                B::Function => panic!("no synthetic owned Function opcode"),
            },
            result: *result,
            end: *end,
            alternative: *alternative,
        },
        O::Else { end } => C::Else { end: *end },
        O::End => C::End,
        O::Br(n) => C::Br(*n),
        O::BrIf(n) => C::BrIf(*n),
        O::BrTable(values, default) => {
            let first = targets.len();
            targets.extend_from_slice(values);
            C::BrTable {
                first,
                count: values.len(),
                default: *default,
            }
        }
        O::Return => C::Return,
        O::Call(n) => C::Call(*n),
        O::CallIndirect(n) => C::CallIndirect(*n),
        O::MemoryCopy => C::MemoryCopy,
        O::MemoryFill => C::MemoryFill,
        O::Drop => C::Drop,
        O::Select => C::Select,
        O::LocalGet(n) => C::LocalGet(*n),
        O::LocalSet(n) => C::LocalSet(*n),
        O::LocalTee(n) => C::LocalTee(*n),
        O::GlobalGet(n) => C::GlobalGet(*n),
        O::GlobalSet(n) => C::GlobalSet(*n),
        O::Load { opcode, offset } => C::Load {
            opcode: *opcode,
            offset: *offset,
        },
        O::Store { opcode, offset } => C::Store {
            opcode: *opcode,
            offset: *offset,
        },
        O::MemorySize => C::MemorySize,
        O::MemoryGrow => C::MemoryGrow,
        O::Const(v) => C::Const(*v),
        O::Numeric(n) => C::Numeric(*n),
        O::Saturating(n) => C::Saturating(*n),
    }
}

fn review_every_decoded_instruction_matches_independent_owned_ir() {
    // Unreachable stack permits every admitted instruction to be decoded and
    // type-validated. Absolute module offsets differ; relative offsets must not.
    let mut code = vec![
        0, 1, 0, 0x0c, 0, 0, 0x0d, 0, 0, 0x0e, 3, 0, 0, 0, 0, 0, 0x0f, 0, 0x10, 35, 0, 0x1a, 0,
        0x1b,
    ];
    for opcode in 0x20..=0x24 {
        code.extend([0, opcode, 0x80, 0]);
    }
    for opcode in 0x28..=0x3e {
        code.extend([0, opcode, 0, 0x80, 1]);
    }
    code.extend([
        0, 0x3f, 0, 0, 0x40, 0, 0, 0x41, 0x80, 0x80, 0x80, 0x80, 0x78, 0, 0x42, 0xff, 0xff, 0xff,
        0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0,
    ]);
    for opcode in 0x45..=0xc4 {
        if matches!(opcode,0x45..=0x5a|0x67..=0x8a|0xa7|0xac|0xad|0xc0..=0xc4|0x5b..=0x66|0x8b..=0xa6|0xa8..=0xab|0xae..=0xbf)
        {
            code.extend([0, opcode]);
        }
    }
    code.extend([0, 0x43, 1, 0, 0xc0, 0x7f, 0, 0x44, 1, 2, 3, 4, 5, 6, 7, 8]);
    for sub in 0..=7 {
        code.extend([0, 0xfc, sub]);
    }
    code.extend([
        0, 0x11, 34, 0, 0, 0xfc, 10, 0, 0, 0, 0xfc, 11, 0, 0, 2, 0x40, 3, 0x40, 0, 0x0d, 1, 0x0b,
        0x0b, 0, 4, 0x40, 1, 5, 1, 0x0b, 0x0b,
    ]);
    let helper = body(1, &code);
    let bytes = fixture(0, &helper, 100);
    let owned_bytes = review_owned_fixture(&helper);
    let limits = crate::Limits {
        profile: crate::Profile::TableMemoryV3,
        ..crate::Limits::default()
    };
    let owned = crate::Module::decode(&owned_bytes, &limits).unwrap();
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    let p = pin(&mut cache, &mut c, 34, None).unwrap();
    let view = cache.view(&p, &mut c, None).unwrap();
    let expected = &owned.functions[0];
    assert_eq!(view.locals, expected.locals);
    assert_eq!(view.instructions.len(), expected.code.len());
    let mut targets = Vec::new();
    for (index, (actual, original)) in view.instructions.iter().zip(&expected.code).enumerate() {
        assert_eq!(
            actual.operation,
            review_operation(&original.op, &mut targets),
            "instruction{index}"
        );
        assert_eq!(
            actual.offset - view.body_offset,
            original.offset - expected.offset,
            "offset{index}"
        );
    }
    assert_eq!(view.branch_targets, targets);
    println!(
        "review compared exact owned IR instructions={} targets={}",
        view.instructions.len(),
        targets.len()
    );
    finish(cache, c);
}

fn review_final_header_refund_fault_actual_wasi_and_prior_cause() {
    for prior in [false, true] {
        hooks(Hooks::default());
        let bytes = fixture(0, &[0, 0x0b], 100);
        let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
        let mut w = wasi(&mut c);
        w.dispatch(
            &mut c,
            WasiFunction::FdClose,
            &[Value::I32(47)],
            &mut [],
            cache_cursor(),
        )
        .unwrap();
        let actual = w.usage();
        let mut cache = construct(&mut c, a, Some(&w)).unwrap();
        for f in [34, 34, 35, 36] {
            let _ = pin(&mut cache, &mut c, f, Some(&w)).unwrap();
        }
        let first = if prior {
            c.cancellation().cancel();
            Some(c.check_with_wasi(cache_cursor(), Some(actual)).unwrap_err())
        } else {
            None
        };
        let (mut foreign, foreign_proof) = adopt(&bytes, SwiftRunBudget::default());
        let foreign_ticket = foreign
            .admit(SwiftReservationCategory::Cache, 1, cache_cursor())
            .unwrap();
        let before = c.usage(Some(actual));
        let mut owner = Some(cache);
        let (mut tail, drops) =
            measure(|| SwiftFunctionCache::cleanup(&mut owner, &mut c, Some(&w)).unwrap());
        assert_eq!(drops.attempts, 0);
        assert!(owner.is_none());
        let original = inspection::replace_tail_header(&mut tail, foreign_ticket);
        let mut outcome = None;
        let (_, completion) = measure(|| tail.complete(owner, &mut outcome));
        assert_eq!(completion.attempts, 0);
        let failure = outcome.unwrap();
        assert_eq!(failure.at_failure.wasi, Some(actual));
        if let Some(first) = first {
            assert_eq!(failure.code, first.code);
            assert_eq!(failure.at_failure, first.at_failure);
        } else {
            assert_eq!(failure.code, "swift_run_release_owner");
            assert_eq!(failure.stage, SwiftRunStage::Cleanup);
            assert_eq!(
                failure.at_failure.reservations.cache.current,
                cache_header_bytes().unwrap()
            );
            assert_eq!(failure.at_failure.reservations.retained_source.current, 0);
            assert_eq!(failure.at_failure.reservations.retained_metadata.current, 0);
        }
        let after = failure.after_cleanup.unwrap();
        assert_eq!(
            after.cleanup_invariant,
            Some(SwiftCleanupInvariant::ReservationOwner)
        );
        assert_eq!(after.wasi, Some(actual));
        assert_eq!(
            after.reservations.cache.current,
            cache_header_bytes().unwrap()
        );
        assert_eq!(
            after.reservations.construction.current,
            foundation_construction_bytes().unwrap()
        );
        assert_eq!(after.live.active_pins.current, 0);
        assert_eq!(after.live.cache_entries.current, 0);
        assert_eq!(c.usage(Some(actual)).cache_work, before.cache_work);
        assert_eq!(
            c.usage(Some(actual)).reservations.wasi,
            before.reservations.wasi
        );
        c.drop_reserved_with_wasi((), original, Some(actual))
            .unwrap();
        w.cleanup(&mut c).unwrap();
        let final_usage = c.finish_owned_cleanup(None);
        assert_eq!(final_usage.reservations.combined.current, 0);
        assert_eq!(final_usage.reservations.live_tickets, 0);
        foreign.drop_proof(foreign_proof).unwrap();
        let corrupted = foreign.finish_owned_cleanup(None);
        assert_eq!(corrupted.reservations.combined.current, 1);
        assert_eq!(corrupted.reservations.live_tickets, 1);
        println!("review final refund fault prior={prior}; original owner drained; corrupted foreign1-byte charge retained");
    }
}

fn review_cleanup_expired_deadline_exact_work_and_latched_terminal() {
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    let _ = pin(&mut cache, &mut c, 34, None).unwrap();
    let exact_work = c.usage(None).cache_work;
    finish(cache, c);
    for case in ["deadline", "work", "terminal"] {
        let budget = SwiftRunBudget {
            deadline_ms: if case == "deadline" { 1_000 } else { 30_000 },
            cache_work: if case == "work" {
                exact_work
            } else {
                64_000_000
            },
            ..SwiftRunBudget::default()
        };
        let (mut c, mut cache) = new(&bytes, budget);
        let _ = pin(&mut cache, &mut c, 34, None).unwrap();
        if case == "deadline" {
            std::thread::sleep(
                c.deadline().saturating_duration_since(Instant::now()) + Duration::from_millis(1),
            );
        }
        if case == "work" {
            assert_eq!(c.usage(None).cache_work, exact_work);
        }
        let first = if case == "terminal" {
            c.cancellation().cancel();
            Some(c.check(cache_cursor()).unwrap_err())
        } else {
            None
        };
        let before = c.usage(None);
        let mut owner = Some(cache);
        let mut outcome = None;
        let (_, stats) = measure(|| {
            let tail = SwiftFunctionCache::cleanup(&mut owner, &mut c, None).unwrap();
            tail.complete(owner, &mut outcome);
        });
        assert_eq!(stats.attempts, 0);
        assert_eq!(c.usage(None).cache_work, before.cache_work);
        assert_eq!(
            c.usage(None).reservations.construction.current,
            foundation_construction_bytes().unwrap()
        );
        assert_eq!(c.usage(None).reservations.cache.current, 0);
        match first {
            Some(f) => assert_eq!(outcome.unwrap().at_failure, f.at_failure),
            None => assert!(outcome.is_none()),
        }
        let final_usage = c.finish_owned_cleanup(None);
        assert_eq!(final_usage.reservations.combined.current, 0);
        assert_eq!(final_usage.reservations.live_tickets, 0);
    }
}

// Admission probes use actual current ledger totals and the measured formulas;
// each exact-minus-one denial occurs before any payload allocation.
fn review_exact_phase_and_header_admission_boundaries() {
    hooks(Hooks::default());
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (mut baseline, proof) = adopt(&bytes, SwiftRunBudget::default());
    let adopted = baseline.usage(None).reservations.combined.current;
    baseline.drop_proof(proof).unwrap();
    assert_eq!(
        baseline
            .finish_owned_cleanup(None)
            .reservations
            .combined
            .current,
        0
    );
    for exact in [false, true] {
        let extra = cache_construction_bytes().unwrap();
        let (mut c, a) = adopt(
            &bytes,
            SwiftRunBudget {
                combined_bytes: adopted + extra - usize::from(!exact),
                ..SwiftRunBudget::default()
            },
        );
        if exact {
            let (phase, stats) =
                measure(|| SwiftFunctionCache::prepare(&mut c, None, &a, cache_cursor()).unwrap());
            assert_eq!(stats.attempts, 0);
            assert_eq!(
                inspection::construction_current(&phase),
                foundation_construction_bytes().unwrap() + extra
            );
            phase.complete(()).unwrap();
        } else {
            let (failure, stats) = measure(|| {
                SwiftFunctionCache::prepare(&mut c, None, &a, cache_cursor())
                    .err()
                    .unwrap()
            });
            assert_eq!(stats.attempts, 0);
            assert_eq!(failure.kind, SwiftRunFailureKind::CombinedExhausted);
        }
        c.drop_proof(a).unwrap();
        assert_eq!(
            c.finish_owned_cleanup(None).reservations.combined.current,
            0
        );
    }
    let (baseline, cache) = new(&bytes, SwiftRunBudget::default());
    let resident_base = baseline.usage(None).reservations.combined.current;
    finish(cache, baseline);
    for exact in [false, true] {
        let extra = cache_operation_bytes().unwrap();
        let (mut c, cache) = new(
            &bytes,
            SwiftRunBudget {
                combined_bytes: resident_base + extra - usize::from(!exact),
                ..SwiftRunBudget::default()
            },
        );
        if exact {
            let (phase, stats) = measure(|| {
                cache
                    .prepare_operation(&mut c, None, cache_cursor())
                    .unwrap()
            });
            assert_eq!(stats.attempts, 0);
            assert_eq!(
                inspection::operation_current(&phase),
                foundation_construction_bytes().unwrap() + extra
            );
            phase.complete(()).unwrap();
        } else {
            let (failure, stats) = measure(|| {
                cache
                    .prepare_operation(&mut c, None, cache_cursor())
                    .err()
                    .unwrap()
            });
            assert_eq!(stats.attempts, 0);
            assert_eq!(failure.kind, SwiftRunFailureKind::CombinedExhausted);
        }
        finish(cache, c);
    }
    let header = cache_header_bytes().unwrap();
    let patch_bytes = 512 * size_of::<decode::Patch>();
    for ceiling in [
        header - 1,
        header,
        header + patch_bytes - 1,
        header + patch_bytes,
    ] {
        let (mut c, a) = adopt(
            &bytes,
            SwiftRunBudget {
                cache_bytes: ceiling,
                cache_entries: 0,
                active_pins: 0,
                ..SwiftRunBudget::default()
            },
        );
        let (result, stats) = measure(|| construct(&mut c, a, None));
        if ceiling == header + patch_bytes {
            assert_eq!(stats.attempts, 3);
            let cache = result.unwrap();
            assert_eq!(c.usage(None).reservations.cache.current, ceiling);
            finish(cache, c);
        } else {
            assert_eq!(stats.attempts, usize::from(ceiling >= header + patch_bytes));
            let failure = result.err().unwrap();
            assert_eq!(failure.kind, SwiftRunFailureKind::CategoryExhausted);
            assert_eq!(
                c.usage(None).reservations.cache.peak,
                if ceiling < header {
                    0
                } else if ceiling < header + patch_bytes {
                    header
                } else {
                    header + patch_bytes
                }
            );
            assert_eq!(c.usage(None).reservations.cache.current, 0);
            assert_eq!(
                c.finish_owned_cleanup(None).reservations.combined.current,
                0
            );
        }
    }
}

// Exercises the actual constructor failure/partial-drain branch with a private
// per-test-thread counter. No store to the production NEXT_OWNER occurs.
fn review_owner_allocator_exhaustion() {
    hooks(Hooks::default());
    let bytes = fixture(0, &[0, 0x0b], 100);
    let original_test_counter = inspection::owner_counter();
    inspection::with_owner_counter(u64::MAX - 1, || {
        let (c, cache) = new(&bytes, SwiftRunBudget::default());
        assert_eq!(cache.identity().owner, u64::MAX - 1);
        assert_eq!(inspection::owner_counter(), u64::MAX);
        finish(cache, c);
        let (mut baseline, adopted) = adopt(&bytes, SwiftRunBudget::default());
        let (_, proof_drop) = measure(|| baseline.drop_proof(adopted).unwrap());
        assert_eq!(
            baseline
                .finish_owned_cleanup(None)
                .reservations
                .combined
                .current,
            0
        );
        for attempt in 0..3 {
            let (mut c, adopted) = adopt(&bytes, SwiftRunBudget::default());
            let (failure, allocations) =
                measure(|| construct(&mut c, adopted, None).err().unwrap());
            assert_eq!(failure.kind, SwiftRunFailureKind::Invariant);
            assert_eq!(failure.code, "swift_cache_owner_exhausted");
            assert_eq!(allocations.attempts, 5);
            assert_eq!(allocations.injected_failures, 0);
            assert_eq!(allocations.allocations, 5);
            assert_eq!(allocations.reallocations, 0);
            assert_eq!(
                allocations.deallocations,
                allocations.allocations + proof_drop.deallocations
            );
            assert_eq!(
                allocations.freed_bytes,
                allocations.allocated_bytes + proof_drop.freed_bytes
            );
            assert_eq!(inspection::owner_counter(), u64::MAX);
            let after = c.usage(None);
            assert_eq!(after.reservations.cache.current, 0);
            assert_eq!(after.reservations.retained_source.current, 0);
            assert_eq!(after.reservations.retained_metadata.current, 0);
            assert_eq!(after.live.active_pins.current, 0);
            assert_eq!(after.live.cache_entries.current, 0);
            assert_eq!(after.cleanup_invariant, None);
            assert!(failure.at_failure.reservations.cache.current > 0);
            assert!(
                after.reservations.combined.current
                    < failure.at_failure.reservations.combined.current
            );
            let final_usage = c.finish_owned_cleanup(None);
            assert_eq!(final_usage.reservations.combined.current, 0);
            assert_eq!(final_usage.reservations.live_tickets, 0);
            println!("owner allocator exhaustion attempt={attempt} private_counter=MAX actual_constructor_allocations=5 partial_drained=true no_duplicate_authority=true");
        }
    });
    assert!(!inspection::owner_override_active());
    assert_eq!(inspection::owner_counter(), original_test_counter);
    let unwind = std::panic::catch_unwind(|| {
        inspection::with_owner_counter(u64::MAX, || panic!("owner test scope unwind"));
    });
    assert!(unwind.is_err());
    assert!(!inspection::owner_override_active());
    assert_eq!(inspection::owner_counter(), original_test_counter);
    // A normal construction uses the untouched global allocator after both
    // ordinary scope completion and unwinding of the private-counter scope.
    let (c, cache) = new(&bytes, SwiftRunBudget::default());
    assert_ne!(cache.identity().owner, 0);
    assert!(cache.identity().owner < u64::MAX - 1);
    finish(cache, c);
}

// Test-only setup for the lifecycle composition's actual cache checkpoints.
pub(super) fn lifecycle_cancel_at_step(step: CacheStep) {
    hooks(Hooks {
        pause: Some(step),
        cancel_pause: true,
        ..Hooks::default()
    });
}
pub(super) fn lifecycle_reset_hooks() {
    hooks(Hooks::default());
}
// Reset-elision tests: all hooks are test-only; no runtime-control replacement.
#[derive(Clone, Copy)]
struct ElisionObservation {
    enabled: bool,
    dirty: bool,
    dirty_passes: [usize; 2],
    stage_work: [u64; 8],
    previous_work: u64,
    previous_step: CacheStep,
    boundaries: [Option<(usize, u64)>; 2],
}
impl Default for ElisionObservation {
    fn default() -> Self {
        Self {
            enabled: false,
            dirty: false,
            dirty_passes: [0; 2],
            stage_work: [0; 8],
            previous_work: 0,
            previous_step: CacheStep::Constructor,
            boundaries: [None; 2],
        }
    }
}
thread_local! { static ELISION: Cell<ElisionObservation> = Cell::new(ElisionObservation::default()); }
fn elision_observe_checkpoint(control: &RuntimeControl) {
    ELISION.with(|state| {
        let mut x = state.get();
        if x.enabled {
            let work = control.usage(None).cache_work;
            x.stage_work[x.previous_step as usize] += work - x.previous_work;
            x.previous_work = work;
            x.previous_step = HOOKS.with(|h| h.get().step);
            let boundary = match x.previous_step {
                CacheStep::ScanReset => Some(0),
                CacheStep::BuildReset => Some(1),
                _ => None,
            };
            if let Some(index) = boundary {
                x.boundaries[index].get_or_insert((HOOKS.with(|h| h.get().checks), work));
            }
            state.set(x);
        }
    });
}
fn elision_enable(control: &RuntimeControl, dirty: bool) {
    ELISION.with(|s| {
        s.set(ElisionObservation {
            enabled: true,
            dirty,
            previous_work: control.usage(None).cache_work,
            ..ElisionObservation::default()
        })
    });
}
fn elision_finish_observation(control: &RuntimeControl) -> ElisionObservation {
    elision_observe_checkpoint(control);
    ELISION.with(|s| {
        let x = s.get();
        s.set(ElisionObservation::default());
        x
    })
}
// A test-only ordinary decoder meter. It seeds finite initialized scratch and
// checks malformed syntax; it never authorizes a cache entry or substitutes for
// the real RuntimeControl used by every actual-owner cache operation below.
pub(super) struct ElisionScratchMeter;
impl crate::experimental::cache::borrowed::sealed::Meter for ElisionScratchMeter {}
impl crate::experimental::cache::borrowed::DecodeMeter for ElisionScratchMeter {
    type Failure = &'static str;
    fn error(
        &mut self,
        _: crate::experimental::cache::CacheFailureKind,
        code: &'static str,
    ) -> Self::Failure {
        code
    }
    fn check(&mut self) -> Result<(), Self::Failure> {
        Ok(())
    }
    fn work(&mut self, _: u64) -> Result<(), Self::Failure> {
        Ok(())
    }
    fn set_offset(&mut self, _: usize) {}
    fn exact_capacity(&mut self, requested: usize, observed: usize) -> Result<(), Self::Failure> {
        assert_eq!(requested, observed);
        Ok(())
    }
}
pub(super) fn elision_seed_patches(patches: &mut [decode::Patch]) {
    use crate::experimental::cache::borrowed::FrozenPolicy;
    // Each independent one-slot pass writes start=17, alternative=Some(19),
    // kind=If through the unchanged decoder. These are all nonempty fields and
    // hostile for the much shorter bodies below. No raw or uninitialized memory.
    const SEED: &[u8] = &[
        0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4, 0x40, 1, 5, 1, 0x0b, 0x0b,
    ];
    let limits = crate::Limits::default();
    let policy = FrozenPolicy {
        limits: &limits,
        extent: SEED.len(),
    };
    for patch in patches {
        let mut depth = 0;
        let mut counts = decode::Counts::default();
        decode::scan_borrowed(
            SEED,
            0,
            &policy,
            &mut ElisionScratchMeter,
            decode::PassParts {
                controls: std::slice::from_mut(patch),
                depth: &mut depth,
                counts: &mut counts,
            },
            None,
        )
        .unwrap();
        assert_eq!(depth, 0);
    }
}
pub(super) fn elision_dirty_before_boundary(patches: &mut [decode::Patch]) {
    if !ELISION.with(|s| s.get().dirty) {
        return;
    }
    assert_eq!(patches.len(), 512);
    elision_seed_patches(patches);
    let index = match HOOKS.with(|h| h.get().step) {
        CacheStep::ScanReset => 0,
        CacheStep::BuildReset => 1,
        other => panic!("unexpected reset {other:?}"),
    };
    ELISION.with(|s| {
        let mut x = s.get();
        x.dirty_passes[index] += 1;
        s.set(x);
    });
}
#[test]
fn reset_elision_observation_fixture() {
    use crate::experimental::cache::{ControlKind as K, Operation as O};
    for (label, helper, expected) in [
        ("flat", body(0, &[0x0b]), vec![O::End]),
        (
            "nested",
            body(
                0,
                &[
                    2, 0x40, 3, 0x40, 1, 0x0b, 0x0b, 0x41, 0, 4, 0x40, 1, 5, 1, 0x0b, 0x0b,
                ],
            ),
            vec![
                O::Block {
                    kind: K::Block,
                    result: None,
                    end: 4,
                    alternative: None,
                },
                O::Block {
                    kind: K::Loop,
                    result: None,
                    end: 3,
                    alternative: None,
                },
                O::Nop,
                O::End,
                O::End,
                O::Const(Value::I32(0)),
                O::Block {
                    kind: K::If,
                    result: None,
                    end: 10,
                    alternative: Some(8),
                },
                O::Nop,
                O::Else { end: 10 },
                O::Nop,
                O::End,
                O::End,
            ],
        ),
    ] {
        hooks(Hooks::default());
        let bytes = fixture(0, &helper, 100);
        let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
        assert_eq!(c.usage(None).cache_work, 4_928);
        elision_enable(&c, false);
        let before = c.usage(None).cache_work;
        let p = pin(&mut cache, &mut c, 34, None).unwrap();
        let view = cache.view(&p, &mut c, None).unwrap();
        assert_eq!(
            view.instructions
                .iter()
                .map(|i| i.operation.clone())
                .collect::<Vec<_>>(),
            expected
        );
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
        let cold = elision_finish_observation(&c);
        assert_eq!(
            cold.stage_work.iter().sum::<u64>(),
            c.usage(None).cache_work - before
        );
        elision_enable(&c, false);
        let (hit, stats) = measure(|| pin(&mut cache, &mut c, 34, None).unwrap());
        let (_, release_stats) = measure(|| {
            cache
                .release(hit, &mut c, None)
                .map_err(|e| e.failure)
                .unwrap()
        });
        assert_eq!(stats.attempts, 0);
        assert_eq!(release_stats.attempts, 0);
        let hit = elision_finish_observation(&c);
        assert_eq!(hit.stage_work.iter().sum::<u64>(), 8);
        println!("ELISION {{\"case\":\"{label}\",\"constructorWork\":4928,\"coldWork\":{},\"coldStages\":{:?},\"hitWork\":8,\"hitStages\":{:?},\"fixedReserved\":{},\"residentBytes\":{}}}",cold.stage_work.iter().sum::<u64>(),cold.stage_work,hit.stage_work,cache.usage().fixed_reserved,cache.usage().resident_bytes);
        finish(cache, c);
    }
    hooks(Hooks::default());
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (mut c, mut cache) = new(
        &bytes,
        SwiftRunBudget {
            cache_entries: 3,
            ..SwiftRunBudget::default()
        },
    );
    let mut held = None;
    for (index, function) in [34, 35, 36, 35, 37, 34, 38, 37].into_iter().enumerate() {
        let p = pin(&mut cache, &mut c, function, None).unwrap();
        let parts = inspection::elision_pin_parts(&p);
        let times = inspection::elision_times(&cache);
        let newest = times.iter().max().copied().unwrap();
        assert_eq!(newest, c.usage(None).cache_work);
        assert!(times.iter().all(|t| *t == 0 || *t <= newest));
        if index == 0 {
            held = Some(p);
        } else {
            cache
                .release(p, &mut c, None)
                .map_err(|e| e.failure)
                .unwrap();
        }
        if index == 4 {
            cache
                .release(held.take().unwrap(), &mut c, None)
                .map_err(|e| e.failure)
                .unwrap();
        }
        println!("ELISION {{\"case\":\"lru\",\"access\":{index},\"function\":{function},\"pin\":{:?},\"slots\":{:?},\"timestamps\":{:?},\"hits\":{},\"misses\":{},\"evictions\":{},\"residentBytes\":{},\"pinnedBytes\":{}}}",parts,inspection::elision_slots(&cache),times,cache.usage().hits,cache.usage().misses,cache.usage().evictions,cache.usage().resident_bytes,cache.usage().pinned_bytes);
    }
    assert_eq!(cache.usage().hits, 3);
    assert_eq!(cache.usage().misses, 5);
    assert_eq!(cache.usage().evictions, 2);
    finish(cache, c);
    println!("ELISION {{\"case\":\"cleanup\",\"ownersDrained\":3,\"cacheAndCombinedReservations\":0,\"livePinsAndEntries\":0}}");
}
#[test]
fn reset_elision_dirty_actual_owner_both_passes_and_reuse() {
    use crate::experimental::cache::{ControlKind as K, Operation as O};
    let cases = [
        ("flat", body(0, &[1, 0x0b]), vec![O::Nop, O::End], vec![]),
        (
            "siblings",
            body(0, &[2, 0x40, 1, 0x0b, 3, 0x40, 1, 0x0b, 0x0b]),
            vec![
                O::Block {
                    kind: K::Block,
                    result: None,
                    end: 2,
                    alternative: None,
                },
                O::Nop,
                O::End,
                O::Block {
                    kind: K::Loop,
                    result: None,
                    end: 5,
                    alternative: None,
                },
                O::Nop,
                O::End,
                O::End,
            ],
            vec![],
        ),
        (
            "nested",
            body(
                0,
                &[
                    2, 0x40, 3, 0x40, 0x41, 0, 4, 0x40, 1, 5, 1, 0x0b, 0x0b, 0x0b, 0x0b,
                ],
            ),
            vec![
                O::Block {
                    kind: K::Block,
                    result: None,
                    end: 9,
                    alternative: None,
                },
                O::Block {
                    kind: K::Loop,
                    result: None,
                    end: 8,
                    alternative: None,
                },
                O::Const(Value::I32(0)),
                O::Block {
                    kind: K::If,
                    result: None,
                    end: 7,
                    alternative: Some(5),
                },
                O::Nop,
                O::Else { end: 7 },
                O::Nop,
                O::End,
                O::End,
                O::End,
                O::End,
            ],
            vec![],
        ),
        (
            "br_table",
            body(
                1,
                &[
                    2, 0x40, 3, 0x40, 0x41, 0, 0x0e, 3, 0, 1, 2, 2, 0x0b, 0x0b, 0x0b,
                ],
            ),
            vec![
                O::Block {
                    kind: K::Block,
                    result: None,
                    end: 5,
                    alternative: None,
                },
                O::Block {
                    kind: K::Loop,
                    result: None,
                    end: 4,
                    alternative: None,
                },
                O::Const(Value::I32(0)),
                O::BrTable {
                    first: 0,
                    count: 3,
                    default: 2,
                },
                O::End,
                O::End,
                O::End,
            ],
            vec![0, 1, 2],
        ),
    ];
    for (label, helper, expected, targets) in cases {
        hooks(Hooks::default());
        let bytes = fixture(0, &helper, 100);
        let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
        elision_enable(&c, true);
        let p = pin(&mut cache, &mut c, 34, None).unwrap();
        let view = cache.view(&p, &mut c, None).unwrap();
        assert_eq!(
            view.instructions
                .iter()
                .map(|i| i.operation.clone())
                .collect::<Vec<_>>(),
            expected,
            "{label}"
        );
        assert_eq!(view.branch_targets, targets);
        assert_eq!(view.locals.len(), usize::from(label == "br_table"));
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
        let o = elision_finish_observation(&c);
        assert_eq!(o.dirty_passes, [1, 1]);
        assert_eq!(o.stage_work[CacheStep::ScanReset as usize], 0);
        assert_eq!(o.stage_work[CacheStep::BuildReset as usize], 0);
        println!(
            "ELISION_DIRTY case={label} dirtied_slots_per_pass=512 passes={:?} reset_credits=[0,0]",
            o.dirty_passes
        );
        finish(cache, c);
    }
    for depth in [379, 512] {
        hooks(Hooks::default());
        let mut code = Vec::new();
        for _ in 1..depth {
            code.extend([2, 0x40]);
        }
        code.extend(std::iter::repeat_n(0x0b, depth));
        let helper = body(0, &code);
        let bytes = fixture(0, &helper, 100);
        let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
        elision_enable(&c, true);
        let p = pin(&mut cache, &mut c, 34, None).unwrap();
        let view = cache.view(&p, &mut c, None).unwrap();
        assert_eq!(view.instructions.len(), 2 * depth - 1);
        for i in 0..depth - 1 {
            assert_eq!(
                view.instructions[i].operation,
                O::Block {
                    kind: K::Block,
                    result: None,
                    end: 2 * depth - 3 - i,
                    alternative: None
                }
            );
        }
        assert!(view.instructions[depth - 1..]
            .iter()
            .all(|i| i.operation == O::End));
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
        let o = elision_finish_observation(&c);
        assert_eq!(o.dirty_passes, [1, 1]);
        // Reuse the very same owner and deep stale arena for an ordinary flat
        // miss. Do not redirty here: this specifically tests deep-to-shallow reuse.
        let p = pin(&mut cache, &mut c, 35, None).unwrap();
        let view = cache.view(&p, &mut c, None).unwrap();
        assert_eq!(view.instructions.len(), 1);
        assert_eq!(view.instructions[0].operation, O::End);
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
        println!("ELISION_DIRTY depth={depth} inclusive=true deep_to_shallow_same_owner=true");
        finish(cache, c);
    }
    let mut code = Vec::new();
    for _ in 0..512 {
        code.extend([2, 0x40]);
    }
    code.extend(std::iter::repeat_n(0x0b, 513));
    let rejected = validate_swift_reactor(
        &fixture(0, &body(0, &code), 100),
        SwiftValidationBudget::default(),
        &Cancellation::default(),
    )
    .err()
    .expect("depth513 rejected by complete validation");
    println!("ELISION_DIRTY depth=513 validation_rejection={rejected:?}");
}
#[test]
fn reset_elision_hostile_inactive_malformed_controls() {
    hooks(Hooks::default());
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (c, mut cache) = new(&bytes, SwiftRunBudget::default());
    for (body, expected) in [
        (&[0, 5, 0x0b][..], "decode_else"),
        (&[0, 4, 0x40, 5, 5, 0x0b, 0x0b][..], "decode_else"),
        (&[0, 2, 0x40][..], "decode_end"),
        (&[0, 2, 0x40, 1][..], "decode_end"),
        (&[0, 0x0b, 1][..], "decode_trailing"),
    ] {
        assert_eq!(
            inspection::elision_malformed(&mut cache, body),
            [expected; 2]
        );
    }
    inspection::elision_dirty_owner(&mut cache);
    finish(cache, c);
    println!(
        "ELISION_MALFORMED cases=5 passes_per_case=2 actual_owner_slots=512 typed_failures=true"
    );
}

#[test]
fn reset_elision_boundary_precedence_and_sticky() {
    hooks(Hooks::default());
    let bytes = fixture(0, &body(1, &[0, 0x0e, 2, 0, 0, 0, 0x0b]), 29);
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    hooks(Hooks::default());
    elision_enable(&c, false);
    let p = pin(&mut cache, &mut c, 34, None).unwrap();
    let observed = elision_finish_observation(&c);
    cache
        .release(p, &mut c, None)
        .map_err(|e| e.failure)
        .unwrap();
    finish(cache, c);
    for (index, step) in [CacheStep::ScanReset, CacheStep::BuildReset]
        .into_iter()
        .enumerate()
    {
        let (ordinal, credits) = observed.boundaries[index].expect("ordinary boundary observed");
        for expired in [false, true] {
            for cancelled in [false, true] {
                hooks(Hooks::default());
                let (mut c, mut cache) = new(
                    &bytes,
                    SwiftRunBudget {
                        cache_work: credits,
                        deadline_ms: if expired {
                            20
                        } else {
                            SwiftRunBudget::default().deadline_ms
                        },
                        ..SwiftRunBudget::default()
                    },
                );
                hooks(Hooks {
                    cancel: cancelled.then_some(ordinal),
                    pause: expired.then_some(step),
                    ..Hooks::default()
                });
                let f = pin(&mut cache, &mut c, 34, None).unwrap_err();
                hooks(Hooks::default());
                assert_eq!(
                    f.kind,
                    if cancelled {
                        SwiftRunFailureKind::Cancelled
                    } else if expired {
                        SwiftRunFailureKind::Deadline
                    } else {
                        SwiftRunFailureKind::WorkExhausted
                    }
                );
                assert_eq!(c.usage(None).cache_work, credits);
                assert_eq!(c.usage(None).live.active_pins.current, 0);
                assert_eq!(c.usage(None).live.cache_entries.current, 0);
                assert_eq!(cache.usage().decodes, 0);
                assert_eq!(c.check_with_wasi(cache_cursor(), None).unwrap_err(), f);
                let before = c.usage(None);
                let (again, stats) = measure(|| pin(&mut cache, &mut c, 34, None));
                assert_eq!(again.unwrap_err(), f);
                assert_eq!(stats.attempts, 0);
                assert_eq!(c.usage(None).cache_work, before.cache_work);
                assert_eq!(c.usage(None).reservations, before.reservations);
                println!("ELISION_PRECEDENCE boundary={step:?} credits={credits} expired={expired} cancelled={cancelled} first={:?} sticky=true publication=0",f.kind);
                finish(cache, c);
            }
        }
    }
}

// Selected bounded resident-index controls. The oracle walks actual owner slots
// independently and compares every chain membership with the resident set.
fn resident_assert_index(cache: &SwiftFunctionCache) {
    let index = inspection::resident_index(cache);
    assert_eq!(index.len(), 192);
    let slots = inspection::elision_slots(cache);
    let mut seen = [false; 64];
    for bucket in 0..128 {
        let mut node = index[bucket];
        let mut count = 0;
        while node != 0 {
            assert!(count < 64, "unbounded or cyclic chain");
            let slot = usize::from(node - 1);
            assert!(slot < slots.len());
            assert!(!seen[slot]);
            seen[slot] = true;
            let function = slots[slot][1];
            assert_ne!(function, u64::MAX);
            assert_eq!(
                (((function * 0x9e37_79b9) & 0xffff_ffff) >> 25) as usize,
                bucket
            );
            node = index[128 + slot];
            count += 1;
        }
    }
    for (slot, actual) in slots.iter().enumerate() {
        assert_eq!(seen[slot], actual[1] != u64::MAX);
        if !seen[slot] {
            assert_eq!(index[128 + slot], 0);
        }
    }
    assert!(index[128 + slots.len()..].iter().all(|link| *link == 0));
}
fn resident_seed(c: &mut RuntimeControl, cache: &mut SwiftFunctionCache) {
    for function in [34, 178, 267] {
        let p = pin(cache, c, function, None).unwrap();
        cache.release(p, c, None).map_err(|e| e.failure).unwrap();
        resident_assert_index(cache);
    }
}
#[test]
fn resident_index_collision_delete_head_middle_tail_and_reinsert() {
    // These four independently calculated identities share bucket1.
    for victim in [267, 178, 34] {
        hooks(Hooks::default());
        let bytes = fixture(0, &[0, 0x0b], 500);
        let (mut c, mut cache) = new(
            &bytes,
            SwiftRunBudget {
                cache_entries: 3,
                ..SwiftRunBudget::default()
            },
        );
        resident_seed(&mut c, &mut cache);
        let victim_slot = inspection::elision_slots(&cache)
            .iter()
            .find(|s| s[1] == victim)
            .unwrap()[0];
        for function in [34, 178, 267]
            .into_iter()
            .filter(|f| u64::from(*f) != victim)
        {
            let (p, allocations) = measure(|| pin(&mut cache, &mut c, function, None).unwrap());
            assert_eq!(allocations.attempts, 0);
            cache
                .release(p, &mut c, None)
                .map_err(|e| e.failure)
                .unwrap();
        }
        let p = pin(&mut cache, &mut c, 411, None).unwrap();
        assert_eq!(cache.view(&p, &mut c, None).unwrap().function, 411);
        assert_eq!(cache.usage().evictions, 1);
        assert_eq!(
            inspection::elision_slots(&cache)[victim_slot as usize][1],
            411
        );
        resident_assert_index(&cache);
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
        let p = pin(&mut cache, &mut c, victim as u32, None).unwrap();
        assert_eq!(
            cache.view(&p, &mut c, None).unwrap().function,
            victim as u32
        );
        resident_assert_index(&cache);
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
        finish(cache, c);
        println!("RESIDENT collision victim={victim} removed/reused/reinserted cleanup=zero");
    }
}
#[test]
fn resident_index_every_collision_replacement_work_and_cancel_boundary() {
    for victim in [34, 178, 267] {
        hooks(Hooks::default());
        let bytes = fixture(0, &[0, 0x0b], 500);
        let budget = SwiftRunBudget {
            cache_entries: 3,
            ..SwiftRunBudget::default()
        };
        let (mut c, mut cache) = new(&bytes, budget);
        resident_seed(&mut c, &mut cache);
        for function in [34, 178, 267].into_iter().filter(|f| *f != victim) {
            let p = pin(&mut cache, &mut c, function, None).unwrap();
            cache
                .release(p, &mut c, None)
                .map_err(|e| e.failure)
                .unwrap();
        }
        let base = c.usage(None).cache_work;
        hooks(Hooks::default());
        let p = pin(&mut cache, &mut c, 411, None).unwrap();
        let credits = c.usage(None).cache_work - base;
        let checks = HOOKS.with(|h| h.get().checks);
        hooks(Hooks::default());
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
        finish(cache, c);
        for prefix in 0..credits {
            hooks(Hooks::default());
            let (mut c, mut cache) = new(
                &bytes,
                SwiftRunBudget {
                    cache_work: base + prefix,
                    ..budget
                },
            );
            resident_seed(&mut c, &mut cache);
            for function in [34, 178, 267].into_iter().filter(|f| *f != victim) {
                let p = pin(&mut cache, &mut c, function, None).unwrap();
                cache
                    .release(p, &mut c, None)
                    .map_err(|e| e.failure)
                    .unwrap();
            }
            let failure = pin(&mut cache, &mut c, 411, None).unwrap_err();
            assert_eq!(failure.resource, Some(SwiftRunResource::CacheWork));
            assert_eq!(c.usage(None).live.active_pins.current, 0);
            resident_assert_index(&cache);
            let before = c.usage(None);
            assert_eq!(
                pin(&mut cache, &mut c, 411, None).unwrap_err().kind,
                failure.kind
            );
            review_assert_same_control_effects(before, c.usage(None));
            finish(cache, c);
        }
        for ordinal in 0..checks {
            hooks(Hooks::default());
            let (mut c, mut cache) = new(&bytes, budget);
            resident_seed(&mut c, &mut cache);
            for function in [34, 178, 267].into_iter().filter(|f| *f != victim) {
                let p = pin(&mut cache, &mut c, function, None).unwrap();
                cache
                    .release(p, &mut c, None)
                    .map_err(|e| e.failure)
                    .unwrap();
            }
            hooks(Hooks {
                cancel: Some(ordinal),
                ..Hooks::default()
            });
            assert_eq!(
                pin(&mut cache, &mut c, 411, None).unwrap_err().kind,
                SwiftRunFailureKind::Cancelled
            );
            hooks(Hooks::default());
            assert_eq!(c.usage(None).live.active_pins.current, 0);
            resident_assert_index(&cache);
            finish(cache, c);
        }
        println!("RESIDENT every replacement victim={victim} work_prefixes={credits} cancellation_checks={checks} original_failure_sticky=true cleanup=zero");
    }
}

#[test]
fn resident_index_invalid_slot_empty_link_wrong_bucket_cycle_fail_closed() {
    for case in 0..4 {
        hooks(Hooks::default());
        let bytes = fixture(0, &[0, 0x0b], 500);
        let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
        resident_seed(&mut c, &mut cache);
        let bucket = (((34u64 * 0x9e37_79b9) & 0xffff_ffff) >> 25) as usize;
        let head = inspection::resident_index(&cache)[bucket];
        match case {
            0 => inspection::corrupt_index(&mut cache, bucket, 255),
            1 => inspection::corrupt_index(&mut cache, 128 + usize::from(head - 1), 64),
            2 => {
                let p = pin(&mut cache, &mut c, 35, None).unwrap();
                cache
                    .release(p, &mut c, None)
                    .map_err(|e| e.failure)
                    .unwrap();
                inspection::corrupt_index(&mut cache, bucket, 4);
            }
            _ => inspection::corrupt_index(&mut cache, 128 + usize::from(head - 1), head),
        }
        let failure = pin(&mut cache, &mut c, 34, None).unwrap_err();
        assert_eq!(failure.kind, SwiftRunFailureKind::DecoderMismatch);
        assert_eq!(cache.usage().decodes, if case == 2 { 4 } else { 3 });
        assert_eq!(c.usage(None).live.active_pins.current, 0);
        finish(cache, c);
        println!(
            "RESIDENT corrupt case={case} code={} failclosed cleanup=zero",
            failure.code
        );
    }
}
#[test]
fn resident_index_all_pinned_exact_capacity_and_empty_links() {
    hooks(Hooks::default());
    let bytes = fixture(0, &[0, 0x0b], 500);
    let (mut c, mut cache) = new(
        &bytes,
        SwiftRunBudget {
            cache_entries: 3,
            ..SwiftRunBudget::default()
        },
    );
    let a = pin(&mut cache, &mut c, 34, None).unwrap();
    let b = pin(&mut cache, &mut c, 178, None).unwrap();
    let d = pin(&mut cache, &mut c, 267, None).unwrap();
    let before = inspection::resident_index(&cache).to_vec();
    assert_eq!(
        pin(&mut cache, &mut c, 411, None).unwrap_err().code,
        "all_entries_pinned"
    );
    assert_eq!(inspection::resident_index(&cache), before);
    resident_assert_index(&cache);
    for p in [a, b, d] {
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
    }
    finish(cache, c);
    println!("RESIDENT all_pinned original_index_retained=true terminal_release=true cleanup=zero");
}

#[test]
fn resident_index_inclusive_64_node_chain_and_cycle_bound() {
    hooks(Hooks::default());
    let functions: Vec<u32> = (34..12034)
        .filter(|f| {
            ((u64::from(*f) * 0x9e37_79b9) & 0xffff_ffff) >> 25
                == ((34u64 * 0x9e37_79b9) & 0xffff_ffff) >> 25
        })
        .take(64)
        .collect();
    assert_eq!(functions.len(), 64);
    let bytes = fixture(0, &[0, 0x0b], 12000);
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    for function in &functions {
        let p = pin(&mut cache, &mut c, *function, None).unwrap();
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
    }
    resident_assert_index(&cache);
    let before = c.usage(None).cache_work;
    let p = pin(&mut cache, &mut c, functions[0], None).unwrap();
    assert_eq!(cache.view(&p, &mut c, None).unwrap().function, functions[0]);
    let hit_work = c.usage(None).cache_work - before;
    assert_eq!(hit_work, 260); // two ordinary headers plus hash/head plus4*64 nodes.
    cache
        .release(p, &mut c, None)
        .map_err(|e| e.failure)
        .unwrap();
    let bucket = (((34u64 * 0x9e37_79b9) & 0xffff_ffff) >> 25) as usize;
    let head = inspection::resident_index(&cache)[bucket];
    inspection::corrupt_index(&mut cache, 128, head); // tail slot0 now closes a64-node cycle.
    assert_eq!(
        pin(&mut cache, &mut c, functions[0], None)
            .unwrap_err()
            .code,
        "swift_cache_index_cycle"
    );
    finish(cache, c);
    println!("RESIDENT chain64 inclusive=true full_chain_hit_work={hit_work} adversarial_cost_not_discounted=true cycle_failclosed=true cleanup=zero");
}

#[test]
fn resident_index_finite_cost_fixture() {
    hooks(Hooks::default());
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
    let constructor = c.usage(None).cache_work;
    for function in 34..98 {
        let p = pin(&mut cache, &mut c, function, None).unwrap();
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
    }
    let cold = c.usage(None).cache_work - constructor;
    let before = c.usage(None).cache_work;
    let (_, allocations) = measure(|| {
        for _ in 0..4 {
            for function in 34..98 {
                let p = pin(&mut cache, &mut c, function, None).unwrap();
                assert_eq!(cache.view(&p, &mut c, None).unwrap().function, function);
                cache
                    .release(p, &mut c, None)
                    .map_err(|e| e.failure)
                    .unwrap();
            }
        }
    });
    assert_eq!(allocations.attempts, 0);
    assert_eq!(cache.usage().hits, 256);
    assert_eq!(cache.usage().misses, 64);
    assert_eq!(cache.usage().evictions, 0);
    let hits = c.usage(None).cache_work - before;
    println!("RESIDENT_COST {{\"constructorWork\":{constructor},\"cold64Work\":{cold},\"hit256Work\":{hits},\"fixedReserved\":{},\"residentBytes\":{},\"hitAllocatorRequests\":{},\"slots\":{:?}}}",cache.usage().fixed_reserved,cache.usage().resident_bytes,allocations.attempts,inspection::elision_slots(&cache));
    finish(cache, c);
}

#[test]
fn plan_reuse_observation() {
    use crate::experimental::cache::Operation as O;
    for wide in [false, true] {
        let helper = body(1, &[0x41, 7, 0x21, 0, 0x20, 0, 0x1a, 0x0b]);
        let bytes = if wide {
            plan_reuse_wide_fixture(&helper, 600)
        } else {
            fixture(0, &helper, 600)
        };
        let (mut c, mut cache) = new(&bytes, SwiftRunBudget::default());
        let fixed = cache.usage().fixed_reserved;
        let start = c.usage(None).cache_work;
        let mut credits = vec![];
        for sweep in 0..3 {
            let begin = c.usage(None).cache_work;
            for f in 34..130 {
                let p = pin(&mut cache, &mut c, f, None).unwrap();
                let v = cache.view(&p, &mut c, None).unwrap();
                if f == 34 {
                    let operations: Vec<_> =
                        v.instructions.iter().map(|x| x.operation.clone()).collect();
                    assert_eq!(v.locals, &[Type::I32]);
                    assert_eq!(
                        operations,
                        vec![
                            O::Const(Value::I32(7)),
                            O::LocalSet(0),
                            O::LocalGet(0),
                            O::Drop,
                            O::End
                        ]
                    );
                    assert!(v.branch_targets.is_empty());
                    println!(
                        "PLAN_IR wide={wide} sweep={sweep} operations={operations:?} offsets={:?}",
                        v.instructions
                            .iter()
                            .map(|x| x.offset - v.body_offset)
                            .collect::<Vec<_>>()
                    );
                }
                cache
                    .release(p, &mut c, None)
                    .map_err(|e| e.failure)
                    .unwrap();
            }
            credits.push(c.usage(None).cache_work - begin);
        }
        assert_eq!(cache.usage().decodes, 288);
        assert_eq!(cache.usage().evictions, 224);
        assert!(c.usage(None).reservations.peak_tickets <= 86);
        println!("PLAN_COST wide={wide} fixed={fixed} constructor_work={start} sweeps={credits:?} usage={:?} tickets={}/{}",cache.usage(),c.usage(None).reservations.live_tickets,c.usage(None).reservations.peak_tickets);
        println!(
            "PLAN_LRU wide={wide} slots={:?}",
            inspection::elision_slots(&cache)
        );
        finish(cache, c);
    }
}

use super::cache::plan_inspection as pi;
fn plan_reuse_release(cache: &mut SwiftFunctionCache, c: &mut RuntimeControl, f: u32) {
    let p = pin(cache, c, f, None).unwrap();
    cache.release(p, c, None).map_err(|e| e.failure).unwrap();
}
fn plan_reuse_seed(bytes: &[u8], budget: SwiftRunBudget) -> (RuntimeControl, SwiftFunctionCache) {
    let (mut c, mut cache) = new(bytes, budget);
    plan_reuse_release(&mut cache, &mut c, 34);
    plan_reuse_release(&mut cache, &mut c, 35);
    assert_eq!(pi::key(&cache, 34), Some(34));
    (c, cache)
}
fn plan_reuse_primary(a: SwiftRunFailure, b: SwiftRunFailure) {
    assert_eq!(
        (
            a.kind,
            a.code,
            a.function,
            a.offset,
            a.resource,
            a.attempted,
            a.limit
        ),
        (
            b.kind,
            b.code,
            b.function,
            b.offset,
            b.resource,
            b.attempted,
            b.limit
        )
    );
}
#[test]
fn plan_reuse_shapes_and_admission() {
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
    let (result, stats) = measure(|| construct(&mut c, a, None));
    let cache = result.unwrap();
    assert_eq!(stats.attempts, 5);
    assert_eq!(c.budget(), SwiftRunBudget::default());
    assert_eq!(c.usage(None).reservations.live_tickets, 9);
    println!(
        "PLAN_SHAPE {:?} constructor_allocations={stats:?} fixed={} cleanup={:?}",
        pi::shape(),
        cache.usage().fixed_reserved,
        cache_cleanup_temporary_bytes()
    );
    assert_eq!(pi::count(&cache), 0);
    finish(cache, c);
}
#[test]
fn plan_reuse_collisions_and_independent_identity() {
    let bytes = fixture(0, &body(1, &[0x0b]), 600);
    let budget = SwiftRunBudget {
        cache_entries: 1,
        ..SwiftRunBudget::default()
    };
    let (mut c, mut cache) = new(&bytes, budget);
    plan_reuse_release(&mut cache, &mut c, 34);
    assert_eq!(pi::key(&cache, 34), Some(34));
    plan_reuse_release(&mut cache, &mut c, 546);
    assert_eq!(pi::key(&cache, 34), Some(546));
    plan_reuse_release(&mut cache, &mut c, 34);
    assert_eq!(pi::key(&cache, 546), Some(34));
    plan_reuse_release(&mut cache, &mut c, 35);
    let ((r, scans), stats) = measure(|| {
        hooks(Hooks::default());
        let r = pin(&mut cache, &mut c, 34, None).unwrap();
        (r, HOOKS.with(|h| h.get().steps[CacheStep::Scan as usize]))
    });
    assert_eq!(scans, 0);
    assert_eq!(stats.attempts, 2);
    cache
        .release(r, &mut c, None)
        .map_err(|e| e.failure)
        .unwrap();
    finish(cache, c);
    let (c, cache) = new(&bytes, budget);
    assert_eq!(pi::count(&cache), 0);
    finish(cache, c);
    for field in 0..4 {
        let (mut c, mut cache) = plan_reuse_seed(&bytes, budget);
        pi::corrupt(&mut cache, 34, field);
        let f = pin(&mut cache, &mut c, 34, None).unwrap_err();
        assert_eq!(f.kind, SwiftRunFailureKind::DecoderMismatch);
        assert_eq!(
            f.code,
            if field < 3 {
                "swift_plan_identity"
            } else {
                "decode_count_mismatch"
            }
        );
        let work = c.usage(None).cache_work;
        let second = pin(&mut cache, &mut c, 35, None).unwrap_err();
        plan_reuse_primary(f, second);
        assert_eq!(c.usage(None).cache_work, work);
        assert_eq!(c.usage(None).live.active_pins.current, 0);
        finish(cache, c);
    }
    let (c, mut cache) = plan_reuse_seed(&bytes, budget);
    let (mut other, other_cache) = new(&bytes, budget);
    let before = pi::count(&cache);
    let (r, stats) = measure(|| pin(&mut cache, &mut other, 34, None));
    assert!(r.is_err());
    assert_eq!(stats.attempts, 0);
    assert_eq!(pi::count(&cache), before);
    finish(other_cache, other);
    finish(cache, c);
}
#[test]
fn plan_reuse_constructor_all_boundaries() {
    let bytes = fixture(0, &[0, 0x0b], 29);
    hooks(Hooks::default());
    let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
    hooks(Hooks::default());
    let cache = construct(&mut c, a, None).unwrap();
    let checks = HOOKS.with(|h| h.get().checks);
    let credits = c.usage(None).cache_work;
    hooks(Hooks::default());
    finish(cache, c);
    for ordinal in 0..5 {
        let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
        let (r, s) = measure_extended(Some(ordinal), || construct(&mut c, a, None));
        assert!(r.is_err());
        assert_eq!(s.injected_failures, 1);
        assert_eq!(c.usage(None).reservations.cache.current, 0);
        assert_eq!(
            c.finish_owned_cleanup(None).reservations.combined.current,
            0
        );
        let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
        hooks(Hooks {
            capacity: Some(ordinal),
            ..Hooks::default()
        });
        let f = construct(&mut c, a, None).err().unwrap();
        hooks(Hooks::default());
        assert_eq!(f.resource, Some(SwiftRunResource::ExactCapacity));
        assert_eq!(c.usage(None).reservations.cache.current, 0);
        assert_eq!(
            c.finish_owned_cleanup(None).reservations.combined.current,
            0
        );
    }
    for work in 0..credits {
        let (mut c, a) = adopt(
            &bytes,
            SwiftRunBudget {
                cache_work: work,
                ..SwiftRunBudget::default()
            },
        );
        let r = construct(&mut c, a, None);
        assert!(r.is_err(), "work {work}");
        assert_eq!(c.usage(None).reservations.cache.current, 0);
        assert_eq!(
            c.finish_owned_cleanup(None).reservations.combined.current,
            0
        );
    }
    for ordinal in 0..checks {
        let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
        hooks(Hooks {
            cancel: Some(ordinal),
            ..Hooks::default()
        });
        let r = construct(&mut c, a, None);
        hooks(Hooks::default());
        assert!(r.is_err(), "check {ordinal}");
        assert_eq!(c.usage(None).reservations.cache.current, 0);
        assert_eq!(
            c.finish_owned_cleanup(None).reservations.combined.current,
            0
        );
    }
    println!("PLAN_CONSTRUCTOR allocation=5 capacity=5 shorter_work={credits} cancellation_checks={checks} cleanup_zero=true");
}
#[test]
fn plan_reuse_cold_cached_all_boundaries() {
    let bytes = fixture(0, &body(1, &[0, 0x0e, 1, 0, 0, 0x0b]), 100);
    let base = SwiftRunBudget {
        cache_entries: 1,
        ..SwiftRunBudget::default()
    };
    for cached in [false, true] {
        hooks(Hooks::default());
        let (mut c, mut cache) = if cached {
            plan_reuse_seed(&bytes, base)
        } else {
            new(&bytes, base)
        };
        let before = c.usage(None).cache_work;
        hooks(Hooks::default());
        let p = pin(&mut cache, &mut c, 34, None).unwrap();
        let checks = HOOKS.with(|h| h.get().checks);
        let work = c.usage(None).cache_work - before;
        hooks(Hooks::default());
        cache
            .release(p, &mut c, None)
            .map_err(|e| e.failure)
            .unwrap();
        finish(cache, c);
        for shorter in 0..work {
            hooks(Hooks::default());
            let (mut c, mut cache) = if cached {
                plan_reuse_seed(
                    &bytes,
                    SwiftRunBudget {
                        cache_work: before + shorter,
                        ..base
                    },
                )
            } else {
                new(
                    &bytes,
                    SwiftRunBudget {
                        cache_work: before + shorter,
                        ..base
                    },
                )
            };
            let f = pin(&mut cache, &mut c, 34, None).unwrap_err();
            assert_eq!(f.resource, Some(SwiftRunResource::CacheWork));
            let retained = pi::key(&cache, 34);
            assert!(retained.is_none() || retained == Some(34));
            let stopped = c.usage(None).cache_work;
            plan_reuse_primary(f, pin(&mut cache, &mut c, 34, None).unwrap_err());
            assert_eq!(c.usage(None).cache_work, stopped);
            finish(cache, c);
        }
        for ordinal in 0..checks {
            let (mut c, mut cache) = if cached {
                plan_reuse_seed(&bytes, base)
            } else {
                new(&bytes, base)
            };
            hooks(Hooks {
                cancel: Some(ordinal),
                ..Hooks::default()
            });
            let f = pin(&mut cache, &mut c, 34, None).unwrap_err();
            hooks(Hooks::default());
            assert_eq!(f.kind, SwiftRunFailureKind::Cancelled);
            assert_eq!(c.usage(None).live.active_pins.current, 0);
            plan_reuse_primary(f, pin(&mut cache, &mut c, 34, None).unwrap_err());
            finish(cache, c);
        }
        for ordinal in 0..3 {
            let (mut c, mut cache) = if cached {
                plan_reuse_seed(&bytes, base)
            } else {
                new(&bytes, base)
            };
            let (r, s) = measure_extended(Some(ordinal), || pin(&mut cache, &mut c, 34, None));
            assert!(r.is_err());
            assert_eq!(s.injected_failures, 1);
            assert_eq!(pi::key(&cache, 34), Some(34));
            assert_eq!(c.usage(None).live.active_pins.current, 0);
            finish(cache, c);
        }
        println!("PLAN_OPERATION cached={cached} shorter_work={work} cancellation_checks={checks} allocations=3 cleanup_zero=true");
    }
}

// Test-only section builder: every body is admitted by the real complete validator.
fn plan_reuse_wide_fixture(helper: &[u8], definitions: usize) -> Vec<u8> {
    let mut module = fixture(0, helper, definitions);
    let mut cursor = 8;
    loop {
        let start = cursor;
        let id = module[cursor];
        cursor += 1;
        let mut size = 0usize;
        let mut shift = 0;
        loop {
            let b = module[cursor];
            cursor += 1;
            size |= ((b & 127) as usize) << shift;
            if b & 128 == 0 {
                break;
            }
            shift += 7;
        }
        if id == 10 {
            module.truncate(start);
            let mut code = vec![];
            uint(definitions as u32, &mut code);
            let mut rich = vec![0, 0x01];
            rich.extend(std::iter::repeat_n(0x01, 511));
            rich.push(0x0b);
            for index in 0..definitions {
                let b = if index == 28 {
                    &[0, 0x41, 0, 0x0b][..]
                } else if index == 0 {
                    helper
                } else {
                    &rich
                };
                uint(b.len() as u32, &mut code);
                code.extend_from_slice(b);
            }
            section(10, &code, &mut module);
            return module;
        }
        cursor += size;
    }
}

#[test]
fn plan_reuse_header_lifetime_and_narrow_admission() {
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (mut c, cache) = new(&bytes, SwiftRunBudget::default());
    let mut owned = Some(cache);
    let (tail, s) = measure(|| SwiftFunctionCache::cleanup(&mut owned, &mut c, None).unwrap());
    assert!(owned.is_none());
    assert!(s.freed_bytes >= pi::shape().1);
    assert_eq!(
        pi::tail_usage(&tail).reservations.cache.current,
        cache_header_bytes().unwrap()
    );
    let mut result = None;
    tail.complete(owned, &mut result);
    assert_eq!(c.usage(None).reservations.cache.current, 0);
    assert_eq!(
        c.finish_owned_cleanup(None).reservations.combined.current,
        0
    );
    // The additional table cannot silently outgrow a narrowed cache ceiling.
    for limit in [0, pi::shape().1 - 1, cache_header_bytes().unwrap() - 1] {
        let (mut c, a) = adopt(
            &bytes,
            SwiftRunBudget {
                cache_bytes: limit,
                ..SwiftRunBudget::default()
            },
        );
        assert!(construct(&mut c, a, None).is_err());
        assert_eq!(c.usage(None).reservations.cache.current, 0);
        assert_eq!(
            c.finish_owned_cleanup(None).reservations.combined.current,
            0
        );
    }
    println!("PLAN_HEADER payload_dropped_before_header=true narrowed_limits=3 cleanup_zero=true");
}
#[test]
fn plan_reuse_collision_publish_boundaries() {
    let bytes = fixture(0, &body(1, &[0x0b]), 600);
    let base = SwiftRunBudget {
        cache_entries: 1,
        ..SwiftRunBudget::default()
    };
    let (mut c, mut cache) = new(&bytes, base);
    plan_reuse_release(&mut cache, &mut c, 34);
    let begin = c.usage(None).cache_work;
    hooks(Hooks::default());
    plan_reuse_release(&mut cache, &mut c, 546);
    let checks = HOOKS.with(|h| h.get().checks);
    let credits = c.usage(None).cache_work - begin;
    let published = pi::summary(&cache, 546).unwrap();
    hooks(Hooks::default());
    finish(cache, c);
    for (is_cancel, n) in [(false, credits as usize), (true, checks)] {
        for ordinal in 0..n {
            let (mut c, mut cache) = new(
                &bytes,
                if is_cancel {
                    base
                } else {
                    SwiftRunBudget {
                        cache_work: begin + ordinal as u64,
                        ..base
                    }
                },
            );
            plan_reuse_release(&mut cache, &mut c, 34);
            let old = pi::summary(&cache, 34).unwrap();
            if is_cancel {
                hooks(Hooks {
                    cancel: Some(ordinal),
                    ..Hooks::default()
                });
            }
            let f = pin(&mut cache, &mut c, 546, None).unwrap_err();
            hooks(Hooks::default());
            let actual = pi::summary(&cache, 546).unwrap();
            assert!(
                actual == old || actual == published,
                "atomic metadata publish ordinal {ordinal}"
            );
            plan_reuse_primary(f, pin(&mut cache, &mut c, 34, None).unwrap_err());
            finish(cache, c);
        }
    }
    println!("PLAN_COLLISION shorter_work={credits} cancellation_checks={checks} atomic=true cleanup_zero=true");
}

#[test]
fn plan_reuse_cached_deadline_and_precedence() {
    let bytes = fixture(0, &body(1, &[0, 0x0e, 1, 0, 0, 0x0b]), 100);
    for step in [
        CacheStep::Lookup,
        CacheStep::BuildReset,
        CacheStep::Build,
        CacheStep::Publication,
    ] {
        for cancel in [false, true] {
            hooks(Hooks::default());
            let (mut c, mut cache) = plan_reuse_seed(
                &bytes,
                SwiftRunBudget {
                    cache_entries: 1,
                    deadline_ms: 20,
                    ..SwiftRunBudget::default()
                },
            );
            hooks(Hooks {
                pause: Some(step),
                cancel_pause: cancel,
                ..Hooks::default()
            });
            let f = pin(&mut cache, &mut c, 34, None).unwrap_err();
            hooks(Hooks::default());
            assert_eq!(
                f.kind,
                if cancel {
                    SwiftRunFailureKind::Cancelled
                } else {
                    SwiftRunFailureKind::Deadline
                }
            );
            assert_eq!(c.usage(None).live.active_pins.current, 0);
            plan_reuse_primary(f, pin(&mut cache, &mut c, 34, None).unwrap_err());
            finish(cache, c);
        }
    }
    println!("PLAN_CACHED_DEADLINE boundaries=4 precedence_pairs=4 cleanup_zero=true");
}

#[test]
fn plan_reuse_profile_envelopes_without_guest_execution() {
    use super::execution::{self,SwiftReactorInstance};
    use super::execution::frame_operations::{FrameOperationStorage,FrameCompletion};
    use crate::experimental_wasi::accounted::accounted_header_bytes;
    let bytes=fixture(0,&[0,0x0b],100);
    let max=SwiftRunBudget::default();
    let mut pair=Some(adopt(&bytes,max));
    let mut returned=Some(SwiftReactorInstance::construct(&mut pair,WasiGrants::default(),WasiBudget::default(),Instant::now(),cache_cursor()));
    let mut owner=returned.take().unwrap().unwrap();assert!(pair.is_none());drop((pair,returned));
    let constructed=owner.control.as_ref().unwrap().usage(owner.wasi.as_ref().map(AccountedWasi::usage));
    assert_eq!(constructed.reservations.live_tickets,21);
    for f in 34..98 {
        let cache=owner.cache.as_mut().unwrap();let control=owner.control.as_mut().unwrap();let wasi=owner.wasi.as_ref();
        let p=pin(cache,control,f,wasi).unwrap();cache.release(p,control,wasi).map_err(|e|e.failure).unwrap();
    }
    let resident=owner.control.as_ref().unwrap().usage(owner.wasi.as_ref().map(AccountedWasi::usage));
    assert_eq!(resident.live.cache_entries.current,64);assert_eq!(resident.reservations.live_tickets,85);
    let mut preparation=Some(owner.prepare_frames(cache_cursor()));
    let mut phase=preparation.take().unwrap().unwrap();let report=phase.drain();
    let bound=report.bound.unwrap();assert_eq!(report.usage.instructions,0);assert_eq!(report.usage.instruction_fuel,0);
    let frame_bytes=bound.admitted-bound.previous;
    assert!(matches!(phase.complete(FrameOperationStorage{preparation,entry:None,returned:None,drained:Some(report),controlled:None}),FrameCompletion::Completed));
    let floor=foundation_construction_bytes().unwrap();
    let construction=execution::construction_bytes().unwrap();
    let execution_header=execution::execution_header_bytes().unwrap();
    // A conservative simultaneous ceiling calculation, not a claim that every
    // independent category ceiling is reachable in a valid module.
    let categories=max.source_bytes+max.metadata_bytes+max.cache_bytes+max.state_bytes;
    let wasi=accounted_header_bytes().unwrap()+4*65536;
    let shared=constructed.reservations.shared.current;
    let phase_peak=floor+construction.max(frame_bytes+cache_operation_bytes().unwrap());
    let maximum_envelope=categories+wasi+shared+phase_peak;
    println!("PLAN_PROFILE floor={floor} execution_header={execution_header} execution_construction={construction} frame_operation={frame_bytes} category_ceiling_sum={categories} wasi_max={wasi} shared={shared} conservative_combined={maximum_envelope} combined_limit={} constructed_current={} constructed_peak={} resident_current={} resident_peak={} frame_peak={} tickets={}/{}",max.combined_bytes,constructed.reservations.combined.current,constructed.reservations.combined.peak,resident.reservations.combined.current,resident.reservations.combined.peak,report.usage.reservations.combined.peak,report.usage.reservations.live_tickets,report.usage.reservations.peak_tickets);
    assert!(maximum_envelope<=max.combined_bytes);
    assert!(execution_header<=max.state_bytes);assert!(report.usage.reservations.peak_tickets<=86);
    assert_eq!(owner.control.as_ref().unwrap().budget(),max);
    let mut owned=Some(owner);let mut cleanup=Some(SwiftReactorInstance::cleanup_owned(&mut owned));
    let tail=cleanup.take().unwrap().unwrap();let mut failure=None;let mut usage=None;
    tail.complete((owned,cleanup),&mut failure,&mut usage);
    let final_usage=usage.unwrap();assert_eq!(final_usage.reservations.combined.current,0);assert_eq!(final_usage.reservations.live_tickets,0);assert!(failure.is_none());
    println!("PLAN_PROFILE cleanup_zero=true guest_instructions=0 initializes=0 invokes=0");
}

#[test]
fn full_regression_observe_cache_fixture_shapes() {
    let bytes = fixture(0, &[0, 0x0b], 100);
    let (mut c, a) = adopt(&bytes, SwiftRunBudget::default());
    let (cache, stats) = measure(|| construct(&mut c, a, None).unwrap());
    println!(
        "REGRESSION_CACHE stats={stats:?} header={} fixed={} work={}",
        cache_header_bytes().unwrap(),
        c.usage(None).reservations.cache.current,
        c.usage(None).cache_work
    );
    assert_eq!(stats.reallocations, 0);
    finish(cache, c);
}

// Test-only external telemetry. No guest instantiation or full target execution.
use std::cell::RefCell;
use std::fmt::Write as _;
const ATTR_BITS: usize = 80_000;
const ATTR_WORDS: usize = 1_250;
const ATTR_OUTPUT: usize = 4_096;
const ATTR_RANGE: u32 = 1;
const ATTR_OVERFLOW: u32 = 2;
const ATTR_CONTEXT: u32 = 4;
const ATTR_OUTPUT_OVERFLOW: u32 = 8;
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct AttributionRejection {
    site: usize, requested: u64, cursor_function: Option<u32>, cursor_offset: Option<usize>,
    kind: SwiftRunFailureKind, resource: Option<SwiftRunResource>,
    function: Option<u32>, offset: Option<usize>, attempted: u64, limit: u64,
}
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
struct AttributionTotals {
    credits: [u64;16], calls: [u64;16], plans: [u64;4],
    completed: u64, distinct: u64, repeated: u64,
    scan_credits: [u64;2], scan_calls: [u64;2], scan_published: [u64;2],
    build_credits: [u64;2], build_calls: [u64;2],
}
struct CurrentAttribution {
    seen: [u64;ATTR_WORDS], totals: AttributionTotals, rejected: Option<AttributionRejection>,
    site: usize, function: Option<u32>, repeated: bool, invalid: u32,
}
impl Default for CurrentAttribution {
    fn default() -> Self { Self { seen:[0;ATTR_WORDS], totals:AttributionTotals::default(), rejected:None,
        site:0, function:None, repeated:false, invalid:0 } }
}
fn attr_add(value: &mut u64, n: u64, invalid: &mut u32) {
    if let Some(next)=value.checked_add(n) { *value=next; } else { *invalid |= ATTR_OVERFLOW; }
}
impl CurrentAttribution {
    fn begin(&mut self, function: u32) {
        self.function=Some(function);
        if (function as usize) < ATTR_BITS {
            self.repeated = self.seen[function as usize / 64] & (1u64 << (function as usize % 64)) != 0;
        } else { self.invalid |= ATTR_RANGE; self.repeated=false; }
    }
    fn site(&mut self, site: u8) { if site<16 {self.site=site as usize;} else {self.invalid |= ATTR_CONTEXT;} }
    fn event(&mut self, event: u8) {
        if event>=4 {self.invalid |= ATTR_CONTEXT;return;}
        attr_add(&mut self.totals.plans[event as usize],1,&mut self.invalid);
        if event==2 && !self.repeated {self.invalid |= ATTR_CONTEXT;}
        if event==3 {attr_add(&mut self.totals.scan_published[self.repeated as usize],1,&mut self.invalid);}
    }
    fn completed(&mut self, function: u32) {
        if self.function!=Some(function) {self.invalid |= ATTR_CONTEXT;}
        attr_add(&mut self.totals.completed,1,&mut self.invalid);
        if (function as usize)>=ATTR_BITS {self.invalid |= ATTR_RANGE;return;}
        let word=&mut self.seen[function as usize/64];let bit=1u64 << (function as usize%64);
        if *word & bit == 0 {attr_add(&mut self.totals.distinct,1,&mut self.invalid);}
        else {attr_add(&mut self.totals.repeated,1,&mut self.invalid);}
        *word |= bit; // Only called after original usage.decoded publication.
    }
    fn work(&mut self, n:u64, cursor:Cursor, error:Option<&SwiftRunFailure>) {
        if let Some(e)=error {
            if self.rejected.is_none() {self.rejected=Some(AttributionRejection{site:self.site,requested:n,
                cursor_function:cursor.function,cursor_offset:cursor.offset,kind:e.kind,resource:e.resource,
                function:e.function,offset:e.offset,attempted:e.attempted,limit:e.limit});}
            return; // Never include a rejected requested debit.
        }
        attr_add(&mut self.totals.credits[self.site],n,&mut self.invalid);
        attr_add(&mut self.totals.calls[self.site],1,&mut self.invalid);
        let part=self.repeated as usize;
        if self.site==6 || self.site==13 {
            if self.function!=cursor.function {self.invalid |= ATTR_CONTEXT;}
            let (credits,calls)=if self.site==6 {(&mut self.totals.scan_credits,&mut self.totals.scan_calls)}
                else {(&mut self.totals.build_credits,&mut self.totals.build_calls)};
            attr_add(&mut credits[part],n,&mut self.invalid);attr_add(&mut calls[part],1,&mut self.invalid);
        }
    }
}
thread_local! { static CURRENT_ATTRIBUTION: RefCell<CurrentAttribution> = RefCell::new(CurrentAttribution::default()); }
pub(super) fn remaining_plan_begin(f:u32) { CURRENT_ATTRIBUTION.with(|x| x.borrow_mut().begin(f)); }
pub(super) fn remaining_plan_site(s:u8) { CURRENT_ATTRIBUTION.with(|x| x.borrow_mut().site(s)); }
pub(super) fn remaining_plan_event(e:u8) { CURRENT_ATTRIBUTION.with(|x| x.borrow_mut().event(e)); }
pub(super) fn remaining_plan_completed(f:u32) { CURRENT_ATTRIBUTION.with(|x| x.borrow_mut().completed(f)); }
pub(super) fn remaining_plan_work(n:u64,c:Cursor,e:Option<&SwiftRunFailure>) { CURRENT_ATTRIBUTION.with(|x| x.borrow_mut().work(n,c,e)); }
fn attr_reset() {CURRENT_ATTRIBUTION.with(|x| *x.borrow_mut()=CurrentAttribution::default());}
fn attr_totals() -> AttributionTotals {CURRENT_ATTRIBUTION.with(|x|x.borrow().totals)}
fn attr_check(c:&RuntimeControl,cache:&SwiftFunctionCache) {
    CURRENT_ATTRIBUTION.with(|x|{let x=x.borrow();assert_eq!(x.invalid,0);
        let t=x.totals;assert_eq!(t.credits.iter().sum::<u64>(),c.usage(None).cache_work);
        assert_eq!(t.completed,cache.usage().decodes);assert_eq!(t.distinct+t.repeated,t.completed);
        assert_eq!(t.scan_credits.iter().sum::<u64>(),t.credits[6]);assert_eq!(t.scan_calls.iter().sum::<u64>(),t.calls[6]);
        assert_eq!(t.build_credits.iter().sum::<u64>(),t.credits[13]);assert_eq!(t.build_calls.iter().sum::<u64>(),t.calls[13]);
        assert_eq!(t.scan_published.iter().sum::<u64>(),t.plans[3]);
        assert_eq!(x.seen.iter().map(|w|w.count_ones() as u64).sum::<u64>(),t.distinct);
    });
}
fn attr_diff(t:AttributionTotals,b:AttributionTotals)->AttributionTotals {
    let mut d=t;
    for i in 0..16 {d.credits[i]-=b.credits[i];d.calls[i]-=b.calls[i];}
    for i in 0..4 {d.plans[i]-=b.plans[i];}
    d.completed-=b.completed;d.distinct-=b.distinct;d.repeated-=b.repeated;
    for i in 0..2 {d.scan_credits[i]-=b.scan_credits[i];d.scan_calls[i]-=b.scan_calls[i];d.scan_published[i]-=b.scan_published[i];d.build_credits[i]-=b.build_credits[i];d.build_calls[i]-=b.build_calls[i];}d
}
struct AttributionText {bytes:[u8;ATTR_OUTPUT],len:usize,limit:usize}
impl AttributionText {fn new(limit:usize)->Self {Self{bytes:[0;ATTR_OUTPUT],len:0,limit:limit.min(ATTR_OUTPUT)}}}
impl std::fmt::Write for AttributionText {
    fn write_str(&mut self,s:&str)->std::fmt::Result {
        let end=self.len.checked_add(s.len()).filter(|n|*n<=self.limit).ok_or(std::fmt::Error)?;
        self.bytes[self.len..end].copy_from_slice(s.as_bytes());self.len=end;Ok(())
    }
}
fn attr_format(x:&mut CurrentAttribution,out:&mut AttributionText)->bool {
    let t=x.totals;
    let result=(|| -> std::fmt::Result {
        write!(out,"{{\"invalid\":{},\"credits\":{:?},\"calls\":{:?},\"plans\":{:?},\"completed\":{},\"distinct\":{},\"repeated\":{},\"scan_credits\":{:?},\"scan_calls\":{:?},\"scan_published\":{:?},\"build_credits\":{:?},\"build_calls\":{:?},\"first_rejection\":",x.invalid,t.credits,t.calls,t.plans,t.completed,t.distinct,t.repeated,t.scan_credits,t.scan_calls,t.scan_published,t.build_credits,t.build_calls)?;
        if let Some(r)=x.rejected {
            write!(out,"{{\"site\":{},\"requested\":{},\"cursor_function\":{},\"cursor_offset\":{},\"kind\":\"{:?}\",\"resource\":\"{:?}\",\"function\":{},\"offset\":{},\"attempted\":{},\"limit\":{}}}",r.site,r.requested,r.cursor_function.map(u64::from).unwrap_or(u64::MAX),r.cursor_offset.map(|v|v as u64).unwrap_or(u64::MAX),r.kind,r.resource,r.function.map(u64::from).unwrap_or(u64::MAX),r.offset.map(|v|v as u64).unwrap_or(u64::MAX),r.attempted,r.limit)?;
        } else {out.write_str("null")?;}
        out.write_str("}")
    })();
    if result.is_err() {x.invalid |= ATTR_OUTPUT_OVERFLOW;false} else {true}
}
fn attr_emit(label:&str,c:&RuntimeControl,cache:&SwiftFunctionCache,before:AttributionTotals)->u64 {
    attr_check(c,cache);let d=attr_diff(attr_totals(),before);let work=d.credits.iter().sum::<u64>();
    // Fixed labels are finite fixture metadata, never guest data. The reusable snapshot formatter below has no label.
    println!("ATTR_CASE {{\"case\":\"{label}\",\"work\":{work},\"credits\":{:?},\"calls\":{:?},\"plans\":{:?},\"completed\":{},\"distinct\":{},\"repeated\":{},\"scan_credits\":{:?},\"scan_calls\":{:?},\"scan_published\":{:?},\"build_credits\":{:?},\"build_calls\":{:?},\"hits\":{},\"misses\":{},\"decodes\":{},\"evictions\":{}}}",d.credits,d.calls,d.plans,d.completed,d.distinct,d.repeated,d.scan_credits,d.scan_calls,d.scan_published,d.build_credits,d.build_calls,cache.usage().hits,cache.usage().misses,cache.usage().decodes,cache.usage().evictions);
    work
}
fn attr_one(cache:&mut SwiftFunctionCache,c:&mut RuntimeControl,f:u32) {
    let p=pin(cache,c,f,None).unwrap();cache.release(p,c,None).map_err(|e|e.failure).unwrap();attr_check(c,cache);
}
fn attr_finish(cache:SwiftFunctionCache,mut c:RuntimeControl) {
    if CURRENT_ATTRIBUTION.with(|x|x.borrow().invalid)==0 {attr_check(&c,&cache);}
    let work=c.usage(None).cache_work;
    let _=cleanup(cache,&mut c,None);let u=c.finish_owned_cleanup(None);
    assert_eq!(u.cache_work,work);assert_eq!(u.cleanup_invariant,None);
    assert_eq!(u.reservations.combined.current,0);assert_eq!(u.reservations.live_tickets,0);
    for r in [u.reservations.retained_source,u.reservations.retained_metadata,u.reservations.cache,u.reservations.state,u.reservations.wasi,u.reservations.shared,u.reservations.construction] {assert_eq!(r.current,0);}
    for r in [u.live.active_pins,u.live.cache_entries,u.live.frames,u.live.values,u.live.controls,u.live.memory_pages] {assert_eq!(r.current,0);}
    if CURRENT_ATTRIBUTION.with(|x|x.borrow().invalid)==0 {assert_eq!(attr_totals().credits.iter().sum::<u64>(),u.cache_work);}
}
#[test]
fn current_attribution_actual_cache_finite() {
    use crate::experimental::cache::{Operation,ControlKind};
    for (label,helper) in [("flat_cold",vec![0,0x0b]),("nested_cold",body(0,&[2,0x40,3,0x40,1,0x0b,0x0b,0x41,0,4,0x40,1,5,1,0x0b,0x0b]))] {
        hooks(Hooks::default());attr_reset();let bytes=fixture(0,&helper,600);let (mut c,mut cache)=new(&bytes,SwiftRunBudget::default());
        assert_eq!(c.usage(None).cache_work,4928);attr_emit("constructor",&c,&cache,AttributionTotals::default());let before=attr_totals();
        let p=pin(&mut cache,&mut c,34,None).unwrap();let v=cache.view(&p,&mut c,None).unwrap();
        if label=="flat_cold" {assert_eq!(v.instructions.len(),1);assert_eq!(v.instructions[0].operation,Operation::End);}
        else {assert_eq!(v.instructions.len(),12);assert_eq!(v.instructions[0].operation,Operation::Block{kind:ControlKind::Block,result:None,end:4,alternative:None});assert_eq!(v.instructions[1].operation,Operation::Block{kind:ControlKind::Loop,result:None,end:3,alternative:None});assert_eq!(v.instructions[6].operation,Operation::Block{kind:ControlKind::If,result:None,end:10,alternative:Some(8)});assert_eq!(v.instructions[8].operation,Operation::Else{end:10});}
        cache.release(p,&mut c,None).map_err(|e|e.failure).unwrap();assert_eq!(attr_emit(label,&c,&cache,before),if label=="flat_cold"{164}else{245});
        let before=attr_totals();attr_one(&mut cache,&mut c,34);assert_eq!(attr_emit("resident_hit_free_0",&c,&cache,before),8);
        let mut held=Vec::new();for _ in 0..63 {held.push(pin(&mut cache,&mut c,34,None).unwrap());}
        let before=attr_totals();attr_one(&mut cache,&mut c,34);assert_eq!(attr_emit("resident_hit_free_63",&c,&cache,before),71);
        for p in held {cache.release(p,&mut c,None).map_err(|e|e.failure).unwrap();}attr_finish(cache,c);
    }
    for count in [64,65] {
        hooks(Hooks::default());attr_reset();let bytes=fixture(0,&[0,0x0b],600);let (mut c,mut cache)=new(&bytes,SwiftRunBudget::default());let before=attr_totals();
        for _ in 0..2 {for f in 34..34+count {attr_one(&mut cache,&mut c,f);}}
        let t=attr_totals();assert_eq!(t.distinct,count as u64);assert_eq!(t.repeated,if count==65{65}else{0});
        assert_eq!(t.plans,[count as u64,0,if count==65{65}else{0},count as u64]);
        assert_eq!(attr_emit(if count==64{"64_cycle_twice"}else{"65_cycle_twice"},&c,&cache,before),if count==64{11015}else{25629});attr_finish(cache,c);
    }
    hooks(Hooks::default());attr_reset();let bytes=fixture(0,&[0,0x0b],600);let (mut c,mut cache)=new(&bytes,SwiftRunBudget::default());
    attr_one(&mut cache,&mut c,34);for f in 35..99 {attr_one(&mut cache,&mut c,f);}
    let before=attr_totals();attr_one(&mut cache,&mut c,34);let d=attr_diff(attr_totals(),before);assert_eq!(d.plans,[0,0,1,0]);assert_eq!(d.repeated,1);assert_eq!(d.scan_credits,[0,0]);assert_eq!(d.build_credits,[0,5]);attr_emit("evicted_IR_plan_hit",&c,&cache,before);
    let before=attr_totals();attr_one(&mut cache,&mut c,546);let d=attr_diff(attr_totals(),before);assert_eq!(d.plans,[0,1,0,1]);assert_eq!(d.distinct,1);assert_eq!(d.scan_credits,[4,0]);attr_emit("plan_conflict_546",&c,&cache,before);
    for f in 99..163 {attr_one(&mut cache,&mut c,f);}
    let before=attr_totals();attr_one(&mut cache,&mut c,34);let d=attr_diff(attr_totals(),before);assert_eq!(d.plans,[0,1,0,1]);assert_eq!(d.repeated,1);assert_eq!(d.scan_credits,[0,4]);assert_eq!(d.scan_published,[0,1]);assert_eq!(d.build_credits,[0,5]);attr_emit("plan_conflict_34",&c,&cache,before);attr_finish(cache,c);
    println!("ATTR_CONTROL original_observations=13 guest_instructions=0 initializes=0 invokes=0 cleanup_zero=true");
}
#[test]
fn current_attribution_prefixes_finite() {
    use super::cache::plan_inspection as pi;
    let mut work_prefixes=0;let mut cancellation_prefixes=0;
    let mut evidence=[false;6];
    for (helper,total,scan,build) in [(vec![0,0x0b],164,4,5),(body(0,&[2,0x40,3,0x40,1,0x0b,0x0b,0x41,0,4,0x40,1,5,1,0x0b,0x0b]),245,37,53)] {
        let bytes=fixture(0,&helper,600);
        for shorter in 0..total {
            hooks(Hooks::default());attr_reset();let (mut c,mut cache)=new(&bytes,SwiftRunBudget{cache_work:4928+shorter,..SwiftRunBudget::default()});
            let f=pin(&mut cache,&mut c,34,None).unwrap_err();assert_eq!(f.kind,SwiftRunFailureKind::WorkExhausted);assert_eq!(f.resource,Some(SwiftRunResource::CacheWork));assert_eq!(f.code,"swift_run_work");assert_eq!(f.function,Some(34));assert_eq!(f.limit,4928+shorter);assert!(f.attempted>f.limit);
            attr_check(&c,&cache);let t=attr_totals();assert_eq!(t.completed,0);assert_eq!(t.distinct,0);assert_eq!(t.repeated,0);
            let first=CURRENT_ATTRIBUTION.with(|x|x.borrow().rejected.unwrap());
            assert_eq!((first.kind,first.resource,first.function,first.offset,first.attempted,first.limit),(f.kind,f.resource,f.function,f.offset,f.attempted,f.limit));
            assert_eq!((first.cursor_function,first.cursor_offset),(f.function,f.offset));assert_eq!(f.attempted,c.usage(None).cache_work+first.requested);
            assert_eq!(pi::key(&cache,34),if t.plans[3]==1{Some(34)}else{None});
            if t.credits[6]>0 && t.credits[6]<scan {evidence[0]=true;assert_eq!(t.plans[3],0);}
            if first.site==7 {evidence[1]=true;assert_eq!(t.credits[6],scan);assert_eq!(t.plans[3],0);}
            if t.plans[3]==1 && t.credits[13]==0 {evidence[2]=true;}
            if t.credits[13]>0 && t.credits[13]<build {evidence[3]=true;assert_eq!(t.scan_published,[1,0]);}
            if first.site==14 {evidence[4]=true;assert_eq!(t.credits[13],build);}
            let stopped=c.usage(None).cache_work;let second=pin(&mut cache,&mut c,35,None).unwrap_err();plan_reuse_primary(f,second);
            assert_eq!(c.usage(None).cache_work,stopped);assert_eq!(CURRENT_ATTRIBUTION.with(|x|x.borrow().rejected.unwrap()),first);
            attr_finish(cache,c);work_prefixes+=1;
        }
        hooks(Hooks::default());attr_reset();let (mut c,mut cache)=new(&bytes,SwiftRunBudget::default());hooks(Hooks::default());
        let p=pin(&mut cache,&mut c,34,None).unwrap();let checks=HOOKS.with(|h|h.get().checks);
        cache.release(p,&mut c,None).map_err(|e|e.failure).unwrap();attr_check(&c,&cache);
        c.cancellation().cancel();let f=pin(&mut cache,&mut c,35,None).unwrap_err();assert_eq!(f.kind,SwiftRunFailureKind::Cancelled);assert_eq!(attr_totals().completed,1);evidence[5]=true;attr_finish(cache,c);
        for ordinal in 0..checks {
            hooks(Hooks::default());attr_reset();let (mut c,mut cache)=new(&bytes,SwiftRunBudget::default());hooks(Hooks{cancel:Some(ordinal),..Hooks::default()});
            let f=pin(&mut cache,&mut c,34,None).unwrap_err();hooks(Hooks::default());assert_eq!(f.kind,SwiftRunFailureKind::Cancelled);attr_check(&c,&cache);
            let t=attr_totals();assert_eq!(t.completed,0);assert_eq!(t.distinct,0);assert_eq!(pi::key(&cache,34),if t.plans[3]==1{Some(34)}else{None});
            let first=CURRENT_ATTRIBUTION.with(|x|x.borrow().rejected);
            if let Some(r)=first {assert_eq!(r.kind,f.kind);assert_eq!(r.resource,f.resource);assert_eq!(r.attempted,f.attempted);assert_eq!(r.limit,f.limit);}
            let work=c.usage(None).cache_work;plan_reuse_primary(f,pin(&mut cache,&mut c,35,None).unwrap_err());assert_eq!(c.usage(None).cache_work,work);
            assert_eq!(CURRENT_ATTRIBUTION.with(|x|x.borrow().rejected),first);attr_finish(cache,c);cancellation_prefixes+=1;
        }
    }
    assert_eq!(evidence,[true;6]);
    println!("ATTR_PREFIX {{\"work_prefixes\":{work_prefixes},\"cancellation_prefixes\":{cancellation_prefixes},\"partial_scan\":true,\"rejected_plan_publication\":true,\"after_scan_publication\":true,\"partial_build\":true,\"resident_insert_rejection\":true,\"after_completion_cancelled\":true,\"sticky_failure_preserved\":true,\"cleanup_zero\":true}}");
}
#[test]
fn current_attribution_boundaries_and_invalid_finite() {
    let cursor=Cursor{stage:SwiftRunStage::Cache,function:Some(0),offset:Some(0)};
    let mut x=CurrentAttribution::default();
    for f in [0,79999] {let before=x.totals.completed;x.begin(f);assert!(!x.repeated);x.site(6);x.work(3,Cursor{function:Some(f),..cursor},None);assert_eq!(x.totals.completed,before);x.completed(f);x.begin(f);assert!(x.repeated);x.site(13);x.work(5,Cursor{function:Some(f),..cursor},None);x.completed(f);}
    assert_eq!((x.totals.distinct,x.totals.repeated,x.totals.completed),(2,2,4));assert_eq!(x.totals.scan_credits,[6,0]);assert_eq!(x.totals.build_credits,[0,10]);assert_eq!(x.invalid,0);
    for f in 0..ATTR_BITS as u32 {x.begin(f);x.completed(f);}assert_eq!(x.totals.distinct,80000);assert!(x.seen.iter().all(|v|*v==u64::MAX));
    x.begin(80000);x.completed(80000);assert_eq!(x.invalid,ATTR_RANGE);assert_eq!(x.totals.distinct,80000);assert!(x.seen.iter().all(|v|*v==u64::MAX));
    // The unchanged validator admits at most 79,966 defined functions: last absolute index 79,999.
    // It rejects the next defined function before cache use. Test external telemetry
    // invalidation separately, then prove it cannot reject an otherwise valid operation.
    let rejected=fixture(0,&[0,0x0b],79967);
    let failure=match validate_swift_reactor(&rejected,SwiftValidationBudget::default(),&Cancellation::default()) {Err(f)=>f,Ok(_)=>panic!("original validator must reject the extra function")};
    assert_eq!(failure.code,"profile_vector_limit");assert_eq!((failure.attempted,failure.limit),(79967,79966));
    let bytes=fixture(0,&[0,0x0b],79966);
    hooks(Hooks::default());attr_reset();let (mut c,mut cache)=new(&bytes,SwiftRunBudget::default());
    for f in [79999,34] {if f==34 {remaining_plan_begin(80000);}let p=pin(&mut cache,&mut c,f,None).unwrap();cache.release(p,&mut c,None).map_err(|e|e.failure).unwrap();}
    assert_eq!(cache.usage().decodes,2);assert_eq!(cache.usage().misses,2);
    CURRENT_ATTRIBUTION.with(|x|{let x=x.borrow();assert_eq!(x.invalid,ATTR_RANGE);assert_eq!(x.totals.completed,2);assert_eq!(x.totals.distinct,2);assert_eq!(x.totals.credits.iter().sum::<u64>(),c.usage(None).cache_work);});attr_finish(cache,c);
    // Overflow is diagnostic invalidity, with the same original success/failure.
    let bytes=fixture(0,&[0,0x0b],600);
    for budget in [SwiftRunBudget::default(),SwiftRunBudget{cache_work:5088,..SwiftRunBudget::default()}] {
        let mut primary=None;
        for poison in [0,1,2] {
            hooks(Hooks::default());attr_reset();let (mut c,mut cache)=new(&bytes,budget);
            if poison==1 {CURRENT_ATTRIBUTION.with(|x|{let mut x=x.borrow_mut();x.totals.credits[13]=u64::MAX;x.totals.calls[13]=u64::MAX;x.totals.scan_published[0]=u64::MAX;});}
            if poison==2 {CURRENT_ATTRIBUTION.with(|x|{let mut x=x.borrow_mut();let mut out=AttributionText::new(64);assert!(!attr_format(&mut x,&mut out));});}
            match pin(&mut cache,&mut c,34,None) {
                Ok(p)=>{assert_eq!(c.usage(None).cache_work,5092);assert_eq!(cache.usage().decodes,1);cache.release(p,&mut c,None).map_err(|e|e.failure).unwrap();},
                Err(f)=>{if let Some(previous)=primary {plan_reuse_primary(previous,f);}else{primary=Some(f);}assert_eq!(f.resource,Some(SwiftRunResource::CacheWork));assert_eq!(cache.usage().decodes,0);},
            }
            if poison==1 {assert!(CURRENT_ATTRIBUTION.with(|x|x.borrow().invalid)&ATTR_OVERFLOW!=0);}else if poison==2 {assert_eq!(CURRENT_ATTRIBUTION.with(|x|x.borrow().invalid),ATTR_OUTPUT_OVERFLOW);}else{attr_check(&c,&cache);}
            attr_finish(cache,c);
        }
    }
    // Full reset is for a fresh isolated cache lifetime only.
    for _ in 0..2 {hooks(Hooks::default());attr_reset();let (mut c,mut cache)=new(&bytes,SwiftRunBudget::default());attr_one(&mut cache,&mut c,34);let t=attr_totals();assert_eq!((t.completed,t.distinct,t.repeated),(1,1,0));assert_eq!(t.scan_credits,[4,0]);attr_finish(cache,c);}
    println!("ATTR_BOUNDARY {{\"bitmap_bits\":80000,\"bitmap_bytes\":10000,\"full_bitmap_checked\":true,\"upper_actual_cache_index\":79999,\"index_80000_original_validator_rejected\":true,\"out_of_range_invalidates_only_observer\":true,\"overflow_preserves_original_results\":true,\"fresh_lifetime_resets\":2,\"cleanup_zero\":true}}");
}
#[test]
fn current_attribution_layout_and_output_finite() {
    let mut x=CurrentAttribution::default();let mut out=AttributionText::new(ATTR_OUTPUT);
    assert!(attr_format(&mut x,&mut out));let ordinary_len=out.len;
    x.totals=AttributionTotals{credits:[u64::MAX;16],calls:[u64::MAX;16],plans:[u64::MAX;4],completed:u64::MAX,distinct:u64::MAX,repeated:u64::MAX,scan_credits:[u64::MAX;2],scan_calls:[u64::MAX;2],scan_published:[u64::MAX;2],build_credits:[u64::MAX;2],build_calls:[u64::MAX;2]};x.invalid=u32::MAX;
    x.rejected=Some(AttributionRejection{site:usize::MAX,requested:u64::MAX,cursor_function:None,cursor_offset:None,kind:SwiftRunFailureKind::UnsupportedEnvironment,resource:Some(SwiftRunResource::Reservation(SwiftReservationCategory::RetainedMetadata)),function:None,offset:None,attempted:u64::MAX,limit:u64::MAX});
    let mut max=AttributionText::new(ATTR_OUTPUT);assert!(attr_format(&mut x,&mut max));assert!(max.len<=ATTR_OUTPUT);let max_len=max.len;
    println!("ATTR_MAX_SNAPSHOT {}",std::str::from_utf8(&max.bytes[..max.len]).unwrap());
    let mut short=AttributionText::new(64);x.invalid=0;assert!(!attr_format(&mut x,&mut short));assert_eq!(x.invalid,ATTR_OUTPUT_OVERFLOW);assert!(short.len<=64);
    x=CurrentAttribution::default();x.totals.completed=u64::MAX;x.totals.distinct=u64::MAX;x.begin(1);x.completed(1);assert!(x.invalid&ATTR_OVERFLOW!=0);x.totals.plans[0]=u64::MAX;x.event(0);assert!(x.invalid&ATTR_OVERFLOW!=0);
    x=CurrentAttribution::default();x.site(255);x.event(255);assert_eq!(x.invalid,ATTR_CONTEXT);
    println!("ATTR_LAYOUT {{\"observer_bytes\":{},\"observer_alignment\":{},\"bitmap_bytes\":{},\"totals_bytes\":{},\"rejection_option_bytes\":{},\"formatter_bytes\":{},\"output_capacity\":{},\"ordinary_snapshot_bytes\":{ordinary_len},\"max_snapshot_bytes\":{max_len},\"output_overflow_invalidates\":true,\"external_test_only\":true}}",size_of::<CurrentAttribution>(),std::mem::align_of::<CurrentAttribution>(),size_of::<[u64;ATTR_WORDS]>(),size_of::<AttributionTotals>(),size_of::<Option<AttributionRejection>>(),size_of::<AttributionText>(),ATTR_OUTPUT);
}
