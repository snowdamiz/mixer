//! Private bounded construction of an uninitialized Swift reactor owner.
//! No initialize, invoke, or interpreter algorithm is provided.
#![allow(dead_code)] // The constructor remains private, with no activation route.
#![allow(clippy::result_large_err)]

use super::cache::{
    CacheCleanupTail, CacheConstructionFailure, CacheConstructionPhase, CacheControl,
    CacheOperationPhase, SwiftFunctionCache, SwiftFunctionPin, SwiftReleaseFailure,
};
use super::control::*;
use crate::experimental::cache::{DecodedInstruction, FunctionView, Operation};
use crate::experimental::descriptors::{
    FunctionSpanView, GlobalView, MemoryExecutionView, SegmentExecutionView, SignatureView,
    TableExecutionView,
};
use crate::experimental::execution::{borrowed::*, Control};
use crate::experimental_wasi::{
    accounted::{AccountedWasi, WasiConstructionPhase},
    WasiBudget, WasiGrants, WasiUsage,
};
use crate::{Type, Value};
use std::mem::{size_of, take};
use std::time::Instant;

#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct SwiftMode;
impl sealed::Mode for SwiftMode {}
impl ExecutionMode for SwiftMode {
    type Cache = SwiftFunctionCache;
    type Pin = SwiftFunctionPin;
    type Frame = SwiftFrame;
    type Operation<'a> = SwiftExecutionOperation<'a>;
    type Failure = SwiftRunFailure;
}

#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct SwiftFrame {
    pub function: u32,
    pub pc: usize,
    pub base: usize,
    pub operands: usize,
    pub controls: usize,
    pub result: bool,
    pub pin: SwiftFunctionPin,
}
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct SwiftExecutionState {
    pub memory: Vec<u8>,
    pub table: Vec<Option<u32>>,
    pub globals: Vec<Value>,
    pub values: Vec<Value>,
    pub controls: Vec<Control>,
    pub frames: Vec<SwiftFrame>,
    pub buffers: [Option<ReservationTicket>; 6],
    pub execution_header: Option<ReservationTicket>,
}
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) enum Lifecycle {
    Uninitialized,
    Ready,
    Terminal,
}
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct SwiftReactorInstance {
    pub control: Option<RuntimeControl>,
    pub cache: Option<SwiftFunctionCache>,
    pub wasi: Option<AccountedWasi>,
    pub state: Option<SwiftExecutionState>,
    pub lifecycle: Lifecycle,
}
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct SwiftExecutionOperation<'a> {
    pub control: &'a mut RuntimeControl,
    pub wasi: &'a mut AccountedWasi,
    pub cursor: Cursor,
}
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct ExecutionConstructionPhase<'a> {
    pub control: &'a mut RuntimeControl,
    pub cache: &'a SwiftFunctionCache,
    pub wasi: &'a AccountedWasi,
    pub cursor: Cursor,
    pub previous_bound: usize,
    pub constructed: bool,
}
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct ExecutionOperationPhase<'a> {
    pub parts: ExecutionParts<'a, SwiftMode>,
    pub operation: SwiftExecutionOperation<'a>,
    pub previous_bound: usize,
}
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct PartialState {
    pub state: SwiftExecutionState,
    pub next_arena: usize,
}
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct PartialInstance {
    pub control: Option<RuntimeControl>,
    pub cache: Option<SwiftFunctionCache>,
    pub wasi: Option<AccountedWasi>,
    pub state: Option<SwiftExecutionState>,
}
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct EntryGuard {
    pub pin: Option<SwiftFunctionPin>,
    pub values_debited: usize,
    pub controls_debited: usize,
    pub frame_debited: bool,
}
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct ScalarReader<'a> {
    pub bytes: &'a [u8],
    pub at: usize,
    pub absolute_offset: usize,
}
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct SelectedInstruction {
    pub instruction: DecodedInstruction,
    pub branch_target: Option<u32>,
    pub cursor: Cursor,
}
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct GrowthTransfer {
    pub replacement: Vec<u8>,
    pub ticket: Option<ReservationTicket>,
    pub old: Vec<u8>,
    pub old_ticket: Option<ReservationTicket>,
    pub old_pages: u32,
    pub next_pages: u32,
    pub copied: usize,
}

#[must_use = "The same execution header remains charged until completion consumes all returned storage"]
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct ExecutionCleanupTail {
    pub control: RuntimeControl,
    pub header: Option<ReservationTicket>,
    pub final_wasi: Option<WasiUsage>,
    pub failure: Option<SwiftRunFailure>,
}
/// This is the only selected representation at the final header boundary.
/// The function frame owning all large return/Option/tail storage ends first.
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct HeaderCompletionParts {
    pub control: RuntimeControl,
    pub header: Option<ReservationTicket>,
    pub final_wasi: Option<WasiUsage>,
}
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
fn drop_cleanup_return_storage<T>(tail: ExecutionCleanupTail, storage: T) -> HeaderCompletionParts {
    let ExecutionCleanupTail {
        control,
        header,
        final_wasi,
        failure,
    } = tail;
    drop((storage, failure));
    HeaderCompletionParts {
        control,
        header,
        final_wasi,
    }
}
impl ExecutionCleanupTail {
    /// Cleanup helper only. There is no route that creates a runnable owner.
    #[allow(dead_code)] // Final cleanup helper pending disjoint foundation boundary review.
    pub(crate) fn complete<T>(
        self,
        storage: T,
        outcome: &mut Option<SwiftRunFailure>,
        usage: &mut Option<SwiftRunUsage>,
    ) {
        let HeaderCompletionParts {
            mut control,
            mut header,
            final_wasi,
        } = drop_cleanup_return_storage(self, storage);
        if let Some(ticket) = header.take() {
            // This temporary result ends before record_cleanup/finish below.
            let _ = control.drop_reserved_with_wasi((), ticket, final_wasi);
        }
        *outcome = control.record_cleanup(final_wasi);
        *usage = Some(control.finish_owned_cleanup(final_wasi));
    }
}

/// Compiles the strict-shorter cache reborrow without changing the operation.
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) fn with_cache_operation<R>(
    phase: &mut ExecutionOperationPhase<'_>,
    body: impl for<'short> FnOnce(
        &mut ExecutionParts<'short, SwiftMode>,
        &mut SwiftExecutionOperation<'short>,
    ) -> R,
) -> R {
    let parts = &mut phase.parts;
    let operation = &mut phase.operation;
    let mut short_parts = ExecutionParts {
        cache: &mut *parts.cache,
        memory: &mut *parts.memory,
        table: &mut *parts.table,
        globals: &mut *parts.globals,
        values: &mut *parts.values,
        controls: &mut *parts.controls,
        frames: &mut *parts.frames,
    };
    let mut short_operation = SwiftExecutionOperation {
        control: &mut *operation.control,
        wasi: &mut *operation.wasi,
        cursor: operation.cursor,
    };
    body(&mut short_parts, &mut short_operation)
}

/// Named rows are additional objects, never bytes borrowed from another owner.
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct LayoutTerm {
    pub phase: &'static str,
    pub binding: &'static str,
    pub shape: &'static str,
    pub count: usize,
    pub bytes: usize,
}
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) const fn terms() -> &'static [LayoutTerm] {
    macro_rules! row {
        ($p:literal,$b:literal,$n:expr,$t:ty) => {
            LayoutTerm {
                phase: $p,
                binding: $b,
                shape: stringify!($t),
                count: $n,
                bytes: size_of::<$t>(),
            }
        };
    }
    &[
        row!(
            "construction",
            "state source/return/caller",
            3,
            SwiftExecutionState
        ),
        row!(
            "construction",
            "instance source/return/caller",
            3,
            SwiftReactorInstance
        ),
        row!(
            "construction",
            "partial state source/return/caller",
            3,
            PartialState
        ),
        row!(
            "construction",
            "partial instance source/return/caller",
            3,
            PartialInstance
        ),
        row!(
            "construction",
            "state return plus caller slot",
            2,
            Option<Result<SwiftExecutionState, SwiftRunFailure>>
        ),
        row!(
            "construction",
            "instance return plus caller slot",
            2,
            Option<Result<SwiftReactorInstance, SwiftRunFailure>>
        ),
        row!(
            "construction",
            "cache return plus caller slot",
            2,
            Option<Result<SwiftFunctionCache, CacheConstructionFailure>>
        ),
        row!(
            "construction",
            "wasi return plus caller slot",
            2,
            Option<Result<AccountedWasi, SwiftRunFailure>>
        ),
        row!(
            "construction",
            "state preparation source/return/caller",
            3,
            ExecutionConstructionPhase<'static>
        ),
        row!(
            "construction",
            "cache preparation source/return/caller",
            3,
            CacheConstructionPhase<'static>
        ),
        row!(
            "construction",
            "wasi preparation source/return/caller",
            3,
            WasiConstructionPhase<'static>
        ),
        row!(
            "construction",
            "segment/initializer reader",
            3,
            ScalarReader<'static>
        ),
        row!(
            "construction",
            "descriptor and return",
            2,
            Option<FunctionSpanView<'static>>
        ),
        row!(
            "operation",
            "phase source/return/caller",
            3,
            ExecutionOperationPhase<'static>
        ),
        row!(
            "operation",
            "short parts + helper argument",
            2,
            ExecutionParts<'static, SwiftMode>
        ),
        row!(
            "operation",
            "short operation + helper argument",
            2,
            SwiftExecutionOperation<'static>
        ),
        row!(
            "operation",
            "cache phase source/return/caller",
            3,
            CacheOperationPhase<'static>
        ),
        row!(
            "operation",
            "owned entry guard source/return/caller",
            3,
            EntryGuard
        ),
        row!("operation", "frame source/push/return", 3, SwiftFrame),
        row!(
            "operation",
            "selected instruction source/return/caller",
            3,
            SelectedInstruction
        ),
        row!(
            "operation",
            "selected target source/return/caller",
            3,
            Option<u32>
        ),
        row!(
            "operation",
            "view result/caller",
            2,
            Result<FunctionView<'static>, SwiftRunFailure>
        ),
        row!(
            "operation",
            "pin result/caller slot",
            2,
            Option<Result<SwiftFunctionPin, SwiftRunFailure>>
        ),
        row!("operation","release result/caller",2,Result<(),SwiftReleaseFailure>),
        row!(
            "operation",
            "full structural signature pair",
            2,
            SignatureView<'static>
        ),
        row!(
            "operation",
            "return value source/return/caller",
            3,
            Result<Option<Value>, SwiftRunFailure>
        ),
        row!(
            "growth",
            "old/new vector and ticket transfer source/return/caller",
            3,
            GrowthTransfer
        ),
        row!(
            "growth",
            "allocate result/caller",
            2,
            Result<Vec<u8>, SwiftRunFailure>
        ),
        row!("growth","reserve result/caller",2,Result<ReservationTicket,SwiftRunFailure>),
        row!(
            "cleanup",
            "whole owner caller slot",
            1,
            Option<SwiftReactorInstance>
        ),
        row!(
            "cleanup",
            "taken owner and helper transfer",
            2,
            SwiftReactorInstance
        ),
        row!(
            "cleanup",
            "state source/argument transfer",
            2,
            SwiftExecutionState
        ),
        row!(
            "cleanup",
            "tail source/return/caller",
            3,
            ExecutionCleanupTail
        ),
        row!(
            "cleanup",
            "tail result and caller slot",
            2,
            Option<Result<ExecutionCleanupTail, SwiftRunFailure>>
        ),
        row!(
            "cleanup",
            "cache slot source/argument",
            2,
            Option<SwiftFunctionCache>
        ),
        row!(
            "cleanup",
            "cache tail result and caller slot",
            2,
            Option<Result<CacheCleanupTail<'static>, SwiftRunFailure>>
        ),
        row!(
            "cleanup",
            "cache outcome held by executor",
            1,
            Option<SwiftRunFailure>
        ),
        row!("cleanup", "wasi source/argument", 2, AccountedWasi),
        row!("cleanup","wasi released/accumulator/and-input/and-output",4,Result<(),SwiftRunFailure>),
        row!(
            "cleanup",
            "executor outcome held across component drains",
            1,
            Option<SwiftRunFailure>
        ),
        row!(
            "cleanup",
            "external final observation plus copied drain argument",
            2,
            Option<WasiUsage>
        ),
        row!("cleanup", "frame drain source/argument", 2, SwiftFrame),
        row!("cleanup","owned pin plus release rejected wrapper",2,Result<(),SwiftReleaseFailure>),
        row!("cleanup", "state vector source/argument", 2, Vec<Value>),
        row!(
            "cleanup",
            "state ticket source/argument",
            2,
            Option<ReservationTicket>
        ),
        row!(
            "construction",
            "scalar/borrow source/argument/return inventories",
            3,
            ScalarBorrowInventory
        ),
        row!(
            "construction",
            "caller failure/usage outside foundation",
            2,
            CallerDiagnostics
        ),
        row!(
            "operation",
            "scalar/borrow source/argument/return inventories",
            3,
            ScalarBorrowInventory
        ),
        row!(
            "operation",
            "caller failure/usage outside foundation",
            2,
            CallerDiagnostics
        ),
        row!(
            "growth",
            "scalar/borrow source/argument/return inventories",
            3,
            ScalarBorrowInventory
        ),
        row!(
            "growth",
            "caller failure/usage outside foundation",
            2,
            CallerDiagnostics
        ),
        row!(
            "cleanup",
            "scalar/borrow source/argument/return inventories",
            3,
            ScalarBorrowInventory
        ),
        row!(
            "cleanup",
            "caller failure/usage outside foundation",
            2,
            CallerDiagnostics
        ),
    ]
}
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct ScalarBorrowInventory {
    pub control: &'static mut RuntimeControl,
    pub cache: &'static mut SwiftFunctionCache,
    pub wasi: &'static mut AccountedWasi,
    pub state: &'static mut SwiftExecutionState,
    pub phase: &'static mut ExecutionOperationPhase<'static>,
    pub pin: &'static SwiftFunctionPin,
    pub view: FunctionView<'static>,
    pub initializer: ScalarReader<'static>,
    pub signature: SignatureView<'static>,
    pub values: &'static [Value],
    pub memory: &'static mut [u8],
    pub indices: std::ops::Range<usize>,
    pub cursor: Cursor,
    pub fault: Fault,
    pub capacity: usize,
    pub requested: usize,
    pub observed: usize,
    pub index: usize,
    pub length: usize,
    pub base: usize,
    pub operands: usize,
    pub controls: usize,
    pub frame_count: usize,
    pub value_count: usize,
    pub control_count: usize,
    pub destination: usize,
    pub source: usize,
    pub end: usize,
    pub chunk_end: usize,
    pub copied: usize,
    pub absolute_function: u32,
    pub type_index: u32,
    pub table_index: u32,
    pub branch_depth: u32,
    pub old_pages: u32,
    pub next_pages: u32,
    pub delta_pages: u32,
    pub opcode: u32,
    pub value: Option<Value>,
    pub selected: Operation,
    pub reserve_error: Option<std::collections::TryReserveError>,
}
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) struct CallerDiagnostics {
    pub failure: Option<SwiftRunFailure>,
    pub usage: Option<SwiftRunUsage>,
    pub observation: Option<WasiUsage>,
}
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) fn phase_bytes(phase: &str) -> Option<usize> {
    terms()
        .iter()
        .filter(|r| r.phase == phase)
        .try_fold(0usize, |sum, r| {
            sum.checked_add(r.count.checked_mul(r.bytes)?)
        })
}
const fn named_bytes(phase: &str) -> Option<usize> {
    let rows = terms();
    let mut total = 0usize;
    let mut index = 0;
    while index < rows.len() {
        let a = rows[index].phase.as_bytes();
        let b = phase.as_bytes();
        let mut same = a.len() == b.len();
        let mut at = 0;
        while same && at < a.len() {
            same = a[at] == b[at];
            at += 1;
        }
        if same {
            let Some(bytes) = rows[index].count.checked_mul(rows[index].bytes) else {
                return None;
            };
            let Some(next) = total.checked_add(bytes) else {
                return None;
            };
            total = next;
        }
        index += 1;
    }
    Some(total)
}
/// No negative subtraction; count nested payload once and every Option tag or
/// containing alignment byte in the exclusive residual. Arena payloads have
/// their separate six tickets; all additional cleanup rows use this same header.
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) fn execution_header_bytes() -> Option<usize> {
    EXECUTION_HEADER_BYTES
}
const EXECUTION_HEADER_BYTES: Option<usize> = {
    let nested = size_of::<RuntimeControl>()
        + size_of::<SwiftFunctionCache>()
        + size_of::<AccountedWasi>()
        + size_of::<SwiftExecutionState>();
    match (
        size_of::<SwiftReactorInstance>().checked_sub(nested),
        named_bytes("cleanup"),
    ) {
        (Some(residual), Some(cleanup)) => {
            match residual.checked_add(size_of::<SwiftExecutionState>()) {
                Some(header) => match header.checked_add(cleanup) {
                    Some(header) => header.checked_add(size_of::<CleanupPreflightInventory>()),
                    None => None,
                },
                None => None,
            }
        }
        _ => None,
    }
};

/// Pure checked arena formula; this does not admit, allocate or instantiate.
#[allow(dead_code)] // Chosen private type/layout prerequisite; no executable owner route yet.
pub(crate) fn arena_bytes(
    values: usize,
    controls: usize,
    frames: usize,
    pages: usize,
    table: usize,
    globals: usize,
) -> Option<[usize; 6]> {
    Some([
        values.checked_mul(size_of::<Value>())?,
        controls.checked_mul(size_of::<Control>())?,
        frames.checked_mul(size_of::<SwiftFrame>())?,
        pages.checked_mul(65536)?,
        table.checked_mul(size_of::<Option<u32>>())?,
        globals.checked_mul(size_of::<Value>())?,
    ])
}

const PAGE: usize = 65_536;
const CHUNK: usize = 4_096;

/// Newly named roles, disjoint from the eight original maps. These inventory
/// types are never instantiated; their layouts reserve requested object bytes,
/// not physical stack or allocator overhead. Each repeated position accounts
/// source/argument/return independently, without borrowing containing padding.
struct ConstructionDescriptors {
    memory: Option<MemoryExecutionView>,
    table: Option<TableExecutionView>,
    global: Option<GlobalView<'static>>,
    segment: Option<SegmentExecutionView<'static>>,
    initializer_offset: Option<usize>,
    capacities: [usize; 6],
    requests: Option<[usize; 6]>,
    budget: SwiftRunBudget,
    target_type: Type,
    opcode: u8,
    byte: u8,
    bits: u64,
    shift: u32,
    width: u32,
    signed: i64,
    float32: [u8; 4],
    float64: [u8; 8],
}
struct ConstructionTransfers {
    pair: Option<(RuntimeControl, AdoptedProof)>,
    owned_slot: &'static mut Option<(RuntimeControl, AdoptedProof)>,
    grants: WasiGrants,
    wasi_budget: WasiBudget,
    started: Instant,
    state_phase: Result<ExecutionConstructionPhase<'static>, SwiftRunFailure>,
    cache_phase: Result<CacheConstructionPhase<'static>, SwiftRunFailure>,
    wasi_phase: Result<WasiConstructionPhase<'static>, SwiftRunFailure>,
    reserve: Result<ReservationTicket, SwiftRunFailure>,
    allocate: Result<Vec<Value>, SwiftRunFailure>,
    initialized: Result<(), SwiftRunFailure>,
    constant: Result<Value, SwiftRunFailure>,
    scalar: Result<u64, SwiftRunFailure>,
    end: Option<usize>,
}
/// Names only execution-owned call/borrow/scalar roles. The nested runtime
/// control paths have their separately declared bootstrap dependency below.
struct ConstructionBorrowChain {
    control: [&'static mut RuntimeControl; 6],
    state: [&'static mut SwiftExecutionState; 3],
    cache: [&'static SwiftFunctionCache; 4],
    wasi: [&'static AccountedWasi; 6],
    phase: [&'static mut ExecutionConstructionPhase<'static>; 3],
    reader: [&'static mut ScalarReader<'static>; 3],
    vector: [&'static mut Vec<Value>; 2],
    slice: [&'static [u8]; 4],
    mutable_slice: [&'static mut [u8]; 2],
    index: [usize; 12],
    cursor: [Cursor; 4],
    observation: [Option<WasiUsage>; 2],
    fault: [Fault; 2],
}
struct ConstructionIterationInventory {
    global_range: std::ops::Range<usize>,
    table_range: std::ops::Range<u32>,
    descriptor_range: std::ops::Range<usize>,
    element_range: std::ops::Range<usize>,
    leb_range: std::ops::Range<u32>,
    leb_steps: std::iter::StepBy<std::ops::Range<u32>>,
    float_iter: std::slice::IterMut<'static, u8>,
    float_item: Option<&'static mut u8>,
    descriptor_item: Option<usize>,
    table_item: Option<u32>,
    borrowed_segment: SegmentExecutionView<'static>,
    borrowed_global: GlobalView<'static>,
    typed_result: Result<Value, SwiftRunFailure>,
    signed_result: Result<i64, SwiftRunFailure>,
    unsigned_result: Result<u32, SwiftRunFailure>,
    byte_result: Result<u8, SwiftRunFailure>,
    error: Option<std::collections::TryReserveError>,
    error_callback: (
        &'static mut ExecutionConstructionPhase<'static>,
        &'static usize,
    ),
    descriptor_callback: &'static mut ExecutionConstructionPhase<'static>,
    reader_callback: (
        &'static ScalarReader<'static>,
        &'static mut RuntimeControl,
        &'static AccountedWasi,
        &'static Cursor,
    ),
}
struct CleanupPreflightInventory {
    owner_option: Option<&'static mut SwiftReactorInstance>,
    owner: &'static mut SwiftReactorInstance,
    control_option: Option<&'static mut RuntimeControl>,
    control: &'static mut RuntimeControl,
    wasi_option: Option<&'static AccountedWasi>,
    wasi: &'static AccountedWasi,
    cache_option: Option<&'static SwiftFunctionCache>,
    cache: &'static SwiftFunctionCache,
    state_option: Option<&'static SwiftExecutionState>,
    state: &'static SwiftExecutionState,
    header_option: Option<&'static ReservationTicket>,
    header: &'static ReservationTicket,
    buffer_iter: std::slice::Iter<'static, Option<ReservationTicket>>,
    buffer_item: Option<&'static Option<ReservationTicket>>,
    buffer: &'static Option<ReservationTicket>,
    buffer_ticket: Option<&'static ReservationTicket>,
    cache_usage: super::cache::SwiftCacheUsage,
    cursor_arguments: [Cursor; 2],
    header_error_callback: (&'static mut RuntimeControl, &'static AccountedWasi),
    buffer_error_callback: (&'static mut RuntimeControl, &'static AccountedWasi),
    nonempty: [bool; 4],
}
/// This group must be charged by the foundation before a caller enters either
/// constructor/preparation. The later enlarged phase cannot retroactively cover
/// its own inputs and provenance/admission call chain. Whole groups are a
/// conservative maximum; diagnostic/fault transfers already named by foundation
/// retain those classes and are not reused as smaller borrow slots here.
pub(super) struct ConstructionBootstrapInventory {
    pair_slot: [&'static mut Option<(RuntimeControl, AdoptedProof)>; 2],
    control: [&'static mut RuntimeControl; 8],
    adopted: [&'static AdoptedProof; 3],
    cache: [&'static SwiftFunctionCache; 4],
    wasi: [&'static AccountedWasi; 4],
    cursor: [Cursor; 5],
    grants: [WasiGrants; 3],
    budget: [WasiBudget; 3],
    started: [Instant; 3],
    cache_control: CacheControl<'static>,
    header_option: [Option<&'static ReservationTicket>; 3],
    header: [&'static ReservationTicket; 5],
    observation: [Option<WasiUsage>; 3],
    snapshot_return: [SwiftRunUsage; 2],
    previous_bound: [usize; 4],
    checked_bound: [Option<usize>; 2],
    owner_verdict: [Option<(SwiftCleanupInvariant, &'static str)>; 2],
    ticket_option: Option<&'static ReservationTicket>,
    current: usize,
    requested: usize,
    difference: usize,
    category_next: usize,
    combined_next: usize,
    checked_category: Option<usize>,
    checked_combined: Option<usize>,
    category: SwiftReservationCategory,
    category_usage: &'static SwiftReservationUsage,
    category_mut: &'static mut SwiftReservationUsage,
    reservations: &'static mut SwiftReservations,
    construction_ticket: Option<&'static mut ReservationTicket>,
}
pub(super) const CONSTRUCTION_BOOTSTRAP_BYTES: usize = size_of::<ConstructionBootstrapInventory>();
#[cfg(test)]
pub(super) fn print_construction_layouts() {
    println!("construction bootstrap {}", CONSTRUCTION_BOOTSTRAP_BYTES);
    println!(
        "construction descriptors {}",
        size_of::<ConstructionDescriptors>()
    );
    println!(
        "construction transfers {}",
        size_of::<ConstructionTransfers>()
    );
    println!(
        "construction borrows {}",
        size_of::<ConstructionBorrowChain>()
    );
    println!("construction total {}", construction_bytes().unwrap());
    println!(
        "construction iterations {}",
        size_of::<ConstructionIterationInventory>()
    );
}
const CONSTRUCTION_BYTES: Option<usize> = match named_bytes("construction") {
    Some(base) => match base.checked_add(3 * size_of::<ConstructionDescriptors>()) {
        Some(n) => match n.checked_add(3 * size_of::<ConstructionTransfers>()) {
            Some(n) => match n.checked_add(size_of::<ConstructionBorrowChain>()) {
                Some(n) => n.checked_add(3 * size_of::<ConstructionIterationInventory>()),
                None => None,
            },
            None => None,
        },
        None => None,
    },
    None => None,
};
pub(crate) fn construction_bytes() -> Option<usize> {
    CONSTRUCTION_BYTES
}

fn construction_failure(
    control: &mut RuntimeControl,
    wasi: &AccountedWasi,
    cursor: Cursor,
    kind: SwiftRunFailureKind,
    code: &'static str,
) -> SwiftRunFailure {
    control.fail(cursor, Fault::new(kind, code), Some(wasi.usage()))
}
fn layout_failure(
    control: &mut RuntimeControl,
    wasi: &AccountedWasi,
    cursor: Cursor,
) -> SwiftRunFailure {
    construction_failure(
        control,
        wasi,
        cursor,
        SwiftRunFailureKind::Invariant,
        "swift_execution_layout_overflow",
    )
}
fn checked(
    control: &mut RuntimeControl,
    wasi: &AccountedWasi,
    cursor: Cursor,
) -> Result<(), SwiftRunFailure> {
    #[cfg(test)]
    super::execution_tests::construction_checkpoint(control, cursor);
    control.check_with_wasi(cursor, Some(wasi.usage()))
}
fn work(
    control: &mut RuntimeControl,
    wasi: &AccountedWasi,
    cursor: Cursor,
    credits: usize,
) -> Result<(), SwiftRunFailure> {
    checked(control, wasi, cursor)?;
    control.work_with_wasi(Work::Execution, credits as u64, cursor, Some(wasi.usage()))
}
impl SwiftExecutionState {
    pub(crate) fn prepare<'a>(
        control: &'a mut RuntimeControl,
        cache: &'a SwiftFunctionCache,
        wasi: &'a AccountedWasi,
        cursor: Cursor,
    ) -> Result<ExecutionConstructionPhase<'a>, SwiftRunFailure> {
        // The actual WASI pair wins over cache/ordinary checks. No owner moves.
        wasi.checked_usage(control, cursor)?;
        cache.check_owner(control, Some(wasi), cursor)?;
        checked(control, wasi, cursor)?;
        if cache.usage().active_pins != 0 {
            return Err(construction_failure(
                control,
                wasi,
                cursor,
                SwiftRunFailureKind::Invariant,
                "swift_execution_preexisting_pins",
            ));
        }
        let previous_bound = control
            .usage(Some(wasi.usage()))
            .reservations
            .construction
            .current;
        let bound = construction_bytes()
            .and_then(|n| previous_bound.checked_add(n))
            .ok_or_else(|| layout_failure(control, wasi, cursor))?;
        control.enlarge_construction_with_wasi(bound, cursor, Some(wasi.usage()))?;
        Ok(ExecutionConstructionPhase {
            control,
            cache,
            wasi,
            cursor,
            previous_bound,
            constructed: false,
        })
    }
    fn empty() -> Self {
        Self {
            memory: Vec::new(),
            table: Vec::new(),
            globals: Vec::new(),
            values: Vec::new(),
            controls: Vec::new(),
            frames: Vec::new(),
            buffers: std::array::from_fn(|_| None),
            execution_header: None,
        }
    }
    /// Only this constructor's unpublished State is accepted. Its last fallible
    /// action is the page debit, so every failure here has zero State live counts.
    fn cleanup_unpublished(mut self, control: &mut RuntimeControl, wasi: &AccountedWasi) {
        self.drop_arenas(control, wasi);
        if let Some(header) = self.execution_header.take() {
            let _ = control.drop_reserved_with_wasi(self, header, Some(wasi.usage()));
        }
    }
    fn drop_arenas(&mut self, control: &mut RuntimeControl, wasi: &AccountedWasi) {
        macro_rules! release {
            ($field:ident, $index:literal) => {{
                if let Some(ticket) = self.buffers[$index].take() {
                    let _ = control.drop_reserved_with_wasi(
                        take(&mut self.$field),
                        ticket,
                        Some(wasi.usage()),
                    );
                } else {
                    drop(take(&mut self.$field));
                }
            }};
        }
        release!(values, 0);
        release!(controls, 1);
        release!(frames, 2);
        release!(memory, 3);
        release!(table, 4);
        release!(globals, 5);
    }
}
impl ExecutionConstructionPhase<'_> {
    pub(crate) fn construct(&mut self) -> Result<SwiftExecutionState, SwiftRunFailure> {
        if std::mem::replace(&mut self.constructed, true) {
            return Err(construction_failure(
                self.control,
                self.wasi,
                self.cursor,
                SwiftRunFailureKind::Invariant,
                "swift_execution_construct_once",
            ));
        }
        let mut partial = PartialState {
            state: SwiftExecutionState::empty(),
            next_arena: 0,
        };
        match self.construct_partial(&mut partial) {
            Ok(()) => Ok(partial.state),
            Err(failure) => {
                partial.state.cleanup_unpublished(self.control, self.wasi);
                Err(failure)
            }
        }
    }
    fn construct_partial(&mut self, partial: &mut PartialState) -> Result<(), SwiftRunFailure> {
        checked(self.control, self.wasi, self.cursor)?;
        let budget = self.control.budget();
        let memory = self
            .cache
            .proof()
            .execution_memory()
            .ok_or_else(|| layout_failure(self.control, self.wasi, self.cursor))?;
        if memory.minimum > budget.memory_pages {
            let mut fault = Fault::new(
                SwiftRunFailureKind::ResourceExhausted,
                "swift_execution_memory_minimum",
            );
            fault.resource = Some(SwiftRunResource::MemoryPages);
            fault.attempted = memory.minimum as u64;
            fault.limit = budget.memory_pages as u64;
            return Err(self
                .control
                .fail(self.cursor, fault, Some(self.wasi.usage())));
        }
        let table = self
            .cache
            .proof()
            .execution_table()
            .ok_or_else(|| layout_failure(self.control, self.wasi, self.cursor))?;
        let globals = self.cache.proof().execution_global_count();
        let requests = arena_bytes(
            budget.values,
            budget.controls,
            budget.frames,
            memory.minimum as usize,
            table.minimum as usize,
            globals,
        )
        .ok_or_else(|| layout_failure(self.control, self.wasi, self.cursor))?;
        let header = execution_header_bytes()
            .ok_or_else(|| layout_failure(self.control, self.wasi, self.cursor))?;
        partial.state.execution_header = Some(self.control.admit_with_wasi(
            SwiftReservationCategory::State,
            header,
            self.cursor,
            Some(self.wasi.usage()),
        )?);
        macro_rules! arena {
            ($field:ident, $index:literal, $capacity:expr) => {{
                partial.state.buffers[$index] = Some(self.control.admit_with_wasi(
                    SwiftReservationCategory::State,
                    requests[$index],
                    self.cursor,
                    Some(self.wasi.usage()),
                )?);
                self.reserve(&mut partial.state.$field, $capacity)?;
                partial.next_arena += 1;
            }};
        }
        arena!(values, 0, budget.values);
        arena!(controls, 1, budget.controls);
        arena!(frames, 2, budget.frames);
        arena!(memory, 3, requests[3]);
        arena!(table, 4, table.minimum as usize);
        arena!(globals, 5, globals);
        let credits = requests[3]
            .checked_add(table.minimum as usize)
            .and_then(|n| n.checked_add(globals))
            .ok_or_else(|| layout_failure(self.control, self.wasi, self.cursor))?;
        work(self.control, self.wasi, self.cursor, credits)?;
        while partial.state.memory.len() < requests[3] {
            checked(self.control, self.wasi, self.cursor)?;
            let end = (partial.state.memory.len() + CHUNK).min(requests[3]);
            partial.state.memory.resize(end, 0);
        }
        for _ in 0..table.minimum {
            checked(self.control, self.wasi, self.cursor)?;
            partial.state.table.push(None);
        }
        for index in 0..globals {
            work(self.control, self.wasi, self.cursor, 16)?;
            let global = self
                .cache
                .proof()
                .execution_global(index)
                .ok_or_else(|| layout_failure(self.control, self.wasi, self.cursor))?;
            let offset = self
                .cache
                .proof()
                .execution_global_initializer_offset(index)
                .ok_or_else(|| layout_failure(self.control, self.wasi, self.cursor))?;
            let mut reader = ScalarReader {
                bytes: global.initializer,
                at: 0,
                absolute_offset: offset,
            };
            let value = reader.constant(global.ty, self.control, self.wasi, self.cursor)?;
            partial.state.globals.push(value);
        }
        self.initialize_segments(&mut partial.state)?;
        // Last fallible operation. No publication check/effect follows a failure.
        self.control.add_live_with_wasi(
            Live::MemoryPages,
            memory.minimum as usize,
            self.cursor,
            Some(self.wasi.usage()),
        )
    }
    fn reserve<T>(&mut self, values: &mut Vec<T>, requested: usize) -> Result<(), SwiftRunFailure> {
        checked(self.control, self.wasi, self.cursor)?;
        values.try_reserve_exact(requested).map_err(|_| {
            let mut fault = Fault::new(
                SwiftRunFailureKind::Allocation,
                "swift_execution_allocation",
            );
            fault.attempted = requested as u64;
            self.control
                .fail(self.cursor, fault, Some(self.wasi.usage()))
        })?;
        #[cfg(test)]
        let observed = super::execution_tests::construction_capacity(values.capacity());
        #[cfg(not(test))]
        let observed = values.capacity();
        self.control.exact_capacity_with_wasi(
            requested,
            observed,
            self.cursor,
            Some(self.wasi.usage()),
        )?;
        checked(self.control, self.wasi, self.cursor)
    }
    fn initialize_segments(
        &mut self,
        state: &mut SwiftExecutionState,
    ) -> Result<(), SwiftRunFailure> {
        // All ranges, in the specified order, precede the first payload effect.
        for index in 0..self.cache.proof().execution_data_count() {
            work(self.control, self.wasi, self.cursor, 1)?;
            let segment = self
                .cache
                .proof()
                .execution_data(index)
                .ok_or_else(|| layout_failure(self.control, self.wasi, self.cursor))?;
            self.range(segment, state.memory.len(), "swift_execution_data_bounds")?;
            if segment.count as usize != segment.encoded_payload.len() {
                return Err(self.segment_failure(segment, "swift_execution_data_count"));
            }
        }
        for index in 0..self.cache.proof().execution_element_count() {
            work(self.control, self.wasi, self.cursor, 1)?;
            let segment = self
                .cache
                .proof()
                .execution_element(index)
                .ok_or_else(|| layout_failure(self.control, self.wasi, self.cursor))?;
            self.range(segment, state.table.len(), "swift_execution_element_bounds")?;
        }
        for index in 0..self.cache.proof().execution_data_count() {
            let segment = self
                .cache
                .proof()
                .execution_data(index)
                .ok_or_else(|| layout_failure(self.control, self.wasi, self.cursor))?;
            work(
                self.control,
                self.wasi,
                self.cursor,
                segment.encoded_payload.len(),
            )?;
            let mut copied = 0;
            while copied < segment.encoded_payload.len() {
                let cursor = Cursor {
                    offset: Some(segment.payload_offset + copied),
                    ..self.cursor
                };
                checked(self.control, self.wasi, cursor)?;
                let end = (copied + CHUNK).min(segment.encoded_payload.len());
                let destination = segment.destination as usize + copied;
                state.memory[destination..destination + end - copied]
                    .copy_from_slice(&segment.encoded_payload[copied..end]);
                copied = end;
            }
            checked(
                self.control,
                self.wasi,
                Cursor {
                    offset: Some(segment.payload_offset + copied),
                    ..self.cursor
                },
            )?;
        }
        for index in 0..self.cache.proof().execution_element_count() {
            let segment = self
                .cache
                .proof()
                .execution_element(index)
                .ok_or_else(|| layout_failure(self.control, self.wasi, self.cursor))?;
            work(
                self.control,
                self.wasi,
                self.cursor,
                segment.encoded_payload.len(),
            )?;
            let mut reader = ScalarReader {
                bytes: segment.encoded_payload,
                at: 0,
                absolute_offset: segment.payload_offset,
            };
            for slot in 0..segment.count as usize {
                let function = reader.unsigned(self.control, self.wasi, self.cursor)?;
                if self.cache.proof().execution_signature(function).is_none() {
                    return Err(reader.failure(
                        self.control,
                        self.wasi,
                        self.cursor,
                        "swift_execution_element_function",
                    ));
                }
                state.table[segment.destination as usize + slot] = Some(function);
            }
            reader.end(self.control, self.wasi, self.cursor)?;
        }
        checked(self.control, self.wasi, self.cursor)
    }
    fn range(
        &mut self,
        segment: SegmentExecutionView<'_>,
        length: usize,
        code: &'static str,
    ) -> Result<(), SwiftRunFailure> {
        if (segment.destination as usize)
            .checked_add(segment.count as usize)
            .is_none_or(|end| end > length)
        {
            return Err(self.segment_failure(segment, code));
        }
        Ok(())
    }
    fn segment_failure(
        &mut self,
        segment: SegmentExecutionView<'_>,
        code: &'static str,
    ) -> SwiftRunFailure {
        construction_failure(
            self.control,
            self.wasi,
            Cursor {
                offset: Some(segment.payload_offset),
                ..self.cursor
            },
            SwiftRunFailureKind::GuestTrap,
            code,
        )
    }
    pub(crate) fn complete<T>(self, returned_phase_storage: T) -> Result<(), SwiftRunFailure> {
        let Self {
            control,
            wasi,
            previous_bound,
            ..
        } = self;
        control.end_construction_phase_with_wasi(
            returned_phase_storage,
            previous_bound,
            Some(wasi.usage()),
        )
    }
}

impl ScalarReader<'_> {
    fn failure(
        &self,
        control: &mut RuntimeControl,
        wasi: &AccountedWasi,
        cursor: Cursor,
        code: &'static str,
    ) -> SwiftRunFailure {
        construction_failure(
            control,
            wasi,
            Cursor {
                offset: Some(self.absolute_offset + self.at),
                ..cursor
            },
            SwiftRunFailureKind::Invariant,
            code,
        )
    }
    fn byte(
        &mut self,
        control: &mut RuntimeControl,
        wasi: &AccountedWasi,
        cursor: Cursor,
    ) -> Result<u8, SwiftRunFailure> {
        checked(
            control,
            wasi,
            Cursor {
                offset: Some(self.absolute_offset + self.at),
                ..cursor
            },
        )?;
        let byte = self
            .bytes
            .get(self.at)
            .copied()
            .ok_or_else(|| self.failure(control, wasi, cursor, "swift_execution_scalar_eof"))?;
        self.at += 1;
        Ok(byte)
    }
    fn unsigned(
        &mut self,
        control: &mut RuntimeControl,
        wasi: &AccountedWasi,
        cursor: Cursor,
    ) -> Result<u32, SwiftRunFailure> {
        let mut bits = 0u32;
        for shift in (0..35).step_by(7) {
            let byte = self.byte(control, wasi, cursor)?;
            if shift == 28 && byte & 0xf0 != 0 {
                self.at -= 1;
                return Err(self.failure(control, wasi, cursor, "swift_execution_scalar_u32"));
            }
            bits |= ((byte & 0x7f) as u32) << shift;
            if byte & 0x80 == 0 {
                return Ok(bits);
            }
        }
        Err(self.failure(control, wasi, cursor, "swift_execution_scalar_u32"))
    }
    fn signed(
        &mut self,
        width: u32,
        control: &mut RuntimeControl,
        wasi: &AccountedWasi,
        cursor: Cursor,
    ) -> Result<i64, SwiftRunFailure> {
        let mut bits = 0u64;
        let mut shift = 0;
        loop {
            let byte = self.byte(control, wasi, cursor)?;
            let remaining = width - shift;
            if remaining < 7 {
                let mask = (0x7f_u8 << remaining) & 0x7f;
                let sign = byte & (1 << (remaining - 1)) != 0;
                if byte & 0x80 != 0 || byte & mask != if sign { mask } else { 0 } {
                    self.at -= 1;
                    return Err(self.failure(
                        control,
                        wasi,
                        cursor,
                        "swift_execution_scalar_signed",
                    ));
                }
            }
            bits |= ((byte & 0x7f) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                if shift < 64 && byte & 0x40 != 0 {
                    bits |= u64::MAX << shift;
                }
                return Ok(bits as i64);
            }
        }
    }
    fn constant(
        &mut self,
        ty: Type,
        control: &mut RuntimeControl,
        wasi: &AccountedWasi,
        cursor: Cursor,
    ) -> Result<Value, SwiftRunFailure> {
        let value = match self.byte(control, wasi, cursor)? {
            0x41 => Value::I32(self.signed(32, control, wasi, cursor)? as i32),
            0x42 => Value::I64(self.signed(64, control, wasi, cursor)?),
            0x43 => {
                let mut bytes = [0; 4];
                for byte in &mut bytes {
                    *byte = self.byte(control, wasi, cursor)?;
                }
                Value::F32(u32::from_le_bytes(bytes))
            }
            0x44 => {
                let mut bytes = [0; 8];
                for byte in &mut bytes {
                    *byte = self.byte(control, wasi, cursor)?;
                }
                Value::F64(u64::from_le_bytes(bytes))
            }
            _ => {
                self.at -= 1;
                return Err(self.failure(control, wasi, cursor, "swift_execution_scalar_opcode"));
            }
        };
        if value.ty() != ty {
            self.at = 0;
            return Err(self.failure(control, wasi, cursor, "swift_execution_scalar_type"));
        }
        if self.byte(control, wasi, cursor)? != 0x0b {
            self.at -= 1;
            return Err(self.failure(control, wasi, cursor, "swift_execution_scalar_end"));
        }
        self.end(control, wasi, cursor)?;
        Ok(value)
    }
    fn end(
        &self,
        control: &mut RuntimeControl,
        wasi: &AccountedWasi,
        cursor: Cursor,
    ) -> Result<(), SwiftRunFailure> {
        checked(
            control,
            wasi,
            Cursor {
                offset: Some(self.absolute_offset + self.at),
                ..cursor
            },
        )?;
        if self.at != self.bytes.len() {
            return Err(self.failure(control, wasi, cursor, "swift_execution_scalar_trailing"));
        }
        Ok(())
    }
}
#[cfg(test)]
pub(super) fn scalar_constant_probe(
    bytes: &[u8],
    absolute_offset: usize,
    ty: Type,
    control: &mut RuntimeControl,
    wasi: &AccountedWasi,
) -> Result<Value, SwiftRunFailure> {
    ScalarReader {
        bytes,
        at: 0,
        absolute_offset,
    }
    .constant(
        ty,
        control,
        wasi,
        Cursor {
            stage: SwiftRunStage::Initialization,
            function: None,
            offset: Some(absolute_offset),
        },
    )
}

impl SwiftReactorInstance {
    /// The caller retains exact ownership if bootstrap provenance/admission
    /// rejects. Once taken, any failure destroys every acquired component.
    pub(crate) fn construct(
        owned: &mut Option<(RuntimeControl, AdoptedProof)>,
        grants: WasiGrants,
        wasi_budget: WasiBudget,
        started: Instant,
        cursor: Cursor,
    ) -> Result<Self, SwiftRunFailure> {
        let (control, adopted) = owned
            .as_mut()
            .expect("private constructor requires an adopted owner slot");
        control.check_adopted_owner(adopted, cursor, None)?;
        let previous_bound = control.usage(None).reservations.construction.current;
        let bound = construction_bytes()
            .and_then(|n| previous_bound.checked_add(n))
            .ok_or_else(|| {
                control.fail(
                    cursor,
                    Fault::new(
                        SwiftRunFailureKind::Invariant,
                        "swift_execution_layout_overflow",
                    ),
                    None,
                )
            })?;
        control.enlarge_construction(bound, cursor)?;
        // No owning transfer or partial builder exists before enlargement.
        let (control, adopted) = owned.take().expect("preflight retained adopted owner");
        let mut partial = PartialInstance {
            control: Some(control),
            cache: None,
            wasi: None,
            state: None,
        };
        let result = partial.construct(adopted, grants, wasi_budget, started, cursor);
        if let Err(failure) = result {
            return Err(partial.cleanup_failed(previous_bound, failure));
        }
        let mut instance = Self {
            control: partial.control.take(),
            cache: partial.cache.take(),
            wasi: partial.wasi.take(),
            state: partial.state.take(),
            lifecycle: Lifecycle::Uninitialized,
        };
        // Every partial/ordinary phase has ended before the exact outer restore.
        #[cfg(test)]
        let previous_bound = super::execution_tests::construction_restore_bound(previous_bound);
        if let Err(failure) = instance
            .control
            .as_mut()
            .unwrap()
            .end_construction_phase_with_wasi(
                (partial, result),
                previous_bound,
                instance.wasi.as_ref().map(AccountedWasi::usage),
            )
        {
            // A restore fault changes no component provenance. Keep the owner
            // charged while draining those exact components and return only
            // copied diagnostics. An invalid construction ticket remains charged.
            return Err(Self::cleanup_after_restore_failure(instance, failure));
        }
        Ok(instance)
    }
    fn cleanup_after_restore_failure(instance: Self, failure: SwiftRunFailure) -> SwiftRunFailure {
        let mut owned = Some(instance);
        let mut returned = Some(Self::cleanup_owned(&mut owned));
        let tail = returned
            .take()
            .expect("one cleanup return")
            .expect("restore cannot change component provenance");
        let mut outcome = Some(failure);
        let mut usage = None;
        tail.complete((owned, returned), &mut outcome, &mut usage);
        let mut failure = outcome.unwrap_or(failure);
        failure.after_cleanup = usage;
        failure
    }
    /// Bounded construction cleanup only. Populated interpreter frames and live
    /// values/controls are rejected intact until their separate unwind slice.
    pub(crate) fn cleanup_owned(
        owned: &mut Option<Self>,
    ) -> Result<ExecutionCleanupTail, SwiftRunFailure> {
        {
            let owner = owned
                .as_mut()
                .expect("private cleanup requires an owned slot");
            let control = owner.control.as_mut().expect("owned control");
            let wasi = owner.wasi.as_ref().expect("owned WASI");
            wasi.checked_usage(control, cleanup_cursor())?;
            owner.cache.as_ref().expect("owned cache").check_owner(
                control,
                Some(wasi),
                cleanup_cursor(),
            )?;
            let state = owner.state.as_ref().expect("owned State");
            let header = state.execution_header.as_ref().ok_or_else(|| {
                construction_failure(
                    control,
                    wasi,
                    cleanup_cursor(),
                    SwiftRunFailureKind::Invariant,
                    "swift_execution_missing_header",
                )
            })?;
            control.check_reservation_owner(header, cleanup_cursor(), Some(wasi.usage()))?;
            for ticket in &state.buffers {
                let ticket = ticket.as_ref().ok_or_else(|| {
                    construction_failure(
                        control,
                        wasi,
                        cleanup_cursor(),
                        SwiftRunFailureKind::Invariant,
                        "swift_execution_missing_buffer",
                    )
                })?;
                control.check_reservation_owner(ticket, cleanup_cursor(), Some(wasi.usage()))?;
            }
            if !state.frames.is_empty()
                || !state.values.is_empty()
                || !state.controls.is_empty()
                || owner.cache.as_ref().unwrap().usage().active_pins != 0
            {
                return Err(construction_failure(
                    control,
                    wasi,
                    cleanup_cursor(),
                    SwiftRunFailureKind::Invariant,
                    "swift_execution_cleanup_nonempty",
                ));
            }
        }
        let mut owner = owned.take().expect("all component provenance retained");
        owner.lifecycle = Lifecycle::Terminal;
        let mut control = owner.control.take().unwrap();
        let wasi = owner.wasi.take().unwrap();
        let mut state = owner.state.take().unwrap();
        let pages = state.memory.len() / PAGE;
        state.drop_arenas(&mut control, &wasi);
        let _ = control.remove_live_with_wasi(Live::MemoryPages, pages, Some(wasi.usage()));
        let header = state.execution_header.take();
        // State and its empty Vec handles end while the one header stays live.
        drop(state);
        let mut outcome = None;
        match SwiftFunctionCache::cleanup(&mut owner.cache, &mut control, Some(&wasi)) {
            Ok(tail) => tail.complete(owner.cache.take(), &mut outcome),
            Err(failure) => {
                outcome = Some(failure);
            }
        }
        let final_wasi = Some(wasi.usage());
        let _ = wasi.cleanup(&mut control);
        drop(owner);
        let failure = control.record_cleanup(final_wasi).or(outcome);
        Ok(ExecutionCleanupTail {
            control,
            header,
            final_wasi,
            failure,
        })
    }
}
fn cleanup_cursor() -> Cursor {
    Cursor {
        stage: SwiftRunStage::Cleanup,
        function: None,
        offset: None,
    }
}
impl PartialInstance {
    fn construct(
        &mut self,
        adopted: AdoptedProof,
        grants: WasiGrants,
        wasi_budget: WasiBudget,
        started: Instant,
        cursor: Cursor,
    ) -> Result<(), SwiftRunFailure> {
        let control = self.control.as_mut().unwrap();
        match SwiftFunctionCache::prepare(control, None, &adopted, cursor) {
            Ok(mut phase) => {
                let mut returned = Some(phase.construct(adopted));
                let failure = match returned.take().unwrap() {
                    Ok(cache) => {
                        self.cache = Some(cache);
                        None
                    }
                    Err(error) => {
                        // The same-owner adopted pair passed bootstrap. Repeated
                        // construction is impossible on this fresh local phase.
                        debug_assert!(error.rejected_adopted.is_none());
                        Some(error.failure)
                    }
                };
                phase.complete(returned)?;
                if let Some(failure) = failure {
                    return Err(failure);
                }
            }
            Err(failure) => {
                let _ = control.drop_proof(adopted);
                return Err(failure);
            }
        }
        {
            let mut phase = AccountedWasi::prepare(control, cursor)?;
            let mut returned = Some(phase.construct(grants, wasi_budget, started, cursor));
            let result = returned.take().unwrap();
            match result {
                Ok(wasi) => self.wasi = Some(wasi),
                Err(failure) => {
                    phase.complete()?;
                    return Err(failure);
                }
            }
            phase.complete()?;
        }
        {
            let mut phase = SwiftExecutionState::prepare(
                control,
                self.cache.as_ref().unwrap(),
                self.wasi.as_ref().unwrap(),
                cursor,
            )?;
            let mut returned = Some(phase.construct());
            let failure = match returned.take().unwrap() {
                Ok(state) => {
                    self.state = Some(state);
                    None
                }
                Err(failure) => Some(failure),
            };
            phase.complete(returned)?;
            if let Some(failure) = failure {
                return Err(failure);
            }
        }
        Ok(())
    }
    fn cleanup_failed(
        mut self,
        previous_bound: usize,
        failure: SwiftRunFailure,
    ) -> SwiftRunFailure {
        let mut control = self.control.take().unwrap();
        let mut header = None;
        if let Some(mut state) = self.state.take() {
            let wasi = self.wasi.as_ref().unwrap();
            let pages = state.memory.len() / PAGE;
            state.drop_arenas(&mut control, wasi);
            let _ = control.remove_live_with_wasi(Live::MemoryPages, pages, Some(wasi.usage()));
            header = state.execution_header.take();
            drop(state);
        }
        let mut outcome = None;
        if self.cache.is_some() {
            match SwiftFunctionCache::cleanup(&mut self.cache, &mut control, self.wasi.as_ref()) {
                Ok(tail) => tail.complete(self.cache.take(), &mut outcome),
                Err(error) => {
                    outcome = Some(error);
                }
            }
        }
        let final_wasi = self.wasi.as_ref().map(AccountedWasi::usage);
        if let Some(wasi) = self.wasi.take() {
            let _ = wasi.cleanup(&mut control);
        }
        // End the whole partial helper before final header/foundation completion.
        let _ = control.end_construction_phase_with_wasi(self, previous_bound, final_wasi);
        let tail = ExecutionCleanupTail {
            control,
            header,
            final_wasi,
            failure: outcome,
        };
        let mut outcome = Some(failure);
        let mut usage = None;
        tail.complete((), &mut outcome, &mut usage);
        let mut failure = outcome.unwrap_or(failure);
        failure.after_cleanup = usage;
        failure
    }
}
