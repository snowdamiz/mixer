//! Private bounded bulk-memory execution through the original phase and owners.
#![allow(dead_code, clippy::result_large_err)]
use super::*;
use crate::experimental::execution::CHUNK;

macro_rules! swift_bulk_memory_leaf {
    (pop32 $s:ident) => {$s.memory_pop32()};
    (range $s:ident, $address:expr, $len:expr) => {$s.memory_range($address,$len)};
    (check $s:ident) => {$s.bulk_memory_check()};
    (memory $s:ident) => {$s.phase.parts.memory};
    (charge $s:ident, $credits:expr) => {$s.phase.operation.control.charge_fuel_with_wasi($credits,$s.phase.operation.cursor,Some($s.phase.operation.wasi.usage()))};
    (push $s:ident, $value:expr) => {$s.memory_push_value($value)};
    (pages $s:ident) => {$s.phase.operation.control.usage(Some($s.phase.operation.wasi.usage())).live.memory_pages.current};
}
impl FrameOperationPhase<'_> {
    crate::experimental::execution::borrowed::shared_bulk_memory_methods!(self, SwiftRunFailure, swift_bulk_memory_leaf, bulk_memory_bulk, bulk_memory_copy, bulk_memory_fill);

    fn bulk_memory_check(&mut self) -> Result<(), SwiftRunFailure> {
        #[cfg(test)]
        tests::check_checkpoint(self.phase.operation.control);
        self.phase.operation.control.check_with_wasi(self.phase.operation.cursor,Some(self.phase.operation.wasi.usage()))
    }
    fn bulk_memory_preflight(&mut self, operands: bool) -> Result<(), SwiftRunFailure> {
        let pages = self.phase.operation.control.usage(Some(self.phase.operation.wasi.usage())).live.memory_pages.current;
        if self.phase.parts.memory.len() % PAGE != 0 || pages != self.phase.parts.memory.len() / PAGE {
            return Err(self.invariant("swift_bulk_memory_page_agreement"));
        }
        let frame = match self.phase.parts.frames.last() {
            Some(frame) => frame,
            None => return Err(self.invariant("swift_bulk_memory_frame_missing")),
        };
        let floor = frame.operands;
        if frame.base > floor || frame.controls > self.phase.parts.controls.len() {
            return Err(self.invariant("swift_bulk_memory_frame_floor"));
        }
        let available = match self.phase.parts.values.len().checked_sub(floor) {
            Some(available) => available,
            None => return Err(self.invariant("swift_bulk_memory_operand_floor")),
        };
        if operands {
            if available < 3 { return Err(self.invariant("swift_bulk_memory_operand_count")); }
            let length = self.phase.parts.values.len();
            if self.phase.parts.values[length-3..].iter().any(|value| value.ty()!=crate::Type::I32) {
                return Err(self.invariant("swift_bulk_memory_operand_type"));
            }
        }
        Ok(())
    }
    fn bulk_memory_unsupported(&mut self) -> SwiftRunFailure {
        self.phase.operation.control.fail(self.phase.operation.cursor,Fault::new(SwiftRunFailureKind::UnsupportedEnvironment,"swift_bulk_memory_unsupported_operation"),Some(self.phase.operation.wasi.usage()))
    }
    /// Outer Ok records publication only. Inspect the actual fixed entry slot.
    pub(crate) fn bulk_memory_operation(&mut self, operation: Operation, returned: &mut Option<Result<(),SwiftRunFailure>>) -> Result<(),SwiftRunFailure> {
        if returned.is_some() {
            let failure=self.invariant("swift_bulk_memory_result_occupied");
            self.terminal();
            return Err(failure);
        }
        let result=self.bulk_memory_operation_inner(operation);
        if result.is_err() {self.terminal();}
        *returned=Some(result);
        Ok(())
    }
    fn bulk_memory_operation_inner(&mut self, operation: Operation) -> Result<(),SwiftRunFailure> {
        self.active()?;
        match operation {
            Operation::MemoryCopy => {self.bulk_memory_preflight(true)?;self.bulk_memory_copy()},
            Operation::MemoryFill => {self.bulk_memory_preflight(true)?;self.bulk_memory_fill()},
            Operation::MemorySize => {self.bulk_memory_preflight(false)?;crate::experimental::execution::borrowed::shared_memory_size!(self,swift_bulk_memory_leaf)},
            _ => Err(self.bulk_memory_unsupported()),
        }
    }
}

pub(crate) fn bulk_memory_pinned_caller(phase: &mut FrameOperationPhase<'_>, storage: &mut FrameOperationStorage<'_>) -> Result<(),SwiftRunFailure> {
    if storage.entry.is_some() {
        let failure=phase.invariant("swift_bulk_memory_result_occupied");phase.terminal();return Err(failure);
    }
    let result=bulk_memory_pinned_step(phase);
    if result.is_err(){phase.terminal();}
    storage.entry=Some(result);
    Ok(())
}
fn bulk_memory_pinned_step(phase: &mut FrameOperationPhase<'_>) -> Result<(),SwiftRunFailure> {
    phase.active()?;
    let selected={
        let frame=match phase.phase.parts.frames.last(){Some(frame)=>frame,None=>return Err(phase.invariant("swift_bulk_memory_caller_frame"))};
        let view=phase.phase.parts.cache.view(&frame.pin,phase.phase.operation.control,Some(&*phase.phase.operation.wasi))?;
        let instruction=match view.instructions.get(frame.pc){Some(instruction)=>*instruction,None=>return Err(phase.invariant("swift_bulk_memory_caller_instruction"))};
        (frame.function,instruction)
    };
    let (function,instruction)=selected;
    phase.phase.operation.cursor=Cursor{stage:SwiftRunStage::Invocation,function:Some(function),offset:Some(instruction.offset)};
    match instruction.operation {Operation::MemoryCopy|Operation::MemoryFill|Operation::MemorySize=>{},_=>return Err(phase.bulk_memory_unsupported())}
    phase.phase.operation.control.instruction_with_wasi(phase.phase.operation.cursor,Some(phase.phase.operation.wasi.usage()))?;
    phase.work(1)?;
    #[cfg(test)]
    if tests::PC_OVERFLOW.with(std::cell::Cell::get){phase.phase.parts.frames.last_mut().expect("actual frame").pc=usize::MAX;}
    let pc=match phase.phase.parts.frames.last().and_then(|frame|frame.pc.checked_add(1)){Some(pc)=>pc,None=>return Err(phase.invariant("swift_bulk_memory_caller_pc"))};
    phase.phase.parts.frames.last_mut().expect("active original frame").pc=pc;
    phase.bulk_memory_operation_inner(instruction.operation)
}
#[cfg(test)]
#[path="bulk_memory_operations_tests.rs"]
mod tests;
// ACCOUNTING_START
struct PermanentPositions { placeholder: u8 }
struct ActivePositions { placeholder: u8 }
pub(in crate::experimental_swift_reactor::execution) const PERMANENT_BYTES:usize=size_of::<PermanentPositions>();
pub(super) const ACTIVE_BYTES:usize=size_of::<ActivePositions>();
