# Ordered-retention diagnostic design evidence

Design only; no Rust or target execution is selected. The proposed capped,
baseline-policy stream and pending acceptance gates are in
`docs/swift-ordered-retention-diagnostic-design.md`.

Run the synthetic controls without creating a new receipt:

```sh
python3 -B verification/swift-ordered-retention-diagnostic-design/verify.py
```

`verify.py` rehashes this packet/document and only the 132 named live VM files,
then executes the finite Python codec/state controls. It never imports product
code or prior producer scripts, restores sources, runs Rust/guests/native tests,
scans processes, or writes temporary/build files. Root metadata is historical
context in command receipts and is not required to stay frozen.

`run_checks.py` is the finite receipt producer. Its ordered attempt directories
retain exact selected input hashes, own source hashes, Python tool/platform,
argv/environment, stdout/stderr, exit and unchanged named VM closure. Attempt 1
passes the initial 16 controls; attempt 2 passes 17 after adding the distinction
between slot removal and drop/refund completion. Later receipts bind final
controls. There were no failing synthetic test attempts. Earlier read-only
path-guess errors are preserved in `exploration-failures.json`; that file is an
authored concise record, not a raw reconstructed transcript. Earlier command
hashes do not claim a complete source archive for every intermediate draft.

`codec_model.py` is a finite synthetic model, not the Rust writer/analyzer. Its
footer lifecycle fixture is construction/preconsumption/final-consumption only;
it does not implement full production lifecycle, closed event-specific payloads,
count-plan/work replay, syscall/fault injection or observer memory measurements.
Those remain explicit implementation gates. Its synthetic event lists and
Python dicts are bounded fixture allocations and must not be copied into the
future streaming implementation.

The maximum proposed ordinary stream is 512 MiB plus 1,024 framing bytes; no such
file is generated here. Source-policy/work counts, observer operation bounds,
typed value sizes and physical performance/memory are distinct quantities.
Original CacheWork failure, all three policy rejections, production limits and
full product/GA requirements remain unchanged. No scratch source, compiler,
native instance or capture process was created; no cleanup deletion was needed.
