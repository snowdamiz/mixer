//! Private fixed-target lifecycle over the one original reactor owner.
//! Isolated uncalled candidate: new positions are not yet reservation-authorized.
use super::*;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum Request {
    Initialize,
    Corpus,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum Rejection {
    AlreadyInitialized,
    NotInitialized,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum Reply {
    Initialized,
    Corpus(i32),
}
#[must_use = "Failed completion retains the actual original cleanup authority"]
pub(super) enum Completion<'a> {
    Rejected(Rejection),
    BlockedTerminal,
    PreparationFailed(SwiftRunFailure),
    Completed(Reply),
    Failed {
        failure: Option<SwiftRunFailure>,
        cleanup: GrowthCompletion<'a>,
    },
}

#[derive(Clone, Copy)]
enum Admission {
    Allowed,
    Rejected(Rejection),
    BlockedTerminal,
}
// Ordinary refusals read only lifecycle. No control observation or allocation.
fn precondition(owner: &SwiftReactorInstance, request: Request) -> Admission {
    match (&owner.lifecycle, request) {
        (Lifecycle::Uninitialized, Request::Initialize) | (Lifecycle::Ready, Request::Corpus) => Admission::Allowed,
        (Lifecycle::Ready, Request::Initialize) => Admission::Rejected(Rejection::AlreadyInitialized),
        (Lifecycle::Uninitialized, Request::Corpus) => Admission::Rejected(Rejection::NotInitialized),
        (Lifecycle::Terminal, _) => Admission::BlockedTerminal,
    }
}

pub(super) fn request<'a>(owner: &'a mut SwiftReactorInstance, request: Request) -> Completion<'a> {
    match precondition(owner, request) {
        Admission::Allowed => (),
        Admission::Rejected(rejection) => return Completion::Rejected(rejection),
        Admission::BlockedTerminal => return Completion::BlockedTerminal,
    }
    let (function, stage) = match request {
        Request::Initialize => (35, SwiftRunStage::Initialization),
        Request::Corpus => (62, SwiftRunStage::Invocation),
    };
    let cursor = Cursor { stage, function: Some(function), offset: None };
    let mut preparation = Some(owner.prepare_growth_with_goal(cursor, PreparationGoal::Terminalize));
    let (mut phase, mut context) = match preparation.take().expect("actual preparation result") {
        Ok(prepared) => prepared,
        Err(failure) => {
            // The selected preparation seam has already terminalized the same
            // original lifecycle before constructing any admitted phase borrow.
            return Completion::PreparationFailed(failure);
        }
    };
    let mut pending = SwiftGrowthStorage::empty();
    let mut storage = FrameOperationStorage {
        preparation: None,
        entry: None,
        returned: None,
        drained: None,
        controlled: None,
    };
    let outcome = execute_phase(request, function, cursor, &mut phase, &mut context, &mut pending, &mut storage);
    let goal = match request {
        Request::Initialize => CompletionGoal::Initialize,
        Request::Corpus => CompletionGoal::Preserve,
    };
    // The i32 remains local through the consuming barrier and cannot escape on
    // a retained/restore-rejected branch. No whole-owner access follows prepare.
    #[cfg(test)]
    tests::runtime_before_completion(&mut phase, &mut pending);
    let completed = complete_growth_with_goal(phase, context, pending, storage, preparation, goal);
    match (outcome, completed) {
        (Ok(reply), GrowthCompletion::Completed(FrameCompletion::Completed)) => Completion::Completed(reply),
        (Err(failure), cleanup) => Completion::Failed { failure: Some(failure), cleanup },
        (Ok(_), cleanup) => Completion::Failed { failure: None, cleanup },
    }
}

// This frame ends before consuming completion restores the original admitted
// bound. Its positions are disjoint active additions; caller/retained copies
// in request and consuming completion remain permanently covered.
fn execute_phase<'a>(
    request: Request,
    function: u32,
    cursor: Cursor,
    phase: &mut FrameOperationPhase<'a>,
    context: &mut SwiftGrowthContext<'a>,
    pending: &mut SwiftGrowthStorage,
    storage: &mut FrameOperationStorage<'a>,
) -> Result<Reply, SwiftRunFailure> {
    let entered = phase.enter(function);
    #[allow(unused_mut)]
    let mut execution = match entered {
        Ok(()) => call_dispatch::run(phase, context, pending, storage),
        Err(failure) => Err(failure),
    };
    #[cfg(test)]
    tests::runtime_after_run(phase, storage, &mut execution);
    let mut outcome = match execution {
        Err(failure) => Err(failure),
        Ok(()) => match (request, storage.returned) {
            (_, Some(Err(failure))) => Err(failure),
            (Request::Initialize, Some(Ok(FrameReturn::Outermost(None)))) => Ok(Reply::Initialized),
            (Request::Corpus, Some(Ok(FrameReturn::Outermost(Some(Value::I32(value)))))) => Ok(Reply::Corpus(value)),
            _ => Err(phase.invariant("swift_lifecycle_result_shape")),
        },
    };
    if outcome.is_ok() {
        if matches!(phase.lifecycle, Lifecycle::Terminal) {
            outcome = Err(phase.invariant("swift_lifecycle_terminal_outcome"));
        } else {
            #[cfg(test)]
            tests::runtime_before_final_check(phase);
            // Actual final observation while the original admitted phase exists.
            // This fixed cursor restores the request's lifecycle stage/target.
            outcome = match phase.phase.operation.control.check_with_wasi(
                cursor, Some(phase.phase.operation.wasi.usage()),
            ) {
                Ok(()) => outcome,
                Err(failure) => Err(failure),
            };
        }
    }
    if outcome.is_err() {
        phase.terminal();
    }
    let released = release_growth_pending(phase, context, pending);
    if let Err(failure) = released {
        if outcome.is_ok() {
            outcome = Err(failure);
        }
        phase.terminal();
    }
    if outcome.is_err() {
        storage.drained = Some(phase.drain());
    }
    outcome
}

#[cfg(test)]
#[path = "lifecycle_tests.rs"]
mod tests;

// LIFECYCLE_ACCOUNTING_BEGIN
// Bootstrap declarations replaced only after fresh compiler position discovery.
pub(super) const PERMANENT_BYTES: usize = 0;
pub(super) const ACTIVE_BYTES: usize = 0;
// LIFECYCLE_ACCOUNTING_END
