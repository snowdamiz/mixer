# Public Android V3 development host

Selected explicitly by `mixer create NAME --platform android --android-host public-v3`.
The app-owned external-package Activity consumes only public facade/profile APIs.
Shared Swift uses public MixerAndroid/MixerUI/MixerCore. Original owner, native
packet, appearance and event bytes cross the app JNI glue without JSON rebasing.
Each Activity has an independent bounded context and receiver; no global current
callback context exists. Callbacks execute only during the Android-main pump.
Queued native events retain original bytes and authority in a 32-event,
131072-byte FIFO. A deferred drain submits one JSON array without numeric
decoding/re-encoding. The optional public batch presentation validates every
member against the same installed snapshot and publishes one app-owned atomic
transaction; scalar operation-1 payloads keep strict legacy admission.
The starter
has process-local value state and synchronous reducers; it has no persistence
or asynchronous app effects. Changing config does not migrate an existing host.

`swift test --package-path Platforms/Android -j 2` executes the exact public
factory, open/edit/add/toggle/close, original-frame and refusal tests on macOS.
These controlled native surface tests do not establish Android JNI execution.
`mixer build --platform android` packages this explicit public host with its
app-owned JNI and external Activity. Native input batches retain original
envelopes and publish one app transaction per originating installed frame.
No fallback to staged-v2 is supported. Immutable published-package, Android
runtime/device, signing/store, cleanup on Android and GA qualification remain pending.
