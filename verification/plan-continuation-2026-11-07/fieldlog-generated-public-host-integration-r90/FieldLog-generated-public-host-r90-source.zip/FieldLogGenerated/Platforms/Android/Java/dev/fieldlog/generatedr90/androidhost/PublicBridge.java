package dev.fieldlog.generatedr90.androidhost;
public final class PublicBridge {
    static { System.loadLibrary("mixer_public_android_jni"); }
    private PublicBridge() {}
    public static long open(PublicActivity receiver, String profile) { requireMain(); return openNative(receiver, profile, receiver.getFilesDir().getAbsolutePath().getBytes(java.nio.charset.StandardCharsets.UTF_8)); }
    public static int event(long context, byte[] owner, byte[] envelope) { requireMain(); return eventNative(context, owner, envelope); }
    public static int close(long context) { requireMain(); return closeNative(context); }
    private static native long openNative(PublicActivity receiver, String profile, byte[] directory);
    private static native int eventNative(long context, byte[] originalOwner, byte[] originalEnvelope);
    private static native int closeNative(long context);
    private static void requireMain() {
        if (android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) throw new IllegalStateException("Android main thread required");
    }
}
