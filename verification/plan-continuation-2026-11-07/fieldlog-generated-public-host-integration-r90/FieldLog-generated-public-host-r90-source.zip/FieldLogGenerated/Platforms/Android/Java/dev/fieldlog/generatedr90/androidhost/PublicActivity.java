package dev.fieldlog.generatedr90.androidhost;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.FrameLayout;
import dev.mixer.android.AndroidUIProfile;
import dev.mixer.android.AndroidUINativeSurface;
import java.util.Arrays;
import java.util.ArrayDeque;

public final class PublicActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private FrameLayout root;
    private AndroidUINativeSurface surface;
    private byte[] owner;
    private long context;
    private boolean destroyed, failed, drainScheduled, draining;
    private static final int MAX_EVENTS = 32, MAX_BYTES = 131072;
    private static final class CapturedEvent {
        final long context; final AndroidUINativeSurface surface; final byte[] owner, envelope;
        CapturedEvent(long context, AndroidUINativeSurface surface, byte[] owner, byte[] envelope) {
            this.context = context; this.surface = surface; this.owner = owner.clone(); this.envelope = envelope.clone();
        }
    }
    private final ArrayDeque<CapturedEvent> events = new ArrayDeque<>();
    private int eventBytes = 2; // JSON array delimiters, plus comma per subsequent event.
    private int readiness;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); root = new FrameLayout(this); setContentView(root);
        if (!handler.post(this::openWhenReady)) throw new IllegalStateException("host queue unavailable");
    }
    private void openWhenReady() {
        if (destroyed || failed) return;
        if (root.getWidth() <= 0 || root.getHeight() <= 0 || root.getRootWindowInsets() == null || !root.hasWindowFocus()) {
            if (++readiness > 625 || !handler.postDelayed(this::openWhenReady, 16)) fail();
            return;
        }
        surface = new AndroidUINativeSurface(this, root, AndroidUIProfile.MEASURED_MULTILINE_RETIREMENT_V3, this::enqueue);
        context = PublicBridge.open(this, surface.profile().name());
        if (context <= 0) fail();
    }
    private void enqueue(byte[] capturedOwner, byte[] envelope) {
        if (Looper.myLooper() != Looper.getMainLooper() || destroyed || failed || draining || context <= 0 || surface == null ||
            owner == null || capturedOwner == null || !Arrays.equals(capturedOwner, owner) || envelope == null ||
            envelope.length == 0 || envelope.length > MAX_BYTES || events.size() >= MAX_EVENTS ||
            eventBytes + envelope.length + (events.isEmpty() ? 0 : 1) > MAX_BYTES) {
            deferQueueFailure(); throw new IllegalStateException("native event queue unavailable");
        }
        CapturedEvent first = events.peekFirst();
        if (first != null && (first.context != context || first.surface != surface || !Arrays.equals(first.owner, capturedOwner))) {
            deferQueueFailure(); throw new IllegalStateException("native event authority changed");
        }
        eventBytes += envelope.length + (events.isEmpty() ? 0 : 1);
        events.addLast(new CapturedEvent(context, surface, capturedOwner, envelope));
        if (!drainScheduled) {
            drainScheduled = true;
            if (!handler.post(this::drainEvents)) {
                deferQueueFailure(); throw new IllegalStateException("host queue unavailable");
            }
        }
    }
    private void drainEvents() {
        drainScheduled = false;
        if (destroyed || failed) { invalidateEvents(); return; }
        if (events.isEmpty()) return;
        draining = true;
        try {
            surface.gateInput();
            CapturedEvent first = events.peekFirst();
            for (CapturedEvent event : events) {
                if (event.context != context || event.surface != surface || !Arrays.equals(event.owner, owner) ||
                    event.context != first.context || event.surface != first.surface || !Arrays.equals(event.owner, first.owner)) {
                    fail(); return;
                }
            }
            byte[] batch = new byte[eventBytes]; int offset = 0; batch[offset++] = '[';
            for (CapturedEvent event : events) {
                if (offset > 1) batch[offset++] = ',';
                System.arraycopy(event.envelope, 0, batch, offset, event.envelope.length); offset += event.envelope.length;
            }
            batch[offset++] = ']';
            if (offset != batch.length) { fail(); return; }
            invalidateEvents();
            if (PublicBridge.event(first.context, first.owner, batch) != 0) fail();
            // Only the ensuing validated surface.install reopens native input.
        } catch (RuntimeException error) {
            fail(); throw error;
        } finally { draining = false; }
    }
    // Native callbacks only record/copy and post. Even rejected input must
    // unwind its editor lease before the app asks the surface to gate.
    private void deferQueueFailure() {
        boolean first = !failed;
        failed = true; invalidateEvents();
        if (first) handler.post(this::fail);
    }
    private void invalidateEvents() { events.clear(); eventBytes = 2; }
    public int surface(long capturedContext, int operation, byte[] token, byte[] packet, byte[] descriptor) {
        if (Looper.myLooper() != Looper.getMainLooper()) return 1;
        // During open, the native bridge has not returned this lifetime's id.
        if (context == 0 && operation == 0 && !destroyed && !failed) context = capturedContext;
        if (capturedContext != context || surface == null || (destroyed && operation != 2)) return 1;
        try {
            switch (operation) {
                case 0: if (owner != null) return 1; surface.activate(token); owner = token.clone(); break;
                case 1: surface.install(new AndroidUINativeSurface.Frame(token, packet, descriptor)); break;
                case 2: invalidateEvents(); surface.revoke(token); owner = null; break;
                default: return 1;
            }
            return 0;
        } catch (RuntimeException error) { android.util.Log.e("MixerAndroidHost", "Native surface operation failed: " + operation, error); fail(); return 1; }
    }
    private void fail() { failed = true; invalidateEvents(); if (surface != null) surface.gateInput(); }
    @Override public void onResume() { super.onResume(); if (surface != null) surface.onResume(); }
    @Override public void onPause() { if (surface != null) surface.onPause(); super.onPause(); }
    @Override public void onStop() { if (surface != null) surface.onStop(); super.onStop(); }
    @Override public void onDestroy() {
        destroyed = true; invalidateEvents(); handler.removeCallbacksAndMessages(null);
        if (context > 0 && PublicBridge.close(context) != 0) failed = true;
        if (surface != null) surface.close(); super.onDestroy();
    }
}
