// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "FieldLogGeneratedAndroid", platforms: [.macOS(.v14)],
    products: [.library(name: "AppAndroid", type: .dynamic, targets: ["AppAndroid"])],
    dependencies: [.package(name: "Application", path: "../.."), .package(path: "../../Generated/MixerSDK")],
    targets: [
        .target(name: "AppAndroid", dependencies: [.product(name: "FieldLogFeatures", package: "Application"), .product(name: "FieldLogModels", package: "Application"), .product(name: "FieldLogStorage", package: "Application"),
            .product(name: "MixerAndroid", package: "MixerSDK"), .product(name: "MixerCore", package: "MixerSDK"), .product(name: "MixerUI", package: "MixerSDK")]),
        .testTarget(name: "AppAndroidTests", dependencies: ["AppAndroid", .product(name: "FieldLogModels", package: "Application"), .product(name: "FieldLogStorage", package: "Application"), .product(name: "MixerAndroid", package: "MixerSDK"), .product(name: "MixerUI", package: "MixerSDK")])
    ], swiftLanguageModes: [.v6])
