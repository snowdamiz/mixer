import Foundation
import FieldLogModels
import FieldLogFeatures
import FieldLogStorage
import MixerCore
import MixerUI
import MixerAndroid

public enum PublicHostError: Error { case bounds, surface, closed, profile, context, storage, action }

@MainActor private final class SaveAdmission {
    var accepted = false
}

@MainActor public final class ProjectPresentation: AndroidUIBatchPresentation {
    public private(set) var snapshot: UIRenderSnapshot
    public private(set) var workspace: Workspace
    public var state: TaskEditorState { editor.state }
    private let repository: WorkspaceRepository
    private let projectID: UUID
    private var editor: TaskEditor
    private var editorObservation: UUID?
    private var reconciler: UIReconciler
    private var publishedState = TaskEditorState()
    private var renderingFailure: (any Error)?
    private var closed = false
    private var observers: [UUID: @MainActor (UIRenderSnapshot) -> Void] = [:]

    public init(directory: URL) async throws {
        let repository = try WorkspaceRepository(directory: directory.appendingPathComponent("FieldLog", isDirectory: true))
        do {
            var workspace = await repository.snapshot()
            if workspace.projects.isEmpty {
                workspace = try await repository.transact { next in
                    try next.createProject(title: "FieldLog", site: "Local workspace")
                }
            }
            guard let project = workspace.projects.first else { throw PublicHostError.storage }
            let editor = try TaskEditor(save: { _, _ in .failed("Unadmitted save") })
            var reconciler = UIReconciler(validator: UIValidator(supportedTextFieldAxes: AndroidUIProfile.measuredMultilineRetirementV3.capabilities.textFieldAxes))
            try reconciler.apply(Self.document(editor.state, workspace: workspace, project: project.id, revision: 1))
            self.repository = repository; self.workspace = workspace; self.projectID = project.id
            self.editor = editor; self.reconciler = reconciler; self.snapshot = try reconciler.currentSnapshot()
        } catch {
            await repository.close()
            throw error
        }
    }

    public func observe(_ receive: @escaping @MainActor (UIRenderSnapshot) -> Void) -> @MainActor () -> Void {
        let id = UUID(); observers[id] = receive
        return { [weak self] in self?.observers.removeValue(forKey: id) }
    }
    public func send(_ event: UIEventEnvelope) throws { try sendBatch([event], from: snapshot) }

    public func sendBatch(_ events: [UIEventEnvelope], from captured: UIRenderSnapshot) throws {
        guard !closed, !state.saving, !state.saved else { throw PublicHostError.closed }
        guard !events.isEmpty, events.count <= AndroidUIHost.maximumBatchEvents,
              try JSONEncoder().encode(events).count <= AndroidUIHost.maximumBatchBytes else { throw PublicHostError.bounds }
        guard captured.document == snapshot.document else { throw AndroidUIHostError.sourceChanged }
        // All original envelopes route before any reducer is run. Terminal actions
        // must be last; a trailing event cannot hide a Save effect in a failed batch.
        let actions = try events.map { try captured.route($0) }
        for (index, action) in actions.enumerated() {
            switch (action.nodeID, action.actionID, action.event, action.value) {
            case ("task.title", "task.title.change", .textChange, .string),
                 ("task.responsible", "task.responsible.change", .textChange, .string): break
            case ("task.save", "task.save", .activate, .null):
                guard index == actions.count - 1 else { throw PublicHostError.action }
            default: throw PublicHostError.action
            }
        }
        let admission = SaveAdmission()
        let repository = self.repository, projectID = self.projectID
        // Stage with the actual shared reducer. Its async effect cannot touch the
        // repository until reduction, rendering and native encoding all succeed.
        let candidate = try TaskEditor(save: { [weak self] title, responsible in
            guard await admission.accepted else { return .failed("Unadmitted save") }
            do {
                let saved = try await repository.transact { next in
                    try next.saveTask(projectID: projectID, title: title, responsible: responsible)
                }
                await self?.savedWorkspace(saved)
                return .saved
            } catch { return .failed(error.localizedDescription) }
        })
        do {
            try candidate.changeTitle(state.title)
            try candidate.changeResponsible(state.responsible)
            for action in actions {
                switch (action.nodeID, action.event, action.value) {
                case ("task.title", .textChange, .string(let text)): try candidate.changeTitle(text)
                case ("task.responsible", .textChange, .string(let text)): try candidate.changeResponsible(text)
                case ("task.save", .activate, .null): try candidate.submit()
                default: throw PublicHostError.action
                }
            }
            let (nextReconciler, next) = try render(candidate.state)
            // Closing an editing feature has no durable effects. Do this before
            // swapping state so a thrown staging operation leaves the live editor.
            if let editorObservation { editor.removeObserver(editorObservation) }
            try editor.close()
            editor = candidate; reconciler = nextReconciler; snapshot = next; publishedState = candidate.state
            editorObservation = candidate.observe { [weak self] state in self?.changed(state) }
            admission.accepted = true
            publish()
        } catch {
            try? candidate.close()
            throw error
        }
    }

    private func savedWorkspace(_ saved: Workspace) { workspace = saved }
    private func changed(_ state: TaskEditorState) {
        guard !closed else { return }
        // observe() immediately returns the just-committed state; only subsequent
        // async completions cause a second publication.
        guard state != publishedState else { return }
        do {
            let (nextReconciler, next) = try render(state)
            reconciler = nextReconciler; snapshot = next; publishedState = state; publish()
        } catch {
            // A source encoding failure is sticky; keep native input closed by
            // terminating the source instead of publishing an unvalidated frame.
            renderingFailure = error; closed = true
        }
    }
    private func render(_ state: TaskEditorState) throws -> (UIReconciler, UIRenderSnapshot) {
        guard snapshot.document.revision < UInt64.max else { throw PublicHostError.bounds }
        var next = reconciler
        try next.apply(Self.document(state, workspace: workspace, project: projectID, revision: snapshot.document.revision + 1))
        let result = try next.currentSnapshot()
        _ = try result.encodeNativePacketV1(supportedTextFieldAxes: AndroidUIProfile.measuredMultilineRetirementV3.capabilities.textFieldAxes)
        return (next, result)
    }
    private func publish() { for receive in Array(observers.values) { receive(snapshot) } }
    public func waitForSave() async throws {
        await editor.waitForSave()
        if let renderingFailure { throw renderingFailure }
    }
    public func close() async {
        closed = true; observers.removeAll()
        if let editorObservation { editor.removeObserver(editorObservation) }
        editorObservation = nil
        // An admitted durable save finishes before the lock is released. A fresh
        // context can then open a genuinely new repository from the same files.
        await editor.waitForSave()
        try? editor.close()
        await repository.close()
    }

    // App-owned Android presentation of the actual shared TaskEditor value state.
    // Field validation, canSubmit, save effects and persistence stay in FieldLog.
    private static func document(_ state: TaskEditorState, workspace: Workspace, project: UUID, revision: UInt64) -> UIDocument {
        let inactive = state.saving || state.saved
        return MixerUI.Navigation("task.screen", title: "FieldLog") {
            MixerUI.List("task.form") {
                MixerUI.Section("task.fields", title: "Task") {
                    MixerUI.TextField("task.title", "What needs to happen?", value: state.title, action: "task.title.change", axis: .vertical)
                        .accessibilityIdentifier("task-title").disabled(inactive)
                    MixerUI.TextField("task.responsible", "Responsible person (optional)", value: state.responsible, action: "task.responsible.change").disabled(inactive)
                }
                if let failure = state.failure {
                    MixerUI.Section("task.failure") { MixerUI.Text("task.failure.message", String(decoding: failure.utf8.prefix(4000), as: UTF8.self)) }
                }
                MixerUI.Section("task.actions") {
                    MixerUI.Button("task.save", state.saved ? "Saved" : state.saving ? "Saving…" : "Add", action: "task.save").disabled(!state.canSubmit)
                }
                MixerUI.Section("workspace.tasks", title: "Saved tasks") {
                    for task in workspace.tasks(for: project) {
                        MixerUI.Text("saved." + task.id.uuidString, task.title + " — " + task.responsible)
                    }
                }
            }
        }.document(revision: revision)
    }
}

@MainActor private final class Delivery {
    weak var host: AndroidUIHost?
    var failure: (any Error)?
    func schedule() {
        Task { @MainActor [weak self] in
            guard let self, let host, host.owner != nil else { return }
            do { try host.deliverLatest() } catch { failure = error }
        }
    }
}

@MainActor public final class PublicAndroidApplication {
    private let delivery = Delivery()
    public let presentation: ProjectPresentation
    public let host: AndroidUIHost
    public init(surface: any AndroidUINativeSurface, selectedProfile: String, directory: URL) async throws {
        guard selectedProfile == AndroidUIProfile.measuredMultilineRetirementV3.rawValue,
              surface.profile == .measuredMultilineRetirementV3 else { throw PublicHostError.profile }
        presentation = try await ProjectPresentation(directory: directory)
        host = try AndroidUIHost(surface: surface, profile: .measuredMultilineRetirementV3,
            appearance: UIAppearanceDescriptorCodecV2.mixerDefaultV2(), scheduleDelivery: { [delivery] in delivery.schedule() })
        delivery.host = host
        do { try host.replace(with: presentation); try host.deliverLatest() }
        catch { host.close(); await presentation.close(); throw error }
    }
    public func send(owner: UUID, originalEnvelope: Data) throws {
        if let failure = delivery.failure { throw failure }
        guard originalEnvelope.count <= 131_072 else { throw PublicHostError.bounds }
        try JSONInputGuard.validate(originalEnvelope, limits: JSONInputLimits(maximumDepth: 8, maximumValues: 64))
        try host.send(owner: owner, event: JSONDecoder().decode(UIEventEnvelope.self, from: originalEnvelope))
        try host.deliverLatest()
    }
    public func sendBatch(owner: UUID, originalEnvelopes: Data) throws {
        if let failure = delivery.failure { throw failure }
        guard !originalEnvelopes.isEmpty, originalEnvelopes.count <= AndroidUIHost.maximumBatchBytes else { throw PublicHostError.bounds }
        try JSONInputGuard.validate(originalEnvelopes, limits: JSONInputLimits(maximumDepth: 9, maximumValues: 2049))
        let events = try JSONDecoder().decode([UIEventEnvelope].self, from: originalEnvelopes)
        try host.sendBatch(owner: owner, events: events)
        try host.deliverLatest()
    }
    public func settle() async throws {
        try await presentation.waitForSave()
        if let failure = delivery.failure { throw failure }
        try host.deliverLatest()
    }
    public func close() async { host.close(); await presentation.close() }
}
