import Foundation
import MixerCore
import MixerUI
import MixerAndroid

private typealias SurfaceCall = @convention(c) @Sendable (Int64, Int32, UnsafePointer<UInt8>?, Int, UnsafePointer<UInt8>?, Int, UnsafePointer<UInt8>?, Int) -> Int32
@MainActor private final class BridgeSurface: AndroidUINativeSurface {
    let context: Int64
    let callback: SurfaceCall
    var failure = false
    let profile = AndroidUIProfile.measuredMultilineRetirementV3
    var capabilities: AndroidUICapabilities { profile.capabilities }
    init(_ context: Int64, _ callback: @escaping SurfaceCall) { self.context = context; self.callback = callback }
    func call(_ operation: Int32, _ owner: UUID, _ packet: Data = Data(), _ appearance: Data = Data()) throws {
        guard !failure else { throw PublicHostError.surface }
        let owner = Data(owner.uuidString.utf8)
        let status = owner.withUnsafeBytes { o in packet.withUnsafeBytes { p in appearance.withUnsafeBytes { a in
            callback(context, operation, o.bindMemory(to: UInt8.self).baseAddress, o.count,
                p.bindMemory(to: UInt8.self).baseAddress, p.count, a.bindMemory(to: UInt8.self).baseAddress, a.count)
        } } }
        guard status == 0 else { failure = true; throw PublicHostError.surface }
    }
    func activate(owner: UUID) throws { try call(0, owner) }
    func install(_ frame: AndroidUIFrame) throws {
        guard frame.profile == profile else { throw PublicHostError.profile }
        try call(1, frame.owner, frame.packet, frame.appearanceDescriptorV2)
    }
    func revoke(owner: UUID) {
        // Cleanup must still run after a rejected install. Preserve any earlier
        // failure and never report a failed native lifetime as accepted.
        let previous = failure; failure = false
        do { try call(2, owner) } catch { failure = true }
        failure = failure || previous
    }
}
private final class Replies: @unchecked Sendable {
    private let lock = NSLock()
    private var values: [Int64: Int32] = [:]
    func reserve(_ id: Int64) -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard values[id] == nil, values.count < 16 else { return false }; values[id] = 0; return true
    }
    func complete(_ id: Int64, _ result: Int32) { lock.lock(); defer { lock.unlock() }; values[id] = result }
    func take(_ id: Int64) -> Int32 {
        lock.lock(); defer { lock.unlock() }
        guard let result = values[id] else { return -1 }
        if result != 0 { values.removeValue(forKey: id) }; return result
    }
}
private let replies = Replies()
@MainActor private enum Applications {
    static var values: [Int64: (PublicAndroidApplication, BridgeSurface)] = [:]
    static func execute(_ id: Int64, _ operation: Int32, _ profile: String, _ directory: Data, _ owner: Data, _ event: Data, _ callback: @escaping SurfaceCall) async -> Int32 {
        do {
            switch operation {
            case 0:
                guard values[id] == nil, values.count < 16 else { throw PublicHostError.context }
                let surface = BridgeSurface(id, callback)
                guard let path = String(data: directory, encoding: .utf8), path.hasPrefix("/"), !path.utf8.contains(0) else { throw PublicHostError.storage }
                let application = try await PublicAndroidApplication(surface: surface, selectedProfile: profile, directory: URL(fileURLWithPath: path, isDirectory: true))
                values[id] = (application, surface)
            case 1:
                guard let (application, surface) = values[id], !surface.failure,
                      let text = String(data: owner, encoding: .utf8), let token = UUID(uuidString: text),
                      Data(token.uuidString.utf8) == owner else { throw PublicHostError.context }
                // Array payload opts into atomic batch admission; scalar ABI
                // clients retain the existing strict single-event path.
                if event.first(where: { ![9, 10, 13, 32].contains($0) }) == 91 {
                    try application.sendBatch(owner: token, originalEnvelopes: event)
                } else {
                    try application.send(owner: token, originalEnvelope: event)
                }
                try await application.settle()
            case 2:
                guard let (application, surface) = values[id] else { throw PublicHostError.context }
                await application.close()
                guard !surface.failure else { throw PublicHostError.surface }
                values.removeValue(forKey: id)
            default: throw PublicHostError.context
            }
            return 1
        } catch { return 2 }
    }
}
@_cdecl("mixer_public_android_submit")
public func publicAndroidSubmit(_ context: Int64, _ operation: Int32,
    _ profile: UnsafePointer<UInt8>?, _ profileCount: Int,
    _ directory: UnsafePointer<UInt8>?, _ directoryCount: Int,
    _ owner: UnsafePointer<UInt8>?, _ ownerCount: Int,
    _ event: UnsafePointer<UInt8>?, _ eventCount: Int,
    _ callback: @convention(c) @Sendable @escaping (Int64, Int32, UnsafePointer<UInt8>?, Int, UnsafePointer<UInt8>?, Int, UnsafePointer<UInt8>?, Int) -> Int32) -> Int32 {
    guard context > 0, (0...2).contains(operation), (0...64).contains(profileCount),
          (0...4096).contains(directoryCount), (operation == 0 ? directoryCount > 0 : directoryCount == 0),
          (directoryCount == 0 || directory != nil), (0...64).contains(ownerCount), (0...131_072).contains(eventCount),
          (profileCount == 0 || profile != nil), (ownerCount == 0 || owner != nil), (eventCount == 0 || event != nil) else { return 1 }
    let profile = profile.map { Data(bytes: $0, count: profileCount) } ?? Data()
    let directory = directory.map { Data(bytes: $0, count: directoryCount) } ?? Data()
    let owner = owner.map { Data(bytes: $0, count: ownerCount) } ?? Data()
    let event = event.map { Data(bytes: $0, count: eventCount) } ?? Data()
    guard let selected = String(data: profile, encoding: .utf8), replies.reserve(context) else { return 1 }
    Task { @MainActor in replies.complete(context, await Applications.execute(context, operation, selected, directory, owner, event, callback)) }
    return 0
}
@_cdecl("mixer_public_android_poll")
public func publicAndroidPoll(_ context: Int64) -> Int32 {
    guard Thread.isMainThread else { return -1 }
    _ = RunLoop.main.run(mode: .default, before: Date(timeIntervalSinceNow: 0.001))
    return replies.take(context)
}
