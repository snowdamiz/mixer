// swift-tools-version: 6.0
import PackageDescription
let package = Package(
    name: "FieldLogGenerated", platforms: [.iOS("26.0"), .macOS(.v14)],
    products: [.library(name: "FieldLogFeatures", targets: ["FieldLogFeatures"]), .library(name: "FieldLogModels", targets: ["FieldLogModels"]), .library(name: "FieldLogStorage", targets: ["FieldLogStorage"]), .library(name: "AppFeatures", targets: ["AppFeatures"])],
    dependencies: [.package(path: "Generated/MixerSDK")],
    targets: [
        .target(name: "FieldLogModels"),
        .target(name: "FieldLogFeatures", dependencies: ["FieldLogModels", .product(name: "MixerCore", package: "MixerSDK"), .product(name: "MixerUI", package: "MixerSDK")], exclude: ["TaskEditorAppleFieldsHost.swift"]),
        .target(name: "FieldLogStorage", dependencies: ["FieldLogModels"]),
        .target(name: "AppModels"),
        .target(name: "AppFeatures", dependencies: ["AppModels", .product(name: "MixerUI", package: "MixerSDK")]),
        .testTarget(name: "AppModelsTests", dependencies: ["AppModels", "AppFeatures"])
    ]
)
