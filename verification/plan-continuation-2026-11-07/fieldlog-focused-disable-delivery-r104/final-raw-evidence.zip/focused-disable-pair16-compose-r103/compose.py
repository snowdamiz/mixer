#!/usr/bin/env python3
"""Compose exact R98 bytes, permanent regression, and a new Pair16 transition."""
import ast
import copy
import difflib
import hashlib
import importlib.util
import json
import platform
import sys
from pathlib import Path

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
V = 'verification/plan-continuation-2026-11-07/'
B = V + 'source113-inspection-caller-r3/'
R98 = ROOT / V / 'v3-focused-disable-owner-transition-r98'
POLICY = 'cli/Sources/MixerBuild/AndroidSDKCompatibility.swift'
DRIVER = 'cli/Sources/MixerBuild/Resources/android-build.py'
CHECKER = 'scripts/ci/check-android-generated-java.py'
FIXTURE = 'scripts/ci/tests/test_android_generated_java_runner.py'
BOOT = V + 'generated-java-ci-integration/bootstrap.py'
RUNNER = 'native/android/tests/run-public-surface-host.py'
MAP = 'native/android/tests/private-owner-barrier-map.json'
BINDINGS = 'native/android/tests/private-owner-barrier-bindings.json'
JAVA = 'native/android/tests/FocusedDisableOwnerTransitionHostTests.java'
PACKETS = 'native/android/tests/FocusedDisableOwnerTransitionPackets/'
OLD = 'bc66642e1997905c743f529a8a9aafc55a12310f011ff98f78556cd1cf9c6833'
SDK = 'a689f5653ff2d353e3b0ae202ee6169d64c03448a56ec1d5fee389a9a8ff536f'
ADAPTER = '335467770aaa3b163124ea306b148abca0db931175df6207bbd52d54c71ef362'
PRODUCT = {
    'native/android/app/src/dev/mixer/android/NativeRenderer.java': '0a02bb07f479c51294afda487e6c7c540e522450e05929481cb0cd20d6ba7abb',
    'native/android/app/src/dev/mixer/android/NativeAppearanceViewsV2.java': '298f7e9b481878537d427504f4953c388b90497bba3eb7bcb1464ab2a6693185',
}

def need(ok, message):
    if not ok:
        raise RuntimeError(message)

def ident(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def enc(value):
    return (json.dumps(value, indent=2) + '\n').encode()

def save(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)

def module(path):
    spec = importlib.util.spec_from_file_location('pair16_' + path.stem, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

def literal(text, name):
    node = next(n for n in ast.parse(text).body if isinstance(n, ast.Assign)
                and any(isinstance(t, ast.Name) and t.id == name for t in n.targets))
    return ast.literal_eval(node.value)

def main():
    need(not (OUT / 'application-map.json').exists(), 'Already composed')
    owner = module(ROOT / CHECKER)
    prior = owner.load_profile(ROOT)
    before = owner.source_inputs(prior)
    need(len(before) == 116 and owner.source_digest(before) == OLD, 'Canonical owning baseline differs')
    need(before == json.loads((ROOT / B / 'source-inputs.json').read_bytes()), 'Installed source manifest differs')
    need(prior['id'] == 'mixer.android-source-pair.15' and len(prior['sdk_files']) == 24
         and prior['sdk_compatibility_sha256'] == SDK and len(prior['adapter_files']) == 27
         and prior['adapter_compatibility_sha256'] == ADAPTER and len(owner.java_roster(prior)) == 21,
         'Canonical Pair15 differs')
    changes = {}
    originals = {}
    def read(path):
        if path in changes:
            return changes[path]
        if path not in originals:
            originals[path] = (ROOT / path).read_bytes()
        return originals[path]
    def edit(path, old, new, count=1):
        text = read(path).decode()
        need(text.count(old) == count, 'Exact edit count differs: ' + path + ' ' + repr(old[:100]))
        changes[path] = text.replace(old, new).encode()

    for path, digest in PRODUCT.items():
        need(read(path) == (R98 / 'beforeimages' / path).read_bytes(), 'R98 predecessor differs: ' + path)
        raw = (R98 / 'afterimages' / path).read_bytes()
        need(ident(raw)['sha256'] == digest, 'Reviewed R98 afterimage differs')
        changes[path] = raw
    changes[JAVA] = (R98 / 'tests' / Path(JAVA).name).read_bytes()
    # Only the four files consumed by the unchanged R98 main; acknowledge the synthetic predecessor.
    for name in ('descriptor.json', 'synthesized-acknowledged-presave.json', '201-2.json', '201-3.json'):
        changes[PACKETS + name] = (R98 / 'packets' / name).read_bytes()
    changes[PACKETS + 'README.md'] = (
        'R98 focused-disable regression fixtures. 201-2 and 201-3 are exact R90 C-entry busy/saved captures.\n'
        'synthesized-acknowledged-presave derives from captured 201-1 with captured busy field values;\n'
        'it is not a captured native frame. The test synthesizes its initial settled-title frame.\n'
        'Actual production owner/renderer/views run with controlled Android/JNI leaves; no device qualification.\n'
    ).encode()
    edit(RUNNER, "{tests / 'VerticalReflowHostTests.java', tests / 'GeneratedAddTransitionHostTests.java'}",
         "{tests / 'VerticalReflowHostTests.java', tests / 'GeneratedAddTransitionHostTests.java', tests / 'FocusedDisableOwnerTransitionHostTests.java'}")
    edit(RUNNER, '    passed = True', """    focused_packets = tests / 'FocusedDisableOwnerTransitionPackets'
    focused_inputs = [focused_packets / name for name in ('descriptor.json', 'synthesized-acknowledged-presave.json', '201-2.json', '201-3.json')]
    (args.evidence / 'focused-disable-packet-inputs.json').write_text(json.dumps({str(f.relative_to(root)): hashlib.sha256(f.read_bytes()).hexdigest() for f in focused_inputs}, indent=2) + '\\n')
    run('focused-disable-transition', [args.java_home / 'bin/java', '-ea', '-Xmx256m', '-cp', reflow_classes, 'dev.mixer.android.FocusedDisableOwnerTransitionHostTests', focused_packets, 'candidate'])
    passed = True""")
    edit(RUNNER, 'vertical reflow and production-packet Add/clear with actual renderer/owner/views',
         'vertical reflow, production-packet Add/clear and focused model-disable with actual renderer/owner/views')

    mapping = json.loads(read(MAP)); old_map = copy.deepcopy(mapping)
    bindings = json.loads(read(BINDINGS)); old_bindings = copy.deepcopy(bindings)
    lookup = {row['site']: row for row in bindings['bindings']}
    moves = []
    for source in PRODUCT:
        old = read(source) if source not in changes else originals[source]
        new = changes[source]
        old_lines = old.decode().splitlines(True); new_lines = new.decode().splitlines(True)
        equal = {i+1:j+1 for tag,a,b,c,d in difflib.SequenceMatcher(None,old_lines,new_lines,autojunk=False).get_opcodes()
                 if tag == 'equal' for i,j in zip(range(a,b), range(c,d))}
        need(mapping['source_sha256'][source] == ident(old)['sha256'], 'Source-map predecessor differs')
        for row in mapping['records']:
            if row['source'] != source:
                continue
            need(len(row['candidates']) == 1, 'Ambiguous source anchor')
            candidate = row['candidates'][0]; previous = copy.deepcopy(candidate)
            line = equal.get(candidate['line'])
            need(line is not None, 'Changed callback source requires derivation: ' + row['baseline'])
            need(''.join(new_lines[line-1:])[candidate['column']-1:].startswith(candidate['text']), 'Invocation text changed: '+row['baseline'])
            candidate['line'] = line; lookup[row['baseline']]['line'] = line
            frame = row['boundary']['return_frame_line']
            if frame is not None and source.endswith('/NativeAppearanceViewsV2.java'):
                need(frame in equal, 'Changed final native return frame')
                row['boundary']['return_frame_line'] = equal[frame]
            moves.append({'site':row['baseline'], 'before':previous, 'after':copy.deepcopy(candidate)})
        mapping['source_sha256'][source] = ident(new)['sha256']
    need(len(mapping['records']) == len(bindings['bindings']) == 189 and len(bindings['helpers']) == 15, 'Obligation roster changed')
    for old, new in zip(old_map['records'], mapping['records']):
        normalized = copy.deepcopy(new); normalized['candidates'] = old['candidates']; normalized['boundary']['return_frame_line'] = old['boundary']['return_frame_line']
        need(normalized == old, 'Callback contract changed')
    for old, new in zip(old_bindings['bindings'], bindings['bindings']):
        need(dict(new, line=old['line']) == old, 'Historical compiled anchor changed')
    need(bindings['helpers'] == old_bindings['helpers'], 'Historical helper changed')
    changes[MAP] = enc(mapping)
    bindings['provenance']['map_sha256'] = ident(changes[MAP])['sha256']
    changes[BINDINGS] = enc(bindings)
    save(OUT/'source-anchor-refresh.json', enc({'records':189,'helpers':15,'moves':moves,
         'compiledAnchorPolicy':'Historical exactCaller and constant-pool operands retained; existing runner derives actual current BCI from compiled symbols before matrix'}))

    profile = copy.deepcopy(prior); profile['id'] = 'mixer.android-source-pair.16'
    for path in PRODUCT:
        profile['adapter_files'][path.removeprefix('native/android/')] = ident(changes[path])
    profile['adapter_compatibility_sha256'] = owner.source_digest(profile['adapter_files'])
    text = read(POLICY).decode(); start = text.index('Data(#"""\n') + len('Data(#"""\n'); end = text.index('\n        """#.utf8)',start)
    changes[POLICY] = (text[:start] + '\n'.join('        '+line for line in json.dumps(profile,indent=2).splitlines()) + text[end:]).encode()
    raw_edits = {CHECKER:[], FIXTURE:[]}
    for path in (DRIVER,CHECKER,FIXTURE,'cli/build-tests/test_android_sdk_compatibility.py','cli/Tests/MixerBuildTests/AndroidSDKCompatibilityTests.swift'):
        edit(path, prior['id'], profile['id'])
        if path in raw_edits:
            raw_edits[path].append({'before':prior['id'],'after':profile['id']})
    for path in ('cli/build-tests/test_android_sdk_compatibility.py','cli/Tests/MixerBuildTests/AndroidSDKCompatibilityTests.swift'):
        edit(path, ADAPTER, profile['adapter_compatibility_sha256'])
    edit('cli/build-tests/test_android_sdk_compatibility.py','def test_profile15_preserves_exact_profile_session', 'def test_profile16_preserves_exact_profile_session')
    # R93 domain ABI correction stays exact, apart from the required profile ID admission.
    need(changes[DRIVER].replace(profile['id'].encode(),prior['id'].encode()) == originals[DRIVER], 'Driver non-profile change')
    final = {p:ident(changes[p]) if p in changes else row for p,row in before.items()}
    current = owner.source_digest(final)
    need(len(final) == 116 and set(final) == set(before), 'Source116 roster changed')
    transition = {'schema':1,'type':'EXACT_PAIR15_TO_PAIR16_FOCUSED_HORIZONTAL_MODEL_DISABLE_SOURCE',
        'sourceBefore':OLD,'sourceAfter':current,'sourceCountBefore':116,'sourceCountAfter':116,
        'profileBefore':prior,'profileAfter':profile,
        'owningChanges':[{'path':p,'before':before[p],'after':final[p]} for p in sorted(final) if before[p]!=final[p]],
        'rawPredecessors':[{'path':p,'before':ident(originals[p]),'after':ident(changes[p]),'edits':edits} for p,edits in raw_edits.items()],
        'qualification':False,'actualSixConsumers':False,'nativePass':False,'runtimePass':False,'gaPass':False,
        'scope':'Exact R98 two-file source and Pair16 identity only; separate R100 host review and R102 native diagnostic evidence do not transfer qualification'}
    binding = json.loads(read(B+'binding.json')); history = copy.deepcopy(binding)
    binding['source']['sha256'] = current
    binding['profile']['id'] = profile['id']; binding['profile']['adapter_sha256'] = profile['adapter_compatibility_sha256']
    binding['pair16_transition'] = transition
    changes[B+'binding.json'] = enc(binding); changes[B+'source-inputs.json'] = enc(final)
    for path in (BOOT,B+'test_combined.py',B+'test_rebind.py',B+'test_source113.py'):
        edit(path,OLD,current,read(path).decode().count(OLD))
    edit(V+'generated-java-ci-integration/test_bootstrap.py',prior['id'],profile['id'])
    edit(B+'test_combined.py',ADAPTER,profile['adapter_compatibility_sha256'])
    edit(B+'test_combined.py','  source116=a.pair15_predecessor(self.base,binding,actual,owner)',
         "  source_pair15=a.pair16_predecessor(self.base,binding,actual,owner)\n  self.assertEqual(owner.source_digest(source_pair15),binding['pair16_transition']['sourceBefore'])\n  source116=a.pair15_predecessor(self.base,binding,source_pair15,owner)")
    edit(B+'test_combined.py',"[('pair15_transition',key) for key in ('qualification','actualSixConsumers','nativePass','runtimePass','gaPass')]",
         "[('pair15_transition',key) for key in ('qualification','actualSixConsumers','nativePass','runtimePass','gaPass')]+[('pair16_transition',key) for key in ('qualification','actualSixConsumers','nativePass','runtimePass','gaPass')]")
    callers = json.loads(read(B+'caller-inputs.json'))
    need(len(callers)==8,'Caller8 roster changed')
    for row in callers:
        need(ident(read(row['path'])) == {k:row[k] for k in ('bytes','sha256')} if row['path'] not in changes else ident(originals[row['path']]) == {k:row[k] for k in ('bytes','sha256')}, 'Caller predecessor drift')
        row.update(ident(read(row['path'])))
    changes[B+'caller-inputs.json'] = enc(callers)
    adopter = read(B+'adopt_envelope.py').decode(); original_adopter = adopter
    def replace(old,new):
        nonlocal adopter
        need(adopter.count(old)==1,'Adopter edit differs: '+old[:100]); adopter=adopter.replace(old,new)
    replace("same_json(owner.load_profile(ROOT), transition['profileAfter']), 'Pair15 exact profile differs'",
            "same_json(PAIR16_TRANSITION['profileBefore'], transition['profileAfter']), 'Pair15 exact profile differs'")
    replace('def pair15_predecessor_raw(base, path):\n    raw = base.regular(path).read_bytes()',
            'def pair15_predecessor_raw(base, path):\n    raw = pair16_predecessor_raw(base, path)')
    helper = '''
def pair16_predecessor(base, binding, actual, owner):
    transition = PAIR16_TRANSITION
    base.need(same_json(binding.get('pair16_transition'), transition), 'Pair16 typed transition differs')
    base.need(len(actual) == transition['sourceCountAfter'] and owner.source_digest(actual) == transition['sourceAfter'], 'Pair16 current source differs')
    base.need(same_json(owner.load_profile(ROOT), transition['profileAfter']), 'Pair16 exact profile differs')
    predecessor = dict(actual)
    for row in transition['owningChanges']:
        base.need(same_json(actual.get(row['path']), row['after']), 'Pair16 current owning row differs')
        predecessor[row['path']] = row['before']
    base.need(len(predecessor) == transition['sourceCountBefore'] and owner.source_digest(predecessor) == transition['sourceBefore'], 'Pair16 predecessor source differs')
    return predecessor

def pair16_predecessor_raw(base, path):
    raw = base.regular(path).read_bytes()
    relative = path.relative_to(ROOT).as_posix()
    row = next(r for r in PAIR16_TRANSITION['rawPredecessors'] if r['path'] == relative)
    base.need({'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} == row['after'], 'Pair16 exact raw successor differs')
    old = raw.decode()
    for edit in reversed(row['edits']):
        old = old.replace(edit['after'], edit['before'])
    old = old.encode()
    base.need({'bytes':len(old),'sha256':hashlib.sha256(old).hexdigest()} == row['before'], 'Pair16 exact raw predecessor differs')
    return old

'''
    replace('\ndef bind():','\nPAIR16_TRANSITION = '+repr(transition)+'\n'+helper+'\ndef bind():')
    replace('        actual = pair15_predecessor(base, binding, actual, owner)',
            '        actual = pair16_predecessor(base, binding, actual, owner)\n        actual = pair15_predecessor(base, binding, actual, owner)')
    replace("digest == '"+OLD+"'", "digest == '"+current+"'")
    replace("profile['adapter_compatibility_sha256'] == '"+ADAPTER+"'", "profile['adapter_compatibility_sha256'] == '"+profile['adapter_compatibility_sha256']+"'")
    oldcaller=ident(originals[B+'caller-inputs.json']); newcaller=ident(changes[B+'caller-inputs.json'])
    replace("len(caller_raw) == "+str(oldcaller['bytes'])+" and hashlib.sha256(caller_raw).hexdigest() == '"+oldcaller['sha256']+"'",
            "len(caller_raw) == "+str(newcaller['bytes'])+" and hashlib.sha256(caller_raw).hexdigest() == '"+newcaller['sha256']+"'")
    for name in ('PAIR11_TRANSITION','PAIR12_TRANSITION','PAIR13_TRANSITION','PAIR14_TRANSITION','PAIR15_TRANSITION'):
        need(literal(adopter,name)==literal(original_adopter,name)==history[name.lower()],'Typed history changed: '+name)
    need({k:v for k,v in binding.items() if k not in ('source','profile','pair16_transition')} == {k:v for k,v in history.items() if k not in ('source','profile')},'Historical authority changed')
    changes[B+'adopt_envelope.py'] = adopter.encode()
    seal=json.loads(read(B+'seal.json')); need(seal['member_count']==len(seal['members'])==32,'Seal32 roster changed')
    for row in seal['members']:
        path=B+row['path']; old=originals.get(path)
        if old is None: old=(ROOT/path).read_bytes(); originals[path]=old
        need(ident(old)=={k:row[k] for k in ('bytes','sha256')},'Runtime seal predecessor differs: '+path)
        row.update(ident(read(path)))
    seal['tree_sha256']=hashlib.sha256(json.dumps(seal['members'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
    changes[B+'seal.json']=enc(seal)

    # Existing finite CI metadata/source projection; never discover verification directories.
    projection=OUT/'projection'
    paths=set(json.loads((ROOT/V/'public-host-domain-abi-check-fix-r93/frozen-inputs.json').read_bytes()))|set(before)|set(changes)
    for directory in ('native/android/tests','sdk/Sources'):
        paths.update(p.relative_to(ROOT).as_posix() for p in (ROOT/directory).rglob('*') if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts)
    for path in sorted(paths):
        need(not Path(path).is_absolute() and '..' not in Path(path).parts and 'scratch' not in Path(path).parts,'Unsafe projection input')
        save(projection/path,read(path))
    projected=module(projection/CHECKER)
    need(projected.source_inputs(projected.load_profile(projection))==final,'Final source116 bytes differ')
    need((projection/'.github/workflows/verify.yml').read_bytes()==(ROOT/'.github/workflows/verify.yml').read_bytes(),'Workflow differs')
    rows=[]; patch=[]
    for path, raw in sorted(changes.items()):
        old=(ROOT/path).read_bytes() if (ROOT/path).exists() else None
        if raw==old: continue
        if old is not None: save(OUT/'beforeimages'/path,old)
        save(OUT/'afterimages'/path,raw)
        rows.append({'path':path,'before':ident(old) if old is not None else None,'after':ident(raw),
                     'beforeimage':'beforeimages/'+path if old is not None else None,'afterimage':'afterimages/'+path})
        patch.extend(difflib.unified_diff((old or b'').decode().splitlines(True),raw.decode().splitlines(True),fromfile='a/'+path if old is not None else '/dev/null',tofile='b/'+path))
    save(OUT/'application-map.json',enc({'schema':1,'basis':'EXACT_CANONICAL_PAIR15_WITH_R93_DOMAIN_ABI_FIX',
         'sourceBefore':OLD,'sourceAfter':current,'sourceCountBefore':116,'sourceCountAfter':116,
         'profileBefore':prior['id'],'profileAfter':profile['id'],'sdk':{'count':24,'sha256':SDK},
         'adapter':{'count':27,'before':ADAPTER,'after':profile['adapter_compatibility_sha256']},
         'javaSources':21,'callerCount':8,'sealMembers':32,'rows':rows,'canonicalApplied':False,
         'workflowUnchanged':ident((ROOT/'.github/workflows/verify.yml').read_bytes())}))
    save(OUT/'product.patch',''.join(patch).encode()); save(OUT/'source-before.json',enc(before)); save(OUT/'source-after.json',enc(final))
    save(OUT/'composition.json',enc({'python':platform.python_version(),'changedPaths':len(rows),'changedOwningPaths':[r['path'] for r in transition['owningChanges']],
         'permanentRegressionExactR98':True,'historicalTypedTransitionsUnchanged':True,'qualificationPromoted':False,
         'projection':str(projection),'projectionFiles':len(paths),'sourceAfter':current,'adapterAfter':profile['adapter_compatibility_sha256']}))
    print(json.dumps({'changedPaths':len(rows),'sourceAfter':current,'adapterAfter':profile['adapter_compatibility_sha256']}))

if __name__=='__main__':
    main()
