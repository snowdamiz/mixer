#!/usr/bin/env python3
"""Check this exact application's before or after bytes without writing them."""
import argparse
import hashlib
import json
import os
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('phase', choices=('before', 'after'))
parser.add_argument('--root', type=Path, default=Path.cwd())
args = parser.parse_args()
delivery = Path(__file__).resolve().parent
application = json.loads((delivery / 'application-map.json').read_bytes())
for row in application['rows']:
    path = args.root / row['path']
    expected = row[args.phase]
    if expected is None:
        if os.path.lexists(path):
            raise RuntimeError('Expected absent: ' + row['path'])
    else:
        if path.is_symlink():
            raise RuntimeError('Symlink application path: ' + row['path'])
        raw = path.read_bytes()
        if {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} != expected:
            raise RuntimeError('Application ' + args.phase + ' differs: ' + row['path'])
workflow = (args.root / '.github/workflows/verify.yml').read_bytes()
if {'bytes':len(workflow),'sha256':hashlib.sha256(workflow).hexdigest()} != application['workflowUnchanged']:
    raise RuntimeError('Workflow changed')
print('PASS ' + args.phase + ': exact 27 application paths and unchanged workflow')
