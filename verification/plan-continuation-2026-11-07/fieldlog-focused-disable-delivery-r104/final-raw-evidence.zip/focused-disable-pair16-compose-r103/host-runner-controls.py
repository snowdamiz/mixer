#!/usr/bin/env python3
"""Exercise the CI runner's actual routing with controlled compiler/process leaves."""
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import sys
import tempfile
from unittest.mock import patch

OUT = Path(__file__).resolve().parent
P = OUT / 'projection'
tmp = OUT / 'host-control-tmp'
tmp.mkdir(exist_ok=False)
tempfile.tempdir = str(tmp)
results = []
try:
    for fail in (False, True):
        evidence = OUT / ('host-control-refusal' if fail else 'host-control-success')
        calls = []
        class Child:
            def __init__(self, argv, **kwargs):
                self.pid = 900000 + len(calls)
                calls.append(list(map(str, argv)))
            def wait(self, timeout):
                return 9 if fail and 'dev.mixer.android.FocusedDisableOwnerTransitionHostTests' in calls[-1] else 0
        def absent(*args):
            raise ProcessLookupError
        argv = [str(P / 'native/android/tests/run-public-surface-host.py'), '--java-home', '/controlled/no-compiler', '--evidence', str(evidence)]
        failed = False
        with patch('subprocess.Popen', Child), patch('os.killpg', absent), patch.object(sys, 'argv', argv):
            try:
                runpy.run_path(argv[0], run_name='__main__')
            except RuntimeError as error:
                if not fail or 'focused-disable-transition failed' not in str(error):
                    raise
                failed = True
        receipt = json.loads((evidence / 'result.json').read_bytes())
        if receipt['passed'] != (not fail) or failed != fail or len(calls) != 9:
            raise RuntimeError('Runner outcome differs')
        compile_call = next(c for c in calls if str(P / 'native/android/tests/FocusedDisableOwnerTransitionHostTests.java') in c)
        if compile_call[0] != '/controlled/no-compiler/bin/javac' or len([c for c in calls if c[0].endswith('/javac')]) != 2:
            raise RuntimeError('Existing two-compilation structure changed')
        focused = calls[-1]
        if focused[-3:] != ['dev.mixer.android.FocusedDisableOwnerTransitionHostTests', str(P / 'native/android/tests/FocusedDisableOwnerTransitionPackets'), 'candidate']:
            raise RuntimeError('Permanent regression dispatch differs')
        inputs = json.loads((evidence / 'focused-disable-packet-inputs.json').read_bytes())
        if len(inputs) != 4 or any(hashlib.sha256((P / p).read_bytes()).hexdigest() != digest for p,digest in inputs.items()):
            raise RuntimeError('Fixture evidence differs')
        scratch = Path(receipt['scratch'])
        if fail:
            if not scratch.is_relative_to(tmp) or not scratch.exists():
                raise RuntimeError('Failure scratch ownership differs')
            shutil.rmtree(scratch)
        elif scratch.exists() or not receipt['scratchRemoved']:
            raise RuntimeError('Successful cleanup differs')
        results.append({'failureInjected':fail,'commands':len(calls),'controlledCompiler':True,'actualJavaExecuted':False,'passed':True,'ownedScratchRemoved':True})
    (OUT / 'host-controls.json').write_text(json.dumps({'status':'PASS_RUNNER_WIRING_ONLY','controls':results,
        'scope':'Real candidate runner and file hashing; compiler, child wait and group absence are controlled leaves. No Java behavioral or compiler claim.'},indent=2)+'\n')
finally:
    tmp.rmdir()
print('PASS permanent focused regression compiler input, packet hashes, dispatch, failure propagation, and owned cleanup; controlled process leaves')
