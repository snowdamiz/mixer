#!/usr/bin/env python3
"""Existing policy and focused binding controls, in the candidate projection only."""
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest

OUT = Path(__file__).resolve().parent
P = OUT / 'projection'
mode = sys.argv[1]
binding = P / 'verification/plan-continuation-2026-11-07/source113-inspection-caller-r3'
(binding / 'control-scratch').mkdir(exist_ok=True)
tmp = OUT / 'test-tmp' / mode
tmp.mkdir(parents=True, exist_ok=True)
tempfile.tempdir = str(tmp)
os.environ['TMPDIR'] = str(tmp)
original_temporary = tempfile.TemporaryDirectory
def temporary(*args, **kwargs):
    if kwargs.get('dir') == '/tmp':
        kwargs['dir'] = tempfile.tempdir
    return original_temporary(*args, **kwargs)
tempfile.TemporaryDirectory = temporary
sys.dont_write_bytecode = True
sys.path.insert(0, str(P / 'cli/build-tests'))
sys.path.insert(0, str(binding))
print(json.dumps({'python': sys.version, 'optimize': sys.flags.optimize,
      'argv': sys.argv, 'scope': 'Candidate policy and pure binding; no compiler, device or consumer dispatch'}), flush=True)
policy = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('test_android_sdk_compatibility'))
# Install the existing strict binding guard only after the independent policy suite.
tempfile.tempdir = str(binding / 'control-scratch')
names = [
    'test_binding',
    'test_combined.MetadataDiagnostics.test_projected_installed_whole_job_is_exact_without_qualification',
    'test_combined.MetadataDiagnostics.test_actual_owner_bootstrap_116_and_profile24_27',
    'test_combined.MetadataDiagnostics.test_full_job_mutations_refuse',
    'test_combined.MetadataDiagnostics.test_diagnostic_reverse_precedes_exact_apple_and_guest_history',
    'test_combined.MetadataDiagnostics.test_qualification_boolean_types_refuse_resealed_numeric_aliases',
    'test_rebind.Rebinding.test_each_changed_frozen_source_is_refused',
    'test_source113.Source113.test_actual_owner_and_installed_candidate',
]
suite = unittest.defaultTestLoader.loadTestsFromNames(names)
result = unittest.TextTestRunner(verbosity=2).run(suite)
(binding / 'control-scratch').rmdir()
raise SystemExit(0 if policy.wasSuccessful() and result.wasSuccessful() else 1)
