from pathlib import Path
import json,os,subprocess,time
p=Path(__file__).parent;c=json.loads((p/'selection.json').read_text());owned=Path(c['owned']);root=p.resolve().parents[2]
e=os.environ.copy();swift='/Users/andreyyurlov/Library/Developer/Toolchains/swift-6.3.3-RELEASE.xctoolchain/usr/bin'
e.update(DEVELOPER_DIR='/Applications/Xcode_26.6.app/Contents/Developer',SDKROOT='/Applications/Xcode_26.6.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX26.5.sdk',JAVA_HOME='/opt/homebrew/opt/openjdk@25/libexec/openjdk.jdk/Contents/Home',MIXER_JDK='/opt/homebrew/opt/openjdk@25/libexec/openjdk.jdk/Contents/Home',ANDROID_HOME='/opt/homebrew/share/android-commandlinetools',TMPDIR=str(owned/'tmp')+'/',PATH='/Users/andreyyurlov/.t3/userdata/mixer-p15-cli-r87-6pqa_cns/bin:'+swift+':'+e['PATH'],SWIFT_EXEC=swift+'/swiftc')
argv=[c['CLI'],'build','--platform','android','--directory',c['project']];started=time.monotonic()
with (p/'stdout.log').open('wb') as out,(p/'stderr.log').open('wb') as err:
 child=subprocess.Popen(argv,cwd=root,env=e,stdout=out,stderr=err,start_new_session=True);row={'argv':argv,'pid':child.pid,'pgid':child.pid,'scope':c['scope']};(p/'command.json').write_text(json.dumps(row,indent=2)+'\n')
 try:code=child.wait(timeout=240)
 except subprocess.TimeoutExpired:
  row['state']='UNKNOWN';row['reason']='Distinct Android build outer deadline; preserve exact resources without retry/cleanup';(p/'HOLD.json').write_text(json.dumps(row,indent=2)+'\n');raise SystemExit(74)
try:os.killpg(child.pid,0);absent=False
except ProcessLookupError:absent=True
row.update(exitCode=code,groupAbsent=absent,seconds=time.monotonic()-started);(p/'result.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row))
