#!/usr/bin/env python3
"""Check the delivered afterimage map against actual bytes and write the handoff."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PROJ = Path(json.loads((OUT / 'scratch.json').read_bytes())['workspace'])
mapping = json.loads((OUT / 'application-map.json').read_bytes())


def ident(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def need(value, message):
    if not value:
        raise RuntimeError(message)


need(len(mapping['rows']) == 11 and not mapping['canonicalApplied'], 'Application scope differs')
for row in mapping['rows']:
    path = row['path']
    need(ident((ROOT / path).read_bytes()) == row['before'], 'Canonical preimage drift: ' + path)
    need(ident((OUT / row['beforeimage']).read_bytes()) == row['before'], 'Beforeimage drift: ' + path)
    need(ident((OUT / row['afterimage']).read_bytes()) == row['after'], 'Afterimage drift: ' + path)
    need((PROJ / path).read_bytes() == (OUT / row['afterimage']).read_bytes(), 'Tested projection differs: ' + path)
checker = PROJ / 'scripts/ci/check-android-generated-java.py'
spec = importlib.util.spec_from_file_location('r93_owner_final', checker)
owner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(owner)
profile = owner.load_profile(PROJ)
actual = owner.source_inputs(profile)
need(actual == json.loads((OUT / 'source-after.json').read_bytes()), 'Tested owning bytes changed')
need(len(actual) == 116 and owner.source_digest(actual) == mapping['sourceAfter'], 'Source116 digest differs')
commands = json.loads((OUT / 'control-commands.json').read_bytes())
need([r['label'] for r in commands] == ['actual-symbol-controls', 'normal', 'optimized'], 'Control run roster differs')
need(all(r['exit'] == 0 for r in commands), 'Failed controls')
for label, flag in [('normal', 0), ('optimized', 1)]:
    header = json.loads((OUT / (label + '.stdout.log')).read_text().splitlines()[0])
    need(header['optimize'] == flag, 'Actual optimization mode differs')
    log = (OUT / (label + '.stderr.log')).read_text()
    need('Ran 60 tests in ' in log and log.rstrip().endswith('OK'), 'Incomplete focused suite')
symbols = json.loads((OUT / 'actual-symbol-controls.json').read_bytes())
cleanup = json.loads((OUT / 'cleanup.json').read_bytes())
need(symbols['status'] == cleanup['status'] == 'PASS', 'Incomplete diagnostics/cleanup')
binding = json.loads((OUT / 'binding-checks.json').read_bytes())
need(binding['callerCount'] == 8 and binding['sealMembers'] == 32 and not binding['qualificationPromoted'], 'Binding scope differs')
handoff = {
    'status': 'READY_FOR_ROOT_INDEPENDENT_REVIEW_AND_APPLICATION',
    'applicationMap': 'application-map.json', 'applicationPaths': 11,
    'patch': {'path': 'product.patch', **ident((OUT / 'product.patch').read_bytes())},
    'sourceBefore': mapping['sourceBefore'], 'sourceAfter': mapping['sourceAfter'],
    'sourceCount': 116, 'changedOwningPaths': binding['changedOwningPaths'],
    'driver': mapping['rows'][0],
    'profile': mapping['profile'], 'sdk': mapping['sdk'], 'adapter': mapping['adapter'],
    'javaSources': len(owner.java_roster(profile)),
    'sameOriginalPair14ToFinalPair15': True, 'typedHistoryUnchanged': True,
    'callerCount': 8, 'sealMembers': 32, 'fullCallerIdentityGuardPreserved': True,
    'baseline': 'Original check rejects actual R91 official nm output for missing AppFeatures; baseline.json retained.',
    'tests': {'normal': 60, 'actualOptimized': 60, 'actualSymbolAndClassControls': symbols['count'],
              'commands': 'control-commands.json', 'bindingChecks': 'binding-checks.json'},
    'tools': {'python': sys.version, 'llvmNm': (OUT / 'version-nm.stdout').read_text().strip(),
              'compilerPolicyUnchanged': 'JDK25 --release17; no JDK or Swift compiler invoked'},
    'harnessCorrections': 1, 'harnessFailurePreserved': 'harness-correction.txt',
    'cleanup': 'Owned temporary test directory empty; both suites and diagnostic commands exited 0. Projection and finite frozen inputs retained in owned userdata.',
    'timedControlsSeconds': cleanup['activeSeconds'],
    'canonicalApplied': False, 'canonicalPreimagesStillMatch': True,
    'hostCompiles': 0, 'androidCompiles': 0, 'deviceCommands': 0,
    'gitMutations': 0, 'pushes': 0, 'ciDispatches': 0, 'childrenDelegated': 0,
    'qualificationPromoted': False,
    'pendingRootWork': ['Independent slice review', 'Apply exact 11-path map to matching preimages',
                        'Refresh cached CLI resource', 'Full actual consumer build', 'Emulator behavior'],
    'limitations': 'Read-only ELF symbols plus Python controls do not qualify feature behavior, native runtime, a successful APK build, published packages, release or GA.'}
(OUT / 'handoff.json').write_text(json.dumps(handoff, indent=2) + '\n')
text = f'''The public-v3 build check now requires the exact exported public C ABI and JNI_OnLoad, independent of app-owned Swift module names. The legacy required markers and receipt wording are unchanged. Public receipt.scope describes app-owned Swift and inspected ABI/JNI/APK structure, without a feature-behavior claim.

Apply only the 11 paths in application-map.json after independent review. Each beforeimage, afterimage and tested projection file matches its recorded identity; canonical preimages still match. product.patch is the corresponding unified patch. Canonical application, cached CLI update, full consumer build and emulator execution belong to root and remain pending.

Original R91 ELF output from official LLVM nm 18.0.4 reproduces the AppFeatures failure (baseline.json). The candidate accepts that actual output. {symbols['count']} diagnostic controls pass, including removed/renamed public exports, injected private exports, missing/renamed JNI_OnLoad, unchanged public/legacy DEX checks and receipt scope. DEX controls use controlled dump text, not a new Android run. The existing focused public-host/compatibility/appearance/staging suite plus six symbol tests passes 60/60 normally and 60/60 under actual -O (optimize=1, inherited PYTHONOPTIMIZE=1). One AST diagnostic harness selection error and its correction are preserved in harness-correction.txt; product bytes were unchanged. Timed controls completed in {cleanup['activeSeconds']:.3f} seconds; owned temporary test files are cleaned.

Source116: {mapping['sourceBefore']} -> {mapping['sourceAfter']}
Driver SHA256: {mapping['rows'][0]['after']['sha256']}
Profile15 / SDK24 a689f5653ff2d353e3b0ae202ee6169d64c03448a56ec1d5fee389a9a8ff536f / adapter27 335467770aaa3b163124ea306b148abca0db931175df6207bbd52d54c71ef362 are unchanged; 21 Java sources, JDK25 --release17 policy unchanged. Only the driver row changes in the 116 owning inputs. R88's refresh lever preserves the original typed Pair14 -> final Pair15 transition and all historical typed history, all 8 callers and 32 members, and full caller identity equality guards. No Pair16, reprofile or qualification promotion.

Zero host/Android compiles, Git mutations, pushes, CI dispatches, device/ADB/signing actions or delegated children. No canonical application or full-build PASS is claimed. No runtime, published-package, release or GA qualification is claimed.
'''
(OUT / 'HANDOFF.md').write_text(text)
print(json.dumps({'status': handoff['status'], 'sourceAfter': mapping['sourceAfter'],
    'applicationPaths': 11, 'tests': handoff['tests'], 'canonicalPreimagesStillMatch': True}))
