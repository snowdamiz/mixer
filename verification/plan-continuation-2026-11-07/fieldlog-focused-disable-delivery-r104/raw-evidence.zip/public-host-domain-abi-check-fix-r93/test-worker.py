#!/usr/bin/env python3
"""Run existing unittest controls, confining their temporary files to userdata."""
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import unittest

OUT = Path(__file__).resolve().parent
selection = json.loads((OUT / 'scratch.json').read_bytes())
owned = Path(selection['owned'])
projection = Path(selection['workspace'])
os.environ['TMPDIR'] = str(owned / 'tmp')
tempfile.tempdir = str(owned / 'tmp')
original_temporary = tempfile.TemporaryDirectory


def temporary(*args, **kwargs):
    if kwargs.get('dir') == '/tmp':
        kwargs['dir'] = os.environ['TMPDIR']
    return original_temporary(*args, **kwargs)


tempfile.TemporaryDirectory = temporary
os.chdir(owned / 'tmp')
# Darwin sockaddr_un has a short pathname limit. Use the same owned filesystem
# socket via its relative name; product inputs and assertions remain unchanged.
original_bind = socket.socket.bind


def bind(endpoint, address):
    if endpoint.family == socket.AF_UNIX and isinstance(address, str) and address.startswith(str(owned) + '/'):
        address = os.path.relpath(address)
    return original_bind(endpoint, address)


socket.socket.bind = bind
sys.path.insert(0, str(projection / 'cli/build-tests'))
print(json.dumps({'python': sys.version, 'optimize': sys.flags.optimize,
    'argv': sys.argv, 'temporaryRoot': tempfile.tempdir,
    'scope': 'Python controls only; no compiler, SDK inspect, device or signing dispatch'}), flush=True)
unittest.main(module=None, argv=[sys.argv[0], '-v', 'test_android_public_host',
    'test_android_sdk_compatibility', 'test_android_appearance', 'test_android_staging'])
