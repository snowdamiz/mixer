#!/usr/bin/env python3
"""Exercise the candidate on official R91 nm output; no rebuild or device use."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
selection = json.loads((OUT / 'scratch.json').read_bytes())
PROJ = Path(selection['workspace'])
DRIVER = 'cli/Sources/MixerBuild/Resources/android-build.py'
spec = importlib.util.spec_from_file_location('r93_candidate', PROJ / DRIVER)
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
symbols = (OUT / 'engine-nm.stdout').read_text()
jni = (OUT / 'jni-nm.stdout').read_text()
checks = []


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def rejects(name, function, message):
    try:
        function()
    except RuntimeError as error:
        require(message in str(error), name + ': different refusal: ' + str(error))
        checks.append({'name': name, 'status': 'PASS', 'error': str(error)})
    else:
        raise RuntimeError(name + ': unexpectedly accepted')


candidate.check_native_symbols(symbols, True, jni)
checks.append({'name': 'actual R91 FieldLog engine + JNI accepted', 'status': 'PASS'})
for name in ('mixer_public_android_submit', 'mixer_public_android_poll'):
    for replacement in ('', name + '_suffix', 'prefix_' + name):
        altered = '\n'.join(line.replace(name, replacement) for line in symbols.splitlines())
        rejects('actual engine C export ' + name + ' -> ' + repr(replacement),
            lambda: candidate.check_native_symbols(altered, True, jni), 'Public Android C ABI')
for name in ('mixer_android_create', 'mixer_android_future_private'):
    rejects('actual engine injected ' + name,
        lambda: candidate.check_native_symbols(symbols + '\n0000 T ' + name, True, jni), 'private legacy exports')
for replacement in ('', 'JNI_OnLoad_suffix', 'prefix_JNI_OnLoad'):
    rejects('actual JNI entry -> ' + repr(replacement),
        lambda: candidate.check_native_symbols(symbols, True, jni.replace('JNI_OnLoad', replacement)), 'JNI registration entry')

before = (OUT / 'beforeimages' / DRIVER).read_text()
after = (PROJ / DRIVER).read_text()
start, end = "    dex_dump = run(", "    symbols = run("
dex_before = before[before.index(start):before.index(end)]
dex_after = after[after.index(start):after.index(end)]
require(dex_before == dex_after, 'DEX class contract changed')
for public in (False, True):
    application = 'app.fieldlog.real'
    descriptors = (['Lapp/fieldlog/real/androidhost/PublicActivity;', 'Lapp/fieldlog/real/androidhost/PublicBridge;',
                    'Ldev/mixer/android/AndroidUINativeSurface;', 'Ldev/mixer/android/NativeRenderer;'] if public else
                   ['Ldev/mixer/android/MixerActivity;', 'Ldev/mixer/android/NativeBridge;', 'Ldev/mixer/android/NativeRenderer;'])

    def check_dex(text):
        exec(compile('if True:\n' + dex_after, '<unchanged-build-dex-check>', 'exec'),
             {'public': public, 'config': {'application': application}, 'run': lambda argv: text,
              'BT': Path('/unused'), 'dex': Path('/unused')})

    check_dex('\n'.join(descriptors))
    checks.append({'name': ('public' if public else 'legacy') + ' DEX class acceptance', 'status': 'PASS'})
    for descriptor in descriptors:
        rejects('missing DEX ' + descriptor,
            lambda: check_dex('\n'.join(d for d in descriptors if d != descriptor)), 'Required owned Android class absent')
    if public:
        rejects('public DEX injected legacy Activity',
            lambda: check_dex('\n'.join(descriptors + ['Ldev/mixer/android/MixerActivity;'])), 'legacy Activity')

# Evaluate the receipt field itself, without fabricating a successful build.
tree = ast.parse(after)
build = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'build')
receipt = next(n.value for n in ast.walk(build) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'receipt' for t in n.targets))
scope = next(v for k, v in zip(receipt.keys, receipt.values) if isinstance(k, ast.Constant) and k.value == 'scope')
evaluate = lambda public: eval(compile(ast.Expression(scope), '<actual-receipt-scope>', 'eval'), {'public': public})
require('App-owned Swift, public C ABI/JNI' in evaluate(True) and 'AppModels/AppFeatures' not in evaluate(True), 'Public scope misstates ownership')
old_tree = ast.parse(before)
old_build = next(n for n in old_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'build')
old_receipt = next(n.value for n in ast.walk(old_build) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'receipt' for t in n.targets))
old_scope = next(v for k, v in zip(old_receipt.keys, old_receipt.values) if isinstance(k, ast.Constant) and k.value == 'scope')
require(evaluate(False) == ast.literal_eval(old_scope), 'Legacy receipt scope changed')
checks.append({'name': 'actual receipt scope expressions: public ownership and unchanged legacy text', 'status': 'PASS'})
result = {'status': 'PASS', 'checks': checks, 'count': len(checks),
    'python': sys.version, 'optimize': sys.flags.optimize,
    'driverSHA256': hashlib.sha256(after.encode()).hexdigest(),
    'publicScope': evaluate(True), 'legacyScope': evaluate(False),
    'scope': 'Actual R91 ELF symbol acceptance and mutated text refusals; unchanged DEX check on controlled dump text. No feature/runtime/GA or full-build qualification.',
    'builds': 0}
(OUT / 'actual-symbol-controls.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': 'PASS', 'checks': len(checks), 'driverSHA256': result['driverSHA256']}))
