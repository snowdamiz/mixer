#!/usr/bin/env python3
"""Prepare a finite R88-based projection; canonical files are read only."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
R88 = OUT.parent / 'public-host-legacy-refusal-order-fix-r88'
DRIVER = 'cli/Sources/MixerBuild/Resources/android-build.py'
TEST = 'cli/build-tests/test_android_public_host.py'


def ident(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)


def dump(path, value):
    save(path, (json.dumps(value, indent=2) + '\n').encode())


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


owned = Path(tempfile.mkdtemp(prefix='r93-', dir='/Users/andreyyurlov/.t3/userdata'))
proj = owned / 'source'
(owned / 'tmp').mkdir()
dump(OUT / 'scratch.json', {'owned': str(owned), 'workspace': str(proj)})
inputs = json.loads((R88 / 'refresh-inputs.json').read_bytes())
rows = json.loads((R88 / 'application-map.json').read_bytes())['rows']
expected = {**inputs, **{r['path']: r['after'] for r in rows}}
frozen = {}
for path, identity in expected.items():
    need(not any(s in path for s in ('cache-r8', 'resumption-latest', '/scratch/', 'HOLD')), 'Excluded input')
    raw = (ROOT / path).read_bytes()
    need(ident(raw) == identity, 'Live finite R88 input differs: ' + path)
    frozen[path] = raw
    save(proj / path, raw)
dump(OUT / 'frozen-inputs.json', {p: ident(v) for p, v in frozen.items()})

# Official read-only inspection of the existing R91 output, without a build.
spec = importlib.util.spec_from_file_location('r93_original', proj / DRIVER)
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)
nm = original.NDK / 'bin/llvm-nm'
r91 = Path(json.loads((OUT.parent / 'fieldlog-generated-android-build-r91/selection.json').read_bytes())['project'])
lib = r91 / '.mixer/android-build/apk/lib/arm64-v8a'
observations = []
for label, args in [('version', [str(nm), '--version']),
                    ('engine', [str(nm), '-D', '--defined-only', str(lib / 'libAppAndroid.so')]),
                    ('jni', [str(nm), '-D', '--defined-only', str(lib / 'libmixer_public_android_jni.so')])]:
    start = time.monotonic()
    result = subprocess.run(args, capture_output=True, timeout=15)
    save(OUT / (label + '-nm.stdout'), result.stdout)
    save(OUT / (label + '-nm.stderr'), result.stderr)
    observations.append({'argv': args, 'exit': result.returncode, 'seconds': time.monotonic() - start})
    need(result.returncode == 0, 'Official nm failed')
dump(OUT / 'nm-commands.json', observations)
symbols = (OUT / 'engine-nm.stdout').read_text()
jni_symbols = (OUT / 'jni-nm.stdout').read_text()
need(all(n in symbols for n in ('FieldLogFeatures', 'FieldLogModels', 'FieldLogStorage')), 'Actual FieldLog domain markers absent')
need(all(n not in symbols for n in ('AppFeatures', 'AppModels')), 'Prototype domain unexpectedly present')
raw = frozen[DRIVER].decode()
start = raw.index('    required_symbols = ')
end = raw.index('    with zipfile.ZipFile(apk_path) as archive:', start)
old_block = raw[start:end]
baseline = {'symbols': symbols, 'public': True, 'run': lambda argv: jni_symbols,
            'NDK': original.NDK, 'libdir': lib, 'jni_library': 'libmixer_public_android_jni.so'}
try:
    exec(compile('if True:\n' + old_block, '<original-build-symbol-check>', 'exec'), baseline)
except RuntimeError as error:
    need(str(error) == 'App shared feature/model or ABI symbol missing: AppFeatures', 'Different baseline failure')
    dump(OUT / 'baseline.json', {'status': 'EXPECTED_FAILURE', 'error': str(error),
        'method': 'Unmodified original build symbol-check block executed on official R91 nm output',
        'engine': {'path': str(lib / 'libAppAndroid.so'), **ident((lib / 'libAppAndroid.so').read_bytes())},
        'jni': {'path': str(lib / 'libmixer_public_android_jni.so'), **ident((lib / 'libmixer_public_android_jni.so').read_bytes())},
        'source': ident(frozen[DRIVER]), 'rebuilds': 0})
else:
    raise RuntimeError('Baseline unexpectedly passed')

helper = '''def check_native_symbols(symbols, public, jni_symbols=''):
    if public:
        exported = {line.split()[-1] for line in symbols.splitlines() if line.split()}
        if not {'mixer_public_android_submit', 'mixer_public_android_poll'}.issubset(exported) or any(name.startswith('mixer_android_') for name in exported):
            raise RuntimeError('Public Android C ABI is missing or contains private legacy exports.')
        if 'JNI_OnLoad' not in {line.split()[-1] for line in jni_symbols.splitlines() if line.split()}:
            raise RuntimeError('Public Android JNI registration entry is missing.')
        return
    required_symbols = ['mixer_android_create', 'mixer_android_exchange', 'mixer_android_destroy', 'mixer_android_prepare_v2', 'mixer_android_commit_v2', 'mixer_android_abort_v2', 'AppFeatures', 'AppModels']
    for symbol in required_symbols:
        if symbol not in symbols:
            raise RuntimeError('App shared feature/model or ABI symbol missing: ' + symbol)


'''
build_start = raw.index('def build(')
raw = raw[:build_start] + helper + raw[build_start:]
new_block = '''    jni_symbols = run([NDK / 'bin/llvm-nm', '-D', '--defined-only', libdir / jni_library]) if public else ''
    check_native_symbols(symbols, public, jni_symbols)
'''
need(raw.count(old_block) == 1, 'Symbol block ambiguous')
raw = raw.replace(old_block, new_block)
old_scope = "'scope': 'Actual generated AppModels/AppFeatures Swift, owned JNI/native widgets, arm64 Android APK inspected. Unsigned; no install, device interaction, lifecycle, accessibility, performance, published SDK, store or FieldLog qualification.',"
new_scope = "'scope': ('App-owned Swift, public C ABI/JNI registration, owned native widgets, arm64 Android APK inspected.' if public else 'Actual generated AppModels/AppFeatures Swift, owned JNI/native widgets, arm64 Android APK inspected.') + ' Unsigned; no install, device interaction, lifecycle, accessibility, performance, published SDK, store or FieldLog qualification.',"
need(raw.count(old_scope) == 1, 'Scope ambiguous')
raw = raw.replace(old_scope, new_scope)
save(proj / DRIVER, raw.encode())
save(OUT / 'driver-helper.txt', helper.encode())

tests = '''

class NativeSymbolContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.module = load_driver(DRIVER, 'native_symbol_contract')

    public_symbols = '0000 T mixer_public_android_submit\\n0001 T mixer_public_android_poll\\n0002 T $s16FieldLogFeatures5StateV\\n0003 T $s14FieldLogModels5EntryV\\n'
    jni_symbols = '0000 T JNI_OnLoad\\n'
    legacy_names = ('mixer_android_create', 'mixer_android_exchange', 'mixer_android_destroy',
                    'mixer_android_prepare_v2', 'mixer_android_commit_v2', 'mixer_android_abort_v2',
                    'AppFeatures', 'AppModels')

    def test_public_accepts_app_owned_domain_and_no_domain_markers(self):
        self.module.check_native_symbols(self.public_symbols, True, self.jni_symbols)
        self.module.check_native_symbols('0000 T mixer_public_android_submit\\n0001 T mixer_public_android_poll\\n', True, self.jni_symbols)

    def test_public_requires_each_exact_c_export(self):
        for name in ('mixer_public_android_submit', 'mixer_public_android_poll'):
            for replacement in ('', name + '_suffix', 'prefix_' + name):
                with self.subTest(name=name, replacement=replacement):
                    with self.assertRaisesRegex(RuntimeError, 'Public Android C ABI'):
                        self.module.check_native_symbols(self.public_symbols.replace(name, replacement), True, self.jni_symbols)

    def test_public_rejects_every_legacy_export(self):
        for name in self.legacy_names[:6] + ('mixer_android_future_private',):
            with self.subTest(name=name):
                with self.assertRaisesRegex(RuntimeError, 'private legacy exports'):
                    self.module.check_native_symbols(self.public_symbols + '0004 T ' + name + '\\n', True, self.jni_symbols)

    def test_public_requires_exact_jni_registration_entry(self):
        for symbols in ('', '0000 T JNI_OnLoad_suffix\\n', '0000 T prefix_JNI_OnLoad\\n'):
            with self.subTest(symbols=symbols):
                with self.assertRaisesRegex(RuntimeError, 'JNI registration entry'):
                    self.module.check_native_symbols(self.public_symbols, True, symbols)

    def test_legacy_preserves_all_original_required_markers(self):
        symbols = '\\n'.join('0000 T ' + name for name in self.legacy_names)
        self.module.check_native_symbols(symbols, False)
        for name in self.legacy_names:
            with self.subTest(name=name):
                with self.assertRaisesRegex(RuntimeError, 'App shared feature/model or ABI symbol missing: ' + name):
                    self.module.check_native_symbols(symbols.replace(name, ''), False)

    def test_legacy_still_accepts_swift_mangling_substrings(self):
        symbols = '\\n'.join('0000 T ' + name for name in self.legacy_names[:6])
        self.module.check_native_symbols(symbols + '\\n0000 T $s11AppFeatures5StateV\\n0000 T $s9AppModels5EntryV', False)
'''
test_raw = frozen[TEST].decode()
need(test_raw.count("if __name__ == '__main__':") == 1, 'Test entry ambiguous')
save(proj / TEST, test_raw.replace("if __name__ == '__main__':", tests + "\n\nif __name__ == '__main__':").encode())

# Reuse R88's existing refresh algorithm against this exact live projection.
refresh = (R88 / 'refresh.py').read_text()
a = refresh.index('R85=OUT.parent/')
b = refresh.index('# Exact frozen manifest', a)
header = '''ROOT=OUT.parents[2]
R85=OUT.parent/'public-batch-clear-final-bindings-r85'
V='verification/plan-continuation-2026-11-07/'
B=V+'source113-inspection-caller-r3/'
BOOT=V+'generated-java-ci-integration/bootstrap.py'
DRIVER='cli/Sources/MixerBuild/Resources/android-build.py'
TEST='cli/build-tests/test_android_public_host.py'
OLD='3cd790bcd01dcf406ad2935d810b2fbbe7ab126c1e90efa032c3a92a62cc1e07'
spec=importlib.util.spec_from_file_location('r85_compose',R85/'compose.py')
lever=importlib.util.module_from_spec(spec);spec.loader.exec_module(lever)
ident,enc,save,need=lever.ident,lever.enc,lever.save,lever.need
R88=OUT.parent/'public-host-legacy-refusal-order-fix-r88'
M=json.loads((R88/'application-map.json').read_bytes())
I={'sdk':M['sdk'],'adapter':M['adapter']}
PROJ=Path(json.loads((OUT/'scratch.json').read_bytes())['workspace'])
FROZEN=PROJ.parent/'frozen'
inputs=json.loads((OUT/'frozen-inputs.json').read_bytes())
rows={r['path']:r for r in M['rows']}
source=json.loads((ROOT/B/'source-inputs.json').read_bytes())
readmap={}
def frozen(path):
    need(path in inputs,'Outside finite live R88 input roster: '+path)
    raw=(FROZEN/path).read_bytes()
    need(ident(raw)==inputs[path],'Frozen live input drift: '+path)
    readmap[path]=ident(raw)
    return raw
'''
refresh = refresh[:a] + header + refresh[b:]
refresh = refresh.replace("transition['sourceBefore']==M['sourceBefore']", "transition['sourceBefore']==M['pair15OriginalSourceBefore']")
refresh = refresh.replace('EXACT_FROZEN_R85_ALREADY_APPLIED', 'EXACT_LIVE_R88_APPLIED')
refresh = refresh.replace('"""R85 compose/finalize refresh for the same direct Pair14 -> final Pair15."""', '"""Reuse R88 refresh for the same original Pair14 -> final Pair15."""')
save(OUT / 'refresh.py', refresh.encode())
for path, value in frozen.items():
    save(owned / 'frozen' / path, value)
dump(OUT / 'preparation.json', {'status': 'PASS', 'finiteInputs': len(frozen),
    'engineRevisionProvidedByRoot': '6d2648e4360eeff2527d12792c2b718df512d704',
    'python': sys.version, 'canonicalMutations': 0, 'builds': 0,
    'discoveryCleanup': 'Two path-only rg file listings terminated with exact command matching; both exec sessions collected terminal.'})
print(json.dumps({'owned': str(owned), 'finiteInputs': len(frozen), 'baseline': 'EXPECTED_FAILURE', 'ready': 'refresh + tests'}))
