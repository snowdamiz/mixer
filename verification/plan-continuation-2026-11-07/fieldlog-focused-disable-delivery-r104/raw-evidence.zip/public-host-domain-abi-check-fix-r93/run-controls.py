#!/usr/bin/env python3
"""One normal and one actual -O run within the lane's 180-second test budget."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
start = time.monotonic()
records = []
for label, script, options in [('actual-symbol-controls', 'actual-symbol-controls.py', []),
                               ('normal', 'test-worker.py', []),
                               ('optimized', 'test-worker.py', ['-O'])]:
    argv = [sys.executable, '-B', *options, str(OUT / script)]
    env = os.environ.copy()
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env.pop('PYTHONOPTIMIZE', None)
    if options:
        env['PYTHONOPTIMIZE'] = '1'
    remaining = min(60, 180 - (time.monotonic() - start))
    if remaining <= 0:
        raise RuntimeError('Active budget exhausted')
    before = time.monotonic()
    with (OUT / (label + '.stdout.log')).open('wb') as stdout, (OUT / (label + '.stderr.log')).open('wb') as stderr:
        result = subprocess.run(argv, env=env, stdout=stdout, stderr=stderr, timeout=remaining)
    record = {'label': label, 'argv': argv, 'python': sys.version, 'exit': result.returncode,
        'seconds': time.monotonic() - before,
        'PYTHONOPTIMIZE': env.get('PYTHONOPTIMIZE'),
        'stdout': label + '.stdout.log', 'stderr': label + '.stderr.log'}
    records.append(record)
    (OUT / 'control-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if result.returncode:
        raise RuntimeError('Control failed: ' + label)
selection = json.loads((OUT / 'scratch.json').read_bytes())
leftovers = list((Path(selection['owned']) / 'tmp').iterdir())
if leftovers:
    raise RuntimeError('Test scratch remains: ' + str(leftovers))
(OUT / 'cleanup.json').write_text(json.dumps({'status': 'PASS', 'temporaryTestChildren': [],
    'userdataTemporaryRootEmpty': True, 'projectionAndFrozenInputsRetainedForRoot': True,
    'activeSeconds': time.monotonic() - start, 'activeLimitSeconds': 180, 'cleanupLimitSeconds': 30,
    'hostCompiles': 0, 'androidCompiles': 0, 'devices': 0, 'heldResourcesAccessed': False}, indent=2) + '\n')
