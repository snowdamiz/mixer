#!/usr/bin/env python3
"""Reuse R88 refresh for the same original Pair14 -> final Pair15."""
import ast,copy,difflib,hashlib,importlib.util,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
R85=OUT.parent/'public-batch-clear-final-bindings-r85'
V='verification/plan-continuation-2026-11-07/'
B=V+'source113-inspection-caller-r3/'
BOOT=V+'generated-java-ci-integration/bootstrap.py'
DRIVER='cli/Sources/MixerBuild/Resources/android-build.py'
TEST='cli/build-tests/test_android_public_host.py'
OLD='3cd790bcd01dcf406ad2935d810b2fbbe7ab126c1e90efa032c3a92a62cc1e07'
spec=importlib.util.spec_from_file_location('r85_compose',R85/'compose.py')
lever=importlib.util.module_from_spec(spec);spec.loader.exec_module(lever)
ident,enc,save,need=lever.ident,lever.enc,lever.save,lever.need
R88=OUT.parent/'public-host-legacy-refusal-order-fix-r88'
M=json.loads((R88/'application-map.json').read_bytes())
I={'sdk':M['sdk'],'adapter':M['adapter']}
PROJ=Path(json.loads((OUT/'scratch.json').read_bytes())['workspace'])
FROZEN=PROJ.parent/'frozen'
inputs=json.loads((OUT/'frozen-inputs.json').read_bytes())
rows={r['path']:r for r in M['rows']}
source=json.loads((ROOT/B/'source-inputs.json').read_bytes())
readmap={}
def frozen(path):
    need(path in inputs,'Outside finite live R88 input roster: '+path)
    raw=(FROZEN/path).read_bytes()
    need(ident(raw)==inputs[path],'Frozen live input drift: '+path)
    readmap[path]=ident(raw)
    return raw
# Exact frozen manifest, not directory discovery. Keep the two owned corrected files.
changes={p:(PROJ/p).read_bytes() for p in (DRIVER,TEST)}
for path in sorted(set(inputs)|set(rows)|set(source)):
    raw=frozen(path)
    save(PROJ/path,changes.get(path,raw))
owner=lever.module(PROJ/'scripts/ci/check-android-generated-java.py')
profile=owner.load_profile(PROJ)
actual=owner.source_inputs(profile)
need(len(actual)==116 and set(actual)==set(source),'Owning source116 roster changed')
need([p for p in actual if actual[p]!=source[p]]==[DRIVER],'Unexpected owning source change')
current=owner.source_digest(actual)
need(current!=OLD and current==hashlib.sha256(''.join(p+'\0'+actual[p]['sha256']+'\n' for p in sorted(actual)).encode()).hexdigest(),'Owning digest must derive from actual bytes')
changes[B+'source-inputs.json']=enc(actual)
binding=json.loads(frozen(B+'binding.json'));history=copy.deepcopy(binding)
transition=binding['pair15_transition'];prior=copy.deepcopy(transition)
need(transition['sourceAfter']==OLD and transition['sourceBefore']==M['pair15OriginalSourceBefore'],'Pair15 original predecessor differs')
transition['sourceAfter']=current
for row in transition['owningChanges']:
    if row['path']==DRIVER:row['after']=ident(changes[DRIVER])
binding['source']['sha256']=current
changes[B+'binding.json']=enc(binding)
for path in (BOOT,B+'test_combined.py',B+'test_rebind.py',B+'test_source113.py'):
    raw=frozen(path).decode();need(raw.count(OLD)>0,'Missing prior owning literal: '+path)
    changes[path]=raw.replace(OLD,current).encode()
callers=json.loads(frozen(B+'caller-inputs.json'))
need(len(callers)==8,'Eight-caller roster changed')
for row in callers:
    need(ident(frozen(row['path']))=={k:row[k] for k in ('bytes','sha256')},'Caller prior differs')
    if row['path'] in changes:row.update(ident(changes[row['path']]))
changes[B+'caller-inputs.json']=enc(callers)
adopter=frozen(B+'adopt_envelope.py').decode()
def literal(text,name):
    node=next(n for n in ast.parse(text).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
    return node,ast.literal_eval(node.value)
node,value=literal(adopter,'PAIR15_TRANSITION');need(value==prior,'Original Pair15 literal differs')
lines=adopter.splitlines(True);start=sum(map(len,lines[:node.lineno-1]));end=sum(map(len,lines[:node.end_lineno]))
adopter=adopter[:start]+'PAIR15_TRANSITION = '+repr(transition)+'\n'+adopter[end:]
need(adopter.count(OLD)==1,'Only current admission digest remains')
adopter=adopter.replace(OLD,current)
old_caller=ident(frozen(B+'caller-inputs.json'));new_caller=ident(changes[B+'caller-inputs.json'])
old_pin="len(caller_raw) == "+str(old_caller['bytes'])+" and hashlib.sha256(caller_raw).hexdigest() == '"+old_caller['sha256']+"'"
new_pin="len(caller_raw) == "+str(new_caller['bytes'])+" and hashlib.sha256(caller_raw).hexdigest() == '"+new_caller['sha256']+"'"
need(adopter.count(old_pin)==1,'Exact eight-caller equality admission missing')
adopter=adopter.replace(old_pin,new_pin)
for name in ('PAIR11_TRANSITION','PAIR12_TRANSITION','PAIR13_TRANSITION','PAIR14_TRANSITION'):
    need(literal(adopter,name)[1]==literal(frozen(B+'adopt_envelope.py').decode(),name)[1],'Typed historical literal changed')
need('PAIR16_TRANSITION' not in adopter,'Pair16 forbidden')
changes[B+'adopt_envelope.py']=adopter.encode()
seal=json.loads(frozen(B+'seal.json'))
need(seal['member_count']==len(seal['members'])==32,'32-member seal changed')
for row in seal['members']:
    path=B+row['path'];need(ident(frozen(path))=={k:row[k] for k in ('bytes','sha256')},'Sealed prior differs')
    row.update(ident(changes.get(path,frozen(path))))
seal['tree_sha256']=hashlib.sha256(json.dumps(seal['members'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
changes[B+'seal.json']=enc(seal)
patch=[];result=[]
for path,raw in sorted(changes.items()):
    old=frozen(path);need(raw!=old,'Unchanged afterimage: '+path)
    save(OUT/'beforeimages'/path,old);save(OUT/'afterimages'/path,raw);save(PROJ/path,raw)
    result.append({'path':path,'before':ident(old),'after':ident(raw),'beforeimage':'beforeimages/'+path,'afterimage':'afterimages/'+path})
    patch.extend(difflib.unified_diff(old.decode().splitlines(True),raw.decode().splitlines(True),fromfile='a/'+path,tofile='b/'+path))
need(owner.source_inputs(owner.load_profile(PROJ))==actual,'Owning bytes changed during caller refresh')
for path in set(inputs)|set(rows):
    # All current owning digest propagation in the finite existing projection.
    need(OLD.encode() not in (PROJ/path).read_bytes(),'Stale current digest: '+path)
need({k:v for k,v in binding.items() if k not in ('source','pair15_transition')}=={k:v for k,v in history.items() if k not in ('source','pair15_transition')},'Historical/security binding changed')
for key in ('profileBefore','profileAfter','sourceBefore','sourceCountBefore','sourceCountAfter','rawPredecessors','qualification','actualSixConsumers','nativePass','runtimePass','gaPass'):
    need(transition[key]==prior[key],'Pair15 contract changed: '+key)
for row in seal['members']:
    need(ident((PROJ/B/row['path']).read_bytes())=={k:row[k] for k in ('bytes','sha256')},'Seal afterimage mismatch')
for row in callers:
    need(ident((PROJ/row['path']).read_bytes())=={k:row[k] for k in ('bytes','sha256')},'Caller afterimage mismatch')
application={'schema':1,'basis':'EXACT_LIVE_R88_APPLIED','sourceBefore':OLD,'sourceAfter':current,'sourceCountBefore':116,'sourceCountAfter':116,'pair15OriginalSourceBefore':prior['sourceBefore'],'profile':profile['id'],'sdk':I['sdk'],'adapter':I['adapter'],'rows':result,'canonicalApplied':False}
save(OUT/'application-map.json',enc(application));save(OUT/'product.patch',''.join(patch).encode());save(OUT/'source-after.json',enc(actual));save(OUT/'refresh-inputs.json',enc(readmap))
save(OUT/'binding-checks.json',enc({'status':'PASS','actualOwningInputs':116,'changedOwningPaths':[DRIVER],'sameOriginalPair14ToFinalPair15':True,'priorTypedHistoryUnchanged':True,'securityBindingUnchanged':True,'sdk24Adapter27ProfileUnchanged':True,'callerCount':8,'sealMembers':32,'allCallerAndSealBytesEqual':True,'noOldCurrentDigestInFiniteProjection':True,'qualificationPromoted':False}))
print(json.dumps({'sourceAfter':current,'applicationPaths':len(result),'driverAfter':ident(changes[DRIVER]),'callerAfter':new_caller,'sealAfter':ident(changes[B+'seal.json'])}))
