Select a distinct Android build under root ownership. R90 used both permitted host compiler invocations and does not run another build.

1. Extract FieldLog-generated-public-host-r90-source.zip into a fresh root-owned userdata directory. Keep the frozen R90 source and library unchanged. The archive contains the complete FieldLogGenerated project and its admitted local SDK/adapter snapshots.
2. Use the retained CLI /Users/andreyyurlov/.t3/userdata/mixer-p15-cli-r87-6pqa_cns/build/debug/mixer. Set MIXER_JDK and JAVA_HOME to /opt/homebrew/opt/openjdk@25/libexec/openjdk.jdk/Contents/Home. Use the Swift 6.3.3 toolchain, Xcode_26.6 DEVELOPER_DIR and macOS26.5 SDKROOT recorded in create-command.json. Keep build temporary/cache paths in that fresh owned namespace. The Swift --version shim in /Users/andreyyurlov/.t3/userdata/fieldlog-generated-host-r90-f0odqzb9/bin reproduces the successful create environment.
3. Run the following command with PROJECT set to the extracted FieldLogGenerated directory. This command has not run in R90.

```sh
/Users/andreyyurlov/.t3/userdata/mixer-p15-cli-r87-6pqa_cns/build/debug/mixer build --platform android --directory "$PROJECT"
```

The prospective output is "$PROJECT/.mixer/android-build/FieldLogGenerated-unsigned.apk". No unsigned APK currently exists in R90. The Android driver compiles the external app Java with JDK25 and --release17 and uses two Swift jobs for public-v3.

Root owns signing, installation and native execution. After root selects and completes those actions, start dev.fieldlog.generatedr90/dev.fieldlog.generatedr90.androidhost.PublicActivity on its exact owned destination. This lane does not run an ADB command or own emulator-5584. No instrumentation component is provided by the production starter. Enter a Unicode multiline title, enter a responsible person, press Add, verify Saved and the saved task, close the Activity, and open a fresh Activity to verify the same task from its real private files directory.

The source ZIP includes the original failed C-entry XCTest callback. It uses JSONDecoder on UIDocument and needs the public preflight decoder in any separately selected test correction. Do not treat that suite as green. The direct factory test passed; the complete ctypes behavior proof is retained separately. Do not rerun its fixed-name R90 data/output directories. A fresh reproduction must use separately selected directories and preserve the pinned library/source association.
