"""Exercise the compiled app's actual C entry; controlled surface, no compilation."""
from pathlib import Path
import ctypes as C
import hashlib,json,time

p=Path(__file__).resolve().parent;c=json.loads((p/'paths.json').read_text());b=Path(c['owned'])
out=p/'centry-observed-raw';out.mkdir(exist_ok=False)
library=b/'host-build/debug/libAppAndroid.dylib'
lib=C.CDLL(str(library))
callback_type=C.CFUNCTYPE(C.c_int32,C.c_int64,C.c_int32,C.c_void_p,C.c_ssize_t,C.c_void_p,C.c_ssize_t,C.c_void_p,C.c_ssize_t)
submit=lib.mixer_public_android_submit
submit.argtypes=[C.c_int64,C.c_int32,C.c_void_p,C.c_ssize_t,C.c_void_p,C.c_ssize_t,C.c_void_p,C.c_ssize_t,C.c_void_p,C.c_ssize_t,callback_type]
submit.restype=C.c_int32
poll=lib.mixer_public_android_poll;poll.argtypes=[C.c_int64];poll.restype=C.c_int32
owners={};frames={};revocations={};requests=[];callbacks=[]
def raw(pointer,count):return C.string_at(pointer,count) if count else b''
@callback_type
def surface(context,op,o,on,packet,pn,appearance,an):
    try:
        token=raw(o,on);body=raw(packet,pn);descriptor=raw(appearance,an)
        callbacks.append(dict(context=context,operation=op,owner=token.decode(),packetBytes=pn,appearanceBytes=an))
        if op==0:
            assert context not in owners;owners[context]=token
        elif op==1:
            assert owners.get(context)==token
            value=json.loads(body);assert value['schemaVersion']==1 and value['document']['schemaVersion']==1
            assert json.loads(descriptor)['format']=='mixer.native-appearance.2'
            sequence=len(frames.get(context,[]));(out/f'{context}-{sequence}.json').write_bytes(body)
            frames.setdefault(context,[]).append(dict(owner=token,packet=value,raw=body))
        elif op==2:
            assert owners.pop(context)==token;revocations[context]=revocations.get(context,0)+1
        else:raise AssertionError(op)
        return 0
    except Exception as error:
        callbacks[-1]['failure']=repr(error);print('CALLBACK FAILURE',repr(error),flush=True);return 1

def request(context,op,directory=None,owner=b'',event=b''):
    profile=b'MEASURED_MULTILINE_RETIREMENT_V3' if op==0 else b''
    directory=str(directory).encode() if directory else b''
    buffers=[C.create_string_buffer(v) if v else None for v in [profile,directory,owner,event]]
    args=[]
    for buffer,value in zip(buffers,[profile,directory,owner,event]):args += [buffer,len(value)]
    accepted=submit(context,op,*args,surface);assert accepted==0,('not accepted',accepted)
    deadline=time.monotonic()+10
    while time.monotonic()<deadline:
        status=poll(context)
        if status:
            requests.append(dict(context=context,operation=op,status=status,owner=owner.decode(),event=event.decode(),directory=directory.decode()))
            return status
    raise RuntimeError('C-entry timeout; no retry')

def encode(value):return json.dumps(value,ensure_ascii=False,separators=(',',':')).encode()
def event(frame,node,kind,value=None):
    packet=frame['packet'];identity=next(i for i in packet['identities'] if i['id']==node)
    return dict(revision=packet['document']['revision'],identity=identity,event=kind,value=value)
def snapshot(directory):return directory/'FieldLog/workspace.json'

try:
    a=b/'centry-observed-data-a';other=b/'centry-observed-data-b'
    assert request(201,0,directory=a)==1
    assert request(202,0,directory=other)==1
    first=frames[201][-1];token=first['owner'];disk=snapshot(a).read_bytes()
    disabled=[event(first,'task.title','textChange','seed'),event(first,'task.save','activate')]
    assert request(201,1,owner=token,event=encode(disabled))==2
    assert len(frames[201])==1 and snapshot(a).read_bytes()==disk
    assert request(201,1,owner=token,event=encode(event(first,'task.title','textChange','ready')))==1
    captured=frames[201][-1]
    title='Café 東京 🧪\nInspect façade — e\u0301';person='Zoë 👩🏽‍🔬 / Łukasz'
    # Several same-origin edits, including intermediate text, remain in order.
    burst=[event(captured,'task.title','textChange','intermediate'),event(captured,'task.title','textChange',title),
           event(captured,'task.responsible','textChange',person),event(captured,'task.save','activate')]
    invalid=burst+[event(captured,'task.title','textChange','after Save')]
    before=len(frames[201]);assert request(201,1,owner=token,event=encode(invalid))==2
    assert len(frames[201])==before and snapshot(a).read_bytes()==disk
    assert request(201,1,owner=token,event=encode(burst))==1
    saved=json.loads(snapshot(a).read_bytes());assert len(saved['tasks'])==1
    assert saved['tasks'][0]['title'].encode()==title.encode()
    assert saved['tasks'][0]['responsible'].encode()==person.encode()
    assert len([x for x in saved['outbox'] if x['kind']=='taskSaved'])==1
    assert request(201,2)==1
    assert request(203,0,directory=a)==1
    reopened=frames[203][-1];assert reopened['owner']!=token
    def texts(node):return [node['properties'].get('text','')]+[v for child in node['children'] for v in texts(child)]
    assert title+' — '+person in texts(reopened['packet']['document']['root'])
    disk=snapshot(a).read_bytes();before=len(frames[203])
    assert request(203,1,owner=token,event=encode(burst))==2
    assert request(201,1,owner=token,event=encode(burst))==2
    assert len(frames[203])==before and snapshot(a).read_bytes()==disk
    assert request(203,2)==1 and request(202,2)==1
    assert not owners and revocations=={201:1,203:1,202:1}
    assert json.loads(snapshot(other).read_bytes())['tasks']==[]
    result=dict(status='PASS_ACTUAL_C_ENTRY_FIELDLOG_SAVE_CLOSE_FRESH_REPOSITORY_REOPEN',
                dylib=str(library.resolve()),dylibSHA256=hashlib.sha256(library.read_bytes()).hexdigest(),
                title=title,responsible=person,sameOriginBurstSave=True,lateOldOwnerRefused=True,
                invalidTailRefusedBeforeEffect=True,disabledOriginSaveRefused=True,contextStorageIsolation=True,
                revocations=revocations,ownedOwnersRemaining=len(owners),
                scope='macOS arm64 actual app C entry + public AndroidUIHost; controlled callback surface only. Not Android JNI/Activity/NativeRenderer runtime.',
                snapshotSHA256=hashlib.sha256(snapshot(a).read_bytes()).hexdigest())
    (p/'centry-behavior.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(result,ensure_ascii=False),flush=True)
finally:
    (out/'requests.json').write_text(json.dumps(requests,indent=2,ensure_ascii=False)+'\n')
    (out/'callbacks.json').write_text(json.dumps(callbacks,indent=2,ensure_ascii=False)+'\n')
