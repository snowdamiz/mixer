from pathlib import Path
import hashlib,json,shutil

p=Path(__file__).resolve().parent
c=json.loads((p/'paths.json').read_text()); project=Path(c['project']); android=project/'Platforms/Android'
assert json.loads((p/'create-result.json').read_text())['exitCode']==0
if not (p/'generated-baseline').exists():
    shutil.copytree(android,p/'generated-baseline/Platforms/Android')
    shutil.copy2(project/'Package.swift',p/'generated-baseline/Package.swift')
else:
    shutil.copytree(p/'generated-baseline/Platforms/Android',android,dirs_exist_ok=True)
    shutil.copy2(p/'generated-baseline/Package.swift',project/'Package.swift')
for module in (p/'source-inputs').iterdir():
    shutil.copytree(module,project/'Sources'/module.name,dirs_exist_ok=True)
rootPackage=project/'Package.swift'
s=rootPackage.read_text().replace('products: [', 'products: [.library(name: "FieldLogFeatures", targets: ["FieldLogFeatures"]), .library(name: "FieldLogModels", targets: ["FieldLogModels"]), .library(name: "FieldLogStorage", targets: ["FieldLogStorage"]), ',1)
s=s.replace('targets: [\n', '''targets: [
        .target(name: "FieldLogModels"),
        .target(name: "FieldLogFeatures", dependencies: ["FieldLogModels", .product(name: "MixerCore", package: "MixerSDK"), .product(name: "MixerUI", package: "MixerSDK")], exclude: ["TaskEditorAppleFieldsHost.swift"]),
        .target(name: "FieldLogStorage", dependencies: ["FieldLogModels"]),
''',1)
rootPackage.write_text(s)
package=android/'Package.swift';s=package.read_text().replace('.product(name: "AppFeatures", package: "Application")', '.product(name: "FieldLogFeatures", package: "Application"), .product(name: "FieldLogModels", package: "Application"), .product(name: "FieldLogStorage", package: "Application")')
s=s.replace('dependencies: ["AppAndroid",', 'dependencies: ["AppAndroid", .product(name: "FieldLogModels", package: "Application"), .product(name: "FieldLogStorage", package: "Application"),')
package.write_text(s)
shutil.copy2(p/'PublicFactory.swift',android/'Sources/AppAndroid/PublicFactory.swift')

def change(path,old,new):
    s=path.read_text();assert s.count(old)==1,(path,old,s.count(old));path.write_text(s.replace(old,new,1))

entry=android/'Sources/AppAndroid/NativeEntry.swift'
change(entry,'_ profile: String, _ owner: Data, _ event: Data, _ callback: @escaping SurfaceCall) -> Int32', '_ profile: String, _ directory: Data, _ owner: Data, _ event: Data, _ callback: @escaping SurfaceCall) async -> Int32')
change(entry,'let application = try PublicAndroidApplication(surface: surface, selectedProfile: profile)', '''guard let path = String(data: directory, encoding: .utf8), path.hasPrefix("/"), !path.utf8.contains(0) else { throw PublicHostError.storage }
                let application = try await PublicAndroidApplication(surface: surface, selectedProfile: profile, directory: URL(fileURLWithPath: path, isDirectory: true))''')
change(entry,'\n            case 2:', '\n                try await application.settle()\n            case 2:')
change(entry,'application.close()', 'await application.close()')
change(entry,'_ profile: UnsafePointer<UInt8>?, _ profileCount: Int,','_ profile: UnsafePointer<UInt8>?, _ profileCount: Int,\n    _ directory: UnsafePointer<UInt8>?, _ directoryCount: Int,')
change(entry,'(0...64).contains(ownerCount),', '(0...4096).contains(directoryCount), (operation == 0 ? directoryCount > 0 : directoryCount == 0),\n          (directoryCount == 0 || directory != nil), (0...64).contains(ownerCount),')
change(entry,'let owner = owner.map', 'let directory = directory.map { Data(bytes: $0, count: directoryCount) } ?? Data()\n    let owner = owner.map')
change(entry,'Applications.execute(context, operation, selected, owner, event, callback)', 'await Applications.execute(context, operation, selected, directory, owner, event, callback)')

bridge=android/('Java/'+c['application'].replace('.','/')+'/androidhost/PublicBridge.java')
change(bridge,'return openNative(receiver, profile);','return openNative(receiver, profile, receiver.getFilesDir().getAbsolutePath().getBytes(java.nio.charset.StandardCharsets.UTF_8));')
change(bridge,'openNative(PublicActivity receiver, String profile);','openNative(PublicActivity receiver, String profile, byte[] directory);')

jni=android/'Bridge/PublicBridge.c'
change(jni,'extern int32_t mixer_public_android_submit(int64_t,int32_t,const uint8_t*,intptr_t,const uint8_t*,intptr_t,const uint8_t*,intptr_t,surface_callback);', 'extern int32_t mixer_public_android_submit(int64_t,int32_t,const uint8_t*,intptr_t,const uint8_t*,intptr_t,const uint8_t*,intptr_t,const uint8_t*,intptr_t,surface_callback);')
change(jni,'jobject receiver; int busy, failed;', 'jobject receiver; uint8_t *directory; intptr_t directory_n; int busy, failed;')
change(jni,'c->id,op,profile,profile_n,owner,owner_n,event,event_n,surface', 'c->id,op,profile,profile_n,op==0?c->directory:NULL,op==0?c->directory_n:0,owner,owner_n,event,event_n,surface')
change(jni,'jobject receiver,jstring profile)', 'jobject receiver,jstring profile,jbyteArray directory)')
change(jni,'if(!receiver||!profile||next_id==INT64_MAX)', 'if(!receiver||!profile||!directory||next_id==INT64_MAX)')
change(jni,'jsize n=(*e)->GetStringUTFLength', 'jsize dn=(*e)->GetArrayLength(e,directory); if(dn<=0||dn>4096) return 0;\n    jsize n=(*e)->GetStringUTFLength')
change(jni,'c->next=contexts; contexts=c;', '''c->directory=malloc((size_t)dn);
    if(!c->directory) { (*e)->DeleteGlobalRef(e,c->receiver); free(c); (*e)->ReleaseStringUTFChars(e,profile,text); return 0; }
    (*e)->GetByteArrayRegion(e,directory,0,dn,(jbyte*)c->directory);
    if((*e)->ExceptionCheck(e)) { free(c->directory); (*e)->DeleteGlobalRef(e,c->receiver); free(c); (*e)->ReleaseStringUTFChars(e,profile,text); return 0; }
    c->directory_n=dn;
    c->next=contexts; contexts=c;''')
change(jni,'(*e)->DeleteGlobalRef(e,c->receiver); free(c); return 0;', '(*e)->DeleteGlobalRef(e,c->receiver); free(c->directory); free(c); return 0;')
change(jni,';Ljava/lang/String;)J', ';Ljava/lang/String;[B)J')

# The generated starter tests describe starter-only value state. Preserve their
# exact source in generated-baseline; compile this app's actual integration test.
(android/'Tests/AppAndroidTests/PublicHostTests.swift').unlink()
shutil.copy2(p/'FieldLogGeneratedHostTests.swift',android/'Tests/AppAndroidTests/FieldLogGeneratedHostTests.swift')
rows=[]
for item in json.loads((p/'application-provenance.json').read_text()):
    relative=Path(item['consumedR90']).relative_to(p/'source-inputs')
    dest=project/'Sources'/relative
    assert hashlib.sha256(dest.read_bytes()).hexdigest()==item['sha256']
    rows.append(dict(item,compiledR90=str(dest)))
(p/'application-provenance.json').write_text(json.dumps(rows,indent=2)+'\n')
print('ADAPTED generated public host with app-owned storage bootstrap')
