from pathlib import Path
import hashlib,json,os,shutil,subprocess,tempfile,time
p=Path(__file__).resolve().parent;root=p.parents[2];base=p.parent;kit=json.loads((p/'cli-resource-kit.json').read_text());prior=json.loads((base/'fieldlog-generated-android-build-r91/selection.json').read_text());original=Path(prior['project']);owned=Path(tempfile.mkdtemp(prefix='fieldlog-final-r94-',dir='/Users/andreyyurlov/.t3/userdata'));project=owned/'FieldLogGenerated';(owned/'tmp').mkdir();cli=kit['CLI'];swift='/Users/andreyyurlov/Library/Developer/Toolchains/swift-6.3.3-RELEASE.xctoolchain/usr/bin';env=os.environ.copy();env.update(DEVELOPER_DIR='/Applications/Xcode_26.6.app/Contents/Developer',SDKROOT='/Applications/Xcode_26.6.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX26.5.sdk',JAVA_HOME='/opt/homebrew/opt/openjdk@25/libexec/openjdk.jdk/Contents/Home',MIXER_JDK='/opt/homebrew/opt/openjdk@25/libexec/openjdk.jdk/Contents/Home',ANDROID_HOME='/opt/homebrew/share/android-commandlinetools',TMPDIR=str(owned/'tmp')+'/',PATH='/Users/andreyyurlov/.t3/userdata/mixer-p15-cli-r87-6pqa_cns/bin:'+swift+':'+env['PATH'],SWIFT_EXEC=swift+'/swiftc');rows=[]
(p/'selection.json').write_text(json.dumps({'owned':str(owned),'project':str(project),'originalConsumer':str(original),'source116':'bc66642e1997905c743f529a8a9aafc55a12310f011ff98f78556cd1cf9c6833','scope':'Fresh full CLI create and actual FieldLog Android build with reviewed resource-only ABI correction; no source/profile/security bypass'},indent=2)+'\n')
for label,argv in [('create',[cli,'create','FieldLogGenerated','--platform','android','--android-host','public-v3','--application','dev.fieldlog.generatedr90','--sdk-path',str(root/'sdk'),'--android-adapter-path',str(root/'native/android'),'--directory',str(project)]),('build',[cli,'build','--platform','android','--directory',str(project)])]:
 if label=='build':
  for name in ['Sources','Tests','Platforms']:
   dest=project/name
   if dest.exists():shutil.rmtree(dest)
   shutil.copytree(original/name,dest,ignore=shutil.ignore_patterns('.build','.swiftpm','.mixer'))
  for name in ['Package.swift','Package.resolved']:
   f=original/name
   if f.exists():shutil.copyfile(f,project/name)
  (p/'app-owned-copy.json').write_text(json.dumps({'paths':['Sources','Tests','Platforms','Package.swift','Package.resolved if present'],'SDKAdapterLockAndConfig':'Fresh candidate CLI-created; not overwritten','appSource':'Exact frozen R90 consumer from R91 extraction'},indent=2)+'\n')
 started=time.monotonic()
 with (p/(label+'.stdout')).open('wb') as out,(p/(label+'.stderr')).open('wb') as err:
  child=subprocess.Popen(argv,cwd=root,env=env,stdout=out,stderr=err,start_new_session=True);row={'label':label,'argv':argv,'pid':child.pid,'pgid':child.pid};rows.append(row);(p/'commands.json').write_text(json.dumps(rows,indent=2)+'\n')
  try:code=child.wait(timeout=240)
  except subprocess.TimeoutExpired:
   row['state']='UNKNOWN';(p/'HOLD.json').write_text(json.dumps(row,indent=2)+'\n');raise SystemExit(74)
 try:os.killpg(child.pid,0);absent=False
 except ProcessLookupError:absent=True
 row.update(exitCode=code,groupAbsent=absent,seconds=time.monotonic()-started);(p/'commands.json').write_text(json.dumps(rows,indent=2)+'\n')
 if code or not absent:raise RuntimeError(label+' failed; preserve outputs')
apk=project/'.mixer/android-build/FieldLogGenerated-unsigned.apk';assert apk.is_file();result={'status':'PASS_ACTUAL_FIELDLOG_ANDROID_PUBLIC_HOST_BUILD','APK':str(apk),'APK_SHA256':hashlib.sha256(apk.read_bytes()).hexdigest(),'scope':'Actual shared FieldLog features/models/storage, generated public host with app-owned storage bootstrap, arm64 Swift/JNI/SDK37 Java/D8/APK, unsigned; runtime pending','commands':rows,'source116':'bc66642e1997905c743f529a8a9aafc55a12310f011ff98f78556cd1cf9c6833','runtime':'pending root','GA':False};(p/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
