import hashlib, json, os, pathlib, secrets, shutil, signal, subprocess, tempfile, time, zipfile

p = pathlib.Path(__file__).resolve().parent
root = p.parents[2]
base = p.parent
sdk = pathlib.Path('/opt/homebrew/share/android-commandlinetools')
jdk = pathlib.Path('/opt/homebrew/opt/openjdk@25/libexec/openjdk.jdk/Contents/Home')
bt = sdk / 'build-tools/37.0.0'
jar = sdk / 'platforms/android-37.0/android.jar'
original = base / 'fieldlog-generated-public-native-r95/FieldLog-generated-r95-unsigned.apk'
source_zip = base / 'fieldlog-generated-public-host-integration-r90/FieldLog-generated-public-host-r90-source.zip'
proposal = base / 'v3-focused-disable-owner-transition-r98'
scratch = pathlib.Path(tempfile.mkdtemp(prefix='fieldlog-r102-', dir='/Users/andreyyurlov/.t3/userdata'))
commands, inputs = [], {}
env = os.environ.copy()
env['JAVA_HOME'] = str(jdk)
env['MIXER_R102_SIGN_PASSWORD'] = secrets.token_hex(24)
started = time.monotonic()

def sha(data): return hashlib.sha256(data).hexdigest()

def run(label, argv, timeout=45):
    t = time.monotonic()
    with (p / (label + '.stdout')).open('wb') as out, (p / (label + '.stderr')).open('wb') as err:
        child = subprocess.Popen(list(map(str, argv)), env=env, stdout=out, stderr=err, start_new_session=True)
        try: code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            code = child.wait(timeout=10)
            raise RuntimeError(label + ' timed out, owned command stopped: ' + str(code))
    try: os.killpg(child.pid, 0)
    except ProcessLookupError: gone = True
    else: gone = False
    commands.append(dict(label=label, argv=list(map(str, argv)), pid=child.pid, exitCode=code, groupAbsent=gone, seconds=time.monotonic()-t))
    (p / 'build-commands.json').write_text(json.dumps(commands, indent=2)+'\n')
    if code or not gone: raise RuntimeError(label + ' failed: ' + str(code))

result = {'passed': False, 'scope': 'Diagnostic Java-only R98 overlay; canonical Pair15 profile unchanged, prospective Pair16 pending'}
try:
    baseline = json.loads((proposal / 'baseline-inputs.json').read_text())
    with zipfile.ZipFile(source_zip) as archive:
        product = []
        app = []
        for name in archive.namelist():
            if not name.endswith('.java'): continue
            if '/Generated/MixerAndroid/app/src/' in name:
                rel = 'native/android/app/src/' + name.split('/app/src/', 1)[1]
                data = (root / rel).read_bytes()
                assert data == archive.read(name), 'R90 SDK differs from current selected Pair15: ' + rel
                if rel in baseline: assert sha(data) == baseline[rel]
                after = proposal / 'afterimages' / rel
                if after.is_file(): data = after.read_bytes()
                dest = scratch / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(data)
                inputs[rel] = sha(data)
                if dest.name != 'MixerActivity.java': product.append(dest)
            elif '/Platforms/Android/Java/' in name:
                dest = scratch / name
                dest.parent.mkdir(parents=True, exist_ok=True)
                data = archive.read(name)
                dest.write_bytes(data)
                inputs[name] = sha(data)
                app.append(dest)
        assert len(product) == 20 and len(app) == 2
    (p / 'input-hashes.json').write_text(json.dumps(inputs, indent=2)+'\n')
    classes = scratch / 'classes'
    sdk_classes, app_classes, dex = classes / 'sdk', classes / 'app', scratch / 'dex'
    for d in (sdk_classes, app_classes, dex): d.mkdir(parents=True)
    flags = ['--release', '17', '-Xlint:all', '-Werror', '-proc:none', '-sourcepath', '']
    run('sdk37-compile', [jdk/'bin/javac', *flags, '-classpath', jar, '-d', sdk_classes, *sorted(product)])
    run('external-app-compile', [jdk/'bin/javac', *flags, '-classpath', str(jar)+os.pathsep+str(sdk_classes), '-d', app_classes, *sorted(app)])
    run('d8', [bt/'d8', '--min-api', '28', '--lib', jar, '--output', dex, *sorted(classes.rglob('*.class'))])
    unaligned = scratch / 'unaligned.apk'
    with zipfile.ZipFile(original) as old, zipfile.ZipFile(unaligned, 'w') as new:
        unchanged = {}
        for item in old.infolist():
            if item.filename.endswith('.dex') or item.filename.startswith('META-INF/'): continue
            data = old.read(item.filename)
            new.writestr(item, data)
            unchanged[item.filename] = sha(data)
        for item in sorted(dex.glob('*.dex')): new.write(item, item.name, compress_type=zipfile.ZIP_DEFLATED)
    unsigned = p / 'FieldLog-focused-disable-r102-unsigned.apk'
    run('align', [bt/'zipalign', '-f', '-P', '16', '4', unaligned, unsigned])
    run('verify-align', [bt/'zipalign', '-c', '-P', '16', '4', unsigned])
    with zipfile.ZipFile(unsigned) as new:
        assert all(sha(new.read(name)) == value for name, value in unchanged.items())
    (p / 'unchanged-payloads.json').write_text(json.dumps(unchanged, indent=2)+'\n')
    key = scratch / 'ephemeral-debug.p12'
    run('keytool', [jdk/'bin/keytool', '-genkeypair', '-keystore', key, '-alias', 'mixer-test', '-keyalg', 'RSA', '-keysize', '2048', '-validity', '2', '-dname', 'CN=Mixer development test', '-storetype', 'PKCS12', '-storepass:env', 'MIXER_R102_SIGN_PASSWORD', '-keypass:env', 'MIXER_R102_SIGN_PASSWORD'])
    signed = p / 'FieldLog-focused-disable-r102-debug.apk'
    run('sign', [bt/'apksigner', 'sign', '--ks', key, '--ks-key-alias', 'mixer-test', '--ks-pass', 'env:MIXER_R102_SIGN_PASSWORD', '--key-pass', 'env:MIXER_R102_SIGN_PASSWORD', '--out', signed, unsigned])
    run('verify-signature', [bt/'apksigner', 'verify', '--verbose', signed])
    result.update(passed=True, unsignedAPK=str(unsigned), signedAPK=str(signed), unsignedSHA256=sha(unsigned.read_bytes()), signedSHA256=sha(signed.read_bytes()), unchangedNativeLibraries=sum(name.startswith('lib/') for name in unchanged), productSourceCount=len(product), externalSourceCount=len(app))
except Exception as error:
    result['error'] = repr(error)
finally:
    shutil.rmtree(scratch)
    result.update(ownedScratchRemoved=True, ephemeralKeyRemoved=True, elapsedSeconds=time.monotonic()-started)
    (p / 'build-result.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result))
