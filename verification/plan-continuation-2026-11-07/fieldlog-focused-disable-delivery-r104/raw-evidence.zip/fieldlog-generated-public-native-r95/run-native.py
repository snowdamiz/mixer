import json, os, pathlib, re, subprocess, time, xml.etree.ElementTree as ET

p = pathlib.Path(__file__).parent
c = json.loads((p / 'runtime-plan.json').read_text())
commands, result = [], {'passed': False, 'scope': c['scope']}
child, verified = None, False
started = time.monotonic()

def run(name, argv, timeout=20, check=True):
    t = time.monotonic()
    with (p / (name + '.stdout')).open('wb') as out, (p / (name + '.stderr')).open('wb') as err:
        r = subprocess.run(argv, stdout=out, stderr=err, timeout=timeout)
    commands.append({'name': name, 'argv': argv, 'exitCode': r.returncode, 'seconds': time.monotonic() - t})
    (p / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    if check and r.returncode:
        raise RuntimeError(name + ' exit ' + str(r.returncode))
    return (p / (name + '.stdout')).read_text(errors='replace')

def adb(name, argv, timeout=20, check=True):
    return run(name, [c['adb'], '-s', c['serial'], *argv], timeout, check)

def hierarchy(label):
    adb(label + '-dump', ['shell', 'uiautomator', 'dump', '/sdcard/mixer-r95.xml'], 20)
    raw = adb(label, ['exec-out', 'cat', '/sdcard/mixer-r95.xml'])
    return list(ET.fromstring(raw).iter('node'))

def tap(label, node):
    values = list(map(int, re.findall(r'\d+', node.attrib['bounds'])))
    assert len(values) == 4 and values[2] > values[0] and values[3] > values[1]
    adb(label, ['shell', 'input', 'tap', str((values[0] + values[2]) // 2), str((values[1] + values[3]) // 2)])

try:
    before = run('baseline-devices', [c['adb'], 'devices', '-l'])
    baseline = [s.strip() for s in before.splitlines()[1:] if s.strip()]
    result['externalBefore'] = baseline
    assert not any(s.split()[0] == c['serial'] for s in baseline), 'Owned serial already active; no duplicate launch'
    env = os.environ.copy()
    env.update(ANDROID_HOME=c['sdk'], ANDROID_SDK_ROOT=c['sdk'], ANDROID_AVD_HOME=c['avdHome'])
    with (p / 'emulator.stdout').open('wb') as out, (p / 'emulator.stderr').open('wb') as err:
        child = subprocess.Popen(c['emulatorArgv'], env=env, stdout=out, stderr=err, start_new_session=True)
    (p / 'emulator-ownership.json').write_text(json.dumps({'pid': child.pid, 'serial': c['serial'], 'argv': c['emulatorArgv'], 'ownedRoot': c['ownedRoot']}, indent=2) + '\n')
    adb('wait-device', ['wait-for-device'], 50)
    assert c['avdName'] in adb('owned-avd-name', ['emu', 'avd', 'name']).splitlines()
    verified = True
    for i in range(60):
        if adb('boot-%02d' % i, ['shell', 'getprop', 'sys.boot_completed'], 5).strip() == '1':
            break
        time.sleep(.5)
    else:
        raise RuntimeError('Owned emulator boot deadline')
    adb('wake', ['shell', 'input', 'keyevent', 'KEYCODE_WAKEUP'])
    adb('keyguard', ['shell', 'wm', 'dismiss-keyguard'])
    adb('install', ['install', '-r', c['signedAPK']], 35)
    result['phase'] = 'launch'
    adb('start', ['shell', 'am', 'start', '-W', '-n', c['package'] + '/' + c['activity']], 30)
    time.sleep(2)
    nodes = hierarchy('opened')
    fields = [n for n in nodes if n.attrib.get('class') == 'android.widget.EditText']
    assert len(fields) == 2, 'Real FieldLog title/person native form missing'
    result['generatedFieldLogStartup'] = True
    result['phase'] = 'edit-title'
    tap('focus-title', fields[0]); adb('type-title', ['shell','input','text','R95-native-save']); time.sleep(.5)
    nodes = hierarchy('title-edited')
    assert any(n.attrib.get('text') == 'R95-native-save' for n in nodes), 'Title native/model echo missing'
    fields = [n for n in nodes if n.attrib.get('class') == 'android.widget.EditText']
    result['phase'] = 'edit-responsible'
    tap('focus-person', fields[1]); adb('type-person', ['shell','input','text','RootOwner']); time.sleep(.5)
    nodes = hierarchy('person-edited')
    assert any(n.attrib.get('text') == 'RootOwner' for n in nodes), 'Person native/model echo missing'
    button = next(n for n in nodes if n.attrib.get('text') == 'Add' and n.attrib.get('enabled') == 'true')
    result['nativeTextAndModelEcho'] = True
    result['phase'] = 'save'
    tap('save', button)
    for observation in range(4):
        time.sleep(.5); nodes = hierarchy('saved-' + str(observation))
        if any(n.attrib.get('text') == 'Saved' for n in nodes): break
    assert any(n.attrib.get('text') == 'Saved' for n in nodes), 'Actual save completion not displayed'
    workspace = json.loads(adb('workspace-saved', ['exec-out','run-as',c['package'],'cat','files/FieldLog/workspace.json']))
    tasks = workspace['tasks']
    assert len(tasks) == 1 and tasks[0]['title'] == 'R95-native-save' and tasks[0]['responsible'] == 'RootOwner', 'Actual repository record differs'
    result['repositorySave'] = True
    result['phase'] = 'process-reopen'
    adb('close-keyboard', ['shell','input','keyevent','KEYCODE_BACK']); adb('close-back', ['shell','input','keyevent','KEYCODE_BACK'])
    adb('stop-owned-app-after-saved', ['shell','am','force-stop',c['package']])
    adb('restart', ['shell','am','start','-W','-n',c['package']+'/'+c['activity']],30); time.sleep(1)
    nodes = hierarchy('reopened')
    assert any(n.attrib.get('text') == 'R95-native-save — RootOwner' for n in nodes), 'Fresh process/Activity failed to recover task'
    reopened = json.loads(adb('workspace-reopened', ['exec-out','run-as',c['package'],'cat','files/FieldLog/workspace.json']))
    assert reopened['tasks'] == tasks, 'Repository changed on reopen'
    result['processRestartFreshActivityRepositoryReopen'] = True
    result['closeMode'] = 'Owned process stopped after visible Saved and exact repository check; graceful private ledgers not observed'
    result['passed'] = True
    result['phase'] = 'completed' 
except Exception as error:
    result['error'] = repr(error)
finally:
    if verified:
        for name, argv in [('final-log', ['logcat', '-d', '-v', 'threadtime', '-s', 'MixerAndroidHost:E', 'AndroidRuntime:E', 'libc:F', '*:S']), ('final-activities', ['shell', 'dumpsys', 'activity', 'activities'])]:
            try:
                adb(name, argv, 15, False)
            except Exception as error:
                result[name + 'Error'] = repr(error)
        for name, argv in [('remove-owned-dump', ['shell', 'rm', '-f', '/sdcard/mixer-r95.xml']), ('force-stop', ['shell', 'am', 'force-stop', c['package']]), ('emulator-quit', ['emu', 'kill'])]:
            try:
                adb(name, argv, 15)
            except Exception as error:
                result[name + 'Error'] = repr(error)
    if child is not None:
        try:
            result['emulatorExitCode'] = child.wait(timeout=20)
        except subprocess.TimeoutExpired:
            child.terminate()
            result['emulatorExitCode'] = child.wait(timeout=10)
    try:
        after = run('devices-after', [c['adb'], 'devices', '-l'], 15)
        for observation in range(3):
            if not any(line.split()[0] == c['serial'] for line in after.splitlines()[1:] if line.strip()):
                break
            time.sleep(.3)
            after = run('devices-after-fresh-' + str(observation), [c['adb'], 'devices', '-l'], 15)
        external = [s.strip() for s in after.splitlines()[1:] if s.strip() and s.split()[0] != c['serial']]
        result['externalBaselineUnchanged'] = sorted(external) == sorted(result.get('externalBefore', []))
        result['ownedSerialAbsent'] = not any(s.split()[0] == c['serial'] for s in after.splitlines()[1:] if s.strip())
    except Exception as error:
        result['deviceObservationError'] = repr(error)
    result['physicalDeviceCommands'] = 0
    result['elapsedSeconds'] = time.monotonic() - started
    if not result.get('externalBaselineUnchanged') or not result.get('ownedSerialAbsent'):
        result['passed'] = False
        result['cleanupFailure'] = 'Device baseline/owned cleanup incomplete; coordinate before another native attempt'
    (p / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
