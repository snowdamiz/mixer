#!/usr/bin/env python3
"""Bounded two-compilation R100 review; writes only this review directory."""
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
R98 = OUT.parent / 'v3-focused-disable-owner-transition-r98'
JDK = Path('/opt/homebrew/opt/openjdk@25/libexec/openjdk.jdk/Contents/Home')
commands = json.loads((OUT / 'commands.json').read_text()) if (OUT / 'commands.json').exists() else []
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')
manifest = json.loads((R98 / 'baseline-inputs.json').read_text())
changed = ['native/android/app/src/dev/mixer/android/NativeRenderer.java',
           'native/android/app/src/dev/mixer/android/NativeAppearanceViewsV2.java']
inputs = {}
for rel, expected in manifest.items():
    inputs[rel] = {'expectedBaseline': expected, 'canonical': sha(ROOT / rel), 'beforeimage': sha(R98 / 'beforeimages' / rel)}
    if inputs[rel]['beforeimage'] != expected:
        raise RuntimeError('R98 beforeimage mismatch: ' + rel)
    allowed = {expected}
    if rel in changed:
        inputs[rel]['afterimage'] = sha(R98 / 'afterimages' / rel)
        allowed.add(inputs[rel]['afterimage'])
    if inputs[rel]['canonical'] not in allowed:
        raise RuntimeError('unreviewed canonical drift: ' + rel)
patch = ''.join(''.join(difflib.unified_diff(
    (R98 / 'beforeimages' / rel).read_text().splitlines(keepends=True),
    (R98 / 'afterimages' / rel).read_text().splitlines(keepends=True),
    fromfile='a/' + rel, tofile='b/' + rel)) for rel in changed)
if patch.encode() != (R98 / 'product.patch').read_bytes():
    raise RuntimeError('two-file patch differs from afterimages')
save('inputs.json', {'sources': inputs, 'sourceTreeSHA256': hashlib.sha256(json.dumps(inputs, sort_keys=True).encode()).hexdigest(),
                    'patchSHA256': sha(R98 / 'product.patch'),
                    'testSHA256': sha(OUT / 'IndependentDisableReview.java'),
                    'r98HarnessSHA256': sha(R98 / 'tests/FocusedDisableOwnerTransitionHostTests.java'),
                    'packets': {p.name: sha(p) for p in sorted((R98 / 'packets').glob('*.json'))}})
(OUT / 'raw').mkdir(exist_ok=True)
env = os.environ.copy()
for key in ['JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH']:
    env.pop(key, None)
env['JAVA_HOME'] = str(JDK)
env['JAVA_TOOL_OPTIONS'] = '-XX:ActiveProcessorCount=2'
active = sum(c.get('seconds', 0) for c in commands)
def run(label, argv):
    global active
    remaining = 180 - active
    if remaining <= 0:
        raise RuntimeError('active budget exhausted')
    row = {'label': label, 'argv': list(map(str, argv)), 'cwd': str(ROOT), 'activeProcessorCount': 2}
    started = time.monotonic()
    with (OUT / 'raw' / (label + '.stdout')).open('wb') as stdout, (OUT / 'raw' / (label + '.stderr')).open('wb') as stderr:
        child = subprocess.Popen(row['argv'], cwd=ROOT, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        row.update(pid=child.pid, pgid=child.pid)
        commands.append(row)
        save('commands.json', commands)
        try:
            code = child.wait(timeout=min(45, remaining))
        except subprocess.TimeoutExpired:
            row['timedOut'] = True
            os.killpg(child.pid, signal.SIGTERM)
            try:
                code = child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                code = child.wait(timeout=10)
        row.update(exitCode=code, seconds=time.monotonic() - started)
        active += row['seconds']
        try:
            os.killpg(child.pid, 0)
            row['groupAbsent'] = False
        except ProcessLookupError:
            row['groupAbsent'] = True
        save('commands.json', commands)
    print(label, code, 'groupAbsent', row['groupAbsent'], flush=True)
    if code or not row['groupAbsent']:
        raise RuntimeError(label + ' failed; raw evidence preserved')

if not commands:
    run('java-version', [JDK / 'bin/java', '-version'])
    run('javac-version', [JDK / 'bin/javac', '-version'])
for stage in ['baseline', 'candidate']:
    classes = OUT / (stage + '-classes')
    if stage == 'baseline' and any(c['label'] == 'baseline-compile' and c.get('exitCode') == 0 for c in commands):
        continue
    if stage == 'candidate' and any(c['label'] == 'candidate-compile' and c.get('exitCode') == 0 for c in commands):
        break
    if sum(c['label'].endswith('-compile') for c in commands) >= 2:
        raise RuntimeError('two-compilation bound reached')
    classes.mkdir(exist_ok=False)
    sources = [(R98 / 'afterimages' / rel) if stage == 'candidate' and rel in changed else (R98 / 'beforeimages' / rel) for rel in manifest]
    sources += [R98 / 'tests/FocusedDisableOwnerTransitionHostTests.java', OUT / 'IndependentDisableReview.java']
    run(stage + '-compile', [JDK / 'bin/javac', '-J-Xmx256m', '-J-XX:ActiveProcessorCount=2', '--release', '17', '-Xlint:all', '-Werror', '-proc:none', '-sourcepath', '', '-classpath', '', '-d', classes, *sources])
    if stage == 'candidate':
        harness = OUT / 'corrected-baseline-harness/dev/mixer/android'
        harness.mkdir(parents=True)
        for source in (classes / 'dev/mixer/android').glob('IndependentDisableReview*.class'):
            shutil.copyfile(source, harness / source.name)
        run('baseline-independent-corrected', [JDK / 'bin/java', '-ea', '-Xmx256m', '-cp', str(OUT / 'corrected-baseline-harness') + os.pathsep + str(OUT / 'baseline-classes'), 'dev.mixer.android.IndependentDisableReview', R98 / 'packets', 'baseline'])
    run(stage + '-independent', [JDK / 'bin/java', '-ea', '-Xmx256m', '-cp', classes, 'dev.mixer.android.IndependentDisableReview', R98 / 'packets', stage])
    if stage == 'candidate':
        pass
classes = OUT / 'candidate-classes'
run('candidate-author-focused', [JDK / 'bin/java', '-ea', '-Xmx256m', '-cp', classes, 'dev.mixer.android.FocusedDisableOwnerTransitionHostTests', R98 / 'packets', 'candidate'])
run('candidate-clear-regression', [JDK / 'bin/java', '-ea', '-Xmx256m', '-cp', classes, 'dev.mixer.android.GeneratedAddTransitionHostTests', ROOT / 'native/android/tests/GeneratedAddTransitionPackets', 'candidate'])
run('candidate-vertical-regression', [JDK / 'bin/java', '-ea', '-Xmx256m', '-cp', classes, 'dev.mixer.android.VerticalReflowHostTests', R98 / 'packets/descriptor.json', 'candidate'])
cleanup_start = time.monotonic()
for stage in ['baseline', 'candidate']:
    shutil.rmtree(OUT / (stage + '-classes'))
shutil.rmtree(OUT / 'corrected-baseline-harness')
save('cleanup.json', {'allCommandGroupsObservedAbsent': all(c['groupAbsent'] for c in commands), 'ownedClassesRemoved': True, 'cleanupSeconds': time.monotonic() - cleanup_start, 'devices': False, 'heldResourcesTouched': False, 'initialDiscoverySessions': {'60854': 'interrupted with Ctrl-C; terminal exit130', '42199': 'interrupted with Ctrl-C; terminal exit130'}})
save('result.json', {'status': 'PASS_WITH_REVIEW_HARNESS_LIMITATION', 'materialJavacCompilations': 2, 'activeCommandSeconds': active, 'activeLimitSeconds': 180, 'cleanupLimitSeconds': 30, 'activeProcessorCount': 2, 'canonicalWrites': False, 'gitMutation': False, 'devices': False, 'children': False, 'limitations': ['controlled concrete Android/JNI leaves', 'no APK/device execution by reviewer', 'synthesized acknowledged predecessor retained from R98', 'independent candidate run completed 11 controls and asserted fatal-finish primary before cleanup rethrew retained Error; fatal-close extra control unrun', 'first baseline harness expected direct failure instead of public wrapper; corrected harness verified against same baseline production classes', 'no native/public-package/physical/GA qualification']})
print('PASS bounded independent review', flush=True)
