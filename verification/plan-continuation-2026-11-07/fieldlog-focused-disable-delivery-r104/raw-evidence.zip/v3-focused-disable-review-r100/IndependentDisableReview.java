package dev.mixer.android;

import android.app.Activity;
import android.os.Handler;
import android.text.Editable;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;
import android.widget.FrameLayout;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Independent actual-owner controls. Android and JNI are inert concrete host leaves. */
public final class IndependentDisableReview {
    static byte[] descriptor,echo,opened,busy;
    static int checks,cases;
    static void require(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
    static Object get(Object value,String name)throws Exception{Field f=value.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(value);}
    static Map<String,Object> node(Object value,String id){
        Map<String,Object> n=Json.object(value);if(id.equals(n.get("id")))return n;
        for(Object child:Json.array(n.get("children"))){Map<String,Object> found=node(child,id);if(found!=null)return found;}return null;
    }
    static Map<String,Object> properties(Map<String,Object> packet){return Json.object(node(Json.object(packet.get("document")).get("root"),"task.responsible").get("properties"));}
    static void write(StringBuilder out,Object value){
        if(value instanceof List<?> list){out.append('[');for(int i=0;i<list.size();i++){if(i>0)out.append(',');write(out,list.get(i));}out.append(']');}
        else if(value instanceof Map<?,?> map){out.append('{');boolean comma=false;for(var e:map.entrySet()){if(comma)out.append(',');comma=true;Json.write(out,e.getKey());out.append(':');write(out,e.getValue());}out.append('}');}
        else Json.write(out,value);
    }
    static byte[] encode(Object value){StringBuilder out=new StringBuilder();write(out,value);return out.toString().getBytes(StandardCharsets.UTF_8);}
    static byte[] changed(String kind){
        Map<String,Object> p=Json.object(Json.parse(busy)),props=properties(p);
        switch(kind){
            case "value" -> props.put("value","not the acknowledged buffer");
            case "label" -> props.put("label","changed during disable");
            case "accessibility" -> props.put("accessibilityIdentifier","different");
            case "actions" -> node(Json.object(p.get("document")).get("root"),"task.responsible").put("actions",List.of(Json.map("id","different","event","textChange")));
            case "generation" -> {for(Object value:Json.array(p.get("identities"))){Map<String,Object> i=Json.object(value);if("task.responsible".equals(i.get("id")))i.put("generation",new Json.Num("998"));}}
            default -> throw new AssertionError(kind);
        }return encode(p);
    }
    static final class Fixture implements AutoCloseable {
        final Activity activity=new Activity();final FrameLayout root=new FrameLayout(activity);
        final List<byte[]> events=new ArrayList<>();final NativeOwnerV2 owner;final NativeRenderer renderer;final EditText edit;final Handler queue;
        Fixture()throws Exception{
            ConcreteHostProbe.reset();activity.assets.put(InstalledAppearanceV2.DESCRIPTOR,descriptor);
            root.layout(0,0,1206,2622);activity.window.getDecorView().layout(0,0,1206,2622);root.hostAttach(new Object());
            owner=NativeOwnerV2.external(activity,root,new ExternalFrameSourceV2(events::add));queue=(Handler)get(owner,"handler");owner.installExternal(opened,descriptor);
            require(owner.hasCommittedPresentation(),"initial presentation");renderer=(NativeRenderer)get(get(owner,"coordinator"),"renderer");edit=(EditText)renderer.view("task.responsible");
        }
        InputConnection acknowledge()throws Exception{
            require(edit.requestFocus(),"focus");InputConnection c=edit.onCreateInputConnection(new EditorInfo());require(c!=null,"connection");
            String expected=(String)properties(Json.object(Json.parse(echo))).get("value");require(c.commitText(expected,1),"native draft");
            require(events.size()==1&&expected.equals(Json.object(Json.parse(events.get(0))).get("value")),"exact draft event");
            owner.installExternal(echo,descriptor);require(owner.hasCommittedPresentation(),"model acknowledgment");
            require(c.setComposingRegion(0,edit.getText().length()),"compose acknowledged buffer");ConcreteHostProbe.reset();return c;
        }
        @Override public void close(){ConcreteHostProbe.hook=null;owner.close();queue.drainAll(8);ConcreteHostProbe.reset();}
    }
    static void late(InputConnection c){
        require(!c.commitText("late",1),"late commit");require(!c.setComposingText("late",1),"late compose");
        require(!c.deleteSurroundingText(1,0),"late delete");require(!c.deleteSurroundingTextInCodePoints(1,0),"late codepoint delete");
        require(!c.setSelection(0,0),"late selection");require(!c.setComposingRegion(0,0),"late composing region");
        require(!c.beginBatchEdit()&&!c.endBatchEdit(),"late batch");require(!c.performEditorAction(EditorInfo.IME_ACTION_DONE),"late editor action");
        require(c.getSelectedText(0)==null&&c.getTextBeforeCursor(1,0)==null&&c.getTextAfterCursor(1,0)==null,"late reads");
    }
    static void disable(boolean baseline,String site)throws Exception{
        try(Fixture f=new Fixture()){
            InputConnection c=f.acknowledge();Editable buffer=f.edit.getText();String text=buffer.toString();Object prior=f.renderer.packet;int events=f.events.size();boolean[] hit={false};
            if(!site.isEmpty())ConcreteHostProbe.hook=(method,phase)->{if((method+"/"+phase).equals(site)){hit[0]=true;late(c);require(f.edit.getText()==buffer&&text.equals(buffer.toString())&&f.events.size()==events,"reentrant input changes nothing");}};
            Throwable failure=null;try{f.owner.installExternal(busy,descriptor);}catch(RuntimeException|Error e){failure=e;}ConcreteHostProbe.hook=null;
            if(baseline){Throwable primary=f.owner.cleanupLedger().primary();require(failure!=null&&primary instanceof AppearanceDescriptorV2.Failure,"baseline disabled refusal");require(failure.getCause()==primary&&primary.getStackTrace()[0].getMethodName().equals("preflightEditorPlanV2"),"baseline causal primary");require(f.renderer.packet==prior,"baseline unpublished");}
            else{
                require(failure==null&&f.owner.hasCommittedPresentation(),"disable commits "+failure);require(site.isEmpty()||hit[0],"callback hit "+site);
                require(f.renderer.view("task.responsible")==f.edit&&f.edit.getText()==buffer&&text.equals(buffer.toString()),"retained identities/text");
                require(!f.edit.isEnabled()&&!f.edit.hasFocus()&&BaseInputConnection.getComposingSpanStart(buffer)<0,"disabled and retired");
                require(f.edit.onCreateInputConnection(new EditorInfo())==null,"disabled no new connection");late(c);c.closeConnection();c.closeConnection();
                require(f.events.size()==events,"no extra reducer event");require(ConcreteHostProbe.count("BaseInputConnection.commitText","entry")==0&&ConcreteHostProbe.count("BaseInputConnection.deleteSurroundingText","entry")==0,"late calls never reach target");
                require(ConcreteHostProbe.count("BaseInputConnection.finishComposingText","entry")==1&&ConcreteHostProbe.count("BaseInputConnection.closeConnection","entry")==1,"single finish/close");
            }
            System.out.println("PASS independent "+(baseline?"baseline refusal":"disable "+site));cases++;
        }
    }
    static void invalid(String change)throws Exception{
        try(Fixture f=new Fixture()){
            InputConnection c=f.acknowledge();Object prior=f.renderer.packet;
            if(change.equals("unacknowledged"))require(c.commitText("new unacknowledged draft",1),"new draft");
            Throwable failure=null;try{f.owner.installExternal(change.equals("unacknowledged")?busy:changed(change),descriptor);}catch(RuntimeException|Error e){failure=e;}
            require(failure!=null&&!f.owner.hasCommittedPresentation()&&f.renderer.packet==prior,"actual owner refuses "+change);
            require(f.owner.cleanupLedger().primary()==failure||f.owner.cleanupLedger().primary()==failure.getCause(),"actual owner original primary "+change);
            require(ConcreteHostProbe.events().stream().noneMatch(e->e.productionFrames.stream().anyMatch(frame->frame.className().endsWith("$FieldTransition")&&frame.methodName().equals("prepareAttachment"))),"invalid plan never obtains retirement "+change);
            System.out.println("PASS independent actual-owner refusal "+change);cases++;
        }
    }
    static void fatal(String method)throws Exception{
        try(Fixture f=new Fixture()){
            InputConnection c=f.acknowledge();Object prior=f.renderer.packet;Error injected=new AssertionError("independent R100 "+method);boolean[] hit={false};
            ConcreteHostProbe.hook=(m,p)->{if(!hit[0]&&m.equals("BaseInputConnection."+method)&&p.equals("entry")){hit[0]=true;throw injected;}};
            Throwable failure=null;try{f.owner.installExternal(busy,descriptor);}catch(RuntimeException|Error e){failure=e;}ConcreteHostProbe.hook=null;
            require(hit[0]&&(failure==injected||failure!=null&&failure.getCause()==injected)&&f.owner.cleanupLedger().primary()==injected,"Error identity primary "+method);
            require(!f.owner.hasCommittedPresentation()&&f.renderer.packet==prior,"fatal candidate unpublished");late(c);
            require(ConcreteHostProbe.count("BaseInputConnection."+method,"entry")==1,"fatal call not retried");
            if(method.equals("closeConnection"))require(((NativeAppearanceViewsV2.NativeField)f.edit).attempt.close==NativeAppearanceViewsV2.NativeField.Close.FAILED_UNCERTAIN,"fatal close remains uncertain");
            System.out.println("PASS independent Error primary "+method);cases++;
        }
    }
    public static void main(String[] args)throws Exception{
        Path packets=Path.of(args[0]);descriptor=Files.readAllBytes(packets.resolve("descriptor.json"));echo=Files.readAllBytes(packets.resolve("synthesized-acknowledged-presave.json"));busy=Files.readAllBytes(packets.resolve("201-2.json"));
        Map<String,Object> initial=Json.object(Json.parse(echo));properties(initial).put("value","");Json.object(initial.get("document")).put("revision",new Json.Num("1"));opened=encode(initial);
        boolean baseline=args[1].equals("baseline");disable(baseline,"");
        if(!baseline){for(String site:List.of("BaseInputConnection.finishComposingText/entry","BaseInputConnection.finishComposingText/beforeReturn","BaseInputConnection.closeConnection/entry","BaseInputConnection.closeConnection/beforeReturn"))disable(false,site);
            for(String change:List.of("value","label","accessibility","actions","generation","unacknowledged"))invalid(change);
            fatal("finishComposingText");fatal("closeConnection");}
        System.out.println("PASS independent "+args[1]+" cases="+cases+" checks="+checks+"; concrete Android/JNI leaves, no native qualification");
    }
}
