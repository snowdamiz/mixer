"""One inert JDK compilation; exact source slices, no Android runtime or app changes."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

out = Path(__file__).resolve().parent
selection = json.loads((out / 'selection.json').read_text())
owned = Path(selection['owned'])
jdk = Path('/opt/homebrew/opt/openjdk@25/libexec/openjdk.jdk/Contents/Home')
root = out.parents[2]
started = time.monotonic()
commands = []


def method(source, signature):
    start = source.index(signature)
    brace = source.index('{', start)
    depth = 1
    end = brace + 1
    while depth:
        depth += (source[end] == '{') - (source[end] == '}')
        end += 1
    return source[start:end]


field = (out / 'sources/NativeAppearanceViewsV2.java').read_text()
renderer = (out / 'sources/NativeRenderer.java').read_text()
widget = method(field, 'private boolean widget(')
same = method(renderer, 'private static boolean sameEditorBindingV2(')
owner_path = root / 'native/android/app/src/dev/mixer/android/OwnerLifecycleV2.java'
owner_bytes = owner_path.read_bytes()
(out / 'sources/OwnerLifecycleV2.java').write_bytes(owner_bytes)
(out / 'extracted-methods.txt').write_text(widget + '\n\n' + same + '\n')

# Neutral lease/native stand-ins below test only the extracted early input gate
# and string comparison. They do not emulate Android widgets or validate leases.
java = '''package dev.mixer.android;
import java.util.List;
import java.util.function.Supplier;
public final class R97Control {
    static void check(boolean value, String name) {
        if (!value) throw new AssertionError(name);
        System.out.println("PASS " + name);
    }
    static final class NativeEnvironmentV2 { static void requireMain() {} }
    static final class Mutation {
        boolean current() { return true; }
        boolean result(boolean value) { return value; }
    }
    static final class EditorLease {
        String hook = "context";
        Mutation original = new Mutation();
        Object editable = new Object();
        EditorSnapshot before;
        void check() {} void exact() {}
    }
    static final class EditorSnapshot {
        EditorSnapshot(Field field, Object editable) {}
        boolean same(Field field, Object editable) { return true; }
    }
    static final class Record { EditorLease editorCallbackLease; }
    static final class Field {
        final Record record = new Record();
        boolean gate = true;
        int nativeCalls;
        Object attempt;
        String text = "";
        boolean live() { return gate; }
        Mutation entryMutation() { return new Mutation(); }
        EditorLease begin(Object attempt, Mutation original, String hook, boolean nested) { return new EditorLease(); }
        void end(EditorLease lease) {} void surface() {}
        void uncertain(Throwable failure) { throw new AssertionError(failure); }
        boolean eventsAllowed() { return true; }
        boolean marker(String value) {
            return widget("key", () -> true, () -> { nativeCalls++; text += value; return true; });
        }
        __WIDGET__
    }
    static final class TextView {
        final String text;
        TextView(String text) { this.text = text; }
        CharSequence getText() { return text; }
    }
    static final class NativeAppearanceViewsV2 {
        static final class Record { Object view; Record(String text) { view = new TextView(text); } }
    }
    static boolean sameEditorConfigurationV2(NativeAppearanceViewsV2.Record old, NativeAppearanceViewsV2.Record next) {
        return true; // Explicit fixed-equal configuration premise, not Android verification.
    }
    __SAME__
    static OwnerLifecycleV2.Decision decision(List<OwnerLifecycleV2.Decision> values, OwnerLifecycleV2.Kind kind) {
        return values.stream().filter(value -> value.kind() == kind).findFirst().orElseThrow();
    }
    public static void main(String[] args) {
        Field f = new Field();
        check(f.marker("A") && f.text.equals("A") && f.nativeCalls == 1, "exact_widget_open_marker_reaches_native_supplier");
        f.gate = false;
        check(!f.marker("B") && f.text.equals("A") && f.nativeCalls == 1, "exact_widget_closed_marker_refused_before_native_supplier_without_exception");
        f.gate = true;
        check(f.text.equals("A") && f.marker("C") && f.text.equals("AC"), "exact_widget_reopen_does_not_replay_refused_marker");
        var nativeValue = new NativeAppearanceViewsV2.Record("AB");
        check(!sameEditorBindingV2(nativeValue, new NativeAppearanceViewsV2.Record("A")), "exact_focused_echo_check_rejects_stale_prefix");
        check(sameEditorBindingV2(nativeValue, new NativeAppearanceViewsV2.Record("AB")), "exact_focused_echo_check_accepts_equal_value_under_equal_config_premise");
        Object activity = new Object(), root = new Object(), window = new Object(), resource = new Object();
        var core = new OwnerLifecycleV2(() -> {}, activity, root, true);
        var owner = core.lifetime();
        var facts = new OwnerLifecycleV2.WindowFacts(activity, root, false, true, window, 100, 100, true);
        core.focusChanged(owner, true); core.resume(owner);
        core.windowChanged(owner, facts);
        var opening = decision(core.drain(owner, core.snapshot().pendingDrain(), facts), OwnerLifecycleV2.Kind.OPEN_INITIAL);
        core.complete(opening.token(), resource, true, null);
        check(core.admitsInput(owner, core.snapshot().presentation()), "unmodified_owner_live_accepts_input");
        var oldPresentation = core.snapshot().presentation();
        var invalidation = core.invalidate(owner);
        check(decision(invalidation, OwnerLifecycleV2.Kind.SEAL).terminal() == false &&
              core.snapshot().pendingDrain() != null && !core.admitsInput(owner, oldPresentation) &&
              core.snapshot().terminalReason() == null && core.snapshot().primaryFailure() == null,
              "unmodified_owner_notice_creates_nonterminal_input_refusal_before_queued_refresh");
        var refresh = decision(core.drain(owner, core.snapshot().pendingDrain(), facts), OwnerLifecycleV2.Kind.REFRESH_COMMITTED);
        check(!core.admitsInput(owner, oldPresentation), "unmodified_owner_refuses_input_during_refresh");
        core.complete(refresh.token(), resource, true, null);
        check(core.admitsInput(owner, core.snapshot().presentation()) && !core.admitsInput(owner, oldPresentation),
              "unmodified_owner_refresh_reopens_only_new_presentation");
        System.out.println("LIMIT exact source slices plus unmodified pure owner core; no Android scheduling, Editable, JNI/Swift execution, ADB, IME, persistence or native qualification");
    }
}
'''.replace('__WIDGET__', widget).replace('__SAME__', same)
(out / 'R97Control.java').write_text(java)
src = owned / 'src/dev/mixer/android'
src.mkdir(parents=True)
(src / 'R97Control.java').write_text(java)
(src / 'OwnerLifecycleV2.java').write_bytes(owner_bytes)
(owned / 'classes').mkdir()
env = os.environ.copy()
env.update(JAVA_HOME=str(jdk), TMPDIR=str(owned / 'tmp') + '/')


def run(label, argv):
    begin = time.monotonic()
    with (out / (label + '.stdout')).open('wb') as stdout, (out / (label + '.stderr')).open('wb') as stderr:
        completed = subprocess.run([str(v) for v in argv], cwd=owned, env=env, stdout=stdout, stderr=stderr, timeout=30)
    commands.append({'label': label, 'argv': [str(v) for v in argv], 'exitCode': completed.returncode,
                     'seconds': time.monotonic() - begin})
    (out / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    if completed.returncode:
        raise RuntimeError(label + ' failed; retained output')


run('java-version', [jdk / 'bin/java', '-XX:-UsePerfData', '-version'])
run('compile', [jdk / 'bin/javac', '-J-XX:ActiveProcessorCount=2', '-J-Xmx128m', '-J-XX:-UsePerfData',
                '--release', '17', '-proc:none', '-Xlint:all', '-Werror', '-d', owned / 'classes',
                src / 'OwnerLifecycleV2.java', src / 'R97Control.java'])
run('control', [jdk / 'bin/java', '-XX:ActiveProcessorCount=2', '-Xmx128m', '-XX:-UsePerfData',
                '-Djava.io.tmpdir=' + str(owned / 'tmp'), '-cp', owned / 'classes', 'dev.mixer.android.R97Control'])
log = (out / 'control.stdout').read_text()
assert log.count('PASS ') == 9
assert time.monotonic() - started < 120
result = {'status': 'PASS_SCOPED_INERT_CONTROLS', 'checks': 9, 'compilerInvocations': 1,
          'sourceOwnerSHA256': hashlib.sha256(owner_bytes).hexdigest(),
          'sourceSlicesSHA256': hashlib.sha256((widget + '\n\n' + same + '\n').encode()).hexdigest(),
          'elapsedSeconds': time.monotonic() - started,
          'correctionDemonstrated': False, 'nativeCausePinned': False,
          'limitations': 'Gate refusal and stale echo rejection demonstrated under stated inert premises; no actual R95 timing, Android widgets or key delivery observed.',
          'cleanup': 'Only finite javac/java commands; all returned. No device, background worker or application lifetime created. Owned source/class scratch retained for review.'}
(out / 'control-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
