#!/usr/bin/env python3
"""Two-build R98 production-closure reproducer. Owns only its recorded userdata."""
import hashlib,json,os,signal,subprocess,sys,time,shutil
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
JDK=Path('/opt/homebrew/opt/openjdk@25/libexec/openjdk.jdk/Contents/Home')
DATA=Path(json.loads((OUT/'userdata.json').read_text())['owned'])
RECORD=OUT/'commands.json'
commands=json.loads(RECORD.read_text()) if RECORD.exists() else []
env=os.environ.copy()
for key in ['JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH']:env.pop(key,None)
env.update(JAVA_HOME=str(JDK),TMPDIR=str(DATA),JAVA_TOOL_OPTIONS='-XX:ActiveProcessorCount=2')
def run(name,argv):
    spent=sum(c.get('seconds',0) for c in commands)
    remaining=180-spent
    if remaining<=0:raise RuntimeError('R98 active budget exhausted')
    row={'name':name,'argv':list(map(str,argv)),'cwd':str(ROOT)}
    start=time.monotonic()
    with (OUT/'raw'/f'{name}.stdout').open('wb') as stdout,(OUT/'raw'/f'{name}.stderr').open('wb') as stderr:
        p=subprocess.Popen(row['argv'],cwd=ROOT,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        row.update(pid=p.pid,pgid=p.pid);commands.append(row);RECORD.write_text(json.dumps(commands,indent=2)+'\n')
        try:code=p.wait(timeout=min(55,remaining))
        except subprocess.TimeoutExpired:
            row['timedOut']=True;os.killpg(p.pid,signal.SIGTERM)
            try:code=p.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=10)
        row.update(exitCode=code,seconds=time.monotonic()-start)
        try:os.killpg(p.pid,0);row['groupAbsent']=False
        except ProcessLookupError:row['groupAbsent']=True
        RECORD.write_text(json.dumps(commands,indent=2)+'\n')
    print(name,code,'groupAbsent',row['groupAbsent'],flush=True)
    if code or not row['groupAbsent']:raise RuntimeError(name+' failed; preserved raw output')
def compile_stage(label):
    if sum(c['name'].endswith('-compile') for c in commands)>=2:raise RuntimeError('R98 two material javac bound reached')
    baseline=OUT/'beforeimages'
    manifest=json.loads((OUT/'baseline-inputs.json').read_text())
    sources=[]
    for rel in manifest:
        p=OUT/'afterimages'/rel if label=='candidate' and (OUT/'afterimages'/rel).is_file() else baseline/rel
        sources.append(p)
    sources.append(OUT/'tests/FocusedDisableOwnerTransitionHostTests.java')
    classes=DATA/label;classes.mkdir(exist_ok=False)
    (OUT/f'{label}-source-inputs.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},indent=2)+'\n')
    run(label+'-compile',[JDK/'bin/javac','-J-Xmx256m','-J-XX:ActiveProcessorCount=2','--release','17','-Xlint:all','-Werror','-proc:none','-sourcepath','','-classpath','','-d',classes,*sources])
    if label=='candidate':
        harness=DATA/'corrected-baseline-harness/dev/mixer/android';harness.mkdir(parents=True)
        for source in (classes/'dev/mixer/android').glob('FocusedDisableOwnerTransitionHostTests*.class'):shutil.copyfile(source,harness/source.name)
        run('baseline-corrected-focused',[JDK/'bin/java','-ea','-Xmx256m','-cp',str(DATA/'corrected-baseline-harness')+os.pathsep+str(DATA/'baseline'),'dev.mixer.android.FocusedDisableOwnerTransitionHostTests',OUT/'packets','baseline'])
    run(label+'-focused' ,[JDK/'bin/java','-ea','-Xmx256m','-cp',classes,'dev.mixer.android.FocusedDisableOwnerTransitionHostTests',OUT/'packets',label])
    if label=='candidate':
        run('candidate-r81-exact',[JDK/'bin/java','-ea','-Xmx256m','-cp',classes,'dev.mixer.android.GeneratedAddTransitionHostTests',ROOT/'native/android/tests/GeneratedAddTransitionPackets','candidate'])
        run('candidate-r58-reflow',[JDK/'bin/java','-ea','-Xmx256m','-cp',classes,'dev.mixer.android.VerticalReflowHostTests',ROOT/'verification/ui-measured-appearance-v2-contract/mixer-measured-default-v2.json','candidate'])
if sys.argv[1]=='baseline':
    run('javac-version',[JDK/'bin/javac','-version']);run('java-version',[JDK/'bin/java','-version'])
compile_stage(sys.argv[1])
