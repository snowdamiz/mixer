"""Appended to the frozen diagnostic adapter in the selected runtime only.

No import invokes native tools. Root supplies one fresh selection before dispatch.
"""
import importer
import reference_contract
_ROOT = None
_OFFICIAL = None
_ORIGINAL_SELECT = select_command
_ORIGINAL_RUN_OBSERVED = run_observed


def configure_root(selection):
    global _ROOT
    require(_ROOT is None, 'Root selection already configured')
    _ROOT = importer.validate_root(selection)


def select_command(h, argv, session):
    require(_ROOT is not None and list(map(str,argv)) == importer.command_argv(_ROOT,session), 'Command must come from root-selected context')
    require(session.resolve() == session and session.is_dir() and not session.is_symlink() and session.name == 'session' and session.parent.name == 'runtime' and session.parent.parent.name == 'native-run-'+_ROOT['runID'], 'Root-selected fresh result workspace required')
    require(not (session/'session.xcresult').exists() and not (session/'session.xcresult').is_symlink(), 'Result bundle exists before dispatch; replay refused')
    _ORIGINAL_SELECT(h,argv,session)
    _selected['sessionIdentity'] = path_identity(session,0o700)
    _selected['rootSHA256'] = sha(importer.stable(_ROOT))



def path_identity(path, mode=None):
    require(path.resolve() == path and path.is_dir() and not path.is_symlink(), 'Canonical owned directory required')
    info = path.lstat()
    require(mode is None or stat.S_IMODE(info.st_mode) == mode, 'Owned directory mode changed')
    return (info.st_dev,info.st_ino,info.st_uid)


def run_observed(commands, argv, timeout, check, retained_stdout_filter):
    result = _ORIGINAL_RUN_OBSERVED(commands,argv,timeout,check,retained_stdout_filter)
    require(path_identity(_selected['session'],0o700) == _selected['sessionIdentity'], 'Selected session identity changed during command')
    _selected['resultIdentity'] = path_identity(_selected['session']/'session.xcresult')
    return result


def observer_terminal(summary, code, argv=None):
    # The observer's own full stream binding is checked again at final import.
    cleanup = summary.get('cleanup',{})
    return (summary.get('schema') == 'mixer.apple-command-finalization-observer.2'
        and type(code) is int and summary.get('exitCode') == code
        and (argv is None or summary.get('argv') == argv)
        and summary.get('startNewSession') is True
        and summary.get('ownedProcessGroup',{}).get('state') == 'absent'
        and ((cleanup.get('attempted') is True and cleanup.get('complete') is True)
             or (cleanup.get('attempted') is False and cleanup.get('complete') is None and cleanup.get('signals') == []))
        and set(summary.get('streams',{})) == {'stdout','stderr'}
        and all(row.get('eof') is True and row.get('readerFailed') is False and row.get('readerErrors') == [] for row in summary['streams'].values())
        and summary.get('successInferredFromConsoleOrMarkers') is False)



def application_captures(output):
    folder = output/'runtime/captures'
    require(folder.resolve() == folder and folder.is_dir() and not folder.is_symlink(), 'Selected application capture directory unavailable')
    allowed = {'0001-begin.json','0001-ready.json','0001-command-1.json','0001-command-2.json','0001-before-1.json','0001-after-1.json','0001-keyboard-witness-1.json','0001-focus-diagnostic-1.json'}
    require(all(path.name.startswith('0000-settings-') or path.name in allowed for path in folder.iterdir()), 'Unexpected generation/action capture rejected')
    result = {}
    for role,name in [('begin','0001-begin.json'),('before','0001-before-1.json'),('after','0001-after-1.json'),('witness','0001-keyboard-witness-1.json')]:
        path=folder/name
        if path.exists() or path.is_symlink():
            require(path.resolve() == path and path.is_file() and not path.is_symlink(), 'Application capture path substituted')
            result[role]=path.read_bytes()
    return result


def capture_official(commands, base_run, h, output):
    """Called by the selected command wrapper; bytes originate in actual tool returns.

    Matching IDs in stored evidence cannot call this path or replace its outputs.
    """
    global _OFFICIAL
    require(_selected is not None and _selected['called'] and _OFFICIAL is None, 'Exactly one actual selected command capture required')
    session = _selected['session']
    require(_selected['rootSHA256'] == sha(importer.stable(_ROOT)) and session == output/'runtime/session' and h.RUN_DIR == output/'runtime', 'Official capture differs from root-selected run/path')
    require(path_identity(session,0o700) == _selected['sessionIdentity'] and path_identity(session/'session.xcresult') == _selected['resultIdentity'], 'Official result/session path identity substituted')
    official = {}; invocations = []
    for kind in ['summary','tests']:
        argv = ['/usr/bin/xcrun','xcresulttool','get','test-results',kind,'--path',str(session/'session.xcresult')]
        code, stdout, stderr = base_run(commands,argv,check=False)
        require(type(code) is int and code == 0, 'Official result traversal command failed')
        raw = stdout.encode('utf-8')
        importer.parse(raw)
        invocations.append({'argv':argv,'exitCode':code,'stdoutSHA256':sha(raw),'stderrSHA256':sha(stderr.encode('utf-8'))})
        official[kind] = raw
        path = output/'runtime'/('xctest-'+kind+'.json')
        with path.open('xb') as stream: stream.write(raw)
    # Read only the export generated by the exact selected command wrapper.
    retained = importer.read(output/'runtime/attachment-export.json')
    require(retained.get('ownedResultPath') == str(session/'session.xcresult') and retained.get('exitCode') == 0 and retained.get('passed') is True, 'Selected official attachment export failed')
    folder = output/'runtime/attachments'
    manifest = folder/'manifest.json'
    require(manifest.is_file() and not manifest.is_symlink(), 'Selected official manifest absent')
    official['manifest'] = manifest.read_bytes()
    # Traverse actual official execution identities before attachment bytes are joined.
    observer = importer.read(session/'command-observer/observer.json')
    importer.official_methods(importer.parse(official['summary']),importer.parse(official['tests']),_ROOT,observer['exitCode'])
    payloads = {}
    for name, row in retained['files'].items():
        require(Path(name).name == name, 'Nested attachment refused')
        path = folder/name
        require(path.is_file() and not path.is_symlink() and path.resolve() == path, 'Attachment export entry redirected')
        raw = path.read_bytes()
        require(len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'Attachment bytes changed before capture')
        if name != 'manifest.json': payloads[name] = raw
    require({path.name for path in folder.iterdir()} == set(retained['files']), 'Attachment export inventory changed')
    require(path_identity(session,0o700) == _selected['sessionIdentity'] and path_identity(session/'session.xcresult') == _selected['resultIdentity'], 'Official result/session substituted during traversal')
    captures = application_captures(output)
    captured = {'official':importer.CapturedOfficial(importer._CAPTURE_TOKEN,_ROOT,session,observer['exitCode'],official,payloads,captures),'payloads':payloads,'captures':captures,'runID':_ROOT['runID'],'argv':list(_selected['argv'])}
    receipt = {'schema':'mixer.apple-focus-reference-official-capture.1','runID':_ROOT['runID'],'rootSelectionSHA256':sha(importer.stable(_ROOT)), 'argv':_selected['argv'],'officialSHA256':{k:sha(v) for k,v in official.items()},'payloadSHA256':{k:sha(v) for k,v in payloads.items()},'applicationCaptureSHA256':{k:sha(v) for k,v in captures.items()},'officialToolInvocations':invocations,'sessionIdentity':list(_selected['sessionIdentity']),'resultIdentity':list(_selected['resultIdentity']),'nativeQualification':False}
    with (output/'runtime/official-capture.json').open('xb') as stream:
        stream.write(importer.stable(receipt));stream.flush();os.fsync(stream.fileno())
    _OFFICIAL = captured


def runtime_summary(base, h, oracle, setup_ready, scope, bridge, xctest_exit, failure, cleanup_results):
    report = {'schema':'mixer.apple-focus-reference-runtime.2','diagnosticOnly':True,'diagnosticOutcome':'unknown','runPassed':False,'strictNativeVerdictsPassed':False,'completeCaseSet':False,'cursorCompletionCredit':False,'fullSixCaseQualification':False,'nativeKeyboardQualification':False,'carrierAccepted':False,'gaAccepted':False,'physicalPhones':'disconnected-deferred','cleanupResults':cleanup_results,'sessionFailure':failure,'xcodebuildExitCode':xctest_exit,'selectedMethods':list(importer.METHODS),'selectedApplicationCases':[importer.CASE],'actualNativeInputActions':None}
    if cleanup_results is None or _OFFICIAL is None: return report
    try:
        require(_OFFICIAL['runID'] == _ROOT['runID'] and _OFFICIAL['argv'] == _selected['argv'], 'Official capture belongs to another dispatch')
        require(failure is None and getattr(h,'reporting_state',{}).get('firstFailure') is None, 'Runtime command/reporting failure prevents diagnostic import')
        require(bridge is not None and list(bridge.failures) == [] and setup_ready(bridge.settings), 'Durable Settings completion required')
        session = _selected['session']; observer_dir = session/'command-observer'
        captures = application_captures(base)
        require(captures == _OFFICIAL['captures'], 'Application observations changed after selected official capture')
        imported = importer.import_selected(_ROOT,session,importer.read(observer_dir/'observer.json'),{name:(observer_dir/(name+'.log')).read_bytes() for name in ['stdout','stderr']},_OFFICIAL['official'],_OFFICIAL['payloads'],captures,cleanup_results,oracle,reference_contract)
        report.update(imported,actualNativeInputActions=imported['keyInjectionCount'],settingsDiagnostic=bridge.settings.summary(),bridgeFailures=list(bridge.failures))
    except (KeyError,ValueError,TypeError,OSError,OverflowError,RecursionError) as error:
        report.update(diagnosticOutcome='invalid-or-incomplete-evidence',failure=type(error).__name__+': '+str(error))
    return report
