# Apple reference-first runtime preparation V5

V5 repairs the rejected V4 root-time precision, fixture closure, ambient Decimal
flags and incomplete-report namespace defects. This is host-only preparation.
The immutable packet must pass host controls, independent V5 review and a fresh
root selection before any separate native dispatch. Physical phones remain
disconnected and deferred. All runtime, keyboard, carrier and GA credit is false.

Root selected the schema 5 timestamp contract in coordination: canonical ISO
calendar date/time with no fraction or exactly six fractional digits, plus a
canonical whole-minute ±HH:MM offset. Exact existing offsets, including -04:00,
remain supported; the actual emitter remains datetime.now(UTC).isoformat().
Lexical validation precedes datetime parsing. Calendar validity and an exact
isoformat roundtrip precede freshness and range use. No endpoint is rounded,
floored or admitted with tolerance. Fractional or second-resolution timezone
offsets and submicrosecond timestamps fail closed.

The complete immutable input archive binds the original rejected V4 producer,
independent review, failures and exact separately bound Settings supplement.
The 276 journal bytes come from that supplemental archive; V4 never bound them.
Tests execute in a fresh isolated copy of the explicitly enumerated closed packet,
with filesystem audit guards preventing fallback reads from the live workspace.

Decimal raw-token parsing bounds token length and effective exponent before exact
construction with a private invalid-conversion context. It does no arithmetic,
rounding or context-dependent precision adjustment. Caller flags and traps remain
unchanged on successful and rejected documents. Original exact-nanosecond,
trailing-zero and exponent behavior is retained. Every V5 runtime-summary branch
uses a schema in the V5 namespace.

Final host results and frozen identities are recorded after replay below.
