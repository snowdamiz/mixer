// swift-tools-version: 6.2
import PackageDescription
let package = Package(
    name: "MixerAndroidBindingHostChecks",
    platforms: [.macOS(.v14)],
    products: [.executable(name: "Stage4HostTests", targets: ["Stage4HostTests"])],
    dependencies: [
        .package(path: "experimental-capability-runtime"),
        .package(path: "runtime-identity"),
        .package(path: "updates"),
        .package(path: "sdk"),
    ],
    targets: [
        .target(name: "CMixerUITransport", path: ".",
            sources: ["native/android/signed-guest-ui/transport/transport.c"],
            publicHeadersPath: "native/android/signed-guest-ui/binding/include",
            cSettings: [.define("MIXER_UI_TRANSPORT_TESTING")]),
        .target(name: "CMixerUIAndroidHostBridge", dependencies: ["CMixerUITransport"],
            path: "verification/android-binding-stage4/host-bridge",
            sources: ["host_bridge.c"], publicHeadersPath: ".",
            cSettings: [.define("MIXER_UI_TRANSPORT_TESTING")]),
        .target(name: "MixerCapabilityDurableIO",
            path: "capability-activation/Sources/MixerCapabilityDurableIO"),
        .target(name: "MixerCapabilityActivation", dependencies: [
            "MixerCapabilityDurableIO", "CMixerUITransport", "CMixerUIAndroidHostBridge",
            .product(name: "MixerExperimentalCapabilityRuntime", package: "experimental-capability-runtime"),
            .product(name: "MixerRuntimeIdentity", package: "runtime-identity"),
            .product(name: "MixerUpdates", package: "updates"),
            .product(name: "MixerCapabilities", package: "sdk"),
            .product(name: "MixerGuest", package: "sdk"),
            .product(name: "MixerUI", package: "sdk"),
            .product(name: "MixerApple", package: "sdk"),
        ], path: "capability-activation/Sources/MixerCapabilityActivation"),
        .executableTarget(name: "Stage4HostTests", dependencies: [
            "MixerCapabilityActivation", "CMixerUITransport", "CMixerUIAndroidHostBridge",
            .product(name: "MixerGuest", package: "sdk"),
            .product(name: "MixerUI", package: "sdk"),
        ], path: "Harness"),
    ],
    swiftLanguageModes: [.v6]
)
