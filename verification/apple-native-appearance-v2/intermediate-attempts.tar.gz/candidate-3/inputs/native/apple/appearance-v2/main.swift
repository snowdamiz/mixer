import UIKit
import MixerUI
@testable import MixerAppearanceInternal

@MainActor final class HarnessController: UIViewController {
    var renderer: AppearanceNativeRendererV2!
    var actionLog: [[String:Any]] = []
    var observations: [[String:Any]] = []
    var checks: [[String:Any]] = []
    var timer: Timer?
    var lastCommand = ""
    let directory = FileManager.default.urls(for:.documentDirectory,in:.userDomainMask)[0]
    var revision: UInt64 = 1
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        do {
            renderer = AppearanceNativeRendererV2(installed:try AppearanceInstalledV2.capture(bundle:.main))
            addChild(renderer); renderer.view.frame = view.bounds; renderer.view.autoresizingMask = [.flexibleWidth,.flexibleHeight]
            view.addSubview(renderer.view); renderer.didMove(toParent:self)
            renderer.onAction = { [weak self] action in
                self?.actionLog.append(["id":action.nodeID,"event":action.event.rawValue,"revision":action.revision])
                self?.save()
            }
        } catch { record("bootstrap",false,String(describing:error)) }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        DispatchQueue.main.asyncAfter(deadline:.now()+0.6) { self.stage("initial") }
        timer = Timer.scheduledTimer(withTimeInterval:0.1,repeats:true) { [weak self] _ in
            MainActor.assumeIsolated {
                guard let self, let command = try? String(contentsOf:self.directory.appendingPathComponent("command.txt"),encoding:.utf8), command != self.lastCommand else { return }
                self.lastCommand = command; self.stage(command)
            }
        }
    }
    func fixture(_ rev: UInt64, suffix: String = "", disabled: Bool = false, checked: Bool = true) -> MixerUI.UIDocument {
        func text(_ id:String,_ value:String,_ extra:[String:UIValue] = [:]) -> UINode {
            UINode(id:id,kind:.text,properties:extra.merging(["text":.string(value)]) { _,new in new })
        }
        let field = UINode(id:"field",kind:.textField,properties:["label":.string("Native editor"),"value":.string("alpha      omega"),"disabled":.bool(disabled)],actions:[.init(id:"edit",event:.textChange),.init(id:"submit",event:.submit)])
        let button = UINode(id:"button",kind:.button,properties:["label":.string("Activate"+suffix),"disabled":.bool(disabled)],actions:[.init(id:"activate",event:.activate)])
        let toggle = UINode(id:"toggle",kind:.toggle,properties:["label":.string("Shared switch"),"value":.bool(checked),"disabled":.bool(disabled)],actions:[.init(id:"toggle",event:.valueChange)])
        let v = UINode(id:"v",kind:.vStack,children:[text("body","Body / 日本語 / العربية / 👩🏽‍💻"),text("caption","Native caption",["style":.string("caption")])])
        let h = UINode(id:"h",kind:.hStack,children:[text("short","Short"),text("long","A substantially longer native shaped label that wraps under bounded proposals")])
        let z = UINode(id:"z",kind:.zStack,children:[text("overlay","Overlay"),text("overlaid","       second")])
        let selectable = text("selectable","Selectable native text",["selectable":.bool(true)])
        let first = UINode(id:"section",kind:.section,properties:["title":.string("Native shared appearance")],children:[field,button,toggle,v,h,z,selectable])
        let rows = (0..<12).map { text("row\($0)","Measured row \($0) — café 中文") }
        let second = UINode(id:"second",kind:.section,properties:["title":.string("Retained scroll")],children:rows)
        return MixerUI.UIDocument(revision:rev,root:UINode(id:"navigation",kind:.navigation,properties:["title":.string("Mixer Appearance")],children:[UINode(id:"list",kind:.list,children:[first,second])]))
    }
    func record(_ name:String,_ pass:Bool,_ detail:String = "") { checks.append(["name":name,"pass":pass,"detail":detail]) }
    func expected(_ name:String,_ operation:() throws -> Void) {
        do { try operation(); record(name,false,"unexpected acceptance") } catch { record(name,true,String(describing:error)) }
    }
    func native(_ renderer: AppearanceNativeRendererV2? = nil) -> [String:Any] {
        let owner = renderer ?? self.renderer!
        var out: [String:Any] = ["revision":owner.snapshot?.document.revision as Any,"retired":owner.retiredReason as Any,
            "rootHidden":owner.view.isHidden,"rootInteraction":owner.view.isUserInteractionEnabled,"suppressedCallbacks":owner.suppressedCallbacks,
            "actions":actionLog,"operations":owner.lastAttachmentOperations]
        var nodes: [String:Any] = [:]
        for (id,view) in owner.records {
            var value: [String:Any] = ["nativeIdentity":String(describing:ObjectIdentifier(view)),"generation":view.identity.generation,
                "kind":view.kind.rawValue,"frame":rect(view.frame),"semantic":rect(CGRect(origin:.zero,size:view.semanticSize)),
                "content":rect(view.contentRect),"visual":rect(view.visualRect),"firstBaseline":view.firstBaseline as Any,"lastBaseline":view.lastBaseline as Any,
                "fontSize":view.label.font.pointSize,"fontName":view.label.font.fontName]
            if let field = view.field {
                value["inputIdentity"] = String(describing:ObjectIdentifier(field)); value["text"] = field.text ?? ""
                value["firstResponder"] = field.isFirstResponder; value["fontSize"] = field.font?.pointSize
                value["selectedRange"] = field.selectedTextRange.map { [field.offset(from:field.beginningOfDocument,to:$0.start),field.offset(from:field.beginningOfDocument,to:$0.end)] } as Any
                value["markedRange"] = field.markedTextRange.map { [field.offset(from:field.beginningOfDocument,to:$0.start),field.offset(from:field.beginningOfDocument,to:$0.end)] } as Any
                value["cursorInstalled"] = field.selectionDisplay?.cursorView === field.cursor
                value["cursorInWindow"] = field.cursor.window === field.window && field.window != nil
                value["cursorBlinking"] = field.cursor.isBlinking; value["cursorBlinkRequests"] = field.cursor.blinkRequestCount
                value["cursorBlinkResets"] = field.cursor.blinkResetCount
                value["cursorPresentationOpacity"] = field.cursor.layer.presentation()?.opacity as Any
                value["cursorRectInWindow"] = rect(field.cursor.convert(field.cursor.bounds,to:owner.view.window))
                value["highlightInWindow"] = field.highlight.window === field.window && field.window != nil
                value["highlightRectCount"] = field.highlight.selectionRects.count
            }
            if let toggle = view.toggle { value["inputIdentity"] = String(describing:ObjectIdentifier(toggle)); value["checked"] = toggle.isOn; value["nativeMaskEmpty"] = (toggle.layer.mask as? CAShapeLayer)?.path?.isEmpty ?? false; value["accessibilityLabel"] = toggle.accessibilityLabel }
            if let scroll = view.scroll { value["scrollIdentity"] = String(describing:ObjectIdentifier(scroll)); value["offset"] = [scroll.contentOffset.x,scroll.contentOffset.y]; value["contentSize"] = [scroll.contentSize.width,scroll.contentSize.height] }
            nodes[id] = value
        }
        out["nodes"] = nodes
        if let env = owner.plan?.environment { out["environment"] = ["generation":env.generation,"profile":env.profile.rawValue,"density1024":env.density1024,"locale":env.localeIdentifier,"viewport":[env.viewport.width64,env.viewport.height64],"safeArea":[env.safeArea64.top,env.safeArea64.leading,env.safeArea64.bottom,env.safeArea64.trailing],"scheme":env.scheme.rawValue,"direction":env.direction.rawValue] }
        return out
    }
    func rect(_ rect:CGRect) -> [Double] { [rect.minX,rect.minY,rect.width,rect.height].map(Double.init) }
    func range(_ offset:Int,_ length:Int) -> UITextRange? {
        guard let field = renderer.records["field"]?.field, let start = field.position(from:field.beginningOfDocument,offset:offset),let end = field.position(from:start,offset:length) else { return nil }
        return field.textRange(from:start,to:end)
    }
    func stage(_ name:String) {
        guard let renderer else { return }
        let before = native()
        do {
            switch name {
            case "initial":
                for fixture in ["BadDescriptor","UnsupportedResources"] {
                    if let path = Bundle.main.url(forResource:fixture,withExtension:"bundle"), let bundle = Bundle(url:path) {
                        expected("installed-"+fixture) { _ = try AppearanceInstalledV2.capture(bundle:bundle) }
                    } else { record("fixture-bundle-"+fixture,false) }
                }
                let candidate = try renderer.prepare(document:fixture(1))
                record("prepare-does-not-commit",renderer.snapshot == nil && renderer.records.isEmpty)
                _ = try renderer.commit(candidate)
                record("all-ten-native-kinds",Set(renderer.records.values.map(\.kind)) == Set(NodeKind.allCases))
                record("real-native-controls",renderer.records["field"]?.field != nil && renderer.records["toggle"]?.toggle != nil && renderer.records["list"]?.scroll != nil && renderer.records["button"]?.button != nil && renderer.records["selectable"]?.selectable != nil)
            case "focus":
                let field = renderer.records["field"]!.field!
                _ = field.becomeFirstResponder(); field.selectedTextRange = range(5,0)
                record("native-focus",field.isFirstResponder)
            case "selection": renderer.records["field"]!.field!.selectedTextRange = range(5,6)
            case "caret": renderer.records["field"]!.field!.selectedTextRange = range(5,0)
            case "blink-a","blink-b","blink-c","blink-d":
                let cursor = renderer.records["field"]!.field!.cursor
                record("managed-blink-active-"+name,cursor.isBlinking && cursor.layer.animation(forKey:"mixer.native.cursor.blink") != nil)
            case "ordinary":
                let field = renderer.records["field"]!.field!, toggle = renderer.records["toggle"]!.toggle!, scroll = renderer.records["list"]!.scroll!
                let selected = field.selectedTextRange.map { [field.offset(from:field.beginningOfDocument,to:$0.start),field.offset(from:field.beginningOfDocument,to:$0.end)] }
                let offset = scroll.contentOffset
                let candidate = try renderer.prepare(document:fixture(2,suffix:" updated"))
                record("prepare-native-editor-unchanged",renderer.records["field"]!.field === field && field.isFirstResponder && selected == field.selectedTextRange.map { [field.offset(from:field.beginningOfDocument,to:$0.start),field.offset(from:field.beginningOfDocument,to:$0.end)] })
                _ = try renderer.commit(candidate); revision = 2
                record("surviving-input-list-identity",renderer.records["field"]!.field === field && renderer.records["toggle"]!.toggle === toggle && renderer.records["list"]!.scroll === scroll)
                record("selection-focus-offset-retained",field.isFirstResponder && selected == field.selectedTextRange.map { [field.offset(from:field.beginningOfDocument,to:$0.start),field.offset(from:field.beginningOfDocument,to:$0.end)] } && scroll.contentOffset == offset)
                expected("reused-candidate") { _ = try renderer.commit(candidate) }
            case "composition":
                let field = renderer.records["field"]!.field!
                field.setMarkedText("にほん",selectedRange:NSRange(location:3,length:0))
                let text = field.text, marked = field.markedTextRange
                expected("composing-preflight") { _ = try renderer.prepare(document:fixture(revision+1)) }
                record("composition-not-serialized-or-mutated",marked != nil && field.markedTextRange != nil && field.text == text && field.isFirstResponder)
                field.unmarkText()
            case "environment":
                let previous = renderer.plan!.environment.generation
                let identities = renderer.records.mapValues { ObjectIdentifier($0) }
                renderer.invalidateEnvironment()
                let candidate = try renderer.prepareEnvironment()
                let changes = try renderer.commit(candidate)
                record("environment-same-guest-revision",changes == nil && renderer.snapshot!.document.revision == revision && renderer.plan!.environment.generation > previous)
                record("environment-same-native-identities",renderer.records.mapValues { ObjectIdentifier($0) } == identities)
            case "stale":
                let stale = try renderer.prepare(document:fixture(revision+1))
                let newest = try renderer.prepare(document:fixture(revision+2))
                _ = try renderer.commit(newest); revision += 2
                expected("stale-candidate") { _ = try renderer.commit(stale) }
                let changed = try renderer.prepareEnvironment(); renderer.invalidateEnvironment()
                expected("changed-environment-candidate") { _ = try renderer.commit(changed) }
                let discarded = try renderer.prepareEnvironment(); try renderer.discard(discarded)
                expected("discard-consumes") { _ = try renderer.commit(discarded) }
            case "callback":
                let count = actionLog.count
                renderer.records["button"]!.button!.sendActions(for:.touchUpInside)
                record("native-button-callback-at-most-once",actionLog.count == count+1)
            case "pressed": renderer.records["button"]!.button!.isHighlighted = true
            case "normal": renderer.records["button"]!.button!.isHighlighted = false
            case "toggle-input":
                let count = actionLog.count
                let control = renderer.records["toggle"]!.toggle!
                control.setOn(false,animated:false); control.sendActions(for:.valueChanged)
                record("native-switch-value-callback-once",actionLog.count == count+1 && !control.isOn)
            case "toggle-reset": renderer.records["toggle"]!.toggle!.setOn(true,animated:false); renderer.records["toggle"]!.stateChanged?()
            case "scroll-update":
                let scroll = renderer.records["list"]!.scroll!, offset = scroll.contentOffset
                let candidate = try renderer.prepare(document:fixture(revision+1))
                _ = try renderer.commit(candidate); revision += 1
                record("nonzero-scroll-offset-native-identity-retained",renderer.records["list"]!.scroll === scroll && scroll.contentOffset == offset)
                record("compact-native-presentation-retained-through-commit",renderer.records["navigation"]!.label.font.pointSize == 17)
            case "scroll":
                let scroll = renderer.records["list"]!.scroll!
                scroll.setContentOffset(CGPoint(x:0,y:120),animated:false)
                record("native-scroll-compact-threshold",renderer.records["navigation"]!.label.font.pointSize == 17 && renderer.records["list"]!.frame.minY == 44)
            case "scroll-top": renderer.records["list"]!.scroll!.setContentOffset(.zero,animated:false)
            case "foreign-fault":
                let other = AppearanceNativeRendererV2(installed:try AppearanceInstalledV2.capture(bundle:.main))
                addChild(other); other.view.frame = view.bounds; view.addSubview(other.view); other.didMove(toParent:self); other.view.layoutIfNeeded()
                let foreign = try other.prepare(document:fixture(1))
                expected("foreign-owner-candidate") { _ = try renderer.commit(foreign) }
                _ = try other.commit(foreign)
                let candidate = try other.prepare(document:fixture(2))
                let old = other.snapshot!.document
                other.onAttachmentOperation = { [weak other] _ in other?.records["button"]?.button?.sendActions(for:.touchUpInside) }
                other.failAttachmentAfterOperation = 1
                expected("attach-fault") { _ = try other.commit(candidate) }
                record("main-thread-native-callback-suppressed-during-attach",other.suppressedCallbacks > 0)
                record("attach-fault-explicit-retirement",other.retiredReason != nil && other.view.isHidden && !other.view.isUserInteractionEnabled && other.snapshot!.document == old)
                expected("retired-owner-denies-future-use") { _ = try other.prepare(document:fixture(3)) }
                observations.append(["stage":"retired-owner","after":native(other)])
                other.willMove(toParent:nil); other.view.removeFromSuperview(); other.removeFromParent()
            case "disabled":
                let candidate = try renderer.prepare(document:fixture(revision+1,disabled:true,checked:false)); _ = try renderer.commit(candidate); revision += 1
                let count = actionLog.count; renderer.records["button"]!.button!.sendActions(for:.touchUpInside)
                record("disabled-native-event-denied",actionLog.count == count && !renderer.records["button"]!.button!.isEnabled)
            default: break
            }
        } catch { record("stage-"+name,false,String(describing:error)) }
        renderer.view.layoutIfNeeded()
        observations.append(["stage":name,"before":before,"after":native()])
        save()
        try? name.write(to:directory.appendingPathComponent("stage.txt"),atomically:true,encoding:.utf8)
    }
    func save() {
        func clean(_ value:Any) -> Any {
            let mirror = Mirror(reflecting:value)
            if mirror.displayStyle == .optional { return mirror.children.first.map { clean($0.value) } ?? NSNull() }
            if let array = value as? [Any] { return array.map(clean) }
            if let dictionary = value as? [String:Any] { return dictionary.mapValues(clean) }
            return value
        }
        let data: [String:Any] = ["checks":checks,"observations":observations,"actions":actionLog,"runtime":UIDevice.current.systemVersion,"physicalDeviceTested":false,"realKeyboardIMEQualified":false,"voiceOverQualified":false]
        if let bytes = try? JSONSerialization.data(withJSONObject:clean(data),options:[.prettyPrinted,.sortedKeys]) { try? bytes.write(to:directory.appendingPathComponent("observations.json"),options:.atomic) }
    }
}
@MainActor final class AppDelegate: NSObject, UIApplicationDelegate {
    var window: UIWindow?
    func application(_ application:UIApplication,didFinishLaunchingWithOptions launchOptions:[UIApplication.LaunchOptionsKey:Any]?) -> Bool {
        let window = UIWindow(frame:UIScreen.main.bounds)
        let navigation = UINavigationController(rootViewController:HarnessController())
        navigation.setNavigationBarHidden(true,animated:false)
        window.rootViewController = navigation; window.makeKeyAndVisible(); self.window = window
        return true
    }
}
UIApplicationMain(CommandLine.argc,CommandLine.unsafeArgv,nil,NSStringFromClass(AppDelegate.self))
