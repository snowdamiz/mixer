import AppFeatures
import MixerAndroidRuntime
// App-owned native entry point; state, document and reducer live in shared Swift.
// State must remain a value type; callbacks are synchronous, non-reentrant and
// free of I/O/async/shared mutable references. Sendable alone is insufficient.
private let sessions = AndroidSessionRegistry {
    try AndroidDocumentSession(state: ProjectFeatureState(),
        document: { ProjectFeature.document(state: $0, revision: $1) },
        reduce: { try ProjectFeature.handle($1, state: &$0) })
}
@_cdecl("mixer_android_create")
public func mixerAndroidCreate() -> UInt64 { sessions.create() }
@_cdecl("mixer_android_destroy")
public func mixerAndroidDestroy(_ handle: UInt64) -> Int32 { sessions.destroy(handle) }
@_cdecl("mixer_android_exchange")
public func mixerAndroidExchange(_ handle: UInt64, _ operation: UInt32,
    _ input: UnsafePointer<UInt8>?, _ inputLength: Int,
    _ output: UnsafeMutablePointer<UInt8>?, _ capacity: Int, _ written: UnsafeMutablePointer<Int>?
) -> Int32 { sessions.exchange(handle, operation, input, inputLength, output, capacity, written) }
