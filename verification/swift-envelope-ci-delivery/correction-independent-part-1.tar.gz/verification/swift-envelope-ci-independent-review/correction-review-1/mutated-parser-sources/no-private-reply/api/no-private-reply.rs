use mixer_absence::FixtureEnvelopeReplyV1;fn main(){}
