use mixer_absence::*;fn need<T:Clone>(){}fn main(){need::<FixtureEnvelopeObservationV1>();}
