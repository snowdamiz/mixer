use mixer_absence::FixtureDecodedRecordV1;fn main(){}
