//! Original-owner bounded host behavior fixtures; no dispatcher or mock engine.
use super::*;
use super::super::tests::{self as frame_tests, hooks, Hooks, cursor, owner, retire, pin_ids, install_foreign, restore_foreign};
use frame_tests::control_tests::body_owner;
use crate::experimental_swift_reactor::allocation_tests::measure_extended;
use std::cell::Cell;
thread_local! { pub(super) static PC_OVERFLOW: Cell<bool> = const { Cell::new(false) }; static FIXTURES: Cell<usize> = const { Cell::new(0) }; static STEPS: Cell<usize> = const { Cell::new(0) }; }
struct Bounds;
impl Bounds { fn new() -> Self { FIXTURES.with(|v|v.set(0)); STEPS.with(|v|v.set(0)); Self } }
impl Drop for Bounds { fn drop(&mut self) { if !std::thread::panicking() { println!("MM_BOUND fixtures={} totalSteps={} maxStepsPerFixture=64 maxFrames=3 realPages=584",FIXTURES.with(Cell::get),STEPS.with(Cell::get)); assert!(FIXTURES.with(Cell::get)<=64); assert!(STEPS.with(Cell::get)<=4096); } } }
fn observed(p: &FrameOperationPhase<'_>) -> SwiftRunUsage { p.phase.operation.control.usage(Some(p.phase.operation.wasi.usage())) }
fn storage<'a>() -> FrameOperationStorage<'a> { FrameOperationStorage{preparation:None,entry:None,returned:None,drained:None,controlled:None} }
fn fixture(enter: bool, body: Option<&[u8]>, action: impl FnOnce(&mut FrameOperationPhase<'_>)) {
 FIXTURES.with(|n|n.set(n.get()+1));
 let mut owned=if let Some(b)=body { body_owner(b,false,&[],SwiftRunBudget::default()) } else {owner()};
 let before=owned.control.as_ref().unwrap().usage(None).reservations.construction.current;
 let mut prep=Some(owned.prepare_frames(cursor())); let mut phase=prep.take().unwrap().unwrap();
 if enter {phase.enter(34).unwrap();}
 assert_eq!(phase.phase.parts.memory.len(),584*65536);
 assert!(phase.phase.parts.frames.len()<=3);
 let start=STEPS.with(Cell::get);
 action(&mut phase);
 assert!(STEPS.with(Cell::get)-start<=64);
 hooks(Hooks::default()); PC_OVERFLOW.with(|v|v.set(false));
 let report=phase.drain(); assert_eq!(report.retained_frames,0);
 let debt=report.live_unreconciled;
 let completion=phase.complete(FrameOperationStorage{preparation:prep,..storage()});
 if debt { assert!(matches!(completion,FrameCompletion::Retained(_))); let mut own=Some(owned); assert!(SwiftReactorInstance::cleanup_owned(&mut own).is_err()); assert!(own.is_some()); drop(own); }
 else { assert!(matches!(completion,FrameCompletion::Completed)); assert_eq!(owned.control.as_ref().unwrap().usage(None).reservations.construction.current,before); retire(owned); }
}
fn push(p: &mut FrameOperationPhase<'_>, v: &[Value]) { for x in v {p.phase.push_value(*x).unwrap();} }
fn op(p: &mut FrameOperationPhase<'_>, operation: Operation) -> Result<(),SwiftRunFailure> {
 STEPS.with(|n|n.set(n.get()+1)); let before=observed(p); let mut result=None; assert_eq!(p.memory_operation(operation,&mut result),Ok(()));
 let after=observed(p); assert_eq!((after.instructions,after.instruction_fuel),(before.instructions,before.instruction_fuel));
 assert_eq!(after.live.values.current,p.phase.parts.values.len()); result.unwrap()
}
const LOAD: Operation=Operation::Load{opcode:0x28,offset:0};
const STORE: Operation=Operation::Store{opcode:0x36,offset:0};
const BODY: &[u8]=&[0x41,0,0x28,2,0,0x1a,0x0b];
fn pinned<'a>(p: &mut FrameOperationPhase<'a>, s: &mut FrameOperationStorage<'a>) -> Result<(),SwiftRunFailure> { STEPS.with(|n|n.set(n.get()+1)); memory_pinned_caller_prerequisite(p,s) }
#[test] fn mm01_all_load_store_shapes() { let _b=Bounds::new();
 let expected=[Value::I32(0xf654b381u32 as i32),Value::I64(0xfedcba98f654b381u64 as i64),Value::F32(0xf654b381),Value::F64(0xfedcba98f654b381),Value::I32(-127),Value::I32(129),Value::I32(-19583),Value::I32(45953),Value::I64(-127),Value::I64(129),Value::I64(-19583),Value::I64(45953),Value::I64(-162221183),Value::I64(4132746113)];
 for (i,value) in expected.iter().enumerate(){fixture(true,None,|p|{p.phase.parts.memory[3..11].copy_from_slice(&0xfedcba98f654b381u64.to_le_bytes());push(p,&[Value::I32(3)]);let before=observed(p);op(p,Operation::Load{opcode:0x28+i as u8,offset:0}).unwrap();assert_eq!(p.phase.parts.values.as_slice(),&[*value]);assert_eq!(observed(p).live.values.current,before.live.values.current);assert_eq!(observed(p).execution_work-before.execution_work,2+width(0x28+i as u8) as u64);});}
 for opcode in 0x36..=0x3e {fixture(true,None,|p|{let value=match opcode{0x37|0x3c..=0x3e=>Value::I64(0xfedcba98f654b381u64 as i64),0x38=>Value::F32(0xf654b381),0x39=>Value::F64(0xfedcba98f654b381),_=>Value::I32(0xf654b381u32 as i32)};push(p,&[Value::I32(3),value]);let before=observed(p);op(p,Operation::Store{opcode,offset:0}).unwrap();assert!(p.phase.parts.values.is_empty());let w=width(opcode);assert_eq!(&p.phase.parts.memory[3..3+w],&0xfedcba98f654b381u64.to_le_bytes()[..w]);assert_eq!(observed(p).execution_work-before.execution_work,2+w as u64);});}
}
#[test] fn mm02_little_endian_nan_unaligned(){let _b=Bounds::new();
 for offset in [1,3,7]{for value in [Value::F32(0),Value::F32(0x80000000),Value::F32(0x7f800000),Value::F32(0x7fc12345),Value::F32(0x7f812345),Value::F32(0x12345678),Value::F64(0),Value::F64(0x8000000000000000),Value::F64(0x7ff0000000000000),Value::F64(0x7ff8123456789abc),Value::F64(0x7ff0123456789abc),Value::F64(0x123456789abcdef0)]{fixture(true,None,|p|{let (store,load,bits)=match value{Value::F32(x)=>(0x38,0x2a,x as u64),Value::F64(x)=>(0x39,0x2b,x),_=>unreachable!()};push(p,&[Value::I32(10),value]);op(p,Operation::Store{opcode:store,offset}).unwrap();let w=width(store);assert_eq!(&p.phase.parts.memory[10+offset as usize..10+offset as usize+w],&bits.to_le_bytes()[..w]);push(p,&[Value::I32(10)]);op(p,Operation::Load{opcode:load,offset}).unwrap();assert_eq!(p.phase.parts.values.as_slice(),&[value]);});}}
}
#[test] fn mm03_memory_bounds_overflow(){let _b=Bounds::new();
 for (address,offset,pass) in [(584*65536-4,0,true),(584*65536-3,0,false),(-1,u32::MAX,false)]{fixture(true,None,|p|{push(p,&[Value::I32(address)]);let r=op(p,Operation::Load{opcode:0x28,offset});assert_eq!(r.is_ok(),pass);if let Err(e)=r{assert_eq!(e.code,"memory_out_of_bounds");assert!(p.phase.parts.values.is_empty());}});}
 fixture(true,None,|p|{assert_eq!(p.memory_range(usize::MAX,1).unwrap_err().code,"memory_out_of_bounds");});
}
#[test] fn mm04_opcode_type_floor_closed(){let _b=Bounds::new();
 for operation in [Operation::Nop,Operation::Load{opcode:0x36,offset:0},Operation::Store{opcode:0x35,offset:0}]{fixture(true,None,|p|{push(p,&[Value::I32(1),Value::I32(2)]);let before=observed(p);assert_eq!(op(p,operation).unwrap_err().kind,SwiftRunFailureKind::UnsupportedEnvironment);assert_eq!(p.phase.parts.values.len(),2);assert_eq!(observed(p).execution_work,before.execution_work);});}
 fixture(false,None,|p|{assert_eq!(op(p,LOAD).unwrap_err().code,"swift_memory_frame_missing");});
 for fault in 0..7 {fixture(true,None,|p|{push(p,&[Value::I32(0),Value::I32(7)]);let f=&mut p.phase.parts.frames[0];let original=(f.base,f.operands,f.controls);match fault{0=>f.base=1,1=>f.operands=3,2=>f.operands=2,3=>f.operands=1,4=>f.controls=99,5=>p.phase.parts.values[0]=Value::I64(0),_=>p.phase.parts.values[1]=Value::F64(0)};let before=observed(p);assert!(op(p,STORE).is_err());assert_eq!(p.phase.parts.values.len(),2);assert_eq!(observed(p).execution_work,before.execution_work);let f=&mut p.phase.parts.frames[0];(f.base,f.operands,f.controls)=original;});}
}
#[test] fn mm05_load_store_work_prefix(){let _b=Bounds::new();
 for store in [false,true]{for allowed in 0..=6 {fixture(true,None,|p|{push(p,if store {&[Value::I32(3),Value::I32(0x12345678)]}else{&[Value::I32(3)]});let before=observed(p);let old=p.phase.operation.control.test_replace_execution_work_limit(before.execution_work+allowed);let r=op(p,if store{STORE}else{LOAD});p.phase.operation.control.test_replace_execution_work_limit(old);let lengths=if store{[2,1,0,0,0,0,0]}else{[1,0,0,0,0,0,1]};assert_eq!(p.phase.parts.values.len(),lengths[allowed as usize]);assert_eq!(r.is_ok(),allowed>=6);let spent=if store {if allowed==0{0}else if allowed==1{1}else if allowed<6{2}else{6}}else if allowed==0{0}else if allowed<5{1}else if allowed==5{5}else{6};assert_eq!(observed(p).execution_work-before.execution_work,spent);assert_eq!(&p.phase.parts.memory[3..7],if store&&allowed>=6{&[0x78,0x56,0x34,0x12]}else{&[0;4]});});}}
}
#[test] fn mm06_cancel_prefix(){let _b=Bounds::new();
 for store in [false,true]{for checkpoint in 0..=3 {fixture(true,None,|p|{push(p,if store{&[Value::I32(3),Value::I32(9)]}else{&[Value::I32(3)]});hooks(Hooks{push_fault:6,cancel_local:Some(checkpoint),..Hooks::default()});let r=op(p,if store{STORE}else{LOAD});assert_eq!(r.is_ok(),checkpoint>=3);let expected=if store{[2,1,0,0]}else{[1,0,0,1]};assert_eq!(p.phase.parts.values.len(),expected[checkpoint]);assert_eq!(p.phase.parts.memory[3],if store&&checkpoint>=3{9}else{0});if let Err(e)=r{assert_eq!(e.kind,SwiftRunFailureKind::Cancelled);}});}}
 fixture(true,Some(BODY),|p|{p.phase.parts.frames[0].pc=1;push(p,&[Value::I32(0)]);hooks(Hooks{push_fault:6,cancel_local:Some(0),..Hooks::default()});let before=observed(p);let pins=pin_ids(p);let memory=p.phase.parts.memory[..8].to_vec();let mut s=storage();assert_eq!(pinned(p,&mut s),Ok(()));assert_eq!(s.entry.unwrap().unwrap_err().kind,SwiftRunFailureKind::Cancelled);assert_eq!(observed(p).instructions,before.instructions+1);assert_eq!(observed(p).instruction_fuel,before.instruction_fuel+1);assert_eq!(observed(p).execution_work,before.execution_work);assert_eq!(p.phase.parts.frames[0].pc,1);assert_eq!(p.phase.parts.values.as_slice(),&[Value::I32(0)]);assert_eq!(pin_ids(p),pins);assert_eq!(&p.phase.parts.memory[..8],memory.as_slice());assert!(matches!(p.lifecycle,Lifecycle::Terminal));assert!(matches!(p.cleanup.disposition,FrameDisposition::Draining));println!("MM06_CALLER_CANCEL afterInstruction=true instructionDelta=1 fuelDelta=1 workDelta=0 pcDelta=0 valueDelta=0 memoryChanged=false pinsChanged=false outerPublication=Ok stored=Cancelled terminal=true draining=true");});
}
#[test] fn mm07_pinned_decoded_caller(){let _b=Bounds::new();fixture(true,Some(BODY),|p|{push(p,&[Value::I32(0)]);p.phase.parts.frames[0].pc=1;let pin=pin_ids(p);let before=observed(p);let actual={let f=&p.phase.parts.frames[0];p.phase.parts.cache.view(&f.pin,p.phase.operation.control,Some(&*p.phase.operation.wasi)).unwrap().instructions[1]};let mut s=storage();pinned(p,&mut s).unwrap();assert_eq!(s.entry,Some(Ok(())));assert_eq!(p.phase.operation.cursor.function,Some(34));assert_eq!(p.phase.operation.cursor.offset,Some(actual.offset));assert_eq!(p.phase.parts.frames[0].pc,2);assert_eq!(pin_ids(p),pin);assert_eq!(observed(p).instructions-before.instructions,1);assert_eq!(observed(p).instruction_fuel-before.instruction_fuel,1);assert_eq!(observed(p).execution_work-before.execution_work,7);});
 // Real early active, missing instruction/frame, caller work and checked-PC errors.
 for fault in 0..5{fixture(true,Some(BODY),|p|{push(p,&[Value::I32(0)]);p.phase.parts.frames[0].pc=1;let old=if fault==2{Some(p.phase.operation.control.test_replace_execution_work_limit(observed(p).execution_work))}else{None};match fault{0=>p.terminal(),1=>p.phase.parts.frames[0].pc=usize::MAX,3=>PC_OVERFLOW.with(|v|v.set(true)),4=>p.phase.operation.control.cancellation().cancel(),_=>{}}let before=observed(p);let mut s=storage();pinned(p,&mut s).unwrap();assert!(s.entry.unwrap().is_err());if fault==4{assert_eq!(observed(p).instructions,before.instructions);assert_eq!(observed(p).instruction_fuel,before.instruction_fuel);assert_eq!(observed(p).execution_work,before.execution_work);println!("MM07_CALLER_CANCEL beforeInstruction=true instructionDelta=0 fuelDelta=0 workDelta=0 pcDelta=0");}assert!(matches!(p.lifecycle,Lifecycle::Terminal));assert!(matches!(p.cleanup.disposition,FrameDisposition::Draining));if let Some(old)=old{p.phase.operation.control.test_replace_execution_work_limit(old);}assert_eq!(p.phase.parts.values.len(),1);});}
 fixture(false,None,|p|{let mut s=storage();pinned(p,&mut s).unwrap();assert_eq!(s.entry.unwrap().unwrap_err().code,"swift_memory_caller_frame");assert!(matches!(p.lifecycle,Lifecycle::Terminal));});
 let mut foreign=owner();fixture(true,Some(BODY),|p|{push(p,&[Value::I32(0)]);p.phase.parts.frames[0].pc=1;let foreign_header=crate::experimental_swift_reactor::cache::inspection::replace_header(foreign.cache.as_mut().unwrap(),None);let original=crate::experimental_swift_reactor::cache::inspection::replace_header(p.phase.parts.cache,foreign_header);let mut s=storage();pinned(p,&mut s).unwrap();assert!(s.entry.unwrap().is_err());assert!(matches!(p.lifecycle,Lifecycle::Terminal));assert_eq!(p.phase.parts.frames[0].pc,1);let foreign_header=crate::experimental_swift_reactor::cache::inspection::replace_header(p.phase.parts.cache,original);assert!(crate::experimental_swift_reactor::cache::inspection::replace_header(foreign.cache.as_mut().unwrap(),foreign_header).is_none());});retire(foreign);
 FIXTURES.with(|n|n.set(n.get()+1));let mut own=body_owner(BODY,false,&[],SwiftRunBudget{instruction_fuel:0,..SwiftRunBudget::default()});let mut prep=Some(own.prepare_frames(cursor()));let mut p=prep.take().unwrap().unwrap();p.enter(34).unwrap();push(&mut p,&[Value::I32(0)]);p.phase.parts.frames[0].pc=1;let before=observed(&p);let mut s=storage();pinned(&mut p,&mut s).unwrap();assert_eq!(s.entry.unwrap().unwrap_err().kind,SwiftRunFailureKind::FuelExhausted);assert_eq!(p.phase.parts.frames[0].pc,1);assert_eq!(observed(&p).execution_work,before.execution_work);p.drain();assert!(matches!(p.complete(FrameOperationStorage{preparation:prep,..s}),FrameCompletion::Completed));retire(own);

}
#[test] fn mm08_post_pop_live_fault(){let _b=Bounds::new();fixture(true,None,|p|{p.phase.operation.wasi.dispatch(p.phase.operation.control,crate::experimental_wasi::WasiFunction::ArgsSizesGet,&[Value::I32(0),Value::I32(4)],&mut [0;8],cursor()).unwrap();let wasi=p.phase.operation.wasi.usage();push(p,&[Value::I32(0)]);hooks(Hooks{push_fault:5,..Hooks::default()});let mut slot=None;assert_eq!(p.memory_operation(LOAD,&mut slot),Ok(()));let e=slot.unwrap().unwrap_err();assert_eq!(e.code,"swift_run_live_underflow");assert_eq!(e.stage,SwiftRunStage::Cleanup);assert_eq!((e.function,e.offset,e.resource),(None,None,None));assert_eq!(e.at_failure.wasi,Some(wasi));assert!(p.cleanup.live_unreconciled);assert!(p.phase.parts.values.is_empty());assert_eq!(observed(p).live.values.current,0);assert!(matches!(p.lifecycle,Lifecycle::Terminal));let mut next=None;p.memory_operation(LOAD,&mut next).unwrap();assert_eq!(next.unwrap().unwrap_err().code,e.code);});}
#[test] fn mm09_held_pin_cleanup(){let _b=Bounds::new();
 for case in 0..10 {
 FIXTURES.with(|n|n.set(n.get()+2));let mut foreign=owner();install_foreign(&mut foreign);let mut own=owner();let mut prep=Some(own.prepare_frames(cursor()));let mut p=prep.take().unwrap().unwrap();p.enter(34).unwrap();p.enter(36).unwrap();p.enter(34).unwrap();let pins=pin_ids(&p);
 let store=case>=4&&case<=7;push(&mut p,if store{&[Value::I32(0),Value::I32(9)]}else{&[Value::I32(-1)]});
 let old=if (1..=7).contains(&case){let base=observed(&p).execution_work;Some(p.phase.operation.control.test_replace_execution_work_limit(base+match case{1|4=>0,2|5=>1,3=>5,_=>2}))}else{None};
 if case==8{p.phase.operation.control.cancellation().cancel();}let operation=if case==9{Operation::Nop}else if store{STORE}else{LOAD};let failure=op(&mut p,operation).unwrap_err();if let Some(old)=old{p.phase.operation.control.test_replace_execution_work_limit(old);}assert_eq!(pin_ids(&p),pins);
 hooks(Hooks{release_mask:7,..Hooks::default()});let report=p.drain();assert_eq!(report.retained_frames,3);assert_eq!(pin_ids(&p),pins);assert_eq!(p.phase.parts.cache.usage().active_pins,3);assert_eq!(report.first_failure.unwrap().code,failure.code);
 hooks(Hooks::default());assert_eq!(p.drain().retained_frames,3);assert!(matches!(p.complete(FrameOperationStorage{preparation:prep,..storage()}),FrameCompletion::Retained(_)));
 let mut resumed=Some(own.resume_frame_cleanup());let mut p=resumed.take().unwrap().unwrap();let r=p.drain();assert_eq!(r.retained_frames,0);assert!(!r.live_unreconciled);assert_eq!(r.first_failure.unwrap().code,failure.code);assert!(matches!(p.complete(FrameOperationStorage{preparation:resumed,..storage()}),FrameCompletion::Completed));
 restore_foreign(&mut foreign);retire(foreign);retire(own);
 }
}
#[test] fn mm10_actual_live_capacity(){let _b=Bounds::new();
 for fault in [2,4]{fixture(true,None,|p|{push(p,&[Value::I32(0)]);hooks(Hooks{push_fault:fault,..Hooks::default()});let r=op(p,LOAD);assert_eq!(r.unwrap_err().kind,SwiftRunFailureKind::ValueLimit);assert!(p.phase.parts.values.is_empty());assert_eq!(observed(p).live.values.current,0);});}
 fixture(true,None,|p|{push(p,&[Value::I32(0)]);p.phase.operation.control.remove_live(Live::Values,1).unwrap();let before=observed(p).execution_work;let mut s=None;p.memory_operation(LOAD,&mut s).unwrap();assert_eq!(s.unwrap().unwrap_err().code,"swift_frame_live_mismatch");assert_eq!(p.phase.parts.values.len(),1);assert_eq!(observed(p).execution_work,before);assert!(p.cleanup.live_unreconciled);});
}
#[test] fn mm11_slot_vacancy(){let _b=Bounds::new();for direct in [false,true]{for failed in [false,true]{fixture(true,Some(BODY),|p|{push(p,&[Value::I32(0)]);p.phase.parts.frames[0].pc=1;let saved=if failed{Err(p.invariant("first_failure"))}else{Ok(())};let mut s=storage();s.entry=Some(saved);let before=observed(p);let pins=pin_ids(p);assert!(if direct{p.memory_operation(LOAD,&mut s.entry)}else{pinned(p,&mut s)}.is_err());assert_eq!(s.entry,Some(saved));assert_eq!(p.phase.parts.frames[0].pc,1);assert_eq!(pin_ids(p),pins);assert_eq!(p.phase.parts.values.len(),1);assert_eq!((observed(p).instructions,observed(p).execution_work),(before.instructions,before.execution_work));if failed{assert_eq!(p.invariant("later").code,"first_failure");}});}}}
#[test] fn mm12_outcome_completion(){let _b=Bounds::new();
 fixture(true,Some(BODY),|p|{push(p,&[Value::I32(-1)]);p.phase.parts.frames[0].pc=1;let mut s=storage();assert_eq!(pinned(p,&mut s),Ok(()));let e=s.entry.unwrap().unwrap_err();let before=observed(p);assert!(pinned(p,&mut s).is_err());assert_eq!(s.entry,Some(Err(e)));assert_eq!(observed(p).instructions,before.instructions);});
 fixture(true,Some(BODY),|p|{push(p,&[Value::I32(0)]);p.phase.parts.frames[0].pc=1;let mut s=storage();pinned(p,&mut s).unwrap();assert_eq!(s.entry.take(),Some(Ok(())));p.phase.parts.frames[0].pc=1;pinned(p,&mut s).unwrap();assert_eq!(s.entry,Some(Ok(())));assert_eq!(p.phase.parts.frames[0].pc,2);});
 // Feed the actual occupied failure slot through original fixed completion.
 FIXTURES.with(|n|n.set(n.get()+1));let mut own=owner();let mut s=storage();s.preparation=Some(own.prepare_frames(cursor()));let mut p=s.preparation.take().unwrap().unwrap();p.enter(34).unwrap();push(&mut p,&[Value::I32(-1)]);p.memory_operation(LOAD,&mut s.entry).unwrap();let e=s.entry.unwrap().unwrap_err();s.drained=Some(p.drain());assert_eq!(s.drained.as_ref().unwrap().first_failure.unwrap().code,e.code);assert!(matches!(p.complete(s),FrameCompletion::Completed));retire(own);
}
#[test] fn mm13_no_alloc_warm(){let _b=Bounds::new();
 for opcode in 0x28..=0x3e {for trap in [false,true]{fixture(true,None,|p|{let address=Value::I32(if trap{-1}else{0});let store=opcode>=0x36;let value=match opcode{0x37|0x3c..=0x3e=>Value::I64(-1),0x38=>Value::F32(0x7fc12345),0x39=>Value::F64(0x7ff0123456789abc),_=>Value::I32(-1)};if store{push(p,&[address,value]);}else{push(p,&[address]);}let operation=if store{Operation::Store{opcode,offset:0}}else{Operation::Load{opcode,offset:0}};let ((outer,slot),stats)=measure_extended(Some(0),||{let mut s=None;let r=p.memory_operation(operation,&mut s);(r,s)});assert_eq!(stats.attempts,0);assert_eq!(stats.injected_failures,0);outer.unwrap();assert_eq!(slot.unwrap().is_ok(),!trap);});}}
 for store in [false,true]{for cancel in [false,true]{for checkpoint in 0..3{fixture(true,None,|p|{if store{push(p,&[Value::I32(0),Value::I32(9)]);}else{push(p,&[Value::I32(0)]);}if cancel{hooks(Hooks{push_fault:6,cancel_local:Some(checkpoint),..Hooks::default()});}else{let base=observed(p).execution_work;p.phase.operation.control.test_replace_execution_work_limit(base+if checkpoint==2&&!store{5}else{checkpoint as u64});}let ((outer,slot),stats)=measure_extended(Some(0),||{let mut s=None;let r=p.memory_operation(if store{STORE}else{LOAD},&mut s);(r,s)});assert_eq!(stats.attempts,0);assert_eq!(stats.injected_failures,0);outer.unwrap();assert!(slot.unwrap().is_err());});}}}
}
#[test] fn mm14_frozen_parity(){let _b=Bounds::new();
 fixture(true,None,|p|{push(p,&[Value::I32(0),Value::I32(0x12345678)]);op(p,STORE).unwrap();push(p,&[Value::I32(0)]);op(p,LOAD).unwrap();assert_eq!(p.phase.parts.values.as_slice(),&[Value::I32(0x12345678)]);assert_eq!(&p.phase.parts.memory[..4],&[0x78,0x56,0x34,0x12]);});
 #[cfg(feature="experimental-span-execution")]
 {use crate::experimental::{cache::{FunctionCache,CacheBudget},execution::{SpanInstance,ExecutionBudget},validate_spans,ValidationBudget};
 FIXTURES.with(|n|n.set(n.get()+1));
 // Original bounded Wasm binary fixture: ()->i32, one-page memory, run export.
 let bytes:Vec<u8>=[b"\0asm\x01\0\0\0".as_slice(),&[1,5,1,0x60,0,1,0x7f,3,2,1,0,5,4,1,1,1,1,7,7,1,3,b'r',b'u',b'n',0,0,10,16,1,14,0,0x41,0,0x41,0x78,0x36,2,0,0x41,0,0x28,2,0,0x0b]].concat();let limits=crate::Limits{profile:crate::Profile::TableMemoryV3,..crate::Limits::default()};let cancel=crate::Cancellation::default();let spans=validate_spans(&bytes,limits,ValidationBudget::default(),&cancel).unwrap();let cache=FunctionCache::new(spans,CacheBudget::default(),&cancel).unwrap();let mut frozen=SpanInstance::new(cache,ExecutionBudget::default(),cancel).unwrap();assert_eq!(frozen.invoke("run",&[]).unwrap(),Some(Value::I32(-8)));assert_eq!(&frozen.memory()[..4],&[0xf8,0xff,0xff,0xff]);assert_eq!(frozen.usage().active_pins,0);println!("MM_FROZEN executed original public SpanInstance load/store; baseline/candidate oracle suite separately bound");}
 #[cfg(not(feature="experimental-span-execution"))]
 println!("MM_FROZEN feature absent in Swift-only build; baseline/candidate execution oracle is separate all-feature receipt");
}
#[test] fn mm15_deferred_fail_closed(){let _b=Bounds::new();for operation in [Operation::MemoryCopy,Operation::MemoryFill,Operation::MemoryGrow,Operation::MemorySize,Operation::Return,Operation::Const(Value::I32(0)),Operation::Nop]{fixture(true,None,|p|{push(p,&[Value::I32(0),Value::I32(1)]);let cap=p.phase.parts.memory.capacity();let before=observed(p);assert_eq!(op(p,operation).unwrap_err().kind,SwiftRunFailureKind::UnsupportedEnvironment);assert_eq!(p.phase.parts.memory.capacity(),cap);assert_eq!(p.phase.parts.values.len(),2);assert_eq!(observed(p).reservations,before.reservations);assert_eq!(observed(p).execution_work,before.execution_work);});}}
#[test] fn mm16_accounting_restore(){let _b=Bounds::new();fixture(true,None,|p|{let before=observed(p);push(p,&[Value::I32(0)]);op(p,LOAD).unwrap();assert_eq!(observed(p).reservations,before.reservations);assert_eq!(FRAME_OPERATION_BYTES.unwrap(),super::super::ACTIVE_BYTES+value_operations::VALUE_OPERATION_BYTES.unwrap()+control_operations::ACTIVE_BYTES+ACTIVE_BYTES);assert_eq!(SwiftRunBudget::default().state_bytes,128*1024*1024);assert_eq!(SwiftRunBudget::default().combined_bytes,256*1024*1024);println!("MM_EXTERNAL exact MIR inventory and eight actual layouts are bound outside runtime fixture");});}

// Independent test additions. These call original owners and production methods.
#[test]
fn review_all23_final_range_and_offset() {
 let _bound=Bounds::new();
 let widths=[4,8,4,8,1,1,2,2,1,1,2,2,4,4,4,8,4,8,1,2,1,2,4];
 for (index,w) in widths.into_iter().enumerate(){for outside in [false,true]{
  fixture(true,None,|p|{
   let opcode=0x28+index as u8;let store=opcode>=0x36;let end=p.phase.parts.memory.len();
   let start=end-w+usize::from(outside);let offset=13u32;let address=(start-offset as usize) as i32;
   let value=match opcode{0x37|0x3c..=0x3e=>Value::I64(-1),0x38=>Value::F32(u32::MAX),0x39=>Value::F64(u64::MAX),_=>Value::I32(-1)};
   if store{push(p,&[Value::I32(address),value]);}else{push(p,&[Value::I32(address)]);}
   let before=observed(p);let pins=pin_ids(p);let cap=p.phase.parts.memory.capacity();
   let result=op(p,if store{Operation::Store{opcode,offset}}else{Operation::Load{opcode,offset}});
   assert_eq!(result.is_err(),outside);assert_eq!(pin_ids(p),pins);assert_eq!(p.phase.parts.memory.capacity(),cap);
   assert_eq!(observed(p).reservations,before.reservations);
   if outside {assert_eq!(result.unwrap_err().code,"memory_out_of_bounds");assert!(p.phase.parts.values.is_empty());assert_eq!(&p.phase.parts.memory[end-8..],&[0;8]);assert_eq!(observed(p).execution_work-before.execution_work,if store{2}else{1});}
   else if store {assert!(p.phase.parts.values.is_empty());assert!(p.phase.parts.memory[start..].iter().all(|v|*v==255));assert_eq!(observed(p).execution_work-before.execution_work,(2+w) as u64);}
   else {let expected=match opcode{0x29|0x30..=0x35=>Value::I64(0),0x2a=>Value::F32(0),0x2b=>Value::F64(0),_=>Value::I32(0)};assert_eq!(p.phase.parts.values.as_slice(),&[expected]);assert_eq!(observed(p).execution_work-before.execution_work,(2+w) as u64);}
  });
 }}
 println!("REVIEW final-range all23 forms success/trap 46 original owners; explicit independent widths; nonzero offset");
}
#[test]
fn review_all_store_type_denials_preserve_floor() {
 let _bound=Bounds::new();
 for opcode in 0x36..=0x3e{for wrong in [Value::I32(8),Value::I64(8),Value::F32(8),Value::F64(8)]{
  let right=match opcode{0x37|0x3c..=0x3e=>crate::Type::I64,0x38=>crate::Type::F32,0x39=>crate::Type::F64,_=>crate::Type::I32};if wrong.ty()==right{continue}
  fixture(true,None,|p|{
   push(p,&[Value::I64(0x7788),Value::I32(0),wrong]);p.phase.parts.frames[0].operands=1;
   let before=observed(p);let mut slot=None;p.memory_operation(Operation::Store{opcode,offset:0},&mut slot).unwrap();
   assert_eq!(slot.unwrap().unwrap_err().code,"swift_memory_operand_type");assert_eq!(p.phase.parts.values.as_slice(),&[Value::I64(0x7788),Value::I32(0),wrong]);
   assert_eq!(observed(p).execution_work,before.execution_work);assert_eq!(observed(p).reservations,before.reservations);assert_eq!(&p.phase.parts.memory[..8],&[0;8]);
   p.phase.parts.frames[0].operands=0;
  });
 }}
 println!("REVIEW 27 exact store-type denials preserve caller/local floor, values, bytes and work");
}
#[test]
fn review_pinned_success_requires_take_before_next_decode() {
 let _bound=Bounds::new();
 fixture(true,Some(BODY),|p|{
  push(p,&[Value::I32(0)]);p.phase.parts.frames[0].pc=1;let before=observed(p);let mut s=storage();
  pinned(p,&mut s).unwrap();assert_eq!(s.entry.take(),Some(Ok(())));let success=observed(p);
  assert_eq!(success.instructions-before.instructions,1);assert_eq!(success.instruction_fuel-before.instruction_fuel,1);assert_eq!(success.execution_work-before.execution_work,7);assert_eq!(p.phase.parts.frames[0].pc,2);
  // PC now selects the actual decoded drop. The memory-only caller must reject
  // it before instruction charging and preserve the completed load value.
  pinned(p,&mut s).unwrap();let failure=s.entry.unwrap().unwrap_err();assert_eq!(failure.kind,SwiftRunFailureKind::UnsupportedEnvironment);
  assert_eq!(observed(p).instructions,success.instructions);assert_eq!(observed(p).execution_work,success.execution_work);assert_eq!(p.phase.parts.frames[0].pc,2);assert_eq!(p.phase.parts.values.as_slice(),&[Value::I32(0)]);
  let pins=pin_ids(p);assert!(p.memory_operation(STORE,&mut s.entry).is_err());assert_eq!(s.entry,Some(Err(failure)));assert_eq!(pin_ids(p),pins);assert_eq!(p.invariant("later").code,failure.code);
 });
 println!("REVIEW actual pin selects load then decoded drop; take success, preserve stored failure and exactly-once work/fuel/PC");
}
#[test]
fn review_caller_zero_alloc_and_occupied_precedes_inactive() {
 let _bound=Bounds::new();
 for trap in [false,true]{fixture(true,Some(BODY),|p|{
  push(p,&[Value::I32(if trap{-1}else{0})]);p.phase.parts.frames[0].pc=1;let mut s=storage();
  let (result,stats)=measure_extended(Some(0),||pinned(p,&mut s));assert_eq!(stats.attempts,0);assert_eq!(stats.injected_failures,0);result.unwrap();assert_eq!(s.entry.unwrap().is_err(),trap);
  let old=s.entry;let before=observed(p);let cursor=p.phase.operation.cursor;p.terminal();
  let (result,stats)=measure_extended(Some(0),||pinned(p,&mut s));assert!(result.is_err());assert_eq!(stats.attempts,0);assert_eq!(s.entry,old);assert_eq!((p.phase.operation.cursor.stage,p.phase.operation.cursor.function,p.phase.operation.cursor.offset),(cursor.stage,cursor.function,cursor.offset));
  assert_eq!(observed(p).instructions,before.instructions);assert_eq!(observed(p).execution_work,before.execution_work);assert_eq!(p.phase.parts.frames[0].pc,2);
 });}
 println!("REVIEW actual caller success/trap/occupied routes observe zero allocations under first-request refusal");
}
#[test]
fn review_store_postpop_cleanup_preserves_first_diagnostic() {
 let _bound=Bounds::new();fixture(true,None,|p|{
  push(p,&[Value::I32(0),Value::I32(123)]);let pins=pin_ids(p);let before=observed(p);
  hooks(Hooks{push_fault:5,..Hooks::default()});let mut s=storage();p.memory_operation(STORE,&mut s.entry).unwrap();let failure=s.entry.unwrap().unwrap_err();
  assert_eq!(failure.stage,SwiftRunStage::Cleanup);assert_eq!((failure.function,failure.offset,failure.resource),(None,None,None));assert_eq!(failure.code,"swift_run_live_underflow");assert!(p.cleanup.live_unreconciled);assert_eq!(p.phase.parts.values.as_slice(),&[Value::I32(0)]);assert_eq!(&p.phase.parts.memory[..8],&[0;8]);assert_eq!(pin_ids(p),pins);assert_eq!(observed(p).execution_work-before.execution_work,1);
  assert!(p.memory_operation(LOAD,&mut s.entry).is_err());assert_eq!(s.entry,Some(Err(failure)));assert_eq!(p.invariant("later").code,failure.code);
 });println!("REVIEW store first-pop debt retains absent-cursor Cleanup and original slot; no fabricated restoration");
}
#[test]
fn review_partial_pin_retention_requires_cleanup_reacquisition() {
 let _bound=Bounds::new();FIXTURES.with(|n|n.set(n.get()+2));
 let mut foreign=owner();install_foreign(&mut foreign);let mut own=owner();let original_bound=own.control.as_ref().unwrap().usage(None).reservations.construction.current;
 let mut s=storage();s.preparation=Some(own.prepare_frames(cursor()));let mut p=s.preparation.take().unwrap().unwrap();p.enter(34).unwrap();p.enter(36).unwrap();p.enter(34).unwrap();
 push(&mut p,&[Value::I32(-1)]);p.memory_operation(LOAD,&mut s.entry).unwrap();let failure=s.entry.unwrap().unwrap_err();
 hooks(Hooks{release_mask:1,..Hooks::default()});let first=p.drain();assert_eq!(first.retained_frames,1);assert_eq!(first.first_failure,Some(failure));assert_eq!(p.phase.parts.cache.usage().active_pins,1);
 hooks(Hooks::default());assert_eq!(p.drain().retained_frames,1);assert_eq!(p.phase.parts.cache.usage().active_pins,1);assert!(matches!(p.complete(s),FrameCompletion::Retained(_)));
 let mut resumed=Some(own.resume_frame_cleanup());let mut p=resumed.take().unwrap().unwrap();let report=p.drain();assert_eq!(report.retained_frames,0);assert_eq!(report.first_failure,Some(failure));assert!(!report.live_unreconciled);assert!(matches!(p.complete(FrameOperationStorage{preparation:resumed,..storage()}),FrameCompletion::Completed));
 assert_eq!(own.control.as_ref().unwrap().usage(None).reservations.construction.current,original_bound);restore_foreign(&mut foreign);retire(foreign);retire(own);
 println!("REVIEW deepest release rejected while other original pins drain; sticky original OOB; explicit cleanup-only retry restores bound");
}
