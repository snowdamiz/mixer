//===----------------------------------------------------------------------===//
//
// This source file is part of the SwiftCrypto open source project
//
// Copyright (c) 2019 Apple Inc. and the SwiftCrypto project authors
// Licensed under Apache License v2.0
//
// See LICENSE.txt for license information
// See CONTRIBUTORS.txt for the list of SwiftCrypto project authors
//
// SPDX-License-Identifier: Apache-2.0
//
//===----------------------------------------------------------------------===//
#if canImport(CryptoKit)
@_exported import CryptoKit
#else
#if hasFeature(SourceWarningControl)
@diagnose(ImplementationOnlyDeprecated, as: ignored) @_implementationOnly import CCryptoBoringSSL
#else
@_implementationOnly import CCryptoBoringSSL
#endif
#if canImport(FoundationEssentials)
import FoundationEssentials
#else
import Foundation
#endif

// For signing and verifying, we use BoringSSL's Ed25519, not the X25519 stuff.
@available(macOS 10.15, iOS 13, watchOS 6, tvOS 13, macCatalyst 13, visionOS 1.0, *)
extension Curve25519.Signing {
    @usableFromInline
    @available(macOS 10.15, iOS 13, watchOS 6, tvOS 13, macCatalyst 13, visionOS 1.0, *)
    struct OpenSSLCurve25519PrivateKeyImpl: Sendable {
        var _privateKey: SecureBytes
        @usableFromInline var _publicKey: [UInt8]

        @usableFromInline
        init() {
            // BoringSSL's Ed25519 implementation stores the private key concatenated with the public key, so we do
            // as well. We also store the public key because it makes our lives easier.
            var publicKey = Array(repeating: UInt8(0), count: 32)
            let privateKey = SecureBytes(unsafeUninitializedCapacity: 64) {
                privateKeyPtr,
                privateKeyBytes in
                privateKeyBytes = 64
                publicKey.withUnsafeMutableBytes { publicKeyPtr in
                    CCryptoBoringSSL_ED25519_keypair(
                        publicKeyPtr.baseAddress,
                        privateKeyPtr.baseAddress
                    )
                }
            }

            self._privateKey = privateKey
            self._publicKey = publicKey
        }

        @usableFromInline
        var publicKey: Curve25519.Signing.OpenSSLCurve25519PublicKeyImpl {
            OpenSSLCurve25519PublicKeyImpl(self._publicKey)
        }

        var key: SecureBytes {
            self._privateKey
        }

        init<D: ContiguousBytes>(rawRepresentation data: D) throws {
            // What this calls "rawRepresentation" BoringSSL calls the "seed". Otherwise, this is
            // the same as the above initializer.
            var publicKey = Array(repeating: UInt8(0), count: 32)
            let privateKey: SecureBytes = try data.withUnsafeBytes { seedPtr in
                guard seedPtr.count == 32 else {
                    throw CryptoKitError.incorrectKeySize
                }

                let privateKey = SecureBytes(unsafeUninitializedCapacity: 64) {
                    privateKeyPtr,
                    privateKeyBytes in
                    privateKeyBytes = 64
                    publicKey.withUnsafeMutableBytes { publicKeyPtr in
                        CCryptoBoringSSL_ED25519_keypair_from_seed(
                            publicKeyPtr.baseAddress,
                            privateKeyPtr.baseAddress,
                            seedPtr.baseAddress
                        )
                    }
                }

                return privateKey
            }

            self._privateKey = privateKey
            self._publicKey = publicKey
        }

        @usableFromInline
        var rawRepresentation: Data {
            // The "rawRepresentation" is what BoringSSL calls the "seed", and it's the first 32 bytes of our key.
            Data(self._privateKey.prefix(32))
        }
    }

    @usableFromInline
    @available(macOS 10.15, iOS 13, watchOS 6, tvOS 13, macCatalyst 13, visionOS 1.0, *)
    struct OpenSSLCurve25519PublicKeyImpl: Sendable {
        @usableFromInline
        var keyBytes: [UInt8]

        @inlinable
        init<D: ContiguousBytes>(rawRepresentation: D) throws {
            self.keyBytes = try rawRepresentation.withUnsafeBytes { keyBytesPtr in
                guard keyBytesPtr.count == 32 else {
                    throw CryptoKitError.incorrectKeySize
                }
                return Array(keyBytesPtr)
            }
        }

        init(_ keyBytes: [UInt8]) {
            precondition(keyBytes.count == 32)
            self.keyBytes = keyBytes
        }

        var rawRepresentation: Data {
            Data(self.keyBytes)
        }
    }
}
#endif  // canImport(CryptoKit)
